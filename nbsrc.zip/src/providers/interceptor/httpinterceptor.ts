import {ToastController} from 'ionic-angular';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
 
import { Observable } from 'rxjs';
import { _throw } from 'rxjs/observable/throw';
import { catchError } from 'rxjs/operators';

export const InterceptorSkipHeader = 'X-Skip-Interceptor';
export const NoContentType = 'NoContentType';
export const Authorization = 'Authorization';
@Injectable()
export class HttpInterceptorProvider implements HttpInterceptor {
 
    constructor(private storage: Storage, public toastController: ToastController) { }
 
    // Intercepts all HTTP requests!
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
 
        let promise = this.storage.get('userToken');
        
 
        return Observable.fromPromise(promise)
            .mergeMap(token => {
               let clonedReq = this.addToken(request, token);
                return next.handle(clonedReq).pipe(
                    catchError(error => {
                        // Perhaps display an error for specific status codes here already?
                       // this.presentToast(error.error.message==undefined?"Please try again after sometime":error.error.message);
                        return _throw(error);
                    })
                );
            });
    }
 
    presentToast(params) {
        let toast = this.toastController.create({
          message: params,
          duration: 3000
        });
        toast.present();
      }
    // Adds the token to your headers if it exists
    private addToken(request: HttpRequest<any>, token: any) {
        var temToken;
        if(request.headers.has("Authorization") && request.headers.get("Authorization")!="null"){
            temToken=request.headers.get("Authorization");
        }else{
            temToken=token;
        }
       if (token && !request.headers.has(InterceptorSkipHeader)  && !request.headers.has(NoContentType)) {
            let clone: HttpRequest<any>;
            clone = request.clone({
                setHeaders: {
                    Accept: `application/json`,
                    'Content-Type': `application/json`,
                    Authorization: `Bearer ${temToken}`
                }
            });
            return clone;
        }else if(token && request.headers.has(NoContentType)){
            let clone1: HttpRequest<any>;
            clone1 = request.clone({
                setHeaders: {
                    'Content-Type': `application/json`,
                    Authorization: `Bearer ${temToken}`
                }
            });
            return clone1;
        }
            let clone2: HttpRequest<any>;
            clone2 = request.clone({
                setHeaders: {
                    Accept: `application/json`,
                   'Content-Type': `application/json`
                }
            });
        
 
        return clone2;
    }
}