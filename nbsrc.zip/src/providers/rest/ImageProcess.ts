import { Component } from "@angular/core";
import { NavController, ToastController } from "ionic-angular";
import { Camera } from "@ionic-native/camera";
import { Injectable } from "@angular/core";

@Injectable()
export class ImageProcess {
  base64Image: any;
  picture: any;
  kbytes: any;

  constructor(private camera: Camera,public toastController:ToastController) {}
  AccessCamera(): Promise<any>{
    return new Promise((resolve) => {
       this.camera
         .getPicture({
           targetWidth: 512,

           targetHeight: 512,

           correctOrientation: true,

           sourceType: this.camera.PictureSourceType.CAMERA,

           destinationType: this.camera.DestinationType.DATA_URL,
           encodingType: this.camera.EncodingType.JPEG,
           mediaType: this.camera.MediaType.PICTURE,
         })
         .then(
           (imageData) => {
             this.base64Image = imageData;
//this.presentToast(imageData);
             this.picture = imageData;
             if (this.calculateImageSize(imageData) > 100) {
             // this.presentToast(imageData);
               alert("Reduce the size of image");
               resolve(null);
             } else {
                resolve(imageData);
             }
           },
           (err) => {
              resolve(null);
             
           }
         );
    });
   
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }
  AccessGallery(): Promise<any>{
     return new Promise((resolve) => {
      this.camera
        .getPicture({
          sourceType: this.camera.PictureSourceType.SAVEDPHOTOALBUM,

          destinationType: this.camera.DestinationType.DATA_URL,
        })
        .then(
          (imageData) => {
            this.base64Image = imageData;
            //this.presentToast(imageData);
            this.picture = imageData;
            if (this.calculateImageSize(imageData) > 100) {
              //this.presentToast(imageData);
              alert("Reduce the size of image");
              resolve(null);
            } else {
              resolve(imageData);
            }
          },
          (err) => {
            resolve(null);
           
          }
        );
     });
    
  }
  calculateImageSize(base64String) {
    let padding, inBytes, base64StringLength;
    if (base64String.endsWith("==")) padding = 2;
    else if (base64String.endsWith("=")) padding = 1;
    else padding = 0;

    base64StringLength = base64String.length;
    
    inBytes = (base64StringLength / 4) * 3 - padding;
    
    this.kbytes = inBytes / 1000;
    //this.presentToast(this.kbytes);
    return this.kbytes;
   
  }
}
