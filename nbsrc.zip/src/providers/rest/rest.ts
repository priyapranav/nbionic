import { HttpClient, HttpHeaders } from '@angular/common/http';
//import { HttpClientModule } from '@angular/common/http';
import { HTTP } from '@ionic-native/http';
//import { HttpModule } from '@angular/common/http';
//import { Http , Headers, RequestOptions} from '@angular/common/http';

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { ToastController, Platform,  App } from 'ionic-angular';

//import {RequestOptions} from '@angular/common/http';
//import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
//import { Storage } from '@ionic/storage';
export const InterceptorSkipHeader = 'X-Skip-Interceptor';
export const NoContentType = 'NoContentType';
export const Authorization = 'Authorization';
//export const ContentType = 'appplication/json';

@Injectable()
export class RestProvider {
  // apiUrl = "https://www.neighbourbase.com/nbasedemo/rest/";
  // imgUrl = "https://www.neighbourbase.com/nbasedemo/images/";
  //apiUrl="http://192.168.4.43:8081/neighbourbase/rest/";
  //imgUrl="http://192.168.4.43:8081/neighbourbase/images/";
   apiUrl = "https://www.neighbourbase.com/rest/";
   imgUrl = "https://www.neighbourbase.com/images/"; //-->production

  // apiUrl = "http://143.244.133.219:8080/rest/";
  // imgUrl = "http://143.244.133.219:8080/images/";

  nav: any;

  constructor(
    public http: HttpClient,
    private app: App,
    private platform: Platform,
    public toastController: ToastController // private transfer: FileTransfer
  ) {}

  loginRest(email, pass) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "loginValidate.json?email=" +
            email +
            "&password=" +
            pass,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  loginMobileRest(mobile) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "loginValidationByPhoneNumber.json?phoneNumber=" +
            mobile,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  confirmMobileRest(data) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "confirmOtpByPhoneNumber.json?phoneNumber=" +
            data.mobileNumber +
            "&otp=" +
            data.otp,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  registerRest({ data }: { data; }) {
    return new Promise((resolve, reject) => {
      this.http
        // .post(this.apiUrl + "createmember.json", data, { responseType: "text" })
        .post(this.apiUrl + "registerNewMember.json", data, {
          responseType: "text",
        })
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  addCategoryList(data) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "createnetworkcontactlistcategory.json", data, {
          responseType: "text",
        })
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  addfeedbackList(data) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "createfeedback.json", data, {
          responseType: "text",
        })
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  getAllreq(prodid, memberid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getallrequestmade.json?productid=" +
            prodid +
            "&memberId=" +
            memberid,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  sendreq(data, id) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "createrequest.json?memberId=" + id, data)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  emailCheck(email) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "emailavailablecheck.json?email=" + email, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  getsearchresponse(prodtransname, networkid, memberid, radius, lat, lng) {
    //
    return new Promise((resolve, reject) => {
      this.http
        .get(
          //+"&memberId="+memberid+"&radius="+radius+"&latitude="+lat+"&longitude="+lng
          this.apiUrl +
            "getproductbynameandtranstype.json?prodNameTransName=" +
            prodtransname +
            "&networkId=" +
            networkid +
            "&memberId=" +
            memberid +
            "&radius=" +
            radius +
            "&latitude=" +
            lat +
            "&longitude=" +
            lng,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  editlist(prodid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl + "getproductlistingbyproductid.json?productid=" + prodid,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  updatelist(data) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + "updateproductlisting.json", data).subscribe(
        (res) => {
          resolve(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }
  getMylistingforborrowScroll(transid, catid, pno, networkid, memberid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getownerproductlistng.json?transtypeid=" +
            transid +
            "&categoryid=" +
            catid +
            "&pageNumber=" +
            pno +
            "&networkid=" +
            networkid +
            "&memberId=" +
            memberid,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  groupProductListScroll(transTypeId, categoryId, groupId, memberId, pageNo) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getnetworkproductlisting.json?transtypeid=" +
            transTypeId +
            "&categoryid=" +
            categoryId +
            "&pageNumber=" +
            pageNo +
            "&networkid=" +
            groupId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  loadMoreProduct(
    categoryId,
    pincode,
    radius,
    latitude,
    longitude,
    memberId,
    transType,
    pageNumber
  ) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getallproductlistng.json?transtypeid=" +
            transType +
            "&pageNumber=" +
            pageNumber +
            "&pincode=" +
            pincode +
            "&lat=" +
            latitude +
            "&lng=" +
            longitude +
            "&memberId=" +
            memberId +
            "&categoryid=" +
            categoryId +
            "&radius=" +
            radius,
          {}
        )
        // this.apiUrl +  "getallproductlistng.json?transtypeid=4&categoryid=0&pageNumber=0&radius=1500&pincode="+pincode+"&lat="+latitude+"&lng="+longitude+"&memberId="+memberId, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  inviteFriends() {
    /*return new Promise((resolve, reject) => {
      this.http 
        .post(this.apiUrl + "emailavailablecheck.json?email=" + email,{})
        .subscribe(
          (res) =>{
            resolve(res);
          },
          (err) =>{
            reject(err);
          }
        );
    }); */
  }

  getGroupdet(id) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "getnetwork.json?memberId=" + id, {
          responseType: "text",
        })
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  publicInvite(id, emailid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            // "referfriends.json?memberId=" +
            "referfriendsbynum.json?memberId=" +
            id +
            // "&emailIds=" +
            // emailid,
            "&contactNumbers=" +
            emailid,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getblocklistMember(id) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "getblocklistbymemberid.json?memberId=" + id, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  getunblocklistMember(reqid, mid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "unblockrequest.json?requestid=" +
            reqid +
            "&memberId=" +
            mid,
          {},
          { responseType: "text" }
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  getissuerRemindlist(id) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl + "getissuernotedateremainder.json?memberId=" + id,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getMylistingforborrow(transid, catid, pno, networkid, memberid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getownerproductlistng.json?transtypeid=" +
            transid +
            "&categoryid=" +
            catid +
            "&pageNumber=" +
            pno +
            "&networkid=" +
            networkid +
            "&memberId=" +
            memberid,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  getreceiverRemindlist(id) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl + "getreceivernotedateremainder.json?memberId=" + id,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  deletProd(id) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "deleteproductlist.json?productid=" + id, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  resumeProd(id) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "resumeproduct.json?productid=" + id, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  pauseProd(id) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "pauseproduct.json?productid=" + id, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  getsubCategory(rootid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl + "getavailablecategories.json?parentid=" + rootid,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  groupInvite(data) {
    return new Promise((resolve, reject) => {
    //  this.http.post(this.apiUrl + "createinvitationNew.json", data).subscribe(
       this.http
         .post(this.apiUrl + "createinvitationNewByNum.json", data)
         .subscribe(
           (res) => {
             resolve(res);
           },
           (err) => {
             reject(err);
           }
         );
    });
  }
  groupProductList(transTypeId, categoryId, groupId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getnetworkproductlisting.json?transtypeid=" +
            transTypeId +
            "&categoryid=" +
            categoryId +
            "&pageNumber=0&networkid=" +
            groupId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  removeMember(memberId, networkId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "deletenetworkmember.json?memberid=" +
            memberId +
            "&networkid=" +
            networkId,
          {},
          { responseType: "text" }
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  exitMember(memberId, networkId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "leavenetwork.json?memberid=" +
            memberId +
            "&networkid=" +
            networkId,
          {},
          { responseType: "text" }
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  assignMember(memberId, networkId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "assignmoderator.json?memberid=" +
            memberId +
            "&networkid=" +
            networkId,
          {},
          { responseType: "text" }
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  groupDetailEdit(groupIdStr) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl + "getnetworkbynetworkid.json?networkid=" + groupIdStr,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  editNetwork(reqData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + "editnetwork.json", reqData).subscribe(
        (res) => {
          resolve(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  issuerRemainderResponse(memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getreceivernotedateremainder.json?memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  messagercv(memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getreqreceivedbynetwork.json?memberId=" +
            memberId +
            "&pageNumber=" +
            0 +
            "&networkId=0",
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  messagesnt(memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getreqmadebynetwork.json?memberId=" +
            memberId +
            "&pageNumber=" +
            0 +
            "&networkId=0",
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  borrowproduct(categoryId, pincode, radius, latitude, longitude, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getallproductlistng.json?transtypeid=1&pageNumber=0&pincode=" +
            pincode +
            "&lat=" +
            latitude +
            "&lng=" +
            longitude +
            "&memberId=" +
            memberId +
            "&categoryid=" +
            categoryId +
            "&radius=" +
            radius,
          {}
        )
        // this.apiUrl + "getallproductlistng.json?transtypeid=1&categoryid=0&pageNumber=0&radius=1500&pincode=" + pincode + "&lat=" + latitude + "&lng=" + longitude + "&memberId=" + memberId, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  updateProductlist(
    categoryId,
    pincode,
    radius,
    latitude,
    longitude,
    memberId
  ) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getallproductlistng.json?transtypeid=1&pageNumber=0&pincode=" +
            pincode +
            "&lat=" +
            latitude +
            "&lng=" +
            longitude +
            "&memberId=" +
            memberId +
            "&categoryid=" +
            categoryId +
            "&radius=" +
            radius,
          {}
        )
        // this.apiUrl + "getallproductlistng.json?transtypeid=1&categoryid=0&pageNumber=0&radius=1500&pincode=" + pincode + "&lat=" + latitude + "&lng=" + longitude + "&memberId=" + memberId, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  rentproduct(categoryId, pincode, radius, latitude, longitude, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getallproductlistng.json?transtypeid=2&pageNumber=0&pincode=" +
            pincode +
            "&lat=" +
            latitude +
            "&lng=" +
            longitude +
            "&memberId=" +
            memberId +
            "&categoryid=" +
            categoryId +
            "&radius=" +
            radius,
          {}
        )
        //this.apiUrl +  "getallproductlistng.json?transtypeid=2&categoryid=0&pageNumber=0&radius=1500&pincode="+pincode+"&lat="+latitude+"&lng="+longitude+"&memberId="+memberId, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  buyproduct(categoryId, pincode, radius, latitude, longitude, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getallproductlistng.json?transtypeid=3&pageNumber=0&pincode=" +
            pincode +
            "&lat=" +
            latitude +
            "&lng=" +
            longitude +
            "&memberId=" +
            memberId +
            "&categoryid=" +
            categoryId +
            "&radius=" +
            radius,
          {}
        )
        //this.apiUrl +  "getallproductlistng.json?transtypeid=3&categoryid=0&pageNumber=0&radius=1500&pincode="+pincode+"&lat="+latitude+"&lng="+longitude+"&memberId="+memberId, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  giveawayproduct(categoryId, pincode, radius, latitude, longitude, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getallproductlistng.json?transtypeid=4&pageNumber=0&pincode=" +
            pincode +
            "&lat=" +
            latitude +
            "&lng=" +
            longitude +
            "&memberId=" +
            memberId +
            "&categoryid=" +
            categoryId +
            "&radius=" +
            radius,
          {}
        )
        // this.apiUrl +  "getallproductlistng.json?transtypeid=4&categoryid=0&pageNumber=0&radius=1500&pincode="+pincode+"&lat="+latitude+"&lng="+longitude+"&memberId="+memberId, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getCheckRequestSendOrNot(productId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getallrequestmade.json?productid=" +
            productId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getViewList(productId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getproductlistingbyproductid.json?productid=" +
            productId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getOwnerRating(memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "productownerreviews.json?memberId=" + memberId, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  createAbusereport(data) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "createreportabuse.json", data, {
          responseType: "text",
        })
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  updatelocation(data) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + "updatelocation.json", data).subscribe(
        (res) => {
          resolve(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  getProductRating(productId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "getproductreviews.json?productId=" + productId, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getGroupDetails(memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl + "getallmembernetworks.json?memberId=" + memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  addContactList(data) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "createnetworkcontactlist.json", data, {
          responseType: "text",
        })
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  updateContactList(data) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "updatenetworkcontactlist.json", data, {
          responseType: "text",
        })
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  /*getMemberDetails(memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +"getmemberdetails.json?&memberId="+memberId,{})
           .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }*/
  getMemberDetails(groupId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getnetworkdetails.json?networkid=" +
            groupId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  allgroupinvite(emailId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "getAllGroupInvites.json?emailId=" + emailId, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getNetworkDetails(groupId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getnetworkdetails.json?networkid=" +
            groupId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getCategoryList(grpid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl + "getallnetworkcategorylist.json?networkid=" + grpid,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  getcontactlistbycat(catid, grpid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getcontactlistbycategory.json?categoryid=" +
            catid +
            "&networkid=" +
            grpid,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  getuserInfo(listid, memid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getdetailsaboutcontactbylistid.json?listid=" +
            listid +
            "&memberId=" +
            memid,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  removeContact(listid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl + "removecontactlist.json?listid=" + listid,
          {},
          { responseType: "text" }
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  groupborrow(transTypeId, categoryId, groupId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getnetworkproductlisting.json?transtypeid=1" +
            transTypeId +
            "&categoryid=" +
            categoryId +
            "&pageNumber=0&networkid=" +
            groupId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  grouprent(transTypeId, categoryId, groupId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getnetworkproductlisting.json?transtypeid=2" +
            transTypeId +
            "&categoryid=" +
            categoryId +
            "&pageNumber=0&networkid=" +
            groupId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  groupbuy(transTypeId, categoryId, groupId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getnetworkproductlisting.json?transtypeid=3" +
            transTypeId +
            "&categoryid=" +
            categoryId +
            "&pageNumber=0&networkid=" +
            groupId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  groupgift(transTypeId, categoryId, groupId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getnetworkproductlisting.json?transtypeid=4" +
            transTypeId +
            "&categoryid=" +
            categoryId +
            "&pageNumber=0&networkid=" +
            groupId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getAvailableCategory(rootId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl + "getavailablecategories.json?parentid=" + rootId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getrootCategory(mid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "getrootcategories.json?memberId=" + mid, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  loadRootCategory(memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "getrootcategories.json?memberId=" + memberId, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  chatunBlock(reqid, mid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "unblockrequest.json?requestid=" +
            reqid +
            "&memberId=" +
            mid,
          {},
          { responseType: "text" }
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  getIssuerNote(reqid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "getissuernote.json?requestid=" + reqid, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  getReceiverNote(reqid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "getreceivernote.json?requestid=" + reqid, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  OwnerMsgfromReceived(msg, requestId, ownerflg, requestStatusId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "updateownermessage.json?ownermsg=" +
            msg +
            "&requestid=" +
            requestId +
            "&ownerflg=" +
            ownerflg +
            "&requestStatusId=" +
            requestStatusId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  OwnerMsgfromSent(msg, requestId, ownerflg, requestStatusId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "updateownermessage.json?ownermsg=" +
            msg +
            "&requestid=" +
            requestId +
            "&ownerflg=" +
            ownerflg +
            "&requestStatusId=" +
            requestStatusId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getNetworkName(memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "getnetwork.json?memberId=" + memberId, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  addtoProductlist(data) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + "createproductlisting.json", data).subscribe(
        (res) => {
          resolve(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  getToolsList(
    transTypeId,
    categoryId,
    radius,
    pincode,
    latitude,
    longitude,
    memberId
  ) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getallproductlistng.json?transtypeid=" +
            transTypeId +
            "&categoryid=" +
            categoryId +
            "&pageNumber=0&radius=" +
            radius +
            "&pincode=" +
            pincode +
            "&lat=" +
            latitude +
            "&lng=" +
            longitude +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  changeprofile(data) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + "updatemember.json", data).subscribe(
        (res) => {
          resolve(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }
  updateProfilePic(data) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "memberprofilepictureupload.json", data)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  retrievePwdRest(user) {
    return new Promise((resolve, reject) => {
      this.http
        .get(this.apiUrl + "/rest/loginservice/forgetpassword?userName=" + user)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  changePwdRest(data) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + "updatemember.json", data).subscribe(
        (res) => {
          resolve(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  sendPassword(email) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "forgotpassword.json?email=" + email, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getProductName(proNameStr, groupId, memberId, radius, latitude, longitude) {
    return new Promise((resolve, reject) => {
      this.http
        .get(
          this.apiUrl +
            "productnamesearch.json?productName=" +
            proNameStr +
            "&networkId=" +
            groupId +
            "&memberId=" +
            memberId +
            "&radius=" +
            radius +
            "&latitude=" +
            latitude +
            "&longitude=" +
            longitude,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  getNotificationMsg(id) {
    return new Promise((resolve, reject) => {
      this.http
        .get(this.apiUrl + "productnamesearch.json?productName=" + id, {})
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  feedbackReq(data) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + "saveContactDetails.json", data).subscribe(
        (res) => {
          resolve(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }
  changeEmail(data) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + "updateemail.json", data).subscribe(
        (res) => {
          resolve(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }
  verifyEmail(id) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl + "sendemailverificationmail.json?memberId=" + id,
          {},
          { responseType: "text" }
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  createGroup(data) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + "createnetwork.json", data).subscribe(
        (res) => {
          resolve(res);
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  acceptInvite(networkId, inviteMemId, emailId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "acceptGroupInvite.json?networkId=" +
            networkId +
            "&invitedMemId=" +
            inviteMemId +
            "&emailId=" +
            emailId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  declineInvite(networkId, inviteMemId, emailid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "declineInvite.json?networkId=" +
            networkId +
            "&invitedMemId=" +
            inviteMemId +
            "&emailId=" +
            emailid,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  createReminder(data) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "createreceivernote.json", data, {
          responseType: "text",
        })
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  updateReminder(data) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "updateissuernote.json", data, {
          responseType: "text",
        })
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  chatReceive(requestId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getnotificationthreadbyrequestid.json?requestId=" +
            requestId +
            "&isOwner=0",
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  chatSent(requestId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "getnotificationthreadbyrequestid.json?requestId=" +
            requestId +
            "&isOwner=1",
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  sendOwnerMsg(msgString, requestId, requestStatusId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "updateownermessage.json?ownermsg=" +
            msgString +
            "&requestid=" +
            requestId +
            "&ownerflg=1&requestStatusId=" +
            requestStatusId +
            "&memberId=" +
            memberId,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  blockMember(requestId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "blockrequestbymemberid.json?requestid=" +
            requestId +
            "&memberId=" +
            memberId,
          {},
          { responseType: "text" }
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  unabletoServiceReq(requestId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "closerequest.json?requestid=" +
            requestId +
            "&memberId=" +
            memberId +
            "&isOwner=0",
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  deleteReq(requestId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "deleterequest.json?requestid=" +
            requestId ,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  cancelServiceReq(requestId, memberId) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "closerequest.json?requestid=" +
            requestId +
            "&memberId=" +
            memberId +
            "&isOwner=1",
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  shareReq(reqid, reqstatusid, mid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(
          this.apiUrl +
            "updaterequeststatus.json?requestid=" +
            reqid +
            "&requeststatusid=" +
            reqstatusid +
            "&memberId=" +
            mid,
          {}
        )
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  sendReceiverfeedback(data) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "createreceiverfeedback.json", data)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
  sendissuerfeedback(data, mid) {
    return new Promise((resolve, reject) => {
      this.http
        .post(this.apiUrl + "createissuerfeedback.json?&memberId=" + mid, data)
        .subscribe(
          (res) => {
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
}

