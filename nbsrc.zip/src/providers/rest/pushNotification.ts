import { Injectable, ViewChild } from "@angular/core";
import 'rxjs/add/operator/filter';
import {AlertController,Platform, ToastController } from 'ionic-angular';
//import { Push, PushObject, PushOptions } from '@ionic-native/push';
import { RestProvider } from '../../providers/rest/rest';
//import { FCM } from '@ionic-native/fcm';

import { NavController } from "ionic-angular";
import { App } from "ionic-angular";

@Injectable()
export class PushNotification {
  @ViewChild("myNav") navCtrl: NavController;
  public watch: any;
  public lat: number = 0;
  public lng: number = 0;
  rootPage: string;

  constructor(
  
    //private fcm: FCM,
    public restProvider: RestProvider,
    //public push: Push,
    public toastController: ToastController,
    public platform: Platform,
    private alertCtrl: AlertController
  ) {}
    /*initPushNotification() {
     
    this.fcm.getToken().then(token => {
    this.presentToast("token"+token);
     this.restProvider.iUpdateRegistrationToken(token).then(data => {
       // this.presentToast("server call"+data);
      });
      
    });


    this.fcm.onTokenRefresh().subscribe(token => {
       /*this.presentToast(" change in token"+token);
      this.restProvider.iUpdateRegistrationToken(token).then(data => {
       // this.presentToast(" change in token"+data);
      });
    });
  }
  /*initPushNotificationNonFCM() {
    //this.presentToast("Push notification Part");
    if (!this.platform.is("cordova")) {
      console.warn(
        "Push notifications not initialized. Cordova is not available - Run in physical device"
      );
      return;
    }
    const options: PushOptions = {
      android: {
        senderID: "1069825298675",
        sound: "true",
       
      },
      ios: {
        alert: "true",
        badge: false,
        sound: "true",
        
      },
      windows: {},
      browser: {
        pushServiceURL: "http://push.api.phonegap.com/v1/push"
      }
    };
    this.push
      .createChannel({
        id: "pickdrop",
        description: "pick drop channel",
        // The importance property goes from 1 = Lowest, 2 = Low, 3 = Normal, 4 = High and 5 = Highest.
        importance: 3,
        sound: "assets/sounds/Warning1.mp3",
        //sound: "assets/sounds/ringtone.mp3",
        vibration: true

      })
      
    const pushObject: PushObject = this.push.init(options);

    pushObject.on("registration").subscribe((data: any) => {
      //this.presentToast("registration"+data);
      //TODO - send device token to server
      this.restProvider
        .iUpdateRegistrationToken(data.registrationId)
        .then(data => {});
    });

    pushObject.on("notification").subscribe((data: any) => {
      //this.presentToast("notification"+data);
      //if user using app and push notification comes
      if (data.additionalData.foreground) {
        // if application open, show popup
        let confirmAlert = this.alertCtrl.create({
          title: "New Notification",
          message: data.message,
          buttons: [
            {
              text: "Ignore",
              role: "cancel"
            },
            {
              text: "View track",
              handler: () => {
               
              }
            }
          ]
        });
        confirmAlert.present();
      } else {
        //if user NOT using app and push notification comes
        //TODO: Your logic on click of push notification directly
        if (data.title != "ASSIGNED") {
         
        }
      }
    });

    pushObject
      .on("error")
      .subscribe(error => console.error("Error with Push plugin" + error));
  }*/
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 3000,
    });
    toast.present();
  }
}