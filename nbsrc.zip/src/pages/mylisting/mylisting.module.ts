import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MylistingPage } from './mylisting';

@NgModule({
  declarations: [
    MylistingPage,
  ],
  imports: [
    IonicPageModule.forChild(MylistingPage),
  ],
})
export class MylistingPageModule {}
