import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, ModalController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from "@ionic/storage";
import { EditmylistingPage } from '../editmylisting/editmylisting';
import { AddproductPage } from '../addproduct/addproduct';
/**
 * Generated class for the MylistingPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-mylisting',
  templateUrl: 'mylisting.html',
})
export class MylistingPage {
  listType:any="borrow";
  loading1: any;
  getDetails: any;
  borrowproductlistings: any;
  rentproductlistings: any;
  buyproductlistings: any;
  giveawayproductlistings: any;
  imgUrl: any;
  showborrowFlg: boolean;
  showrentFlg: boolean;
  showbuyFlg: boolean;
  showgiveFlg: boolean;
  showPauseflg:boolean=true;
  showResumeflg:boolean=false;
  loading: any;
  transId: any = 1;
  catId:any=0;
  pageno: any = 0;
  isScroll: boolean = true;
  networkId: any;
  prodList: any;
  showborrowPauseFlg: any[]=[];
  showborrowResumeFlg:any[]=[];
  showrentPauseflg: any[]=[];
  showrentResumeflg: any[]=[];
  showbuyPauseflg:any[]=[];
  showbuyResumeflg:any[]=[];
  showgivePauseflg: any[]=[];
  showgiveResumeflg: any[] = [];
  groupName: any;
  constructor(public navCtrl: NavController,   public modalCtrl: ModalController,public storage:Storage, public loadingCtrl: LoadingController,  public toastController: ToastController,public restProvider: RestProvider,public navParams: NavParams) {
    this.imgUrl=this.restProvider.imgUrl;  
    this.catId=this.navParams.get("id");
    // this.networkId = this.navParams.get("nid");
    // this.groupName = this.navParams.get("grpName");
    this.storage.get("myListGrpDetail").then((val) => {
      if (val != null && val != undefined) {
        this.networkId = val.nid;
        this.groupName = val.grpName;

    // if (this.networkId != undefined) {
    //   this.networkId = this.navParams.get("nid");
    // } else {
    //   this.networkId = 0;
    // }
    console.log("catid", this.catId, this.networkId);
    if (this.catId == undefined) {
      this.catId = 0;
    }
        
      } 
    });
    
  
    this.storage.set("lastPage", 2);

  

  }
  async ngOnInit() {
  this.getDetails= await this.storage.get("memberDetails");
  console.log(this.getDetails.memberId);
  
    this.getProdlist();
  
  //this.getProdlist();
  
  }
  onSegmentChanged(event){
console.log("seg changed to -->",event.value)

 /*if(event.value =="borrow"){
  this.getProdlist();
}
else if(event.value =="rent"){
  this.rent();
}
else if(event.value =="buy"){
  this.buy();
}
else if(event.value =="giveaway"){
  this. giveaway();
}*/
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
      //  dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  onSegmentSelected(event){
    console.log("seg selected to -->",event.value)
    if(event.value =="borrow"){
      this.transId = 1;
      this.getProdlist();
    }
    else if(event.value =="rent"){
      this.transId = 2;
      this.rent();
    }
    else if(event.value =="buy"){
      this.transId = 3;
      this.buy();
    }
    else if(event.value =="giveaway"){
      this.transId = 4;
      this. giveaway();
    }
  }
  doInfinite(infiniteScroll) {
    if (!this.isScroll) {
      return;
    }

    this.pageno++;

    this.imgUrl = this.restProvider.imgUrl;

    var data: any;

    this.restProvider
      .getMylistingforborrowScroll(
        this.transId,
        this.catId,
        this.pageno,
        this.getDetails.networkId,
        this.getDetails.memberId
      )
      .then((data) => {
        var result: any = data;

        console.log("result", data);
        if (result.status == "success") {
          var borrowproductlistingsScroll = result.productListingDto;
          if (borrowproductlistingsScroll.length > 0) {
            this.borrowproductlistings = this.borrowproductlistings.concat(
              borrowproductlistingsScroll
            );
          } else {
            this.isScroll = false;
          }
        }
      })
      .catch((error) => {
        this.presentToast("Please try again later");
      });
    infiniteScroll.complete();
  }

  getProdlist(){
    this.isScroll = true;

    this.loading = this.loadingCtrl.create({
      spinner: "bubbles",
    });
    this.loading.present();
    
    var data:any;
        //this.getDetails.networkId
    this.restProvider
  .getMylistingforborrow(1,this.catId,
    0,this.networkId,this.getDetails.memberId)
  .then( (data) => { 
    var result : any = data;
   
    console.log("result",data);
    if(result.status =="success"){
      this.borrowproductlistings=result.productListingDto;
      for(let bIndx in this.borrowproductlistings){
        this.showborrowPauseFlg.push(false);
        this.showborrowResumeFlg.push(true);
      }
      if(this.borrowproductlistings.length >0){
       // this.showborrowPauseFlg.push(false);
        //this.showborrowResumeFlg.push(true);
        this.showborrowFlg=true;
      }
      else{
        this.showborrowFlg=false;
      }
    }
   
    this.loading.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading1.dismiss();
  
    this.displayAlert("Please try again later");
  });
  }
  rent(){
    this.isScroll = true;
    this.loading1 = this.loadingCtrl.create({
      spinner: "bubbles",
    });
    this.loading1.present();
    
    var data:any;
        
    this.restProvider
  .getMylistingforborrow(2,this.catId,0,this.networkId,this.getDetails.memberId)
  .then( (data) => { 
    var result : any = data;
   
    console.log("result",data);
    if(result.status =="success"){
      this.rentproductlistings=result.productListingDto;
      for(let rIndx in  this.rentproductlistings){
        this.showrentPauseflg.push(false);
        this.showrentResumeflg.push(true);
      }
      if(this.rentproductlistings.length >0){
        this.showrentFlg=true;
      
      }
      else{
        this.showrentFlg=false;
      }
    }
   
    this.loading1.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading1.dismiss();
  
    this.displayAlert("Please try again later");
  });
  }

  buy(){
    this.isScroll = true;

    this.loading1 = this.loadingCtrl.create({
      spinner: "bubbles",
    });
    this.loading1.present();
    
    var data:any;
        
    this.restProvider
  .getMylistingforborrow(3,this.catId,0,this.networkId,this.getDetails.memberId)
  .then( (data) => { 
    var result : any = data;
   
    console.log("result",data);
    if(result.status =="success"){
      this.buyproductlistings=result.productListingDto;
      for(let bIndx in  this.buyproductlistings){
        this.showbuyPauseflg.push(false);
        this.showbuyResumeflg.push(true);
      }
      if(this.buyproductlistings.length >0){
        
        this.showbuyFlg=true;
      }
      else{
        this.showbuyFlg=false;
      }
    }
   
    this.loading1.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading1.dismiss();
  
    this.displayAlert("Please try again later");
  }); 
  }

  giveaway(){
    this.isScroll = true;

    this.loading1 = this.loadingCtrl.create({
      spinner: "bubbles",
    });
    this.loading1.present();
    
    var data:any;
        
    this.restProvider
  .getMylistingforborrow(4,this.catId,0,this.networkId,this.getDetails.memberId)
  .then( (data) => { 
    var result : any = data;
   
    console.log("result",data);
    if(result.status =="success"){
      this.giveawayproductlistings=result.productListingDto;
      for(let gIndx in this.giveawayproductlistings){
        this.showgivePauseflg.push(false);
        this.showgiveResumeflg.push(true);

      }
      if(this.giveawayproductlistings.length >0){
        this.showgiveFlg=true;
       
      }
      else{
        this.showgiveFlg=false;
      }
    }
   
    this.loading1.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading1.dismiss();
  
    this.displayAlert("Please try again later");
  });
  }
  delete(prodId){
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        // titleName: "Delete",
        bodyTxt:
          "Deleting listed items will also remove product reviews and ratings history if any. <br><br> Do you still want to Delete the item from listing?",
        okBtnNm: "Yes",
        cancelBtnNm: "No",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Yes") {
      this.calldeleteoption(prodId);
      
      } else if (data == "No") {
        
      }
    });
   
   
  }
  calldeleteoption(id){
    this.loading1 = this.loadingCtrl.create({
      spinner: "bubbles",
    });
    this.loading1.present();
    
    var data:any;
        
    this.restProvider
  .deletProd(id)
  .then( (data) => { 
    var result: any = data;
    this.loading1.dismiss();
   
    console.log("result",data);
    if(result.status =="success"){
      if(this.listType =="borrow"){
        this.getProdlist();
        this.transId = 1;
      }
      else if(this.listType =="rent"){
        this.rent();
        this.transId = 2;

      }
      else if(this.listType =="buy"){
        this.buy();
        this.transId = 3;
      }
      else if(this.listType =="giveaway"){
        this. giveaway();
        this.transId = 4;
      }
      this.displayAlert("The item has been removed from your listing.");
    }
    else if(result.status == "fail"){
      this.displayAlert("Failed to remove the product from your listing.");
    }
   
    
  })
  .catch(error => {
    console.log("error",error);
    this.loading1.dismiss();
  
    this.displayAlert("Please try again later");
  });
  }
  edit(editlist){
this.navCtrl.push(EditmylistingPage,{data:editlist});
  }
  pause(segment,indx,id){
    console.log("segment",segment,indx,id)
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        // titleName: "Pause",
        bodyTxt:
          "Pause – will remove the product from getting listed until you resume.<br> Do you want to pause the product from listing?",
        okBtnNm: "Yes",
        cancelBtnNm: "No",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Yes") {
        console.log("segment",segment,indx,id)
      this.callpauseOption(segment,indx,id);
      } else if (data == "No") {
        
      }
    });

    
  }

  callpauseOption(segment,indx,id){
    console.log("segment",segment,indx,id)
    this.loading1 = this.loadingCtrl.create({
      spinner: "bubbles",
    });
    this.loading1.present();
    
    var data:any;
        
    this.restProvider
  .pauseProd(id)
  .then( (data) => { 
    var result : any = data;
   
    console.log("result",data);
    if(result.status =="success"){
      this.displayAlert("Product Listing – Paused");
      if(segment == 1){
        this.showborrowPauseFlg[indx]=true;
        this.showborrowResumeFlg[indx]=false;
      }
      else if(segment == 2){
        this.showrentPauseflg[indx]=true;
        this.showrentResumeflg[indx]=false;
      }
      else if(segment == 3){
        this.showbuyPauseflg[indx]=true;
        this.showbuyResumeflg[indx]=false;
      }
      else if(segment == 4){
        this.showgivePauseflg[indx]=true;
        this.showgiveResumeflg[indx]=false;
      }
     // this.showPauseflg=false;
      //this.showResumeflg=true;
    }
   
    this.loading1.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading1.dismiss();
  
    this.displayAlert("Please try again later");
  });
  }
  gotoAddProduct(){
    this.navCtrl.push(AddproductPage);
  }
  play(segment,indx,id){
    console.log("segment",segment,indx,id)
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        // titleName: "Resume",
        bodyTxt:
          "Resume – will allow product to get listed. Do you want to Resume?",
        okBtnNm: "Yes",
        cancelBtnNm: "No",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Yes") {
        console.log("segment",segment,indx,id)
      this.callplayOption(segment,indx,id);
      } else if (data == "No") {
        
      }
    });
   
  }

  callplayOption(segment,indx,id){
    console.log("segment",segment,indx,id)
    this.loading1 = this.loadingCtrl.create({
      spinner: "bubbles",
    });
    this.loading1.present();
    
    var data:any;
        
    this.restProvider
  .resumeProd(id)
  .then( (data) => { 
    var result : any = data;
   
    console.log("result",data);
    if(result.status =="success"){
      this.displayAlert("Product Released – for Listing.");
      if(segment == 1){
        this.showborrowPauseFlg[indx]=false;
        this.showborrowResumeFlg[indx]=true;
      }
      else if(segment == 2){
        this.showrentPauseflg[indx]=false;
        this.showrentResumeflg[indx]=true;
      }
      else if(segment == 3){
        this.showbuyPauseflg[indx]=false;
        this.showbuyResumeflg[indx]=true;
      }
      else if(segment == 4){
        this.showgivePauseflg[indx]=false;
        this.showgiveResumeflg[indx]=true;
      }
      //this.showPauseflg=true;
      //this.showResumeflg=false;
    }
   
    this.loading1.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading1.dismiss();
  
    this.displayAlert("Please try again later");
  });
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad MylistingPage');
  }

}
