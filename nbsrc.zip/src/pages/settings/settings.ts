import { Component } from '@angular/core';
import { IonicApp, IonicPage, LoadingController, ModalController, NavController, NavParams, Platform, ToastController, ViewController } from 'ionic-angular';
import { UnblockmembersPage } from '../unblockmembers/unblockmembers';
import { ReminderPage } from '../reminder/reminder';
import { GroupinvitereqPage } from '../groupinvitereq/groupinvitereq';
import { MylistingPage } from '../mylisting/mylisting';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from '@ionic/storage';
import { InAppBrowser } from "@ionic-native/in-app-browser";
import { HelpPage } from '../help/help';
import { LoginNewPage } from '../login-new/login-new';
/**
 * Generated class for the SettingsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-settings",
  templateUrl: "settings.html",
})
export class SettingsPage {
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public modalCtrl: ModalController,
    private iab: InAppBrowser,
    public storage: Storage,
  ) {}

  ionViewDidLoad() {
    console.log("ionViewDidLoad SettingsPage");
  }
  unblockMember() {
    this.navCtrl.push(UnblockmembersPage);
  }
  help() {
    this.navCtrl.push(HelpPage);
    //this.navCtrl.push(LoginNewPage);

  }

  reminder() {
    this.navCtrl.push(ReminderPage);
  }
  groupinvite() {
    this.navCtrl.push(GroupinvitereqPage);
  }
  showMylist() {
    const modal = this.modalCtrl.create(
      GrouplistModel,
      {},
      { cssClass: "customModal1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data != undefined && data != "" && data != null) {
        var grpDetail:any = { nid: data.nid, grpName: data.name };
        this.storage.set("myListGrpDetail", grpDetail);
        
        this.navCtrl.push(MylistingPage, { nid: data.nid, grpName: data.name });
      }
    });
    //
  }
}


@Component({
  selector: "page-manageprofile",
  template: `
    <ion-header no-border>
      <ion-toolbar>
        <ion-title>
          <img
            src="assets/imgs/logo.png"
            height="30dp"
            style="padding-top: 5px;"
          />
        </ion-title>

        <ion-buttons end>
          <button ion-button icon-only (click)="closePop()">
            <ion-icon name="ios-close" style="color: black;"></ion-icon>
          </button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>
    <ion-content
      overflow-scroll="false"
      center
      text-center
      style="padding-bottom:16px;padding-top:16px"
    >
      <div class="outer">
        <ion-select (ionChange)="getGroupId($event)" placeholder="SelectGroup">
          <ion-option value="0-All">All</ion-option>
          <ion-option value="2-Public">Public</ion-option>
          <ion-option
            value="{{ group.networkId }}-{{ group.name }}"
            *ngFor="let group of groupList; let i = index"
            >{{ group.name }}</ion-option
          >
        </ion-select>
      </div>
    </ion-content>
  `,
})
export class GrouplistModel {
  public feedbackDet: string;
  unsubscribeBackEvent: any;
  groupList: any;
  loading: any;
  constructor(
    public toastCtrl: ToastController,
    public loadingController: LoadingController,
    public platform: Platform,
    private ionicApp: IonicApp,
    public restProvider: RestProvider,
    public storage: Storage,
    public modalCtrl: ModalController,
    public viewCtrl: ViewController
  ) {}

  closePop() {
    this.viewCtrl.dismiss("");
  }
  ionViewDidLoad() {
    this.groupDetails();
  }
  ionViewWillEnter() {
    this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
      let activePortal = this.ionicApp._modalPortal.getActive();
      if (activePortal) {
        activePortal.dismiss();
      } else {
        return true;
      }
    }, 101);
  }
  ionViewWillLeave() {
    this.unsubscribeBackEvent && this.unsubscribeBackEvent();
  }
  groupDetails() {
    this.storage.get("memberId").then((val) => {
      var memberid: any = val;
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
      this.restProvider
        .getGroupDetails(memberid)
        .then((data) => {
          var result: any = data;
          console.log(result);
          this.groupList = result;

          if (result != null) {
            console.log("success");
          }
          this.loading.dismiss();
        })
        .catch((error) => {
          console.log(error);
          this.loading.dismiss();
          this.displayAlert("Please try again later");
        });
    });
  }
  getGroupId(nid) {
    var splitArr = nid.split("-");
    this.viewCtrl.dismiss({ nid: splitArr[0], name:splitArr[1] });
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
}

