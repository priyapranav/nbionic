import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, ModalController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { LoginPage } from '../login/login';
import { Storage } from '@ionic/storage';
/**
 * Generated class for the ResetpasswordPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-resetpassword",
  templateUrl: "resetpassword.html",
})
export class ResetpasswordPage {
  oldPasswrd: any;
  newPasswrd: any;
  confirmPasswrd: any;
  resetpwdForm: FormGroup;
  loading: any;
  userMemberId: any;
  userAddress: any;
  userArea: any;
  userLat: any;
  userlong: any;
  usercreatedTime: any;
  usercontactno: any;
  useraboutMe: any;
  userdeviceToken: any;
  useremail: any;
  userfirstName: any;
  usermailVerifyFlag: any;
  usermemberId: any;
  usermemberProfilePic: any;
  usermemberTypeId: any;
  usernetworkId: any;
  userpicture: any;
  userpincode: any;
  usersearchRadius: any;
  userstatusId: any;
  userinviteFlag: any;
  userisActive: any;
  userisDeleted: any;
  userlastName: any;
  getDetails: any;
  oldPassStr: any;
  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    public restProvider: RestProvider,
    public toastController: ToastController,
    private storage: Storage,
    public loadingController: LoadingController,
    public navParams: NavParams,
    private formBuilder: FormBuilder
  ) {
    this.resetpwdForm = this.formBuilder.group({
      oldPasswrd: ["", [Validators.required]],
      newPasswrd: ["", [Validators.required]],
      confirmPasswrd: ["", [Validators.required]],
    });
  }
  validation_messages = {
    newPasswrd: [{ type: "required", message: "New Password is required" }],
    oldPasswrd: [{ type: "required", message: "Old Password is required" }],
    confirmPasswrd: [
      { type: "required", message: "Confirm Password is required" },
    ],
  };

  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  async ngOnInit() {
    this.getDetails = await this.storage.get("memberDetails");
    console.log(this.getDetails.memberId);
    this.oldPassStr = this.getDetails.password;

    /*await this.storage.get("memberDetails").then((val )=>{
      if(val !=undefined && val !=null && val !=""){
        this.usermemberId=val.memberId;
        this.userAddress=val.address;
       this.userArea= val.area;
       this.userLat=val.latitude;
       this.userlong=val.longitude;
      this.usercreatedTime= val.createdDateTime;
     this.usercontactno= val.contactNumber;
     this.useraboutMe=val.aboutMe;
this.userdeviceToken=val.deviceToken;
this.useremail=val.email;
this.userfirstName=val.firstName;
this.userinviteFlag=val.inviteFlag;
this.userisActive=val.isActive;
this.userisDeleted=val.isDeleted;
this.userlastName=val.lastName;
this.usermailVerifyFlag=val.mailVerifyFlag;

this.usermemberProfilePic=val.memberProfilePic;
this.usermemberTypeId=val.memberTypeId;
this.usernetworkId=val.networkId;
this.userpicture=val.picture;
this.userpincode=val.pincode;
this.usersearchRadius=val.searchRadius;
this.userstatusId=val.statusId;
    
      }
    });*/
  }
  ionViewDidLoad() {
    console.log("ionViewDidLoad ResetpasswordPage");
  }
  changePwd() {
    var view = this;

    if (this.resetpwdForm.valid) {
      if (this.oldPasswrd == this.getDetails.password) {
        if (this.newPasswrd == this.confirmPasswrd) {
          if ((this.newPasswrd && this.confirmPasswrd) != this.oldPasswrd) {
            return new Promise((resolve, reject) => {
              this.loading = this.loadingController.create({
                spinner: "bubbles",
              });
              this.loading.present();
              var data1: any;

              data1 = {
                memberId: this.getDetails.memberId,
                password: this.newPasswrd,
              };
              console.log("data", data1);

              var result;
              this.restProvider
                .changePwdRest(data1)
                .then((data) => {
                  resolve(data);
                  result = data;
                  console.log("data", result);
                  if (result.status == "success") {
                    this.storage.clear();

                    this.storage.set("memberDetails", "");
                    this.displayAlert(
                      "Password changed. Login with new password"
                    );

                    this.navCtrl.setRoot(LoginPage);
                  } else if (result.status == "fail") {
                    this.displayAlert("Problem in changing password!");
                  }
                  this.loading.dismiss();
                })
                .catch((error) => {
                  console.log("err", error);
                  this.loading.dismiss();
                  this.displayAlert("Please try again later");
                });
            });
          } else {
            this.displayAlert(
              "Old Password and New Password should Not be same"
            );
          }
        } else {
          this.displayAlert("Password confirmation - mismatch");
        }
      } else {
        this.displayAlert("Please Enter Valid Password!");
      }
    } else {
      this.displayAlert("Please Enter All Fields!");
    }
  }
  oldPassChk() {
    if (this.oldPasswrd != '' && this.oldPasswrd != undefined && this.oldPasswrd != null) {
      if (this.oldPassStr != this.oldPasswrd) {
        this.displayAlert("wrong old password");
        this.oldPasswrd = "";
      }
    }
      
    
  }

  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }
}
