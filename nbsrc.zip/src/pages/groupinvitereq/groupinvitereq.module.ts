import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GroupinvitereqPage } from './groupinvitereq';

@NgModule({
  declarations: [
    GroupinvitereqPage,
  ],
  imports: [
    IonicPageModule.forChild(GroupinvitereqPage),
  ],
})
export class GroupinvitereqPageModule {}
