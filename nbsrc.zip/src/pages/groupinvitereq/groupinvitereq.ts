import { Component } from '@angular/core';
import { IonicPage, ModalController, NavController, NavParams, ViewController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { ToastController } from 'ionic-angular';
import { LoadingController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
/**
 * Generated class for the GroupinvitereqPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-groupinvitereq',
  templateUrl: 'groupinvitereq.html',
})
export class GroupinvitereqPage {

  noInviteFlg:boolean=false;
  requestList: any;
  networkId: any;
  memberId: any;
  emailId: any;
  listings: any;
  grpListings: any;
  imgUrl: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public restProvider: RestProvider, 
    public toastController : ToastController, public modalCtrl: ModalController, public loadingController: LoadingController, public storage: Storage) {
      this.imgUrl = restProvider.imgUrl;

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad GroupinvitereqPage');
    this.invite();
  }

  invite(){
    this.storage.get("memberDetails").then((val)=>{
    var memberDet=val;
    var email= val.email;

      this.restProvider
    .allgroupinvite(email)
    .then((data)=>{
      var result : any = data;
      this.requestList=result;
      console.log(result);
     
      if(result!=null && result.length!=0)
      {
        this.noInviteFlg=false;
      }
      else
      {
this.noInviteFlg=true;
        
      }  
    })
    .catch(error => {
      this.displayAlert("Please try again later");
  });
 
})
    
}
displayAlert(message) {
  const modal = this.modalCtrl.create(
    "CustomDialogPage",
    {
      dialogFor: "info",
      iconName: "",
      titleName: "",
      bodyTxt: message,
      okBtnNm: "Ok",
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
}
  
presentToast(params) {
  let toast = this.toastController.create({
    message: params,
    duration: 2000
  });
  toast.present();
}


accept(networkId, memberId, emailid,list){
  this.networkId=networkId;
this.memberId=memberId;
this.emailId=emailid;
this.listings=list;
  const modal = this.modalCtrl.create('CustomDialogPage',{

    titleName: "",

    bodyTxt: "Are you sure want to accept this invitation from your friend?",

    okBtnNm: "Yes",

  },

  { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }

);

modal.present();

modal.onDidDismiss((data) => {

  if (data == "Yes") {

 this.acceptConfirm( this.networkId, this.memberId, this.emailId,this.listings);

  } 

});

} 

acceptConfirm(nid,mid,emailId,listings){
this.grpListings=listings;
  this.restProvider
  .acceptInvite(nid, mid, emailId)
  .then((data)=>{
    var result : any = data;
    console.log(result);

    if(result == true){
      const modal = this.modalCtrl.create(
        "CustomDialogPage",
        {
          titleName: "",

          bodyTxt:
            "You are now part of " +
            this.grpListings.networkDto.name +
            " neighbourbase community",

          okBtnNm: "",
        },

        { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
      );
    
    modal.present();
   
    modal.onDidDismiss((data) => {

        this.invite();
 
      });
        

    }
    
    else if(result== false)
    {
      const modal = this.modalCtrl.create('CustomDialogPage',{

        titleName: "Invitation Accept Fail ",
    
        bodyTxt: "you are not included in the" +this.grpListings.networkDto.name,
    
        okBtnNm: "Ok",
    
      },
    
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    
    );
    
    modal.present();
    modal.onDidDismiss((data) => {

    return;
    });
      
    }

    else
    {
      const modal = this.modalCtrl.create('CustomDialogPage',{

        titleName:"",
    
        bodyTxt: "Server Down. Please Try Again",
    
        okBtnNm: "",
    
      },
    
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    
    );
    
    modal.present();
    modal.onDidDismiss((data) => {

    return;
    });
      
    }
     
  })
  .catch(error => {
    console.log(error);
    this.displayAlert("Please try again later");
});


}


decline(networkId, memberId, emailid, list){
  
  this.networkId=networkId;
  this.memberId=memberId;
  this.emailId=emailid;
  this.listings=list;
var msg =
  "Are you sure you don’t want to join " +
  list.networkDto.name +
  " neighbourbase community?";
  const modal = this.modalCtrl.create(
    "CustomDialogPage",
    {
      titleName: "",

      bodyTxt: msg,

      okBtnNm: "Yes",
      cancelBtnNm: "No",
    },

    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );

modal.present();

modal.onDidDismiss((data) => {

  if (data == "Yes") {

 this.declineConfirm( this.networkId, this.memberId, this.emailId,this.listings);

  } 

});
  

} 

declineConfirm( networkId,memberId, emailid,listings){
  
  this.grpListings=listings;

  
  this.restProvider
  .declineInvite(networkId, memberId, emailid)
  .then((data)=>{
    var result : any = data;
    console.log(result);
    if(result == true){
      const modal = this.modalCtrl.create(
        "CustomDialogPage",
        {
          titleName: "",

          bodyTxt:
            "We will remove the invitation from the pending invite list. Sorry for this inconvenience.",

          okBtnNm: "",
        },

        { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
      );
    
    modal.present();
   
    modal.onDidDismiss((data) => {

        this.invite();
 
      });
        

    }
    
    else if(result== false)
    {
      const modal = this.modalCtrl.create('CustomDialogPage',{

        titleName: "Invitation Accept Fail ",
    
        bodyTxt: "you are not included in the" +this.grpListings.networkDto.name,
    
        okBtnNm: "Ok",
    
      },
    
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    
    );
    
    modal.present();
    modal.onDidDismiss((data) => {

    return;
    });
      
    }

     
  })
  .catch(error => {
    console.log(error);
    this.displayAlert("Please try again later");
});

}
}