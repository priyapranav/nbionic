import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, ModalController } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from '@ionic/storage';
/**
 * Generated class for the FeedbackPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-feedback',
  templateUrl: 'feedback.html',
})
export class FeedbackPage {
  feedbackForm: FormGroup;
  msg:any;
  loading: any;
  usermemberId: any;
  constructor(public navCtrl: NavController,public modalCtrl: ModalController,private storage: Storage,public toastController:ToastController,public restProvider: RestProvider,public loadingController:LoadingController, private formBuilder: FormBuilder,public navParams: NavParams) {
    this.feedbackForm = this.formBuilder.group({
      msg: ["", [Validators.required]],
     
    });
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  async ionViewDidLoad() {
    await this.storage.get("memberDetails").then((val )=>{
      if(val !=undefined && val !=null && val !=""){
        this.usermemberId=val.memberId
      }
    });
    console.log('ionViewDidLoad FeedbackPage');
  }
  validation_messages = {
    'msg': [
      { type: 'required', message: 'Feedback is required' },
     
      
    ],
   
  }
  submit(){
    var view =this;
 
    if (this.feedbackForm.valid) {
      if(this.msg.length < 2000){
      return new Promise((resolve, reject) => {
      this.loading = this.loadingController.create({
        spinner: "bubbles"
      });
      this.loading.present();
      var data:any;
    data ={
      // id:0,
       memberId:this.usermemberId,
       subject:"",
       message:this.msg,
      //status:0,
	    //remarks:null,
      //feedbackDate:null,
      //statusName:null,

     }
      var result;
      this.restProvider.feedbackReq(data)
      .then(data => {
        resolve(data);
        result = data;
        if(result !=null){
          if(result.status == "success"){
            this.displayfeedMsg("Thanks for your feedback. We appreciate your effort.");
            //this.navCtrl.pop();
          }
        }
       
        this.loading.dismiss(); 
      }).catch(error => {
        this.loading.dismiss();
        this.displayAlert("Please try again later");
      });
    });
  }
else{
  this.displayAlert("you reached a limit!")
}
    }
  }
  cancel(){
    this.msg=null;
    
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000
    });
    toast.present();
  }
  displayfeedMsg(message){
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if(data == "Ok"){
        this.navCtrl.pop();
      }

    });
  }
}
