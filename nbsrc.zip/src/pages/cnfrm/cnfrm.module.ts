import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CnfrmPage } from './cnfrm';

@NgModule({
  declarations: [
    CnfrmPage,
  ],
  imports: [
    IonicPageModule.forChild(CnfrmPage),
  ],
})
export class CnfrmPageModule {}
