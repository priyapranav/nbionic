import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Storage } from '@ionic/storage';
import { Events, IonicPage, LoadingController, ModalController, NavController, NavParams, ToastController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { HomePage } from '../home/home';
import { RegisterPage } from '../register/register';

/**
 * Generated class for the CnfrmPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-cnfrm",
  templateUrl: "cnfrm.html",
})
export class CnfrmPage {
  cnfrmForm: FormGroup;
  otp: any;
  mobileNumber: any;
  loading: any;
  grpId: any;

  constructor(
    public navCtrl: NavController,
    private formBuilder: FormBuilder,
    public navParams: NavParams,
    public loadingController: LoadingController,
    public toastController: ToastController,
    public restProvider: RestProvider,
    private storage: Storage,
    public event: Events,
    public modalCtrl: ModalController
  ) {
    this.storage.get("grpInvite").then((val) => {
      if (val != null && val != undefined) {
        this.grpId = val.grpId;
      }
    });
    this.mobileNumber = navParams.get("mobileNumber");
    this.cnfrmForm = this.formBuilder.group({
      otp: [
        "",
        [
          Validators.minLength(5),
          Validators.maxLength(5),
          Validators.pattern("^[0-9]+$"),
          Validators.required,
        ],
      ],
    });
  }

  ionViewDidLoad() {
    console.log("ionViewDidLoad CnfrmPage");
  }
  confirm() {
    var view = this;

    if (this.cnfrmForm.valid) {
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
      var data1 = { mobileNumber: this.mobileNumber, otp: this.otp };
      this.restProvider
        .confirmMobileRest(data1)
        .then((data) => {
          var result: any = data;
          var sts = result.status;
          // if (data) {
          //   this.saveToken(data).subscribe((data) => {
          //     this.loading.dismiss();
          //     this.navCtrl.push("UserupdatePage", {
          //       sendReqData: view.sendRequestData,
          //     });
          //   });
          // }

          if (
            result.latitude != "" &&
            result.latitude != null &&
            result.latitude != undefined
          ) {
            if (sts == "SUCCESS") {
              var productDetails = {
                pincode: result.pincode,
                latitude: result.latitude,
                longitude: result.longitude,
                memberId: result.memberId,
                radius: result.searchRadius,
              };

              this.storage.set("memberDetails", result);
              this.storage.set("memberAddress", result.address);
              this.storage.set("memberId", result.memberId);
              this.storage.set("productDet", productDetails);
              this.storage.set("latitude", result.latitude);
              this.storage.set("longitude", result.longitude);
              this.event.publish("user:created", result.memberId);

              this.navCtrl.setRoot(HomePage);
              if (
                this.grpId != undefined &&
                this.grpId != null &&
                this.grpId != ""
              ) {
                this.acceptConfirm(this.grpId, result.memberId, result.email);
              }
            }
          } else {
            this.navCtrl.setRoot(RegisterPage, {
              mobileNumber: this.mobileNumber,
            });
          }
          this.loading.dismiss();
        })
        .catch((error) => {
          this.loading.dismiss();
          this.presentToast("Please try again later");
        });
    }
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }

  acceptConfirm(nid, mid, emailId) {
    this.restProvider
      .acceptInvite(nid, mid, emailId)
      .then((data) => {
        var result: any = data;
        console.log(result);

        if (result == true) {
          const modal = this.modalCtrl.create(
            "CustomDialogPage",
            {
              titleName: "",

              bodyTxt: "You are now part of group. ",

              okBtnNm: "",
            },

            {
              cssClass: "customModal1 customHrdTxt1",
              enableBackdropDismiss: true,
            }
          );

          modal.present();

          modal.onDidDismiss((data) => {
           // this.invite();
          });
        } else if (result == false) {
          const modal = this.modalCtrl.create(
            "CustomDialogPage",
            {
              titleName: "Invitation Accept Fail ",

              bodyTxt: "you are not included in the group",

              okBtnNm: "Ok",
            },

            {
              cssClass: "customModal1 customHrdTxt1",
              enableBackdropDismiss: true,
            }
          );

          modal.present();
          modal.onDidDismiss((data) => {
            return;
          });
        } else {
          const modal = this.modalCtrl.create(
            "CustomDialogPage",
            {
              titleName: "",

              bodyTxt: "Server Down. Please Try Again",

              okBtnNm: "",
            },

            {
              cssClass: "customModal1 customHrdTxt1",
              enableBackdropDismiss: true,
            }
          );

          modal.present();
          modal.onDidDismiss((data) => {
            return;
          });
        }
      })
      .catch((error) => {
        console.log(error);
        this.presentToast("Please try again later");
      });
  }
}
