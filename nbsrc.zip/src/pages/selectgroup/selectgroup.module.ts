import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SelectgroupPage } from './selectgroup';

@NgModule({
  declarations: [
    SelectgroupPage,
  ],
  imports: [
    IonicPageModule.forChild(SelectgroupPage),
  ],
})
export class SelectgroupPageModule {}
