import { Component } from '@angular/core';
import { IonicPage, LoadingController,ToastController, NavController, NavParams, ModalController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from '@ionic/storage';
import { EditgroupPage } from '../editgroup/editgroup';
import { GroupinfoPage } from '../groupinfo/groupinfo';
/**
 * Generated class for the SelectgroupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-selectgroup',
  templateUrl: 'selectgroup.html',
})
export class SelectgroupPage {
  groupList:any;
  groupListing:any;
  newData:any;
  groupId:any;
  imgUrl:any;
  email:any;
  password: any;
  netId: any;
  newList: any;
  newDet: any;
  showgrpFlg: boolean;
  
  constructor(public navCtrl: NavController, public modalCtrl: ModalController, public navParams: NavParams, public loadingController: LoadingController,
    public restProvider: RestProvider, public toastController: ToastController, public storage: Storage) {
      this.imgUrl = restProvider.imgUrl;

  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad SelectgroupPage');
    this.groupDetails();

  }

  
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000
    });
    toast.present();
  }

  
  groupDetails(){
    this.storage.get("memberId").then((val)=>{
      var memberid:any=val;
 
    this.restProvider
    .getGroupDetails(memberid)
    .then((data) => { 
      var result : any = data;
      console.log(result);
   
      
      if(result!=null)
      {
        this.groupList=result;
        if(this.groupList.length >0){
          this.showgrpFlg=true;
        }
        else{
          this.showgrpFlg=false;
        }
        console.log("success");
      }
      
    })
    .catch(error => {
  console.log(error);
    
      this.displayAlert("Please try again later");
  
  });
});
  }

  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  
myGrpinfo(group){

var Data = {
  networkId: group.networkId,
  memberId: group.memberId,
  networkName: group.name,
  networkImg: group.picture,
};
  this.storage.set("networkData", Data).then((val) => {
    this.navCtrl.push(GroupinfoPage);
  });




}

edit(netId){
  this.netId=netId;
  this.navCtrl.push(EditgroupPage, {data:this.netId});
}
  
  }