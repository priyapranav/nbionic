import { Component } from '@angular/core';
import { IonicPage, ToastController, NavController, NavParams, ModalController, ViewController, LoadingController, Platform, IonicApp } from 'ionic-angular';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Storage } from '@ionic/storage';
import { RestProvider } from '../../providers/rest/rest';
import { ImageProcess } from '../../providers/rest/ImageProcess';
import { HomePage } from '../home/home';
import { MylistingPage } from '../mylisting/mylisting';
/**
 * Generated class for the AddproductPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-addproduct',
  templateUrl: 'addproduct.html',
})
export class AddproductPage {
  listType:any="lend" ;
  productName:any;
  productDesc:any;
  productAvailableOn:any="From";
 
  type:any;
  categoryType:any;
  addProductForm: FormGroup;

  dayFlg:boolean=true;
  subcategoryType:any;
  networkList:any;
  toolsFlg:boolean=false;
  networks:any;
  memberId:any;
  homeFlg:boolean=false;
  lifeFlg:boolean=false;
  electronicFlg:boolean=false;
  carsFlg:boolean=false;
  schoolFlg:boolean=false;
  realEstateFlg:boolean=false;
  categoryList:any;
  noImg:boolean=false;
  rootId:any;
  showImg:boolean=false;
  image:any;
  networkType:any;
  subCategoryList:any;
rentFlg:boolean=false;
sellFlg:boolean=false;
netArr:any;
showDayFlg:boolean=true;
default:any;
rentalDay:any;
rentalMonth:any;
rentalWeek:any;
salePrice;
lendSelect:boolean=false;
rentSelect:boolean=false;
saleSelect:boolean=false;
giftSelect:boolean=false;
  net: string;
  value: string;
  categoryId: any;
  productImage: any;
  loading: any;
  transtypeId: any=1;
  getDetails: any;
  showdayFrom: boolean=true;
  showdayTo: boolean=true;
  dayFrom: any =1;
  dayTo: any=7;
  subCategoryType: any;
  imgArr: any[];
  uploadFlg: boolean;
  addPhotoFlg: boolean;
  uploadphotoFlg: boolean;
  shownoImgflg: boolean;
  categoryName: any;
  catId: any;
  networkId: any;
  fromToselected:boolean=true;
  toFromselected:boolean=true;
  constructor(public navCtrl: NavController, public loadingController: LoadingController,public imageProcess:ImageProcess , public toastController: ToastController ,public restProvider: RestProvider,  
    public storage: Storage, public modalCtrl: ModalController,private formBuilder: FormBuilder,public navParams: NavParams) {
    this.addProductForm=this.formBuilder.group({
      listType:["", [Validators.required]],
      productName:["",  [Validators.required]],
      productDesc:["", [Validators.required]],
      productAvailableOn:[""],
      // dayFrom:[""],
      // dayTo:[""],
      categoryType:["", [Validators.required]],
      subCategoryType:[""],
      networkType:["",  [Validators.required]],
      rentalDay:[""],
      rentalWeek:[""],
      rentalMonth:[""],
      salePrice:[""],
    });
   
  
  }
  
  get productAvailable() {
    return this.addProductForm.get("productAvailableOn") as FormControl;
  }
  get subCategory() {
    return this.addProductForm.get("subCategoryType") as FormControl;
  }

  // get dayfrom() {
  //   return this.addProductForm.get("dayFrom") as FormControl;
  // }
  // get dayto() {
  //   return this.addProductForm.get("dayTo") as FormControl;
  // }
  get rentperday() {
    return this.addProductForm.get("rentalDay") as FormControl;
  }
  get rentperweek() {
    return this.addProductForm.get("rentalWeek") as FormControl;
  }
  get  rentpermonth() {
    return this.addProductForm.get("rentalMonth") as FormControl;
  }
  get saleprice() {
    return this.addProductForm.get("salePrice") as FormControl;
  }
  validation_messages = {
    productName: [{ type: "required", message: "Product Name is required" }],
    productDesc: [{ type: "required", message: " Product Description is required" }],
    productAvailableOn: [{ type: "required", message: "Duration is required" }],
    // dayFrom: [{ type: "required", message: "Day is required" }],
    // dayTo: [{ type: "required", message: "Day is required" }],
    categoryType: [{ type: "required", message: "Category Type is required" }],
    subCategoryType: [{ type: "required", message: "Subcategory Type is required" }],
    networkType: [{ type: "required", message: "Network Type is required" }],
    // rentalDay:  [{ type: "required", message: "Rental Price is required" }],
    // rentalWeek: [{ type: "required", message:"Rental Price  is required" }],
    // rentalMonth: [{ type: "required", message:"Rental Price  is required" }],
    salePrice: [{ type: "required", message: "Rental Price  is required" }],
  };

  
  ionViewDidLoad() {
    console.log('ionViewDidLoad AddproductPage');
    this.rootCategory();
    this. getNetworkDetails();

}
radioEvent(event){
  if(event == "From"){
    this.showdayFrom=true;
    this.showdayTo=true;
    this.fromToselected=true;
    this.toFromselected=true;
  }
  else if(event == "only"){
    this.showdayFrom=false;
    this.showdayTo=true;
    this.fromToselected=false;
    this.toFromselected=true;
  }

}
async ngOnInit() {
  this.getDetails= await this.storage.get("memberDetails");
  console.log(this.getDetails.memberId);
}
subcategories(event){
  this.subCategoryType = event;
  this.catId = event;

}
presentActionSheet() {
  const modal = this.modalCtrl.create(
    RequestSuccessPop,
    {},
    { cssClass: "customModal1" }
  );
  modal.present();
  modal.onDidDismiss((data) => {
    if (data == "1") {
       
      this.imageProcess.AccessCamera().then((res) => {
        this.image = res;
        this.shownoImgflg=false;
        this.convertImgtoBinary(this.image);
        this.uploadphotoFlg=true;
   
      });
      return true;
    } else if (data == "2") {
      this.imageProcess.AccessGallery().then((res) => {
        this.image = res;
        this.shownoImgflg=false;
        this.convertImgtoBinary(this.image);
        this.uploadphotoFlg=true;
       
      });
      return true;
    }
    else if (data == "3") {
      this.shownoImgflg=true;
      this.productImage ="../assets/imgs/NoImg.png";
      this.imgArr=null;
      this.uploadphotoFlg=true;
     
    }
    else if (data == "4") {
      this.shownoImgflg=true;
      this.imgArr=null;
      this.uploadphotoFlg=true;
    
    }
   
  });
}
uploadPhotopop(){
  const modal = this.modalCtrl.create(
    "CustomDialogPage",
    {
      titleName: "Upload Photo",
      bodyTxt:
        "Listing with images generate more interest. Would you like to proceed anyway?",
      okBtnNm: "Yes",
      cancelBtnNm: "No",
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
  modal.onDidDismiss((data) => {
    if (data == "Yes") {
      this.uploadFlg=false;
     this.addtoProductlist();
    } 
    else if(data == "No"){
      this.uploadFlg=true;
     this.addPhotoFlg=true;
      this.presentActionSheet();
    }
  });
}
  addtoProductlist() {
    if(!this.uploadFlg ){
      console.log("Form",this.addProductForm);
     
      if(this.addProductForm.valid ){
        this.loading = this.loadingController.create({
          spinner: "bubbles",
        });
        this.loading.present();
        var data:any;
        if(this.listType == 'lend'){
       data={
        productName:this.productName,
        productDescription:this.productDesc,
        networkId:2,
        transTypeId:this.transtypeId,
        memberId:this.getDetails.memberId,
        networkids:this.networkType,
        categoryId: this.catId,
        // dayfrom:this.dayFrom,
        // dayto:this.dayTo
       }
      }
      else if(this.listType == 'rent'){
        if (
          this.rentalDay == "" ||
          this.rentalDay == undefined ||
          this.rentalDay == null
        ) {
          this.rentalDay = 0;
        }
        if (
          this.rentalWeek == "" ||
          this.rentalWeek == undefined ||
          this.rentalWeek == null
        ) {
          this.rentalWeek = 0;
        }
        if (
          this.rentalMonth == "" ||
          this.rentalMonth == null ||
          this.rentalMonth == undefined
        ) {
          this.rentalMonth = 0;
        }
        if(this.listType == "rent"){
          if(this.rentalDay == 0 &&  this.rentalWeek == 0 &&  this.rentalMonth == 0){
            this.displayAlert("Enter at least any one the Rental price field");
            this.loading.dismiss();
            return;
                   }
        }
        data={
          productName:this.productName,
          productDescription:this.productDesc,
          networkId:2,
          transTypeId:this.transtypeId,
          memberId:this.getDetails.memberId,
          priceperday:this.rentalDay,
          priceperweek:this.rentalWeek,
          pricepermonth:this.rentalMonth,
          networkids:this.networkType,
          categoryId: this.catId,
         // dayfrom:this.dayFrom,
         // dayto:this.dayTo
         }
      }
      else if(this.listType == 'sell'){
        if(this.salePrice == 0){
          this.displayAlert("Enter Sale Price more than Zero!");
          this.loading.dismiss();
          return;
        }
        data={
          productName:this.productName,
          productDescription:this.productDesc,
          networkId:2,
          transTypeId:this.transtypeId,
          memberId:this.getDetails.memberId,
          salePrice:this.salePrice,
          networkids:this.networkType,
          categoryId: this.catId,
          //dayfrom:this.dayFrom,
         // dayto:this.dayTo
         }
      }
      else if(this.listType == 'gift'){
        data={
          productName:this.productName,
          productDescription:this.productDesc,
          networkId:2,
          transTypeId:this.transtypeId,
          memberId:this.getDetails.memberId,
          networkids:this.networkType,
          categoryId: this.catId,
         // dayfrom:this.dayFrom,
         // dayto:this.dayTo
         }
      }
      
        this.restProvider
      .addtoProductlist(data)
      .then( (data) => { 
        var result : any = data;
      
        console.log("result",data);
       if(result.status=="success"){
         this.displayConfirmAlert(
           "Product Listed. Use ‘My Listing’ under Dashboard to make changes"
         );
       }
       
        this.loading.dismiss();
      })


      
      .catch(error => {
        console.log("error",error);
        this.loading.dismiss();
      
        this.displayAlert("Please try again later");
      });
       
      }
      else{
        this.displayAlert("Please Enter all fields");
      }
     }
     else if(this.uploadFlg && this.addPhotoFlg){
      console.log("Form",this.addProductForm);
      if(this.addProductForm.valid ){
        this.loading = this.loadingController.create({
          spinner: "bubbles",
        });
        this.loading.present();
        var data:any;
        if(this.listType == 'lend'){
       data={
        productName:this.productName,
        productDescription:this.productDesc,
        networkId:2,
        transTypeId:this.transtypeId,
        productImage:this.imgArr,
        memberId:this.getDetails.memberId,
        networkids:this.networkType,
        categoryId: this.catId,
      //   dayfrom:this.dayFrom,
      //  dayto:this.dayTo
       }
      }
      else if(this.listType == 'rent'){
       if (
         this.rentalDay == "" ||
         this.rentalDay == undefined ||
         this.rentalDay == null
       ) {
         this.rentalDay = 0;
       }
       if (
         this.rentalWeek == "" ||
         this.rentalWeek == undefined ||
         this.rentalWeek == null
       ) {
         this.rentalWeek = 0;
       }
       if (
         this.rentalMonth == "" ||
         this.rentalMonth == null ||
         this.rentalMonth == undefined
       ) {
         this.rentalMonth = 0;
       }
        if(this.listType == "rent"){
          if(this.rentalDay == 0 &&  this.rentalWeek == 0 &&  this.rentalMonth == 0){
            this.displayAlert("Enter at least any one the Rental price field");
            this.loading.dismiss();
            return;
                   }
        }
        data={
          productName:this.productName,
          productDescription:this.productDesc,
          networkId:2,
          transTypeId:this.transtypeId,
          productImage:this.imgArr,
          memberId:this.getDetails.memberId,
          priceperday:this.rentalDay,
          priceperweek:this.rentalWeek,
          pricepermonth:this.rentalMonth,
          networkids:this.networkType,
          categoryId: this.catId,
          //dayfrom:this.dayFrom,
         //dayto:this.dayTo
         }
      }
      else if(this.listType == 'sell'){
        if(this.salePrice == 0){
          this.displayAlert("Enter Sale Price more than Zero!");
          this.loading.dismiss();
          return;
        }
        data={
          productName:this.productName,
          productDescription:this.productDesc,
          networkId:2,
          transTypeId:this.transtypeId,
          productImage:this.imgArr,
          memberId:this.getDetails.memberId,
          salePrice:this.salePrice,
          networkids:this.networkType,
          categoryId: this.catId,
          //dayfrom:this.dayFrom,
         // dayto:this.dayTo
         }
      }
      else if(this.listType == 'gift'){
        data={
          productName:this.productName,
          productDescription:this.productDesc,
          networkId:2,
          transTypeId:this.transtypeId,
          productImage:this.imgArr,
          memberId:this.getDetails.memberId,
          networkids:this.networkType,
          categoryId: this.catId,
         // dayfrom:this.dayFrom,
         // dayto:this.dayTo
         }
      }
      
        this.restProvider
      .addtoProductlist(data)
      .then( (data) => { 
        var result : any = data;
      
        console.log("result",data);
       if(result.status=="success"){
         this.displayConfirmAlert(
           "Product Listed. Use ‘My Listing’ under Dashboard to make changes"
         );
       }
       
        this.loading.dismiss();
      })
      .catch(error => {
        console.log("error",error);
        this.loading.dismiss();
      
        this.displayAlert("Please try again later");
      });
       
      }
      else{
        this.displayAlert("Please Enter all fields");
      }
     }
  
  }
convertImgtoBinary(image){
  
  console.log("base64",image)
  var raw = window.atob(image);
  console.log("raw",raw)
  var rawLength = raw.length;
  console.log("rawLength",rawLength)
  var array = new Uint8Array(new ArrayBuffer(rawLength));
  console.log("array",array)
  this.imgArr=[];
  for(var i = 0; i < rawLength; i++) {
    array[i] = raw.charCodeAt(i);
    this.imgArr.push(raw.charCodeAt(i));
  }
  
 
 
}

  addproduct(){
    if(this.addProductForm.valid){
      if(this.uploadphotoFlg  ){
        console.log("Form",this.addProductForm);
        if(this.addProductForm.valid ){
          this.loading = this.loadingController.create({
            spinner: "bubbles",
          });
          this.loading.present();
          var data:any;
          if(this.listType == 'lend'){
         data={
          productName:this.productName,
          productDescription:this.productDesc,
          networkId:2,
          transTypeId:this.transtypeId,
          productImage:this.imgArr,
          memberId:this.getDetails.memberId,
          networkids:this.networkType,
          categoryId: this.catId,
          // dayfrom:this.dayFrom,
          // dayto:this.dayTo
         }
        }
        else if(this.listType == 'rent'){
          if(this.rentalDay == ''||this.rentalDay==undefined||this.rentalDay==null){
            this.rentalDay =0;
      
          }
          if (
            this.rentalWeek == "" ||
            this.rentalWeek == undefined ||
            this.rentalWeek == null
          ) {
            this.rentalWeek = 0;
          }
          if (
            this.rentalMonth == "" ||
            this.rentalMonth == null ||
            this.rentalMonth
          ==undefined) {
            this.rentalMonth = 0;
          }
          if(this.rentalDay == 0 &&  this.rentalWeek == 0 &&  this.rentalMonth == 0){
   this.displayAlert("Enter at least any one the Rental price field");
   this.loading.dismiss();
   return;
          }
        
          data={
            productName:this.productName,
            productDescription:this.productDesc,
            networkId:2,
            transTypeId:this.transtypeId,
            productImage:this.imgArr,
            memberId:this.getDetails.memberId,
            priceperday:this.rentalDay,
            priceperweek:this.rentalWeek,
            pricepermonth:this.rentalMonth,
            networkids:this.networkType,
            categoryId: this.catId,
            //dayfrom:this.dayFrom,
            //dayto:this.dayTo
           }
        }
        else if(this.listType == 'sell'){
          if(this.salePrice == 0){
            this.displayAlert("Enter Sale Price more than Zero!");
            this.loading.dismiss();
            return;
          }
          data={
            productName:this.productName,
            productDescription:this.productDesc,
            networkId:2,
            transTypeId:this.transtypeId,
            productImage:this.imgArr,
            memberId:this.getDetails.memberId,
            salePrice:this.salePrice,
            networkids:this.networkType,
            categoryId: this.catId,
           // dayfrom:this.dayFrom,
            //dayto:this.dayTo
           }
        }
        else if(this.listType == 'gift'){
          data={
            productName:this.productName,
            productDescription:this.productDesc,
            networkId:2,
            transTypeId:this.transtypeId,
            productImage:this.imgArr,
            memberId:this.getDetails.memberId,
            networkids:this.networkType,
            categoryId: this.catId,
            //dayfrom:this.dayFrom,
            //dayto:this.dayTo
           }
        }
        
          this.restProvider
        .addtoProductlist(data)
        .then( (data) => { 
          var result : any = data;
        
          console.log("result",data);
         if(result.status=="success"){
           this.displayConfirmAlert(
             "Product Listed. Use ‘My Listing’ under Dashboard to make changes"
           );
           //this.navCtrl.pop();
         }
         
          this.loading.dismiss();
        })
        .catch(error => {
          console.log("error",error);
          this.loading.dismiss();
        
          this.displayAlert("Please try again later");
        });
         
           
          }
          else{
            this.displayAlert("fields should not be left blank");
          }
      }
      else{
        this.uploadPhotopop();
      }
        
      console.log("img",this.productImage);
     
      
    }
    else{
      this.displayAlert("Please Enter Mandatory Fields!");
    }
    
    
  }

 

 getValue(event){
  this.netArr=event;
 
  
  }




  

  getCategory(categoryId, categoryname) {
    this.rootId = categoryId;
    this.categoryName = categoryname;
    this.availableCategory();
  }


  changelisttype(event){
    this.listType=event;
    if(this.listType =="lend"){
      this.transtypeId=1;
      this.productAvailable.setValidators([Validators.required]);
      if(this.productAvailableOn =="From"){
        // this.dayfrom.setValidators([Validators.required]);
        // this.dayto.setValidators([Validators.required]);
      }
      else if(this.productAvailableOn =="only"){
        //this.dayto.setValidators([Validators.required]);
      }
      this.rentperday.setValidators(null);
      this.rentperweek.setValidators(null);
      this.rentpermonth.setValidators(null);
      this.saleprice.setValidators(null);
    }
    else if(this.listType =="rent"){
      this.transtypeId=2;
    
      // this.rentperday.setValidators([Validators.required]);
      // this.rentperweek.setValidators([Validators.required]);
      // this.rentpermonth.setValidators([Validators.required]);          
      this.productAvailable.setValidators(null);
      // this.dayfrom.setValidators(null);
      // this.dayto.setValidators(null);
      this.saleprice.setValidators(null);
    }
    else if(this.listType =="sell"){
      this.transtypeId=3;
      this.saleprice.setValidators([Validators.required]);
      this.productAvailable.setValidators(null);
      // this.dayfrom.setValidators(null); 
      // this.dayto.setValidators(null);
      this.rentperday.setValidators(null);
      this.rentperweek.setValidators(null);
      this.rentpermonth.setValidators(null);

    }
    else if(this.listType =="gift"){
      this.transtypeId=4;
      this.productAvailable.setValidators(null);
      // this.dayfrom.setValidators(null);
      // this.dayto.setValidators(null);
      this.rentperday.setValidators(null);
      this.rentperweek.setValidators(null);
      this.rentpermonth.setValidators(null);
      this.saleprice.setValidators(null);
    }
    this.productAvailable.updateValueAndValidity();
    // this.dayfrom.updateValueAndValidity();
    // this.dayto.updateValueAndValidity();
    this.rentperday.updateValueAndValidity();
    this.rentperweek.updateValueAndValidity();
    this.rentpermonth.updateValueAndValidity();
    this.saleprice.updateValueAndValidity();
  }
  availableCategory(){
   
  this.restProvider
.getAvailableCategory(this.rootId)
.then((data) => {
  console.log(this.rootId);
  console.log(data);
  console.log("data"+data);
  var result: any=data;
  
 
  if (result != null && result.status =="success") {
    this.subCategoryList = result.categoryDto;
  
    if (this.subCategoryList.length>0) {
      this.subCategory.setValidators([Validators.required]);
      this.toolsFlg = true;
    
    } else {
        this.catId = this.categoryType;
      this.subCategory.setValidators(null);
      this.toolsFlg = false;
    }
  }
  else if(result.status == "fail") {
    this.catId = this.categoryType;
    this.subCategory.setValidators(null);
    this.toolsFlg = false;
    }
this.subCategory.updateValueAndValidity();
})
.catch(error => {
  console.log("please try again");
});
  
  }

displayConfirmAlert(msg){
  const modal = this.modalCtrl.create(
    'CustomDialogPage',
    {
      titleName: "",
      bodyTxt:msg,
      okBtnNm: "Ok",
     
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
  modal.onDidDismiss((data) => {
    if (data == "Ok") {
      this.navCtrl.pop();
    this.navCtrl.push(AddproductPage);
    } 
  });

}

displayAlert(msg){
  const modal = this.modalCtrl.create(
    'CustomDialogPage',
    {
      titleName: "Neighbourbase",
      bodyTxt:msg,
      okBtnNm: "Ok",
     
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
  modal.onDidDismiss((data) => {
    if (data == "Ok") {
   
    } 
  });

}
presentToast(params) {
  let toast = this.toastController.create({
    message: params,
    duration: 2000
  });
  toast.present();
  }

rootCategory(){
  this.storage.get("memberId").then((val)=>{
    var  memberId: any=val;
  this.restProvider
  .loadRootCategory(memberId)
  .then( (data) => { 
    var result : any = data;
    var sts =result.status;

   
    if(result!=null && sts=="success")
    {
      this.categoryList= result.categoryDto;
     
      console.log(result);
   console.log("success");
    }
  })
  .catch(error => {
   
    this.presentToast("Please try again later");
  });

});

}
getnetworkName(event){
 
  console.log("netwrk",this.networkType);
  
    }


getNetworkDetails(){
  this.storage.get("memberId").then((val)=>{
    var  memberId: any=val;
  this.restProvider
  .getNetworkName(memberId)
  .then( (data) => { 
    var result : any = data;
    var sts =result.status;

  
 
     
    if(result!=null )
    {
      this.networkType=[];
      this.networkList= result;
     this.networkId= this.networkList[0].networkId;
     this.networkType.push(this.networkId);
      console.log("netlist",this.networkType);
    }
  })
  .catch(error => {
   
    this.presentToast("Please try again later");
  });

});
}

getdayFrom(event){
  this.dayFrom=event;
  // if(this.listType =="lend"){
  //   this.dayto.setValidators([Validators.required]);
  //   this.dayfrom.setValidators([Validators.required]);
  // }
  // else{
  //   this.dayto.setValidators(null);
  //   this.dayfrom.setValidators(null);
  // }
  // this.dayto.updateValueAndValidity();
  // this.dayfrom.updateValueAndValidity();
    }

    getdayTo(event){
  this.dayTo=event;
  // if(this.listType =="lend"){
  //   this.dayfrom.setValidators(null);
  //   this.dayto.setValidators([Validators.required]);
  // }
  // else{
  //   this.dayfrom.setValidators(null);
  //   this.dayto.setValidators(null);
  // }
  // this.dayto.updateValueAndValidity();
  // this.dayfrom.updateValueAndValidity();
    }


from()
{
  this.dayFlg=true;
}
only(){
  this.dayFlg=false;
}}




@Component({
  selector: "request-success-pop",
  template: `
    <ion-content>
      <ion-label text-center>
        <ion-icon
          ngClass="hdrIcon"
          name="ios-checkmark-circle-outline"
          class="larger"
        ></ion-icon>
        <ion-label ngClass="hdrTxt"
          >Choose your image to upload</ion-label
        >
      </ion-label>
      <ion-row>
        <ion-item>
          <ion-label class="actionItemCls" (click)="btnClick(1)"
            >Capture Image
            <ion-icon
              name="ios-camera-outline"
              class="larger iconCls"
            ></ion-icon>
          </ion-label>
        </ion-item>
      </ion-row>
      <ion-row>
        <ion-item>
          <ion-label class="actionItemCls" (click)="btnClick(2)"
            >Choose from gallery
            <ion-icon
              name="ios-images-outline"
              class="larger iconCls"
            ></ion-icon>
          </ion-label>
        </ion-item>
      </ion-row>

      <ion-row>
      <ion-item>
        <ion-label class="actionItemCls" (click)="btnClick(3)"
          >No Image
         
        </ion-label>
      </ion-item>
    </ion-row>

    <ion-row>
    <ion-item>
      <ion-label class="actionItemCls" (click)="btnClick(4)"
        >Cancel
       
      </ion-label>
    </ion-item>
  </ion-row>

      <ion-row text-center ngClass="btnMainCls">
        <button
          ngClass="btnCls"
          text-center
          ion-button
          color="bright"
          text-capitalize
          text-center
          round
          type="submit"
          (click)="btnClick('Close')"
        >
          Close
        </button>
      </ion-row>
    </ion-content>
  `,
})
export class RequestSuccessPop {
  unsubscribeBackEvent: any;
  constructor(
    public platform: Platform,
    private ionicApp: IonicApp,
    public viewCtrl: ViewController,

  ) {}
  ionViewWillEnter() {
    this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
      let activePortal=this.ionicApp._modalPortal.getActive();
        if(activePortal){
          activePortal.dismiss();
        } else {
        return true;
      }
    }, 101);
  }
  ionViewWillLeave() {
    this.unsubscribeBackEvent && this.unsubscribeBackEvent();
  }
  btnClick(data: string) {
    this.viewCtrl.dismiss(data);
  }
}

