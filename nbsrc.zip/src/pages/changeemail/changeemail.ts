import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, ModalController } from 'ionic-angular';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from '@ionic/storage';
import { LoginPage } from '../login/login';
/**
 * Generated class for the ChangeemailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-changeemail',
  templateUrl: 'changeemail.html',
})
export class ChangeemailPage {
  emailForm: FormGroup;
  loading: any;
  email:any;
  userMemberId: any;
  userAddress: any;
  userArea: any;
  userLat: any;
  userlong: any;
  usercreatedTime: any;
  usercontactno: any;
  useraboutMe: any;
  userdeviceToken: any;
  useremail: any;
  userfirstName: any;
  usermailVerifyFlag: any;
  usermemberId: any;
  usermemberProfilePic: any;
  usermemberTypeId: any;
  usernetworkId: any;
  userpicture: any;
  userpincode: any;
  usersearchRadius: any;
  userstatusId: any;
  userinviteFlag: any;
  userisActive: any;
  userisDeleted: any;
  userlastName: any;
  userPassword: any;
  constructor(public navCtrl: NavController, public modalCtrl: ModalController,public toastController:ToastController,public restProvider: RestProvider,public loadingController:LoadingController,private formBuilder: FormBuilder,public navParams: NavParams,private storage: Storage) {
    this.emailForm = this.formBuilder.group({
      email: ["", [Validators.required]],
      useremail: ["", [Validators.required]],
    });

    
  }

  async ionViewDidLoad() {
    await this.storage.get("memberDetails").then((val)=>{
      if(val !=undefined && val !=null && val !=""){
        this.userMemberId=val.memberId;
        this.useremail=val.email;
        //this.email=this.useremail;


        this.userAddress=val.address;
        this.userArea= val.area;
        this.userLat=val.latitude;
        this.userlong=val.longitude;
       this.usercreatedTime= val.createdDateTime;
      this.usercontactno= val.contactNumber;
      this.useraboutMe=val.aboutMe
 this.userdeviceToken=val.deviceToken
 //this.useremail= this.email;
 this.userfirstName=val.firstName
 this.userinviteFlag=val.inviteFlag
 this.userisActive=val.isActive
 this.userisDeleted=val.isDeleted
 this.userlastName=val.lastName
 this.usermailVerifyFlag=val.mailVerifyFlag
 this.usermemberId=val.memberId
 this.usermemberProfilePic=val.memberProfilePic
 this.usermemberTypeId=val.memberTypeId
 this.usernetworkId=val.networkId
 this.userpicture=val.picture
 this.userpincode=val.pincode
 this.usersearchRadius=val.searchRadius
 this.userstatusId=val.statusId
    this.userPassword=val.password
      }
           });
    console.log(this.useremail);
  }
  validation_messages = {
   
    email:[{
      type: "required", message: "Email is required"
    }
  ],
    }


    reset(){
        var view =this;
        if (this.email != undefined ) {
       
          var mailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^ <>() \[\]\\.,;: \s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          if (this.email.match(mailformat)) {
            console.log("ok");
            if (this.emailForm.valid) {
              return new Promise((resolve, reject) => {
              this.loading = this.loadingController.create({
                spinner: "bubbles"
              });
              this.loading.present();
              var data:any;
           data={   
            memberId: this.userMemberId,
            email:this.email, 
               };
            console.log("data",data);
              this.restProvider.changeEmail(data)
              .then(data => {
                resolve(data);
               var  result:any = data;
               console.log("data",result);
              
    if(result.status == "success"){
    this.displayAlert("Email changed. We have sent an email to the new mail id with a link to verify the new id");
    this.navCtrl.setRoot(LoginPage);
    }
    else if(result.status =="exists"){
      this.email=null;
      this.displayAlert(" We have the same id in our records !")
    }
    else if(result.status =="fail" ){
      this.displayAlert("Email can't be changed. please try again..")
    }
              
                
               
                this.loading.dismiss(); 
              }).catch(error => {
                console.log("err",error);
                this.loading.dismiss();
                this.displayAlert("Please try again later");
              });
            });
          }
          else{
            this.displayAlert("Please Enter Email");
          }
          } else {

            this.displayAlert("Enter valid email id");
            return ;
          }
        }
        
      
    }
    presentToast(params) {
      let toast = this.toastController.create({
        message: params,
        duration: 2000
      });
      toast.present();
    }

    verifyEmail(){
     
     
      if (this.emailForm.valid) {
        return new Promise((resolve, reject) => {
        this.loading = this.loadingController.create({
          spinner: "bubbles"
        });
        this.loading.present();
     
        var result;
        console.log("id",this.userMemberId);
        this.restProvider.verifyEmail(this.userMemberId)
        .then(data => {
          resolve(data);
         var result:any = data;

         console.log("data",result);
          if(result =="success"){
this.displayAlert("verification mail sent, check your Email!");
//this.navCtrl.pop();
          }
          else if(result =="fail"){
            this.displayAlert("verification mail sent failed. please try again..!");
          }
         
          this.loading.dismiss(); 
        }).catch(error => {
          console.log("err",error);
          this.loading.dismiss();
          this.displayAlert("Please try again later");
        });
      });
    }
    }

    displayAlert(message) {
 
      const modal = this.modalCtrl.create(
        "CustomDialogPage",
        {
          dialogFor: "info",
          iconName: "",
          titleName: "",
          bodyTxt: message,
          okBtnNm: "Ok",
        },
        { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
      );
      modal.present();
    }
}
