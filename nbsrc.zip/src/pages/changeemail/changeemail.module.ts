import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChangeemailPage } from './changeemail';

@NgModule({
  declarations: [
    ChangeemailPage,
  ],
  imports: [
    IonicPageModule.forChild(ChangeemailPage),
  ],
})
export class ChangeemailPageModule {}
