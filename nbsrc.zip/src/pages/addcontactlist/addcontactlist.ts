import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController } from 'ionic-angular';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from "@ionic/storage";
import { UsefulcontactsPage } from '../usefulcontacts/usefulcontacts';
/**
 * Generated class for the AddcontactlistPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-addcontactlist',
  templateUrl: 'addcontactlist.html',
})
export class AddcontactlistPage {
  addcontactForm:FormGroup;
  feedback:any;
  emailId:any;
  pincode:any;
  city:any;
  address2:any;
  address1:any;
  landLine:any;
  contactNo:any;
  catType:any;
  name:any;
  netwrkid: any;
  getAllcategorylist: any;
  loading: any;
  getDetails: any;
  listid: any;
  usercontacts: any;
  addContactFlg: boolean;

  constructor(public navCtrl: NavController,public modalCtrl: ModalController,
    public storage:Storage, public toastController: ToastController,public loadingController: LoadingController,public restProvider: RestProvider,public navParams: NavParams,private formBuilder: FormBuilder) {

    this.netwrkid=this.navParams.get("data");
    this.listid=this.navParams.get("listid");

    this.usercontacts= this.navParams.get("contact");
  console.log("contactflg",this.usercontacts);
   if(this.usercontacts !=undefined){
     this.addContactFlg =false;
     this.name=this.usercontacts.name;
     this.contactNo=this.usercontacts.mobile;
     this.address1=this.usercontacts.address1;
     this.address2=this.usercontacts.address2;
     this.catType=this.usercontacts.categoryId;
     this.landLine=this.usercontacts.landline;
     this.city=this.usercontacts.city;
     this.pincode=this.usercontacts.pincode; 
     this.emailId=this.usercontacts.email;
     this.emailId=this.usercontacts.email;
    
   }
   else{
    this.addContactFlg =true;
   
  }
   
    console.log("netid",this.netwrkid,this.listid);
    this.addcontactForm=this.formBuilder.group({
      name:["", [Validators.required]],
      catType:["",  [Validators.required]],
      contactNo:["",[
        Validators.pattern("^[0-9]+$"),
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
      ],],
      landLine:[""],
      address1:[""],
      address2:[""],
      city:[""],
      pincode:[""],
      emailId:[""],
      feedback:[""],
     
    });
    this.getCategoryList();
  }
  get feedbk() {
    return this.addcontactForm.get("feedback") as FormControl;
  }
  async ngOnInit() {
    this.getDetails= await this.storage.get("memberDetails");
       console.log(this.getDetails.memberId);
     
     }
     goBackbtn() {
      this.navCtrl.pop();
    }
  
  validation_messages = {
    name: [{ type: "required", message: " Name is required" }],
    catType: [{ type: "required", message: " Category is required" }],
    contactNo: [ { type: "required", message: " Invalid Contact Number " },
    { type: "minlength", message: "Contact Number must be 10 numbers" },
    { type: "maxlength", message: "Contact Number should be 10 numbers" },
    { type: "pattern", message: "Contact Number must be numbers" },],
   
  };
  ionViewDidLoad() {
    console.log('ionViewDidLoad AddcontactlistPage');
  }
  getCategoryList(){
    this.loading = this.loadingController.create({
       spinner: "bubbles",
     });
     this.loading.present();
     
        
     this.restProvider
   . getCategoryList(this.netwrkid)
   .then( (data) => { 
     var result : any = data;
    
     console.log("result",data);
     this.getAllcategorylist=result;
    
     this.loading.dismiss();
   })
   .catch(error => {
     console.log("error",error);
     this.loading.dismiss();
   
     this.presentToast("Please try again later");
   });
 }
 getCategory(event){

 }
 add(val){
   if(val == 2){
    this.feedbk.setValidators(null);
    this.feedbk.updateValueAndValidity();
     //this.name !=undefined && this.catType !=undefined && this.contactNo!=undefined
     if(this.addcontactForm.valid){
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
      var data:any;
      data={
        name:this.name,
        mobile:this.contactNo,
        feedback:this.feedback,
        landline:this.landLine,
        address1:this.address1,
        address2:this.address2,
        city:this.city,
        pincode:this.pincode,
        email:this.emailId,
        categoryId:this.catType,
        listId:this.listid,
        networkId:this.netwrkid,
        //createdMemberId:this.getDetails.memberId,
        updatedMemberId:this.getDetails.memberId,
    
      }
         
      this.restProvider
    .updateContactList(data)
    .then( (data) => { 
      var result : any = data;
     
      console.log("result",data);
      if(result == "success"){
    //this.presentToast("Contact list created successfully!");
  this.displayAlert("Contact list updated successfully!");
  this.navCtrl.push(UsefulcontactsPage,{data:this.netwrkid});
    //this.navCtrl.setRoot(UsefulcontactsPage,{data:this.netwrkid});
      }
      else if(result == "fail"){
        this.displayAlert("Contact List update failed try again...") ;
      }
     
      this.loading.dismiss();
    })
    .catch(error => {
      console.log("error",error);
      this.loading.dismiss();
    
      this.displayAlert("Please try again later");
    });
     }
     else{
      this.displayAlert("Please Enter Mandatory Fields!");
     }
   }
   else if(val == 1 ){
    this.feedbk.setValidators([Validators.required]);
    this.feedbk.updateValueAndValidity();
     //this.name !=undefined && this.catType !=undefined && this.contactNo!=undefined && this.feedback !=undefined
    if(this.addcontactForm.valid){
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    var data:any;
    data={
      name:this.name,
      mobile:this.contactNo,
      feedback:this.feedback,
      landline:this.landLine,
      address1:this.address1,
      address2:this.address2,
      city:this.city,
      pincode:this.pincode,
      email:this.emailId,
      categoryId:this.catType,
      networkId:this.netwrkid,
      createdMemberId:this.getDetails.memberId,
      updatedMemberId:this.getDetails.memberId,
  
    }
       
    this.restProvider
  . addContactList(data)
  .then( (data) => { 
    var result : any = data;
   
    console.log("result",data);
    if(result == "success"){
      this.displayMsgAlert("Contact list created successfully!");
      this.navCtrl.push(UsefulcontactsPage,{data:this.netwrkid});
  //this.navCtrl.setRoot(UsefulcontactsPage,{data:this.netwrkid});
    }
    else if(result == "fail"){
      this.displayAlert("Contact List Created failed try again...") ;
    }
   
    this.loading.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading.dismiss();
  
    this.displayAlert("Please try again later");
  });
   }
  
   else{
    this.displayAlert("Please Enter Mandatory Fields!");
   }
   }
 }
 displayMsgAlert(message){
  const modal = this.modalCtrl.create(
    "CustomDialogPage",
    {
      dialogFor: "info",
      iconName: "",
      titleName: "",
      bodyTxt: message,
      okBtnNm: "Ok",
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
  modal.onDidDismiss((data) => {
    if(data == "Ok"){
      this.navCtrl.setRoot(UsefulcontactsPage,{data:this.netwrkid});
    }
  });
}
 displayAlert(message) {
 
  const modal = this.modalCtrl.create(
    "CustomDialogPage",
    {
      dialogFor: "info",
      iconName: "",
      titleName: "",
      bodyTxt: message,
      okBtnNm: "Ok",
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
}
displayWarn(message) {
  const modal = this.modalCtrl.create(
    "CustomDialogPage",
    {
      dialogFor: "warning",
      iconName: "",
      titleName: "",
      bodyTxt: message,
      okBtnNm: "Ok",
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
}
 cancel(){
// this.name=null;
// this.address1="";
// this.address2="";
// this.city="";
// this.contactNo="";
// this.catType="";
// this.pincode="";
// this.emailId="";
// this.feedback="";
// this.contactNo="";
// this.landLine="";
   this.navCtrl.pop();
 }
 presentToast(params) {
  let toast = this.toastController.create({
    message: params,
    duration: 2000,
  });
  toast.present();
}
}
