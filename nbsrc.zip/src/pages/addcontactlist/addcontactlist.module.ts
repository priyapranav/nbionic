import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddcontactlistPage } from './addcontactlist';

@NgModule({
  declarations: [
    AddcontactlistPage,
  ],
  imports: [
    IonicPageModule.forChild(AddcontactlistPage),
  ],
})
export class AddcontactlistPageModule {}
