import { AsyncPipe } from '@angular/common';
import { Component, NgZone } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Storage } from '@ionic/storage';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, ModalController, Events } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { HomePage } from '../home/home';
import { LoginPage } from '../login/login';
import { TncPage } from '../tnc/tnc';


/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


declare var google;

@IonicPage()
@Component({
  selector: "page-register",
  templateUrl: "register.html",
})
export class RegisterPage {
  firstName: any;
  email: any;
  phoneNo: any;
  password: any;
  cnfrmpassword: any;
  termsCondition: boolean = false;
  registerForm: FormGroup;
  area: any;
  loading: any;
  address: any;
  lat: any;
  lng: any;
  contactNumber: any;
  pincode: any;
  autocomplete: any;
  GoogleAutocomplete: any;
  addr: any;
  autocompleteItems: any[];
  map: any;
  geocoder: any;
  markers: any;
  cityDisable: boolean = true;
  autocompleteAddressItems: any[];
  autocompleteAddress: any;
  addressLocation: any;
  city: any;
  state: any;
  country: any;
  autocompleteFrom: any;
  autocompleteFromItems: any[];
  fromLocation: string;
  userCountry: any = "IN";
  fromLatLong: { lat: number; lng: number };
  senderLocation: any;
  sendFrom: any;
  pickupItems: any;
  pickup: { input: string };
  latlng: any;
  formatAddr: any;
  grpId: any;
  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    public toastController: ToastController,
    public restProvider: RestProvider,
    public loadingController: LoadingController,
    private formBuilder: FormBuilder,
    private zone: NgZone,
    public navParams: NavParams,
    private storage: Storage,
    public event: Events
  ) {
    this.storage.get("grpInvite").then((val) => {
      if (val != null && val != undefined) {
        this.grpId = val.grpId;
      }
    });
    this.phoneNo = navParams.get("mobileNumber");
    this.registerForm = this.formBuilder.group({
      firstName: ["", [Validators.required]],
      email: ["", [Validators.email, Validators.required]],
      phoneNo: [
        "",
        [
          Validators.pattern("^[0-9]+$"),
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10),
        ],
      ],
      // password: ["", [Validators.required]],
      // cnfrmpassword: ["", [Validators.required]],
      termsCondition: [false, [Validators.requiredTrue]],
      area: [""],
      city: ["", [Validators.required]],
    });

    this.pickup = { input: "" };
    this.pickupItems = [];
    if (typeof google != "undefined") {
      this.GoogleAutocomplete = new google.maps.places.AutocompleteService();

      this.geocoder = new google.maps.Geocoder();
    }

    this.autocomplete = { input: "" };
    this.autocompleteItems = [];
  }

  validation_messages = {
    firstName: [{ type: "required", message: "FirstName is required" }],
    email: [
      { type: "email", message: "Invalid Email Address" },
      { type: "required", message: "Email is required" },
    ],

    phoneNo: [
      { type: "required", message: " Invalid Phone Number " },
      { type: "minlength", message: "Receiver Phone must be 10 numbers" },
      { type: "maxlength", message: "Receiver Phone should be 10 numbers" },
      { type: "pattern", message: "Receiver phone must be numbers" },
    ],
    // password: [{ type: "required", message: "Password is required" }],
    // confirmPwd: [
    //   { type: "required", message: "ConfirmPassword is required" },
    // ],

    termsCondition: [
      {
        type: "requiredTrue",
        message: "Please accept Terms of Service",
      },
    ],
  };
  login() {
    this.navCtrl.push(LoginPage);
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  ionViewDidLoad() {
    console.log("ionViewDidLoad RegisterPage");
  }
  gotoTnc() {
    //this.navCtrl.push(TncPage);
  }
  register() {
    if (this.registerForm.valid) {
      // if (this.password == this.cnfrmpassword) {

      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
      var data: any;
      data = {
        firstName: this.firstName,
        //  password: this.password,
        email: this.email,
        area: this.city,
        address: this.autocomplete.input,
        latitude: this.lat,
        longitude: this.lng,
        contactNumber: this.phoneNo,
        pincode: this.pincode,
      };
      //response came in error callback
      this.restProvider
        .registerRest({ data })
        .then((data) => {
          console.log(data);
          var res: any = data;
          var result: any = JSON.parse(res);
          // if(result == "exists"){
          //   this.displayAlert("Email Already Exits");
          // }
          // else if(result == "success"){
          //   this.displayAlert("Registered Successfully");
          //   this.navCtrl.push(LoginPage);
          // }
          // else if(result == "fail"){
          //   this.displayAlert("Sorry Registration Failed Try again");
          // }
          var lat = result.latitude;
          var sta = result.alreadyExists;
          if (lat != 0.0 && sta == "SUCCESS") {
            var productDetails = {
              pincode: result.pincode,
              latitude: result.latitude,
              longitude: result.longitude,
              memberId: result.memberId,
              radius: result.searchRadius,
            };
            if (
              this.grpId != undefined &&
              this.grpId != null &&
              this.grpId != ""
            ) {
              this.acceptConfirm(this.grpId, result.memberId, result.email);
            }

            this.storage.set("memberDetails", result);
            this.storage.set("memberAddress", result.address);
            this.storage.set("memberId", result.memberId);
            this.storage.set("productDet", productDetails);
            this.storage.set("latitude", result.latitude);
            this.storage.set("longitude", result.longitude);
            this.event.publish("user:created", result.memberId);
            this.displayAlert("Registered Successfully");
            this.navCtrl.setRoot(HomePage);
          } else {
            this.displayAlert("Sorry Registration Failed Try again");
          }
          this.loading.dismiss();
        })
        .catch((error) => {
          console.log("error", error);

          this.loading.dismiss();
        });
      // }
      // else {
      //   this.displayAlert("Password and Reenter password should be same");
      // }
    } else {
      this.displayAlert("Please Enter All Fields!");
    }
  }

  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }

  emailAvailable() {
    this.restProvider
      .emailCheck(this.email)
      .then((data) => {
        var result: any = data;
        var sts = result.status;

        if (sts == "Email already exists") {
          this.displayAlert("Email already exists");
        } else {
          return;
        }
      })
      .catch((error) => {
        this.displayAlert("Please try again");
      });
  }

  gototnc() {
    this.navCtrl.push(TncPage);
  }

  updateResults() {
    if (this.autocomplete.input == "") {
      this.autocompleteItems = [];

      return;
    }
    if (this.autocomplete.input.length >= 5) {
      if (this.GoogleAutocomplete != undefined) {
        this.GoogleAutocomplete.getPlacePredictions(
          {
            input: this.autocomplete.input,
            componentRestrictions: { country: this.userCountry },
          },
          (predictions, status) => {
            this.autocompleteItems = [];
            this.zone.run(() => {
              if (
                predictions != undefined &&
                predictions != "" &&
                predictions != null
              ) {
                predictions.forEach((prediction) => {
                  this.autocompleteItems.push(prediction);
                });
              } else {
                this.presentToast(
                  "Location not found, please search nearby location"
                );
              }
            });
          }
        );
      } else {
        this.presentToast("Please check your internet connection");
      }
    }
  }

  selectSearchResult(item) {
    this.autocompleteItems = [];
    this.autocomplete.input = item.description;
    this.geocoder.geocode({ placeId: item.place_id }, (results, status) => {
      if (status === "OK" && results[0]) {
        console.log("formatted", results[0]);
        this.lat = parseFloat(results[0].geometry.location.lat());
        this.lng = parseFloat(results[0].geometry.location.lng());
        this.latlng = { lat: this.lat, lng: this.lng };
        this.formatAddr = results[0].formatted_address;
        console.log(results[0].address_components);
        results[0].address_components.forEach((val) => {
          if (val.types[0] == "locality") {
            this.city = val.short_name;
          }
          if (val.types[0] == "administrative_area_level_1") {
            this.state = val.short_name;
          }
          if (val.types[0] == "country") {
            this.country = val.short_name;
          }
          if (val.types[2] == "sublocality_level_1") {
            this.area = val.short_name;
          }
        });
        this.pincodeFunc();
      }
    });
  }

  pincodeFunc() {
    var view = this;
    this.geocoder.geocode(
      { location: this.latlng },
      function (results, status) {
        if (status === "OK") {
          if (results[0]) {
            console.log(results[0]);

            results[0].address_components.forEach((val) => {
              if (val.types[0] == "postal_code") {
                view.pincode = val.short_name;
                console.log(view.pincode);
              }
            });
          }
        }
      }
    );
  }
  acceptConfirm(nid, mid, emailId) {
    this.restProvider
      .acceptInvite(nid, mid, emailId)
      .then((data) => {
        var result: any = data;
        console.log(result);

        if (result == true) {
          const modal = this.modalCtrl.create(
            "CustomDialogPage",
            {
              titleName: "",

              bodyTxt: "You are now part of group. ",

              okBtnNm: "",
            },

            {
              cssClass: "customModal1 customHrdTxt1",
              enableBackdropDismiss: true,
            }
          );

          modal.present();

          modal.onDidDismiss((data) => {
            // this.invite();
          });
        } else if (result == false) {
          const modal = this.modalCtrl.create(
            "CustomDialogPage",
            {
              titleName: "Invitation Accept Fail ",

              bodyTxt: "you are not included in the group",

              okBtnNm: "Ok",
            },

            {
              cssClass: "customModal1 customHrdTxt1",
              enableBackdropDismiss: true,
            }
          );

          modal.present();
          modal.onDidDismiss((data) => {
            return;
          });
        } else {
          const modal = this.modalCtrl.create(
            "CustomDialogPage",
            {
              titleName: "",

              bodyTxt: "Server Down. Please Try Again",

              okBtnNm: "",
            },

            {
              cssClass: "customModal1 customHrdTxt1",
              enableBackdropDismiss: true,
            }
          );

          modal.present();
          modal.onDidDismiss((data) => {
            return;
          });
        }
      })
      .catch((error) => {
        console.log(error);
        this.presentToast("Please try again later");
      });
  }
}