import { Component } from '@angular/core';
import { IonicPage, NavController, ToastController, NavParams, ModalController, ViewController, Platform, IonicApp } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Storage } from '@ionic/storage';
import { ImageProcess } from '../../providers/rest/ImageProcess';
import { NgZone} from '@angular/core';
import { RestProvider } from '../../providers/rest/rest';
import { SERVER_TRANSITION_PROVIDERS } from '@angular/platform-browser/src/browser/server-transition';
import { ManageprofilePage } from '../manageprofile/manageprofile';
import { SelectgroupPage } from '../selectgroup/selectgroup';
/**
 * Generated class for the EditgroupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
 declare var google;
@IonicPage()
@Component({
  selector: 'page-editgroup',
  templateUrl: 'editgroup.html',
})
export class EditgroupPage {
  groupForm:FormGroup;
  groupName:any;
  groupDetails:any;
  addPhotoFlg: boolean;
  address:any;
  OrgName:any;
  noImg:boolean=false;
  image:any;
  showImg:boolean=false;
  GoogleAutocomplete: any;
  geocoder: any;
  autocomplete: { input: string; };
  autocompleteItems: any[];
  userCountry: any ="IN";
  lat: number;
  formatAddr: any;
  lng: number;
  latlng: { lat: number; lng: number; };
  city: any;
  country: any;
  state: any;
  area: any;
  list: any;
  pincode: any;
  memberId: any;
  uploadFlg: boolean;
  groupType:any="apartment";
  uploadphotoFlg: boolean;
  imgArr: any[];
  imageSrc:any;
  userpicture: any;
  networkTypeId:any;
  netId: any;
  Grpdet: any;
  groupList: any;
picture:any;
  grpName: any;
  grpDetails: any;
  apartmentName: any;
  groupImg: any;
  networkId: any;
  imageUrl:any;
  addLocalFile: any="../assets/imgs/NoImg.png";
  shownoImgflg: boolean;

  constructor(public navCtrl: NavController, public toastController: ToastController,  public imageProcess:ImageProcess , public modalCtrl: ModalController,
    public storage: Storage, public restProvider: RestProvider, private formBuilder: FormBuilder,public navParams: NavParams, private zone: NgZone) {
    this.imageUrl = restProvider.imgUrl;
    this.groupForm = this.formBuilder.group({
      groupName: ["", [Validators.required]],
      groupDetails: ["", [Validators.required]],
      networkTypeId: ["", [Validators.required]],
      address:["",[Validators.required]], 
      OrgName:["",[Validators.required]],
      
    });
  var Data=this.navParams.get("data");
  this.netId=Data;

    if(typeof google!="undefined")
    {
      this.GoogleAutocomplete= new google.maps.places.AutocompleteService();
      this.geocoder=new google.maps.Geocoder();
    
    } this.autocomplete= {input:""};
    this.autocompleteItems=[];
  
  }
  
  ionViewDidLoad() {
      console.log('ionViewDidLoad EditgroupPage');
    
    this.storage.get("memberDetails").then((val)=>
    {

      var det=val;
      this.address=det.address;
      this.pincode=det.pincode;
      this.lat=det.latitude;
      this.lng= det.longitude;
      this.area=det.area;      

    });

    
    this.restProvider
    .groupDetailEdit(this.netId)
    .then( (data) => { 
  
      var result : any = data;
      console.log("result",data);
         if(result!=null){

           console.log(result);
         this.Grpdet=result;
         this.picture=this.Grpdet.picture;
         this.grpName=this.Grpdet.name;
         this.grpDetails=this.Grpdet.networkDetails;
         this.apartmentName=this.Grpdet.addressline2;
         this.groupImg=this.Grpdet.picture;
         
         this.networkId=this.Grpdet.networkId;
         console.log(this.grpName);
         this.groupName= this.grpName;
         this.groupDetails= this.grpDetails;
         this.OrgName= this.apartmentName;
           this.userpicture = this.groupImg;
           this.networkTypeId = this.Grpdet.networkTypeId;
             this.address = this.Grpdet.addressline1;

             if(this.userpicture == null || this.userpicture == "No Image" || this.userpicture == ""){
              this.imageSrc=this.addLocalFile;
              this.shownoImgflg=true;
            }
            else{
              this.imageSrc=this.imageUrl+this.userpicture;
              this.shownoImgflg=true;
            }
      
            console.log("img", this.imageSrc)

         }
      
        })
        .catch(error => {
          console.log("error",error);
          this.displayMsg("Please try again later");
        });
  
       
      
         
  }
  displayMsg(msg){
    const modal = this.modalCtrl.create(
      'CustomDialogPage',
      {
        dialogFor: "info",
      iconName: "",
      titleName: "",
      bodyTxt: msg,
      okBtnNm: "Ok",
        
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Ok") {
     
       
      } 
      
    });
  }
  value(event){
console.log(event);
  }
  updateResults(data) {

    console.log(data);
    if (this.address == "") {
      this.autocompleteItems = [];


      return;
    }
    if(this.address.length>=5){
    if (this.GoogleAutocomplete != undefined) {
      this.GoogleAutocomplete.getPlacePredictions(
        {
          input: this.address,
          componentRestrictions: { country: this.userCountry },
        },
        (predictions, status) => {
          this.autocompleteItems = [];
          this.zone.run(() => {
            if (
              predictions != undefined &&
              predictions != "" &&
              predictions != null
            ) {
              predictions.forEach((prediction) => {
                this.autocompleteItems.push(prediction);
              });
            } else {
              this.presentToast(
                "Location not found, please search nearby location"
              );
            }
          });
        }
      );
    } else {
      this.presentToast("Please check your internet connection");
    }
  }
  }

  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000
    });
    toast.present();
  }



  selectSearchResult(item) {
    this.autocompleteItems = []; 
    this.autocomplete.input = item.description; this.geocoder.geocode({ placeId: item.place_id }, (results, status) => {
      if (status === "OK" && results[0]) {
        console.log("formatted", results[0]); 
        this.lat = parseFloat(results[0].geometry.location.lat());
         this.lng = parseFloat(results[0].geometry.location.lng()); 
         this.latlng = { lat: this.lat, lng: this.lng, }; 
        this.address = results[0].formatted_address; 
        console.log(results[0].address_components); 
        results[0].address_components.forEach((val) => {


          if (val.types[0] == "locality") 
          { this.city = val.short_name; } 
          if (val.types[0] == "administrative_area_level_1") 
          { this.state = val.short_name; } 
          if (val.types[0] == "country") 
          { this.country = val.short_name; } 
          if (val.types[2] == "sublocality_level_1")
           { this.area = val.short_name; }
        }); 
        this.pincodeFunc();
      }
    });
  }
  

  pincodeFunc() {

    var view = this;
    this.geocoder.geocode({ location: this.latlng }, function (results, status) {
      if (status === "OK") {
        if (results[0]) {
          console.log(results[0]);


          results[0].address_components.forEach((val) => {
            if (val.types[0] == "postal_code") {

              view.pincode = val.short_name;
              console.log(view.pincode);
            }

          });
        }
      }
    });

  }

  submit(){
    console.log(this.OrgName);
    if(this.groupForm.valid ){
    if(this.uploadphotoFlg ){
      console.log("Form",this.groupForm);
    

          this.storage.get("memberDetails").then((val)=>{
            this.memberId= val.memberId;
       
        
          var reqdata={name: this.groupName, networkDetails: this.groupDetails, addressline1:this.address,
          addressline2: this.OrgName, latitude:this.lat, longitude: this.lng, networkImage:this.imgArr, networkId:this.networkId,
          pincode: this.pincode, networkTypeId:this.networkTypeId, memberId: this.memberId, picture:this.picture };
      
          console.log(this.OrgName);
        this.restProvider
        .editNetwork(reqdata)
        .then( (data) => { 
      
          var result : any = data;
          console.log("result",data);
          this.groupList=result;
             if(result!=null){
               this.displayAlert("Changes to the Group have been made.");
               //this.navCtrl.pop();
             }
          
            })
            .catch(error => {
              console.log("error",error);
            
              this.displayMsg("Please try again later");
            });
             
            });
         
           
          
        }
        else if(this.shownoImgflg){
          this.imgArr=null;
        

            this.storage.get("memberDetails").then((val)=>{
              this.memberId= val.memberId;
         
          
            var reqdata={name: this.groupName, networkDetails: this.groupDetails, addressline1:this.address,
            addressline2: this.OrgName, latitude:this.lat, longitude: this.lng, networkImage:this.imgArr, networkId:this.networkId,
            pincode: this.pincode, networkTypeId:this.networkTypeId, memberId: this.memberId, picture:this.picture };
        
            console.log(this.OrgName);
          this.restProvider
          .editNetwork(reqdata)
          .then( (data) => { 
        
            var result : any = data;
            console.log("result",data);
            this.groupList=result;
               if(result!=null){
                 this.displayAlert("changes to your network details have been made");
                 //this.navCtrl.pop();
               }
            
              })
              .catch(error => {
                console.log("error",error);
              
                this.displayMsg("Please try again later");
              });
               
              });
           
             
             

        }
        else{
          this.uploadPhotopop();
        }
          
        console.log("img",this.imageSrc
        );
      }
      else{
        this.displayMsg("Please Enter all fields");
      }
      }
    
    newgroup(){

    if(!this.uploadFlg ){
      console.log("Form",this.groupForm);
      if(this.groupForm.valid ){

          this.storage.get("memberDetails").then((val)=>{
            this.memberId= val.memberId;
       
        
          var reqdata={name: this.groupName, networkDetails: this.groupDetails, addressline1:this.address, 
          addressline2: this.OrgName, latitude:this.lat,networkTypeId:this.networkTypeId ,memberId: this.memberId, picture:this.picture,
           longitude: this.lng, pincode: this.pincode,  networkId:this.networkId,};
      
      
        this.restProvider
        .editNetwork(reqdata)
        .then( (data) => { 
      
          var result : any = data;
          console.log("result",data);
          this.groupList=result;
             if(result!=null){
               this.displayAlert("changes to your network details have been made");
             }
          
            })
            .catch(error => {
              console.log("error",error);
            
              this.presentToast("Please try again later");
            });
             
            });
         
           }
           else{
            this.presentToast("Please Enter all fields");
          }
        }
           else if(this.uploadFlg && this.addPhotoFlg){
            console.log("Form",this.groupForm);
            if(this.groupForm.valid ){
              this.storage.get("memberDetails").then((val)=>{
                this.memberId= val.memberId;
           
            
              var reqdata={name: this.groupName, networkDetails: this.groupDetails, addressline1:this.address,
              addressline2: this.OrgName,  networkImage:this.imgArr,networkTypeId:this.networkTypeId, networkId:this.networkId,
               latitude:this.lat, longitude: this.lng, pincode: this.pincode,memberId: this.memberId, picture:this.picture};
          
          
            this.restProvider
            .editNetwork(reqdata) 
            .then( (data) => { 
          
              var result : any = data;
              console.log("result",data);
              this.groupList=result;
                 if(result!=null){
                   this.displayAlert("changes to your network details have been made");
                 }
              
                })
                .catch(error => {
                  console.log("error",error);
                  this.presentToast("Please try again later");
                });
                 
                });
              }
                else{
                  this.presentToast("Please Enter all fields");
                }
            }
      
      }
  

displayAlert(msg){
  const modal = this.modalCtrl.create(
    'CustomDialogPage',
    {
      titleName: "Neighbourbase",
      bodyTxt:msg,
      okBtnNm: "Ok",
     
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
  modal.onDidDismiss((data) => {
    if (data == "Ok") {
      
    this.navCtrl.push(SelectgroupPage);
    } 
  });

}

  cancel(){
this.navCtrl.push(SelectgroupPage);
  }
 validation_messages = {
  groupName: [{ type: "required", message: "GroupName is required" }],
  groupDetails: [{ type: "required", message: "GroupDetails is required" }],
   
    
  OrgName:[{
      type: "required", message: "Organisation Name is required"
    }
  ],
  address:[{
    type: "required", message: "Address is required"
  }
],
groupType:[
  {type: "required", message: "GroupType is required" }
],
    
   
    
  };

  
presentActionSheet() {
  const modal = this.modalCtrl.create( EditGroupPop,
    {},
    { cssClass: "customModal1" }
  );
  modal.present();
  modal.onDidDismiss((data) => {
    if (data == "1") {
       
      this.imageProcess.AccessCamera().then((res) => {
        this.image = res;
        this.shownoImgflg=false;
        this.convertImgtoBinary(this.image);
        this.uploadphotoFlg=true;
   
      });
      return true;
    } else if (data == "2") {
      this.imageProcess.AccessGallery().then((res) => {
        this.image = res;
        this.shownoImgflg=false;
        this.convertImgtoBinary(this.image);
        this.uploadphotoFlg=true;
       
      });
      return true;
    }
    else if (data == "3") {
      this.imageSrc ="../assets/imgs/NoImg.png";
      this.imgArr=null;
      this.uploadphotoFlg=true;
     
    }
    else if (data == "4") {
   
      this.imgArr=null;
      this.uploadphotoFlg=true;
    
    }
   
  });
}


convertImgtoBinary(image){
  
  console.log("base64",image)
  var raw = window.atob(image);
  console.log("raw",raw)
  var rawLength = raw.length;
  console.log("rawLength",rawLength)
  var array = new Uint8Array(new ArrayBuffer(rawLength));
  console.log("array",array)
  this.imgArr=[];
  for(var i = 0; i < rawLength; i++) {
    array[i] = raw.charCodeAt(i);
    this.imgArr.push(raw.charCodeAt(i));
  }
}

uploadPhotopop(){
  const modal = this.modalCtrl.create(
    'CustomDialogPage',
    {
      titleName: "Upload Photo",
      bodyTxt: "You haven't attached a photo. Do you want to proceed anyway?",
      okBtnNm: "Yes",
      cancelBtnNm:""
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
  modal.onDidDismiss((data) => {
    if (data == "Yes") {
      this.uploadFlg=false;
     this.newgroup();
    } 
   
  });
}
}
 

@Component({
  selector: "edit-group-pop",
  template: `
    <ion-content>
      <ion-label text-center>
        <ion-icon
          ngClass="hdrIcon"
          name="ios-checkmark-circle-outline"
          class="larger"
        ></ion-icon>
        <ion-label ngClass="hdrTxt"
          >Choose your image to upload</ion-label
        >
      </ion-label>
      <ion-row>
        <ion-item>
          <ion-label class="actionItemCls" (click)="btnClick(1)"
            >Capture Image
            <ion-icon
              name="ios-camera-outline"
              class="larger iconCls"
            ></ion-icon>
          </ion-label>
        </ion-item>
      </ion-row>
      <ion-row>
        <ion-item>
          <ion-label class="actionItemCls" (click)="btnClick(2)"
            >Choose from gallery
            <ion-icon
              name="ios-images-outline"
              class="larger iconCls"
            ></ion-icon>
          </ion-label>
        </ion-item>
      </ion-row>

      <ion-row>
      <ion-item>
        <ion-label class="actionItemCls" (click)="btnClick(3)"
          >No Image
         
        </ion-label>
      </ion-item>
    </ion-row>

    <ion-row>
    <ion-item>
      <ion-label class="actionItemCls" (click)="btnClick(4)"
        >Cancel
       
      </ion-label>
    </ion-item>
  </ion-row>

      <ion-row text-center ngClass="btnMainCls">
        <button
          ngClass="btnCls"
          text-center
          ion-button
          color="bright"
          text-capitalize
          text-center
          round
          type="submit"
          (click)="btnClick('Close')"
        >
          Close
        </button>
      </ion-row>
    </ion-content>
  `,
})
export class EditGroupPop{
  unsubscribeBackEvent: any;
  constructor(
    public platform: Platform,
    private ionicApp: IonicApp,
    public viewCtrl: ViewController,

  ) {}
  ionViewWillEnter() {
    this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
      let activePortal=this.ionicApp._modalPortal.getActive();
        if(activePortal){
          activePortal.dismiss();
        } else {
        return true;
      }
    }, 101);
  }
  ionViewWillLeave() {
    this.unsubscribeBackEvent && this.unsubscribeBackEvent();
  }
  btnClick(data: string) {
    this.viewCtrl.dismiss(data);
  }

}
