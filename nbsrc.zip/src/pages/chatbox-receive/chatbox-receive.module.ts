import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChatboxReceivePage } from './chatbox-receive';

@NgModule({
  declarations: [
    ChatboxReceivePage,
  ],
  imports: [
    IonicPageModule.forChild(ChatboxReceivePage),
  ],
})
export class ChatboxReceivePageModule {}
