import { Component } from '@angular/core';
import { IonicPage,ToastController, NavController, NavParams, ViewController, LoadingController, Platform, IonicApp } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from '@ionic/storage';
import { ModalController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MessageboxPage } from '../messagebox/messagebox';
import { DatePipe } from '@angular/common';
import moment from 'moment';
import { THROW_IF_NOT_FOUND } from '@angular/core/src/di/injector';
/**
 * Generated class for the ChatboxReceivePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-chatbox-receive",
  templateUrl: "chatbox-receive.html",
})
export class ChatboxReceivePage {
  rcvList: any;

  requestid: any;
  list: any;
  requestId: any;
  memberId: any;
  requestStatusId: any;
  msgString: any;
  notification: void;

  inputMsg: any;
  Form: FormGroup;
  msg: any;
  listing: any;
  listingnew: any;
  requestlist: any;
  notificationlist: any;
  reqStatusId: any;
  blockedFlg: any;
  unableservFlg: any;
  shareFlg: boolean;
  closeFlg: boolean;
  requesterImage: any;
  reqImage: string;
  imageUrl : any;
  requestName: any;
  showblockFlg: boolean = true;
  getDetails: any;
  lists: any;
  showunblockFlg: boolean;
  reqId: any;
  transType: any;
  loading: any;
  initatePopupWindowflg: boolean;
  reminderFlg: boolean;
  showonestarflg: any = true;
  showtwostarflg: any = true;
  showthreestarflg: any = true;
  showfourstarflg: any = true;
  showfivestarflg: any = true;
  ratefeedback: any;
  recvRating: number;
  issuerFeedbacklist: any;
  receiverRating: any;
  rateFlg: boolean;
  hidesubmitflg: boolean;
  reminderpopFlg: boolean;
  toReturnOn: any;
  sharedOn: any;
  returnOn: any;
  sharedflg: boolean;
  toReturnflg: boolean;
  returnOnflg: boolean;
  saveReminderflg: boolean;
  showBlockMsg: boolean;
  issuerlist: any;
  showReminderIconFlg: boolean = true;
  statusId: any;
  shareBtn: any = "Shared";
  netwrkName: any;
  productImage: any;

  constructor(
    public navCtrl: NavController,
    private formBuilder: FormBuilder,
    public loadingController: LoadingController,
    public modalCtrl: ModalController,
    public storage: Storage,
    public toastController: ToastController,
    public restProvider: RestProvider,
    public navParams: NavParams
  ) {
    this.imageUrl = this.restProvider.imgUrl;
    var Data = this.navParams.get("data");
    this.listing = Data;
    this.statusId = this.navParams.get("reqstatId");
    this.requestlist = this.listing.requestDto;
    this.notificationlist = this.listing.notificationThreadDto;
    this.reqStatusId = this.requestlist[0].requestStatusId;
    this.reqId = this.requestlist[0].requestId;
    this.blockedFlg = this.requestlist[0].blockedFlag;
    this.requesterImage = this.requestlist[0].requesterImage;
    this.requestName = this.requestlist[0].requesterName;
    this.transType = this.requestlist[0].transName;
    this.issuerFeedbacklist = this.requestlist[0].issuerFeedback;
    this.netwrkName = this.requestlist[0].networkName;
    this.productImage = this.requestlist[0].productImage;

    if (this.issuerFeedbacklist != null) {
      this.hidesubmitflg = false;
      this.receiverRating = this.issuerFeedbacklist.receiverRating;
      this.ratefeedback = this.issuerFeedbacklist.remarks;
      this.rateFlg = true;
      if (this.receiverRating != undefined) {
        if (this.receiverRating == 1) {
          this.showonestarflg = false;
        } else if (this.receiverRating == 2) {
          this.showonestarflg = false;
          this.showtwostarflg = false;
        } else if (this.receiverRating == 3) {
          this.showonestarflg = false;
          this.showtwostarflg = false;
          this.showthreestarflg = false;
        } else if (this.receiverRating == 4) {
          this.showonestarflg = false;
          this.showtwostarflg = false;
          this.showthreestarflg = false;
          this.showfourstarflg = false;
        } else if (this.receiverRating == 5) {
          this.showonestarflg = false;
          this.showtwostarflg = false;
          this.showthreestarflg = false;
          this.showfourstarflg = false;
          this.showfivestarflg = false;
        }
      }
    } else {
      this.hidesubmitflg = true;
    }

    if (this.blockedFlg == 0) {
      this.showblockFlg = true;
      this.showBlockMsg = false;
      if (this.reqStatusId == 5) {
        this.showReminderIconFlg = true;
        this.unableservFlg = false;
        this.shareFlg = false;
        this.closeFlg = true;
      } else if (this.reqStatusId == 7) {
        //this.showReminderIconFlg=true;
        this.unableservFlg = false;
        this.shareFlg = false;
        this.closeFlg = false;
        const modal = this.modalCtrl.create(
          RatingPopup,
          { reqid: this.reqId },
          { cssClass: "customModal1", enableBackdropDismiss: false }
        );
        modal.present();
        modal.onDidDismiss((data) => {
          if (data != undefined) {
            if (data.receiverflg) {
              //this.navCtrl.push(MessageboxPage,{cancelreqflg:false});
              this.navCtrl.pop();
              
            }
          }
        });
        // this.initatePopupWindowflg=true;
      } else {
        this.showReminderIconFlg = false;
        // this.reminderFlg=false;
        this.shareFlg = true;
        this.closeFlg = false;
        this.unableservFlg = true;
      }
      if (this.transType == "Gift") {
        this.showReminderIconFlg = false;
        //this.reminderFlg=false;
        this.shareFlg = false;
        this.closeFlg = true;
      }
      if ( this.transType == "Sell") {
        this.showReminderIconFlg = false;
        //this.reminderFlg=false;
       this.shareBtn="Sold"
      }
      if (
        this.requesterImage == null ||
        this.requesterImage == "No Image" ||
        this.requesterImage == ""
      ) {
        this.reqImage = "../assets/imgs/NoImg.png";
      } else {
        this.reqImage = this.imageUrl + this.requesterImage;
      }
    } else {
      if (
        this.requesterImage == null ||
        this.requesterImage == "No Image" ||
        this.requesterImage == ""
      ) {
        this.reqImage = "../assets/imgs/NoImg.png";
      } else {
        this.reqImage = this.imageUrl + this.requesterImage;
      }
      this.showblockFlg = false;
      this.showBlockMsg = true;
    }

    this.Form = this.formBuilder.group({
      inputMsg: ["", [Validators.required]],
    });
  }
  displayMsg(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  ionViewDidLoad() {
    //this.getIssuerNote();
    console.log("ionViewDidLoad ChatboxReceivePage");
  }
  async ngOnInit() {
    this.getDetails = await this.storage.get("memberDetails");
    console.log(this.getDetails.memberId);
  }
  goBack() {
    this.navCtrl.pop();
  }

  rating1() {
    this.showonestarflg = false;
    this.recvRating = 1;
  }
  rating2() {
    this.showtwostarflg = false;
    this.recvRating = 2;
  }
  rating3() {
    this.showthreestarflg = false;
    this.recvRating = 3;
  }
  rating4() {
    this.showfourstarflg = false;
    this.recvRating = 4;
  }
  rating5() {
    this.showfivestarflg = false;
    this.recvRating = 5;
  }

  submitfeedback() {
    if (this.ratefeedback != undefined) {
      var data: any;
      data = {
        receiverRating: this.recvRating,
        remarks: this.ratefeedback,
        requestId: this.reqId,
      };
      console.log("reqdata", data);
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
      this.restProvider
        .sendissuerfeedback(data, this.getDetails.memberId)
        .then((data) => {
          console.log("data", data);
          var result: any = data;

          if (result != null) {
          } else {
            this.displayMsg("Please try again later");
          }
          this.loading.dismiss();
        })
        .catch((error) => {
          console.log("error", error);
          this.loading.dismiss();
          this.displayMsg("Please try again later");
        });
    } else {
      this.displayAlert();
    }
  }

  displayAlert() {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        titleName: "Warning",
        bodyTxt: "Please give rating!",
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Ok") {
      }
    });
  }
  sendMessage() {
    if (this.Form.valid) {
      if (this.inputMsg == " ") {
        this.inputMsg = this.inputMsg.replace(" ", "%20");
      }

      this.send(
        this.inputMsg,
        this.reqId,
        1,
        this.reqStatusId,
        this.getDetails.memberId
      );
    }
  }

  send(msg, requestId, ownerflg, requestStatusId, memberId) {
    this.restProvider
      .OwnerMsgfromReceived(
        msg,
        this.reqId,
        ownerflg,
        requestStatusId,
        memberId
      )
      .then((data) => {
        var result: any = data;
        var sts = result.status;
        this.listing = result;

        if (result != null && sts == "success") {
          this.notificationlist = result.notificationThreadDto;
          //this.showReminderIconFlg=false;
          this.inputMsg = "";
          console.log("success");
        }
      })
      .catch((error) => {
        this.displayMsg("Please try again later");
      });
  }

  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }

  block() {
    this.restProvider
      .blockMember(this.reqId, this.getDetails.memberId)
      .then((data) => {
        console.log("res", data);
        var result: any = data;

        if (result == "success") {
          this.showBlockMsg = true;
          //this.getChatMessage();
          this.showblockFlg = false;
        }
      })
      .catch((error) => {
        console.log("error", error);
        this.displayMsg("Please try again later");
      });
  }
  getChatMessage() {
    this.restProvider
      .chatReceive(this.reqId)
      .then((data) => {
        var result: any = data;
        var sts = result.status;
        this.listing = result;
        console.log(result);

        if (result != null && sts == "success") {
          this.requestlist = this.listing.requestDto;
          this.notificationlist = this.listing.notificationThreadDto;
          this.reqStatusId = this.requestlist[0].requestStatusId;
          this.blockedFlg = this.requestlist[0].blockedFlag;
          this.requesterImage = this.requestlist[0].requesterImage;
          this.requestName = this.requestlist[0].requesterName;
          this.transType = this.requestlist[0].transName;

          if (this.blockedFlg == 0) {
            this.showblockFlg = true;
            this.showBlockMsg = false;

            if (this.reqStatusId == 5) {
              this.unableservFlg = false;
              this.shareFlg = false;
              this.closeFlg = true;
              this.showReminderIconFlg = true;
            } else if (this.reqStatusId == 7) {
              this.unableservFlg = false;
              this.shareFlg = false;
              this.closeFlg = false;
              // this.showReminderIconFlg=true;
            } else {
              this.showReminderIconFlg = false;
              this.shareFlg = true;
              this.closeFlg = false;
            }
            if (this.transType == "Gift" ) {
              this.showReminderIconFlg = false;
              this.shareFlg = false;
              this.closeFlg = true;
            }
             if (this.transType == "Sell") {
               this.showReminderIconFlg = false;
               //this.reminderFlg=false;
               this.shareBtn = "Sold";
             }
            if (
              this.requesterImage == null ||
              this.requesterImage == "No Image" ||
              this.requesterImage == ""
            ) {
              this.reqImage = "../assets/imgs/NoImg.png";
            } else {
              this.reqImage = this.imageUrl + this.requesterImage;
            }
          } else {
            if (
              this.requesterImage == null ||
              this.requesterImage == "No Image" ||
              this.requesterImage == ""
            ) {
              this.reqImage = "../assets/imgs/NoImg.png";
            } else {
              this.reqImage = this.imageUrl + this.requesterImage;
            }
            this.showblockFlg = false;
            this.showBlockMsg = true;
          }
        }
      })
      .catch((error) => {
        this.displayMsg("Please try again later");
      });
  }
  getIssuerNote() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    this.restProvider
      .getIssuerNote(this.reqId)
      .then((data) => {
        console.log("res", data);
        var result: any = data;
        //var sts =result.status;
        console.log("sid", this.statusId);
        if (result != null && result.length > 2) {
          this.issuerlist = result;
          this.reminderPopupWindow(this.statusId, this.issuerlist);
        } else {
          this.issuerlist = result;
          this.reminderPopupWindow(this.statusId, this.issuerlist);
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.displayMsg("Please try again later");
        this.loading.dismiss();
      });
  }
  unblock() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    this.restProvider
      .chatunBlock(this.reqId, this.getDetails.memberId)
      .then((data) => {
        console.log("res", data);
        var result: any = data;
        var sts = result.status;

        if (result != null && result == "success") {
          console.log("success");
          this.getChatMessage();
          this.showBlockMsg = false;
          this.showblockFlg = true;
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.displayMsg("Please try again later");
        this.loading.dismiss();
      });
  }
  unabletoservice() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    this.restProvider
      .unabletoServiceReq(this.reqId, this.getDetails.memberId)
      .then((data) => {
        console.log("succeed");
        var result: any = data;
        var sts = result.status;

        if (result != null && sts == "success") {
          console.log("success");
          this.navCtrl.pop();
          
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        this.loading.dismiss();
        this.displayMsg("Please try again later");
      });
  }
  unableToServe() {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        titleName: "Unable to service",
        bodyTxt: "Are you sure you don’t want to service this request?",
        okBtnNm: "Yes",
        cancelBtnNm: "No",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Yes") {
        this.unabletoservice();
      } else if (data == "No") {
      }
    });
  }
  shared() {
    this.reqStatusId = 5;
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    this.restProvider
      .shareReq(this.reqId, this.reqStatusId, this.getDetails.memberId)
      .then((data) => {
        console.log("success");
        var result: any = data;
        var sts = result.status;

        if (result != null && sts == "success") {
          this.listing = result;
          this.notificationlist = this.listing.notificationThreadDto;
          if (this.reqStatusId == 7) {
            const modal = this.modalCtrl.create(
              RatingPopup,
              { reqid: this.reqId },
              { cssClass: "customModal1", enableBackdropDismiss: false }
            );
            modal.present();
            modal.onDidDismiss((data) => {
              if (data != undefined) {
                if (data.receiverflg) {
                  // this.navCtrl.push(MessageboxPage,{cancelreqflg:false});
                    this.navCtrl.pop();
                  
                }
              }
            });
          } else if (this.reqStatusId == 5) {
            if (this.transType == "Gift" || this.transType == "Sell") {
            } else {
              this.reminderPopupWindow(this.reqStatusId, this.issuerlist);
              //this.reminderpopFlg=true;
            }
          }
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        this.loading.dismiss();
        this.displayMsg("Please try again later");
      });
  }
  editReminderIcon() {
    this.getIssuerNote();
    /*if(this.issuerlist!=undefined){
    this.reminderPopupWindow(this.reqStatusId,this.issuerlist);
  }*/
    console.log("reqid", this.reqStatusId, this.issuerlist);
  }
  reminderPopupWindow(reqstatusid, issuerdata) {
    const modal = this.modalCtrl.create(
      ReminderPopup,
      { reqid: this.reqId, reqstatusid: reqstatusid, issuerdata: issuerdata },
      { cssClass: "customModal1", enableBackdropDismiss: false },
      
    );
    modal.present();
    modal.onDidDismiss((data) => {
       this.navCtrl.pop();
      // this.navCtrl.setRoot(MessageboxPage);
    });
    /*if(this.reqStatusId == 5){
this.sharedflg=true;
this.toReturnflg=false;
this.returnOnflg=true;
}
else if(this.reqStatusId == 7){
  this.sharedflg=true;
this.toReturnflg=true;
  this.returnOnflg=false;
  this.saveReminderflg=true;
}
else{
  this.sharedflg=false;
  this.toReturnflg=false;
  this.returnOnflg=true;
}*/
  }
  close() {
    this.reqStatusId = 7;
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    this.restProvider
      .shareReq(this.reqId, this.reqStatusId, this.getDetails.memberId)
      .then((data) => {
        console.log("success");
        var result: any = data;
        var sts = result.status;

        if (result != null && sts == "success") {
          this.listing = result;
          this.notificationlist = this.listing.notificationThreadDto;
          if (this.reqStatusId == 7) {
            const modal = this.modalCtrl.create(
              RatingPopup,
              { reqid: this.reqId },
              { cssClass: "customModal1", enableBackdropDismiss: false }
            );
            modal.present();
            modal.onDidDismiss((data) => {
              if (data != undefined) {
                if (data.receiverflg) {
                  //this.navCtrl.push(MessageboxPage,{cancelreqflg:false});
                  this.navCtrl.pop();
                  //this.navCtrl.push(MessageboxPage, { cancelreqflg: false });
                }
              }
            });
          } else if (this.reqStatusId == 5) {
            if (this.transType == "Gift" || this.transType == "Sell") {
            } else {
              this.reminderPopupWindow(this.reqStatusId, null);
              //this.reminderpopFlg=true;
            }
          }
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        this.loading.dismiss();
        this.displayMsg("Please try again later");
      });
  }
}
@Component({
  selector: "page-chatbox-receive",
  template: `
    <ion-header no-border>
      <ion-toolbar>
        <ion-title>
          <img
            src="assets/imgs/logo.png"
            height="30dp"
            style="padding-top: 5px;"
          />
        </ion-title>

        <ion-buttons end>
          <button ion-button icon-only (click)="closeModal()">
            <ion-icon name="ios-close" style="color: black;"></ion-icon>
          </button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>
    <ion-content>
      <ion-label text-center>
        <ion-label>Set Reminder</ion-label>
      </ion-label>
      <ion-label text-center style="font-size:12px;color:grey;">
        Maintain sharing details to get timely reminders
      </ion-label>
      <ion-row>
        <ion-item>
          <ion-label style="font-size:14px;">Shared On:</ion-label>
          <ion-datetime
            style="font-size:14px;"
            displayFormat="DD/MM/YYYY"
            [disabled]="sharedOnflg"
            [(ngModel)]="sharedOn"
          ></ion-datetime>
        </ion-item>

        <ion-item>
          <ion-label style="font-size:14px;">To be Returned on:</ion-label>
          <ion-datetime
            style="font-size:14px;"
            displayFormat="DD/MM/YYYY"
            [disabled]="toReturnOnflg"
            [(ngModel)]="toReturnOn"
          ></ion-datetime>
        </ion-item>

        <ion-item>
          <ion-label style="font-size:14px;">Returned on:</ion-label>
          <ion-datetime
            style="font-size:14px;"
            displayFormat="DD/MM/YYYY"
            [disabled]="returnOnflg"
            [(ngModel)]="returnOn"
          ></ion-datetime>
        </ion-item>
      </ion-row>

      <ion-row>
        <ion-col text-center>
          <button
            *ngIf="saveReminderflg"
            ion-button
            text-center
            color="bright"
            (click)="save()"
          >
            <span
              text-capitalize
              ion-text
              style="color:rgba(255,255,255,1);font-size:1.4rem;"
              >Save</span
            >
          </button>
        </ion-col>
      </ion-row>
    </ion-content>
  `,
})
export class ReminderPopup {
  sharedflg: boolean;
  toReturnflg: boolean;
  returnOnflg: boolean;
  saveReminderflg: boolean = true;
  toReturnOn: any;
  sharedOn: any;
  returnOn: any;
  reqId: any;
  reqstatusid: any;
  sharedOnflg: any;
  toReturnOnflg: any;
  loading1: any;
  loading: any;
  issuerData: any;
  receiverDto: any;
  issuerNoteId: any = 0;

  ownerRemdata: any;
  unsubscribeBackEvent: any;

  constructor(
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public loadingController: LoadingController,
    public restProvider: RestProvider,
    public toastController: ToastController,
    public modalCtrl: ModalController,
    public datepipe: DatePipe,
    public platform: Platform,
    private ionicApp: IonicApp
  ) {
    //let sharedDate= new Date().toISOString();
    // this.sharedOn=sharedDate;
    this.reqId = this.navParams.get("reqid");
    this.reqstatusid = this.navParams.get("reqstatusid");
    this.issuerData = this.navParams.get("issuerdata");
    console.log("issuerData", this.issuerData, this.reqstatusid);
    console.log("reqstatusid", this.reqstatusid);
    if (
      this.issuerData != null &&
      this.issuerData != undefined &&
      this.issuerData != ""
    ) {
      this.issuerNoteId = this.issuerData.issuerNoteId;
    }

    if (
      this.reqstatusid == 5 &&
      this.issuerData != null &&
      this.issuerData.sharedOnStr != null &&
      this.issuerData.sharedOnStr != ""
    ) {
      this.sharedOnflg = true;
      this.toReturnOnflg = false;
      this.returnOnflg = true;
    } else if (this.reqstatusid == 7) {
      this.sharedOnflg = true;
      this.toReturnOnflg = true;
      this.returnOnflg = false;
      this.saveReminderflg = true;
    } else {
      this.sharedOnflg = false;
      this.toReturnOnflg = false;
      this.returnOnflg = true;
    }
    if (
      this.issuerData != null &&
      this.issuerData.sharedOnStr != null &&
      this.issuerData.sharedOnStr != ""
    ) {
      //this.sharedOn=this.issuerData.sharedOnStr;
      let sharedDate = new Date(this.issuerData.sharedOn).toISOString();
      this.sharedOn = sharedDate;
      //this.sharedOn= moment(new Date(this.sharedOn)).format('DD/MM/YYYY');
      console.log("sharedOn", this.sharedOn);
    }
    if (
      this.issuerData != null &&
      this.issuerData.returnByStr != null &&
      this.issuerData.returnByStr != ""
    ) {
      //this.toReturnOn=this.issuerData.returnByStr;

      let returnDate = new Date(this.issuerData.returnBy).toISOString();
      this.toReturnOn = returnDate;

      //this.toReturnOn= moment(this.toReturnOn).format('DD/MM/YYYY');
      console.log("toReturnOn", this.toReturnOn);
    }
  }
  closeModal() {
    this.viewCtrl.dismiss(null);
  }

  btnClick(data: string) {
    this.viewCtrl.dismiss(data);
  }
  ionViewWillEnter() {
    this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
      let activePortal = this.ionicApp._modalPortal.getActive();
      if (activePortal) {
        activePortal.dismiss();
      } else {
        return true;
      }
    }, 101);
  }
  ionViewWillLeave() {
    this.unsubscribeBackEvent && this.unsubscribeBackEvent();
  }
  save() {
    this.sharedOn = moment(this.sharedOn).format("DD/MM/YYYY");
    console.log("sharedOn", this.sharedOn);
    this.toReturnOn = moment(this.toReturnOn).format("DD/MM/YYYY");
    console.log("toReturnOn", this.toReturnOn);

    if (this.sharedOn != undefined && this.toReturnOn != undefined) {
      this.ownerRemdata = {
        requestId: this.reqId,
        sharedOnStr: this.sharedOn,
        returnByStr: this.toReturnOn,
        returnOnStr: "",
        issuerNoteId: this.issuerNoteId,
      };
      this.updateNote();
      /*if(this.receiverDto!=null ){
        this.receiverDto.receiverNoteId=this.receiverDto.receiverNoteId;
      }
      else{
        
      }
     this.loading1 = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading1.present();
      var recdata:any;
     if(this.receiverDto!=null){
      recdata={
        receiverNoteId:this.receiverDto.receiverNoteId,
        requestId:this.reqId,
        returnByStr:this.toReturnOn,
        sharedOnStr:this.sharedOn,
        returnOnStr:""
      }
     }
     else{
      recdata={
        receiverNoteId:0,
        requestId:this.reqId,
        returnByStr:this.toReturnOn,
        sharedOnStr:this.sharedOn,
        returnOnStr:""
      }
     }
     console.log("recdata",recdata);
     this.updateNote();
      /*this.restProvider
      .createReminder(recdata)
      .then( (data) => { 
        console.log("data",data);
        var result : any = data;
       
       
        if(result!=null )
        {
      if(result =="Success"){
        this.updateNote();
      }
      else{
        this.displayMsg("Reminder not saved, Please try after sometime");
      }
     
       
        }
        this.loading1.dismiss();
      })
      .catch(error => {
        console.log("error",error);
        this.loading1.dismiss();
        this.displayMsg("Please try again later");
      });*/
    }
  }
  displayMsg(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }

  updateNote() {
    /*this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
      var data:any;
      data={
        requestId:this.reqId,
        sharedOnStr:this.sharedOn,
        returnByStr:this.toReturnOn,
        returnOnStr:""
      }*/
    this.restProvider
      .updateReminder(this.ownerRemdata)
      .then((data) => {
        console.log("data", data);
        var result: any = data;

        if (result != null) {
          if (result == "Success") {
            this.viewCtrl.dismiss();
            this.displayMsg("A reminder is set up to help you follow up later");
          } else {
            this.displayMsg("Reminder not saved, Please try after sometime");
            this.viewCtrl.dismiss();
          }
        }
        //this.loading.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        //this.loading.dismiss();
        this.displayMsg("Please try again later");
      });
  }
  displayAlert() {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        titleName: "",
        bodyTxt: "Reminder not saved, Please try after sometime!",
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Ok") {
      }
    });
  }
}

@Component({
  selector: "request-success-pop",
  template: `
    <ion-header no-border>
      <ion-toolbar class="headerCls">
        <ion-title>
          <img
            src="assets/imgs/logo_white.png"
            height="30dp"
            style="padding-top: 5px;"
          />
        </ion-title>
      </ion-toolbar>
    </ion-header>
    <ion-content padding>
      <ion-label text-center>
        <ion-label text-wrap
          >If you use this item, tell us your experience.</ion-label
        >
      </ion-label>

      <ion-row style="margin-top:10px">
        <ion-label style="margin:0px"> Rate Borrower/Buyer </ion-label>

        <ion-icon
          name="ios-star-outline"
          *ngIf="showonestarflg"
          (click)="rating1()"
        ></ion-icon>
        <ion-icon
          name="ios-star"
          *ngIf="!showonestarflg"
          style="color:red"
          (click)="uncheckRating1()"
        ></ion-icon>

        <ion-icon
          name="ios-star-outline"
          *ngIf="showtwostarflg"
          (click)="rating2()"
        ></ion-icon>
        <ion-icon
          name="ios-star"
          *ngIf="!showtwostarflg"
          style="color:red"
          (click)="uncheckRating2()"
        ></ion-icon>

        <ion-icon
          name="ios-star-outline"
          *ngIf="showthreestarflg"
          (click)="rating3()"
        ></ion-icon>
        <ion-icon
          name="ios-star"
          *ngIf="!showthreestarflg"
          style="color:red"
          (click)="uncheckRating3()"
        ></ion-icon>

        <ion-icon
          name="ios-star-outline"
          *ngIf="showfourstarflg"
          (click)="rating4()"
        ></ion-icon>
        <ion-icon
          name="ios-star"
          *ngIf="!showfourstarflg"
          style="color:red"
          (click)="uncheckRating4()"
        ></ion-icon>

        <ion-icon
          name="ios-star-outline"
          *ngIf="showfivestarflg"
          (click)="rating5()"
        ></ion-icon>
        <ion-icon
          name="ios-star"
          *ngIf="!showfivestarflg"
          style="color:red"
        ></ion-icon>
        <ion-label
          style="background-color:red;margin-left:5px;margin-top:0px;margin-bottom:0px;padding:5px;color:white; min-width: 40px !important;
        max-width: 40px !important;"
          >{{ recvRating }}/5</ion-label
        >
      </ion-row>
      <ion-label>Review Borrower/ Buyer</ion-label>
      <ion-item style="border:thin solid #afaeae">
        <ion-input
          style="font-size:14px;"
          [(ngModel)]="ratefeedback"
          type="text"
          [disabled]="rateFlg"
          placeholder="your review"
        ></ion-input>
      </ion-item>

      <ion-row >
      <ion-col col-12 text-center>
       <button
          class="btn3"
          *ngIf="hidesubmitflg"
          ion-button
          
          text-center
          color="bright"
          (click)="submitfeedback()"
        >
          <span
            text-capitalize
            ion-text
            style="color:rgba(255,255,255,1);font-size:1.4rem;"
            >Submit</span
          >
        </button>
      </ion-col>
       
      </ion-row>

     
    </ion-content>
  `,
})
export class RatingPopup {
  reqId: any;
  loading: any;
  showonestarflg: any = true;
  showtwostarflg: any = true;
  showthreestarflg: any = true;
  showfourstarflg: any = true;
  showfivestarflg: any = true;
  ratefeedback: any;
  recvRating: number = 0;
  getDetails: any;
  hidesubmitflg: boolean = true;
  unsubscribeBackEvent: Function;
  constructor(
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public loadingController: LoadingController,
    public restProvider: RestProvider,
    public storage: Storage,
    public modalCtrl: ModalController,
    public toastController: ToastController,
    public platform: Platform,
    private ionicApp: IonicApp
  ) {
    this.reqId = this.navParams.get("reqid");
  }

  btnClick(data: string) {
    this.viewCtrl.dismiss(data);
  }
  /*ionViewWillEnter() {
    this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
      let activePortal=this.ionicApp._modalPortal.getActive();
        if(activePortal){
          activePortal.dismiss();
        } else {
        return true;
      }
    }, 101);
  }
  ionViewWillLeave() {
    this.unsubscribeBackEvent && this.unsubscribeBackEvent();
  }*/
  submitfeedback() {
    if (this.recvRating != undefined && this.ratefeedback != undefined) {
      var data: any;
      data = {
        receiverRating: this.recvRating,
        remarks: this.ratefeedback,
        requestId: this.reqId,
      };
      console.log("reqdata", data);
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
      this.restProvider
        .sendissuerfeedback(data, this.getDetails.memberId)
        .then((data) => {
          console.log("data", data);
          var result: any = data;

          if (result != null) {
            this.viewCtrl.dismiss({ receiverflg: true });
          } else {
            this.displayMsg("Please try again later");
          }
          this.loading.dismiss();
        })
        .catch((error) => {
          console.log("error", error);
          this.loading.dismiss();
          this.displayMsg("Please try again later");
        });
    } else {
      this.displayAlert();
    }
  }

  async ngOnInit() {
    this.getDetails = await this.storage.get("memberDetails");
    console.log(this.getDetails.memberId);
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }
  rating1() {
    this.showonestarflg = false;
    this.recvRating = 1;
    console.log(this.recvRating);
  }
  rating2() {
    this.showonestarflg = false;
    this.showtwostarflg = false;
    this.recvRating = 2;
    console.log(this.recvRating);
  }
  rating3() {
    this.showonestarflg = false;
    this.showtwostarflg = false;
    this.showthreestarflg = false;
    this.recvRating = 3;
    console.log(this.recvRating);
  }
  rating4() {
    this.showonestarflg = false;
    this.showtwostarflg = false;
    this.showthreestarflg = false;
    this.showfourstarflg = false;
    this.recvRating = 4;
    console.log(this.recvRating);
  }
  rating5() {
    this.showonestarflg = false;
    this.showtwostarflg = false;
    this.showthreestarflg = false;
    this.showfourstarflg = false;
    this.showfivestarflg = false;
    this.recvRating = 5;
    console.log(this.recvRating);
  }
  uncheckRating1() {
    this.showonestarflg = false;
    this.showtwostarflg = true;
    this.showthreestarflg = true;
    this.showfourstarflg = true;
    this.showfivestarflg = true;
    this.recvRating = 1;
    console.log(this.recvRating);
  }
  uncheckRating2() {
    this.showonestarflg = false;
    this.showtwostarflg = false;
    this.showthreestarflg = true;
    this.showfourstarflg = true;
    this.showfivestarflg = true;
    this.recvRating = 2;
    console.log(this.recvRating);
  }
  uncheckRating3() {
    this.showonestarflg = false;
    this.showtwostarflg = false;
    this.showthreestarflg = false;
    this.showfourstarflg = true;
    this.showfivestarflg = true;
    this.recvRating = 3;
    console.log(this.recvRating);
  }
  uncheckRating4() {
    this.showonestarflg = false;
    this.showtwostarflg = false;
    this.showthreestarflg = false;
    this.showfourstarflg = false;
    this.showfivestarflg = true;
    this.recvRating = 4;
    console.log(this.recvRating);
  }

  displayAlert() {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        titleName: "Warning",
        bodyTxt: "Please give rating and Feedback!",
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Ok") {
      }
    });
  }
  displayMsg(msg) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: msg,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Ok") {
      }
    });
  }
}



      



      