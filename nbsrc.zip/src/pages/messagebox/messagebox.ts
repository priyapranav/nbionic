import { Component } from '@angular/core';
import { IonicPage, LoadingController, NavController, NavParams, ModalController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { ToastController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { ChatboxReceivePage } from '../chatbox-receive/chatbox-receive';
import { ChatboxSendPage } from '../chatbox-send/chatbox-send';


/**
 * Generated class for the MessageboxPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-messagebox",
  templateUrl: "messagebox.html",
})
export class MessageboxPage {
  messageBox = "requestreceived";
  loading: any;
  imgUrl: any;
  rcvFlg: boolean = false;
  sntFlg: boolean = false;
  memberId: any;
  receiveList: any;
  sentList: any;
  lists: any;
  list: any;
  cancelreqflg: boolean;
  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    public navParams: NavParams,
    public toastController: ToastController,
    public restProvider: RestProvider,
    public loadingController: LoadingController,
    private storage: Storage
  ) {
    this.imgUrl = this.restProvider.imgUrl;
    this.cancelreqflg = this.navParams.get("cancelreqflg");
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }

  ionViewWillEnter() {
     if (this.cancelreqflg) {
       this.sentMessage();
       this.messageBox = "requestsent";
     } else {
       this.receiveMessage();
       this.messageBox = "requestreceived";
     }
    
  }
  // ionViewDidLoad() {
  //   console.log("ionViewDidLoad MessageboxPage");
  //   if (this.cancelreqflg) {
  //     this.sentMessage();
  //     this.messageBox = "requestsent";
  //   } else {
  //     this.receiveMessage();
  //   }
  // }

  messageRcv() {
    this.receiveMessage();
  }
  receiveMessage() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    this.storage.get("memberId").then((val) => {
      this.memberId = val;

      this.restProvider
        .messagercv(this.memberId)
        .then((data) => {
          var result: any = data;
          var sts = result.status;
          this.receiveList = result.requestDto;

          if (result != null && sts == "success") {
            this.loading.dismiss();
            if (this.receiveList.length > 0) {
              this.rcvFlg = true;
            } else {
              this.rcvFlg = false;
            }
          } else {
            this.loading.dismiss();
            this.displayAlert("Please try again later");
          }
        })
        .catch((error) => {
          this.loading.dismiss();
          this.displayAlert("Please try again later");
        });
    });
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }

  messageSnt() {
    this.sentMessage();
  }

  sentMessage() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    this.storage.get("memberId").then((val) => {
      this.memberId = val;

      this.restProvider
        .messagesnt(this.memberId)
        .then((data) => {
          var result: any = data;
          var sts = result.status;
          this.sentList = result.requestDto;

          if (result != null && sts == "success") {
            this.loading.dismiss();
            if (this.sentList.length > 0) {
              this.sntFlg = true;
            } else {
              this.sntFlg = false;
            }
          } else {
            this.loading.dismiss();
            this.displayAlert("Please try again later");
          }
        })
        .catch((error) => {
          this.loading.dismiss();
          this.displayAlert("Please try again later");
        });
    });
  }

  chatboxRcv(image, reqid) {
    var image = image;
    var reqId = reqid;
    this.receiveChat(image, reqId);
  }

  receiveChat(image, requestid) {
    this.restProvider
      .chatReceive(requestid)
      .then((data) => {
        var result: any = data;
        var sts = result.status;
        this.lists = result;
        console.log(result);

        if (result != null && sts == "success") {
          this.navCtrl.push(ChatboxReceivePage, {
            data: this.lists,
            reqstatId: this.lists.requestDto[0].requestStatusId,
          });
          console.log(result);

          console.log("success");
        }
      })
      .catch((error) => {
        this.displayAlert("Please try again later");
      });
  }

  chatboxSnt(image, reqid) {
    var image = image;
    var reqId = reqid;
    this.SendChat(image, reqId);
  }

  SendChat(image, requestid) {
    this.restProvider
      .chatSent(requestid)
      .then((data) => {
        var result: any = data;
        var sts = result.status;
        this.list = result;
        console.log(result);

        if (result != null && sts == "success") {
          this.navCtrl.push(ChatboxSendPage, { data: this.list });
          console.log(result);

          console.log("success");
        }
      })
      .catch((error) => {
        this.displayAlert("Please try again later");
      });
  }
}