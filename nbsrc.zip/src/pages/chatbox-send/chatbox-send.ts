import { Component } from '@angular/core';
import { IonicPage,ToastController, NavController, NavParams, ViewController, LoadingController, Platform, IonicApp } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from '@ionic/storage';
import { ModalController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MessageboxPage } from '../messagebox/messagebox';
import moment from 'moment';
/**
 * Generated class for the ChatboxReceivePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-chatbox-send",
  templateUrl: "chatbox-send.html",
})
export class ChatboxSendPage {
  rcvList: any;

  requestid: any;
  list: any;
  requestId: any;
  memberId: any;
  requestStatusId: any;
  msgString: any;
  notification: void;
  DisableBtn: boolean;
  inputMsg: any;
  Form: FormGroup;
  msg: any;
  listing: any;
  requestlist: any;
  notificationlist: any;
  reqStatusId: any;
  requesterImage: any;
  requestName: any;
  reqImage: string;
  imageUrl: any;
  blockedFlg: any;
  showblockFlg: boolean;
  getDetails: any;
  reqId: any;
  unableservFlg: any;
  closeFlg: boolean;
  deleteFlg: boolean;
  shareFlg: any;
  loading: any;
  transType: any;
  reminderFlg: boolean;
  showreceiverPopupFlg: boolean;
  productfeedback: any;
  ownerfeedback: any;
  showonestarflg: any = true;
  showtwostarflg: any = true;
  showthreestarflg: any = true;
  showfourstarflg: any = true;
  showfivestarflg: any = true;
  ownershowonestarflg: any = true;
  ownershowtwostarflg: any = true;
  ownershowthreestarflg: any = true;
  ownershowfourstarflg: any = true;
  ownershowfivestarflg: any = true;
  issuerRating: any;
  productRating: any;
  receiverfeedbacklist: any;
  hidesubmitflg: boolean;
  ownerfeedflg: any = false;
  prodfeedflg: any = false;
  initatePopupWindowflg: boolean;
  buyershowonestarflg: any = true;
  buyershowtwostarflg: any = true;
  buyershowthreestarflg: any = true;
  buyershowfourstarflg: any = true;
  buyershowfivestarflg: any = true;
  buyerRating: number;
  ratefeedback: any;
  reminderpopFlg: boolean;
  toReturnOn: any;
  sharedOn: any;
  returnOn: any;
  sharedflg: boolean;
  toReturnflg: boolean;
  returnOnflg: boolean;
  saveReminderflg: boolean;
  receiverList: any;
  showReminderIconFlg: any;
  productImg: any;
  proImage: any;
  proName: any;
  netwrkName: any;
  constructor(
    public navCtrl: NavController,
    private formBuilder: FormBuilder,
    public modalCtrl: ModalController,
    public storage: Storage,
    public loadingController: LoadingController,
    public toastController: ToastController,
    public restProvider: RestProvider,
    public navParams: NavParams
  ) {
    this.imageUrl = this.restProvider.imgUrl;
    var Data = this.navParams.get("data");
    this.listing = Data;
    this.requestlist = this.listing.requestDto;
    this.notificationlist = this.listing.notificationThreadDto;
    this.reqStatusId = this.requestlist[0].requestStatusId;
    this.reqId = this.requestlist[0].requestId;
    this.requesterImage = this.requestlist[0].ownerImage;
    this.productImg = this.requestlist[0].productImage;
    this.proName = this.requestlist[0].productName;
    this.requestName = this.requestlist[0].ownerName;
    this.blockedFlg = this.requestlist[0].blockedFlag;
    this.transType = this.requestlist[0].transName;
     this.netwrkName = this.requestlist[0].networkName;

    if (
      this.productImg == null ||
      this.productImg == "No Image" ||
      this.productImg == ""
    ) {
      this.proImage = "../assets/imgs/NoImg.png";
    } else {
      this.proImage = this.imageUrl + this.productImg;
    }

    this.receiverfeedbacklist = this.requestlist[0].receiverFeedback;
    if (this.receiverfeedbacklist != null) {
      this.issuerRating = this.receiverfeedbacklist.issuerRating;
      this.ownerfeedback = this.receiverfeedbacklist.issuerRemarks;
      this.productRating = this.receiverfeedbacklist.productRating;
      this.productfeedback = this.receiverfeedbacklist.productRemarks;
      this.hidesubmitflg = false;
      this.ownerfeedflg = true;
      this.prodfeedflg = true;
      if (this.issuerRating != undefined) {
        if (this.issuerRating == 1) {
          this.ownershowonestarflg = false;
        } else if (this.issuerRating == 2) {
          this.ownershowonestarflg = false;
          this.ownershowtwostarflg = false;
        } else if (this.issuerRating == 3) {
          this.ownershowonestarflg = false;
          this.ownershowtwostarflg = false;
          this.ownershowthreestarflg = false;
        } else if (this.issuerRating == 4) {
          this.ownershowonestarflg = false;
          this.ownershowtwostarflg = false;
          this.ownershowthreestarflg = false;
          this.ownershowfourstarflg = false;
        } else if (this.issuerRating == 5) {
          this.ownershowonestarflg = false;
          this.ownershowtwostarflg = false;
          this.ownershowthreestarflg = false;
          this.ownershowfourstarflg = false;
          this.ownershowfivestarflg = false;
        }
      }

      if (this.productRating != undefined) {
        if (this.productRating == 1) {
          this.showonestarflg = false;
        } else if (this.productRating == 2) {
          this.showonestarflg = false;
          this.showtwostarflg = false;
        } else if (this.productRating == 3) {
          this.showonestarflg = false;
          this.showtwostarflg = false;
          this.showthreestarflg = false;
        } else if (this.productRating == 4) {
          this.showonestarflg = false;
          this.showtwostarflg = false;
          this.showthreestarflg = false;
          this.showfourstarflg = false;
        } else if (this.productRating == 5) {
          this.showonestarflg = false;
          this.showtwostarflg = false;
          this.showthreestarflg = false;
          this.showfourstarflg = false;
          this.showfivestarflg = false;
        }
      }
    } else {
      this.hidesubmitflg = true;
    }

    this.showblockFlg = false;
    if (this.reqStatusId == 5) {
      if (this.transType == "Gift" || this.transType == "Sell") {
        this.showReminderIconFlg = false;
      } else {
        this.showReminderIconFlg = true;
      }
      this.unableservFlg = false;
      this.closeFlg = true;
      this.deleteFlg = false;
    } else if (this.reqStatusId == 7) {
      if (this.transType == "Gift" || this.transType == "Sell") {
        this.showReminderIconFlg = false;
      } else {
        //this.showReminderIconFlg=true;
      }
      this.unableservFlg = false;
      this.shareFlg = false;
      this.closeFlg = true;
      this.deleteFlg = false;
      const modal = this.modalCtrl.create(
        sendRatingPopup,
        { reqid: this.reqId },
        { cssClass: "customModal1" }
      );
      modal.present();
      modal.onDidDismiss((data) => {
        if (data != undefined) {
          if (data.receiverflg) {
            this.navCtrl.pop();
            // this.navCtrl.push(MessageboxPage,{cancelreqflg:true});
          }
        }
      });
      //this.showreceiverPopupFlg=true;
    } else if (this.reqStatusId == 6) {
       this.closeFlg = false;
       this.deleteFlg = true;
       this.unableservFlg = false;
       this.showReminderIconFlg = false;

    } else {
      this.closeFlg = false;
      this.deleteFlg = false;
      this.unableservFlg = true;
      this.showReminderIconFlg = false;
    }

    if (
      this.requesterImage == null ||
      this.requesterImage == "No Image" ||
      this.requesterImage == ""
    ) {
      this.reqImage = "../assets/imgs/NoImg.png";
    } else {
      this.reqImage = this.imageUrl + this.requesterImage;
    }

    this.Form = this.formBuilder.group({
      inputMsg: ["", [Validators.required]],
    });
  }
  async ngOnInit() {
    this.getDetails = await this.storage.get("memberDetails");
    console.log(this.getDetails.memberId);
  }
  ionViewDidLoad() {
    // this.getReceiverNote();
    console.log("ionViewDidLoad ChatboxSentPage");
  }
  editReminderIcon() {
    this.getReceiverNote();
  }
  close() {
    this.reqStatusId = 7;
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    this.restProvider
      .shareReq(this.reqId, this.reqStatusId, this.getDetails.memberId)
      .then((data) => {
        console.log("success");
        var result: any = data;
        var sts = result.status;

        if (result != null && sts == "success") {
          this.listing = result;
          this.notificationlist = this.listing.notificationThreadDto;
          if (this.reqStatusId == 7) {
            const modal = this.modalCtrl.create(
              sendRatingPopup,
              { reqid: this.reqId },
              { cssClass: "customModal1" }
            );
            modal.present();
            modal.onDidDismiss((data) => {
              if (data != undefined) {
                if (data.receiverflg) {
                  this.navCtrl.pop();
                  this.navCtrl.pop();
                  // this.navCtrl.push(MessageboxPage,{cancelreqflg:true});
                }
              }
            });
          } else if (this.reqStatusId == 5) {
            if (this.transType == "Gift" || this.transType == "Sell") {
            } else {
              this.reminderPopupWindow(this.reqStatusId, null);
              //this.reminderpopFlg=true;
            }
          }
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        this.loading.dismiss();
        this.displayMsg("Please try again later");
      });
  }
  getReceiverNote() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    this.restProvider
      .getReceiverNote(this.reqId)
      .then((data) => {
        console.log("res", data);
        var result: any = data;
        //var sts =result.status;

        if (result != null) {
          this.receiverList = result;
          this.reminderPopupWindow(this.reqStatusId, this.receiverList);
        } else {
          this.presentToast("Please try again later");
        }

        this.loading.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.displayMsg("Please try again later");
        this.loading.dismiss();
      });
  }
  buyerrating1() {
    this.buyershowonestarflg = false;
    this.buyerRating = 1;
  }
  buyerrating2() {
    this.buyershowtwostarflg = false;
    this.buyerRating = 2;
  }
  buyerrating3() {
    this.buyershowthreestarflg = false;
    this.buyerRating = 3;
  }
  buyerrating4() {
    this.buyershowfourstarflg = false;
    this.buyerRating = 4;
  }
  buyerrating5() {
    this.buyershowfivestarflg = false;
    this.buyerRating = 5;
  }

  submit() {
    if (this.ratefeedback != undefined) {
      var data: any;
      data = {
        receiverRating: this.buyerRating,
        remarks: this.ratefeedback,
        requestId: this.reqId,
      };
      console.log("reqdata", data);
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
      this.restProvider
        .sendissuerfeedback(data, this.getDetails.memberId)
        .then((data) => {
          console.log("data", data);
          var result: any = data;

          if (result != null) {
          } else {
            this.displayMsg("Please try again later");
          }
          this.loading.dismiss();
        })
        .catch((error) => {
          console.log("error", error);
          this.loading.dismiss();
          this.displayMsg("Please try again later");
        });
    } else {
      this.displayAlert();
    }
  }
  displayMsg(msg) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: msg,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Ok") {
      }
    });
  }
  submitfeedback() {
    if (this.issuerRating != undefined && this.productRating != undefined) {
      var data: any;
      data = {
        issuerRating: this.issuerRating,
        productRating: this.productRating,
        issuerRemarks: this.ownerfeedback,
        productRemarks: this.productfeedback,
        requestId: this.reqId,
      };

      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
      this.restProvider
        .sendReceiverfeedback(data)
        .then((data) => {
          console.log("data", data);
          var result: any = data;

          if (result != null) {
          }
          this.loading.dismiss();
        })
        .catch((error) => {
          console.log("error", error);
          this.loading.dismiss();
          this.displayMsg("Please try again later");
        });
    } else {
      this.displayAlert();
    }
  }
  displayAlert() {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        titleName: "Warning",
        bodyTxt: "Please give rating!",
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Ok") {
      }
    });
  }
  rating1() {
    this.showonestarflg = false;
    this.issuerRating = 1;
  }
  rating2() {
    this.showtwostarflg = false;
    this.issuerRating = 2;
  }
  rating3() {
    this.showthreestarflg = false;
    this.issuerRating = 3;
  }
  rating4() {
    this.showfourstarflg = false;
    this.issuerRating = 4;
  }
  rating5() {
    this.showfivestarflg = false;
    this.issuerRating = 5;
  }

  ownerrating1() {
    this.ownershowonestarflg = false;
    this.productRating = 1;
  }
  ownerrating2() {
    this.ownershowtwostarflg = false;
    this.productRating = 2;
  }
  ownerrating3() {
    this.ownershowthreestarflg = false;
    this.productRating = 3;
  }
  ownerrating4() {
    this.ownershowfourstarflg = false;
    this.productRating = 4;
  }
  ownerrating5() {
    this.ownershowfivestarflg = false;
    this.productRating = 5;
  }

  goBack() {
    this.navCtrl.pop();
  }

  sendMessage() {
    if (this.Form.valid) {
      if (this.inputMsg == " ") {
        this.inputMsg = this.inputMsg.replace(" ", "%20");
      }

      this.send(
        this.inputMsg,
        this.reqId,
        0,
        this.reqStatusId,
        this.getDetails.memberId
      );
    }
  }

  send(msg, requestId, ownerflg, requestStatusId, memberId) {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    this.restProvider
      .OwnerMsgfromSent(msg, this.reqId, ownerflg, requestStatusId, memberId)
      .then((data) => {
        var result: any = data;
        var sts = result.status;
        this.listing = result;

        if (result != null && sts == "success") {
          this.notificationlist = result.notificationThreadDto;
          this.inputMsg = "";
          console.log("success");
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        this.loading.dismiss();
        this.displayMsg("Please try again later");
      });
  }

  block() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    this.restProvider
      .blockMember(0, this.getDetails.memberId)
      .then((data) => {
        console.log("succeed");
        var result: any = data;
        var sts = result.status;

        if (result != null && sts == "success") {
          console.log("success");
          this.getChatMessage();
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        this.loading.dismiss();
        this.displayMsg("Please try again later");
      });
  }
  cancelReq() {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        titleName: "Cancel Request",
        bodyTxt: "Are you sure you want to Cancel the request you have raised?",
        okBtnNm: "Yes",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Yes") {
        this.getcancelRequest();
      }
    });
  }
  getcancelRequest() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    this.restProvider
      .cancelServiceReq(this.reqId, this.getDetails.memberId)
      .then((data) => {
        console.log("succeed");
        var result: any = data;
        var sts = result.status;

        if (result != null && sts == "success") {
          this.navCtrl.pop();
          // this.navCtrl.push(MessageboxPage,{cancelreqflg:true})
          console.log("success");
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        this.loading.dismiss();
        this.displayMsg("Please try again later");
      });
  }

  delete() {
     this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    this.restProvider
      .deleteReq(this.reqId)
      .then((data) => {
        console.log("succeed");
        var result: any = data;
        var sts = result.status;

        if (result != null && sts == "success") {
          this.navCtrl.pop();
          // this.navCtrl.push(MessageboxPage,{cancelreqflg:true})
          console.log("success");
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        this.loading.dismiss();
        this.displayMsg("Please try again later");
      });
  
    
  }
  shared() {
    this.reqStatusId = 5;
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    this.restProvider
      .shareReq(this.reqId, this.reqStatusId, this.getDetails.memberId)
      .then((data) => {
        var result: any = data;
        var sts = result.status;

        if (result != null && sts == "success") {
          this.listing = result;
          this.notificationlist = this.listing.notificationThreadDto;
          if (this.reqStatusId == 7) {
            const modal = this.modalCtrl.create(
              sendRatingPopup,
              { reqid: this.reqId },
              { cssClass: "customModal1", enableBackdropDismiss: false }
            );
            modal.present();
            modal.onDidDismiss((data) => {
              if (data != undefined) {
                if (data.receiverflg) {
                  this.navCtrl.pop();
                  //  this.navCtrl.push(MessageboxPage,{cancelreqflg:true});
                }
              }
            });
          } else if (this.reqStatusId == 5) {
            if (this.transType == "Gift" || this.transType == "Sell") {
            } else {
              this.reminderPopupWindow(this.reqStatusId, this.receiverList);
            }
          }
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        this.loading.dismiss();
        this.presentToast("Please try again later");
      });
  }

  reminderPopupWindow(reqstatusid, receiverList) {
    const modal = this.modalCtrl.create(
      senderReminderPopup,
      {
        reqid: this.reqId,
        reqstatusid: reqstatusid,
        receiverData: receiverList,
      },
      { cssClass: "customModal1", enableBackdropDismiss: false }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      this.navCtrl.pop();
      // this.navCtrl.setRoot(MessageboxPage);
    });
    /*this.sharedflg=true;
      this.toReturnflg=true;
      this.returnOnflg=false;*/
  }
  save() {
    if (this.sharedOn != undefined && this.toReturnOn != undefined) {
      var data: any;
      data = {
        requestId: this.reqId,
        sharedOnStr: this.sharedOn,
        returnByStr: this.toReturnOn,
        returnOnStr: "",
      };
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
      this.restProvider
        .createReminder(data)
        .then((data) => {
          var result: any = data;

          console.log(result);
          if (result == "success") {
          } else {
            this.displayReminderAlert();
          }

          this.loading.dismiss();
        })
        .catch((error) => {
          this.loading.dismiss();
          this.displayMsg("Please try again later");
        });
    }
  }
  displayReminderAlert() {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        titleName: "Warning",
        bodyTxt: "Reminder not saved, Please try after sometime!",
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Ok") {
      }
    });
  }
  getChatMessage() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    this.restProvider
      .chatSent(this.reqId)
      .then((data) => {
        var result: any = data;
        var sts = result.status;
        this.listing = result;
        console.log(result);

        if (result != null && sts == "success") {
          this.requestlist = this.listing.requestDto;
          this.notificationlist = this.listing.notificationThreadDto;
          this.reqStatusId = this.requestlist[0].requestStatusId;
          this.requesterImage = this.requestlist[0].ownerImage;
          this.requestName = this.requestlist[0].ownerName;
          this.blockedFlg = this.requestlist[0].blockedFlag;
          this.showblockFlg = false;
          if (this.reqStatusId == 5) {
            if (this.transType == "Gift" || this.transType == "Sell") {
              this.showReminderIconFlg = false;
            } else {
              this.showReminderIconFlg = true;
            }
            this.unableservFlg = false;
            this.closeFlg = true;
             this.deleteFlg = false;
          } else if (this.reqStatusId == 7) {
            if (this.transType == "Gift" || this.transType == "Sell") {
              this.showReminderIconFlg = false;
            } else {
              //this.showReminderIconFlg=true;
            }
            this.unableservFlg = false;
            this.shareFlg = false;
            this.closeFlg = true;
            this.deleteFlg = false;
          } else if (this.reqStatusId == 6) {
            this.closeFlg = false;
            this.deleteFlg = true;
            this.unableservFlg = false;
            this.showReminderIconFlg = false;
          } else {
            this.showReminderIconFlg = false;
            this.closeFlg = false;
             this.deleteFlg = false;
          }

          if (
            this.requesterImage == null ||
            this.requesterImage == "No Image" ||
            this.requesterImage == ""
          ) {
            this.reqImage = "../assets/imgs/NoImg.png";
          } else {
            this.reqImage = this.imageUrl + this.requesterImage;
          }
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        this.loading.dismiss();
        this.displayMsg("Please try again later");
      });
  }

  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }
}
  @Component({
    selector: "request-success-pop",
    template: `
      <ion-header no-border>
        <ion-toolbar class="headerCls">
          <ion-title>
            <img
              src="assets/imgs/logo_white.png"
              height="30dp"
              style="padding-top: 5px;"
            />
          </ion-title>
        </ion-toolbar>
      </ion-header>
      <ion-content padding>
        <ion-label text-center>
          <ion-label text-wrap
            >If you shared this item,tell us your experience</ion-label
          >
        </ion-label>

        <ion-row style="margin-top:10px">
          <ion-label style="margin:0px"> Rate Owner </ion-label>

          <ion-icon
            name="ios-star-outline"
            *ngIf="ownershowonestarflg"
            (click)="ownerrating1()"
          ></ion-icon>
          <ion-icon
            name="ios-star"
            *ngIf="!ownershowonestarflg"
            style="color:red"
            (click)="uncheckownerRating1()"
          ></ion-icon>

          <ion-icon
            name="ios-star-outline"
            *ngIf="ownershowtwostarflg"
            (click)="ownerrating2()"
          ></ion-icon>
          <ion-icon
            name="ios-star"
            *ngIf="!ownershowtwostarflg"
            style="color:red"
            (click)="uncheckownerRating2()"
          ></ion-icon>

          <ion-icon
            name="ios-star-outline"
            *ngIf="ownershowthreestarflg"
            (click)="ownerrating3()"
          ></ion-icon>
          <ion-icon
            name="ios-star"
            *ngIf="!ownershowthreestarflg"
            style="color:red"
            (click)="uncheckownerRating3()"
          ></ion-icon>

          <ion-icon
            name="ios-star-outline"
            *ngIf="ownershowfourstarflg"
            (click)="ownerrating4()"
          ></ion-icon>
          <ion-icon
            name="ios-star"
            *ngIf="!ownershowfourstarflg"
            style="color:red"
            (click)="uncheckownerRating4()"
          ></ion-icon>

          <ion-icon
            name="ios-star-outline"
            *ngIf="ownershowfivestarflg"
            (click)="ownerrating5()"
          ></ion-icon>
          <ion-icon
            name="ios-star"
            *ngIf="!ownershowfivestarflg"
            style="color:red"
          ></ion-icon>
          <ion-label
            style="background-color:red;margin-left:5px;margin-top:0px;margin-bottom:0px;padding:5px;color:white; min-width: 40px !important;
        max-width: 40px !important;"
            >{{ productRating }}/5</ion-label
          >
        </ion-row>
        <ion-label>Review Owner</ion-label>
        <ion-item style="border:thin solid #afaeae">
          <ion-input
            style="font-size:14px;"
            [(ngModel)]="ownerfeedback"
            type="text"
            [disabled]="ownerfeedflg"
            placeholder="your review about issuer"
          ></ion-input>
        </ion-item>

        <ion-row style="margin-top:10px">
          <ion-label style="margin:0px"> Rate Product </ion-label>

          <ion-icon
            name="ios-star-outline"
            *ngIf="showonestarflg"
            (click)="rating1()"
          ></ion-icon>
          <ion-icon
            name="ios-star"
            *ngIf="!showonestarflg"
            style="color:red"
            (click)="uncheckRating1()"
          ></ion-icon>

          <ion-icon
            name="ios-star-outline"
            *ngIf="showtwostarflg"
            (click)="rating2()"
          ></ion-icon>
          <ion-icon
            name="ios-star"
            *ngIf="!showtwostarflg"
            style="color:red"
            (click)="uncheckRating2()"
          ></ion-icon>

          <ion-icon
            name="ios-star-outline"
            *ngIf="showthreestarflg"
            (click)="rating3()"
          ></ion-icon>
          <ion-icon
            name="ios-star"
            *ngIf="!showthreestarflg"
            style="color:red"
            (click)="uncheckRating3()"
          ></ion-icon>

          <ion-icon
            name="ios-star-outline"
            *ngIf="showfourstarflg"
            (click)="rating4()"
          ></ion-icon>
          <ion-icon
            name="ios-star"
            *ngIf="!showfourstarflg"
            style="color:red"
            (click)="uncheckRating4()"
          ></ion-icon>

          <ion-icon
            name="ios-star-outline"
            *ngIf="showfivestarflg"
            (click)="rating5()"
          ></ion-icon>
          <ion-icon
            name="ios-star"
            *ngIf="!showfivestarflg"
            style="color:red"
          ></ion-icon>
          <ion-label
            style="background-color:red;margin-left:5px;margin-top:0px;margin-bottom:0px;padding:5px;color:white; min-width: 40px !important;
        max-width: 40px !important;"
            >{{ recvRating }}/5</ion-label
          >
        </ion-row>
        <ion-label>Review Product</ion-label>

        <ion-item style="border:thin solid #afaeae">
          <ion-input
            style="font-size:14px;"
            [(ngModel)]="productfeedback"
            [disabled]="prodfeedflg"
            type="text"
            placeholder="your review about product"
          ></ion-input>
        </ion-item>
        <ion-row>
          <ion-col col-12 text-center>
            <button
              class="btn3"
              ion-button
              color="bright"
              *ngIf="hidesubmitflg"
            >
              <span
                text-capitalize
                ion-text
                style="color:rgba(255,255,255,1);font-size:1.4rem;"
                (click)="submitfeedback()"
                >Submit</span
              >
            </button>
          </ion-col>
        </ion-row>
      </ion-content>
    `,
  })
  export class sendRatingPopup {
    reqId: any;
    loading: any;
    productfeedback: any;
    ownerfeedback: any;
    showonestarflg: any = true;
    showtwostarflg: any = true;
    showthreestarflg: any = true;
    showfourstarflg: any = true;
    showfivestarflg: any = true;
    ownershowonestarflg: any = true;
    ownershowtwostarflg: any = true;
    ownershowthreestarflg: any = true;
    ownershowfourstarflg: any = true;
    ownershowfivestarflg: any = true;
    issuerRating: any = 0;
    productRating: any = 0;
    getDetails: any;
    hidesubmitflg: boolean = true;
    recvRating: number = 0;
    unsubscribeBackEvent: any;
    constructor(
      public navParams: NavParams,
      public viewCtrl: ViewController,
      public loadingController: LoadingController,
      public restProvider: RestProvider,
      public storage: Storage,
      public modalCtrl: ModalController,
      public toastController: ToastController,
      public platform: Platform,
      private ionicApp: IonicApp
    ) {
      this.reqId = this.navParams.get("reqid");
    }

    btnClick(data: string) {
      this.viewCtrl.dismiss(data);
    }
    ownerrating1() {
      this.ownershowonestarflg = false;
      this.productRating = 1;
      console.log(this.productRating);
    }
    ownerrating2() {
      this.ownershowonestarflg = false;
      this.ownershowtwostarflg = false;
      this.productRating = 2;
      console.log(this.productRating);
    }
    ownerrating3() {
      this.ownershowonestarflg = false;
      this.ownershowtwostarflg = false;
      this.ownershowthreestarflg = false;
      this.productRating = 3;
      console.log(this.productRating);
    }
    ownerrating4() {
      this.ownershowonestarflg = false;
      this.ownershowtwostarflg = false;
      this.ownershowthreestarflg = false;
      this.ownershowfourstarflg = false;
      this.productRating = 4;
      console.log(this.productRating);
    }
    ownerrating5() {
      this.ownershowonestarflg = false;
      this.ownershowtwostarflg = false;
      this.ownershowthreestarflg = false;
      this.ownershowfourstarflg = false;
      this.ownershowfivestarflg = false;

      this.productRating = 5;
      console.log(this.productRating);
    }

    uncheckownerRating1() {
      this.ownershowonestarflg = false;
      this.ownershowtwostarflg = true;
      this.ownershowthreestarflg = true;
      this.ownershowfourstarflg = true;
      this.ownershowfivestarflg = true;

      this.productRating = 1;
      console.log(this.productRating);
    }
    uncheckownerRating2() {
      this.ownershowonestarflg = false;
      this.ownershowtwostarflg = false;
      this.ownershowthreestarflg = true;
      this.ownershowfourstarflg = true;
      this.ownershowfivestarflg = true;

      this.productRating = 2;
      console.log(this.productRating);
    }
    uncheckownerRating3() {
      this.ownershowonestarflg = false;
      this.ownershowtwostarflg = false;
      this.ownershowthreestarflg = false;
      this.ownershowfourstarflg = true;
      this.ownershowfivestarflg = true;
      this.productRating = 3;
      console.log(this.productRating);
    }
    uncheckownerRating4() {
      this.ownershowonestarflg = false;
      this.ownershowtwostarflg = false;
      this.ownershowthreestarflg = false;
      this.ownershowfourstarflg = false;
      this.ownershowfivestarflg = true;
      this.productRating = 4;
      console.log(this.productRating);
    }
    /* ionViewWillEnter() {
      this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
        let activePortal=this.ionicApp._modalPortal.getActive();
          if(activePortal){
            activePortal.dismiss();
          } else {
          return true;
        }
      }, 101);
    }
    ionViewWillLeave() {
      this.unsubscribeBackEvent && this.unsubscribeBackEvent();
    }*/

    async ngOnInit() {
      this.getDetails = await this.storage.get("memberDetails");
      console.log(this.getDetails.memberId);
    }
    presentToast(params) {
      let toast = this.toastController.create({
        message: params,
        duration: 2000,
      });
      toast.present();
    }
    rating1() {
      this.showonestarflg = false;
      this.recvRating = 1;
      console.log(this.recvRating);
    }
    rating2() {
      this.showonestarflg = false;
      this.showtwostarflg = false;
      this.recvRating = 2;
      console.log(this.recvRating);
    }
    rating3() {
      this.showonestarflg = false;
      this.showtwostarflg = false;
      this.showthreestarflg = false;
      this.recvRating = 3;
      console.log(this.recvRating);
    }
    rating4() {
      this.showonestarflg = false;
      this.showtwostarflg = false;
      this.showthreestarflg = false;
      this.showfourstarflg = false;
      this.recvRating = 4;
      console.log(this.recvRating);
    }
    rating5() {
      this.showonestarflg = false;
      this.showtwostarflg = false;
      this.showthreestarflg = false;
      this.showfourstarflg = false;
      this.showfivestarflg = false;
      this.recvRating = 5;
      console.log(this.recvRating);
    }
    uncheckRating1() {
      this.showonestarflg = false;
      this.showtwostarflg = true;
      this.showthreestarflg = true;
      this.showfourstarflg = true;
      this.showfivestarflg = true;
      this.recvRating = 1;
      console.log(this.recvRating);
    }
    uncheckRating2() {
      this.showonestarflg = false;
      this.showtwostarflg = false;
      this.showthreestarflg = true;
      this.showfourstarflg = true;
      this.showfivestarflg = true;
      this.recvRating = 2;
      console.log(this.recvRating);
    }
    uncheckRating3() {
      this.showonestarflg = false;
      this.showtwostarflg = false;
      this.showthreestarflg = false;
      this.showfourstarflg = true;
      this.showfivestarflg = true;
      this.recvRating = 3;
      console.log(this.recvRating);
    }
    uncheckRating4() {
      this.showonestarflg = false;
      this.showtwostarflg = false;
      this.showthreestarflg = false;
      this.showfourstarflg = false;
      this.showfivestarflg = true;
      this.recvRating = 4;
      console.log(this.recvRating);
    }

    submitfeedback() {
      if (this.recvRating != undefined && this.productRating != undefined) {
        var data: any;
        data = {
          issuerRating: this.productRating,
          productRating: this.recvRating,
          issuerRemarks: this.ownerfeedback,
          productRemarks: this.productfeedback,
          requestId: this.reqId,
        };

        this.loading = this.loadingController.create({
          spinner: "bubbles",
        });
        this.loading.present();
        this.restProvider
          .sendReceiverfeedback(data)
          .then((data) => {
            console.log("data", data);
            var result: any = data;

            if (result != null) {
              this.viewCtrl.dismiss({ receiverflg: true });
            } else {
              this.displayMsg("Please try again later");
            }
            this.loading.dismiss();
          })
          .catch((error) => {
            console.log("error", error);
            this.loading.dismiss();
            this.displayMsg("Please try again later");
          });
      } else {
        this.displayMsg("Please give rating");
        // this.displayAlert();
      }
    }
    displayMsg(msg) {
      const modal = this.modalCtrl.create(
        "CustomDialogPage",
        {
          dialogFor: "info",
          iconName: "",
          titleName: "",
          bodyTxt: msg,
          okBtnNm: "Ok",
        },
        { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
      );
      modal.present();
      modal.onDidDismiss((data) => {
        if (data == "Ok") {
        }
      });
    }

    displayAlert() {
      const modal = this.modalCtrl.create(
        "CustomDialogPage",
        {
          titleName: "Warning",
          bodyTxt: "Please give rating!",
          okBtnNm: "Ok",
        },
        { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
      );
      modal.present();
      modal.onDidDismiss((data) => {
        if (data == "Ok") {
        }
      });
    }
  }
  @Component({
    selector: "request-success-pop",
    template: `
      <ion-header no-border>
        <ion-toolbar>
          <ion-title>
            <img
              src="assets/imgs/logo.png"
              height="30dp"
              style="padding-top: 5px;"
            />
          </ion-title>

          <ion-buttons end>
            <button ion-button icon-only (click)="closeModal()">
              <ion-icon name="ios-close" style="color: black;"></ion-icon>
            </button>
          </ion-buttons>
        </ion-toolbar>
      </ion-header>
      <ion-content>
        <ion-label text-center>
          <ion-label>Set Reminder</ion-label>
        </ion-label>
        <ion-label text-center style="font-size:12px;color:grey;">
          Maintain sharing details to get timely reminders
        </ion-label>
        <ion-row>
          <ion-item>
            <ion-label style="font-size:14px;">Shared On:</ion-label>
            <ion-datetime
              style="font-size:14px;"
              displayFormat="DD/MM/YYYY"
              [disabled]="sharedOnflg"
              [(ngModel)]="sharedOn"
            ></ion-datetime>
          </ion-item>

          <ion-item>
            <ion-label style="font-size:14px;">To be Returned on:</ion-label>
            <ion-datetime
              style="font-size:14px;"
              displayFormat="DD/MM/YYYY"
              [disabled]="toReturnOnflg"
              [(ngModel)]="toReturnOn"
            ></ion-datetime>
          </ion-item>

          <ion-item>
            <ion-label style="font-size:14px;">Returned on:</ion-label>
            <ion-datetime
              style="font-size:14px;"
              displayFormat="DD/MM/YYYY"
              [disabled]="returnOnflg"
              [(ngModel)]="returnOn"
            ></ion-datetime>
          </ion-item>
        </ion-row>

        <ion-row>
        <ion-col text-center>
          <button
            class="btn3"
            *ngIf="saveReminderflg"
            ion-button
            text-center
            color="bright"
            (click)="save()"
          >
            <span
              text-capitalize
              ion-text
              style="color:rgba(255,255,255,1);font-size:1.4rem;"
              >Save</span
            >
          </button>
          </ion-col>
        </ion-row>
      </ion-content>
    `,
  })
  export class senderReminderPopup {
    sharedflg: boolean;
    toReturnflg: boolean;
    returnOnflg: boolean;
    saveReminderflg: boolean = true;
    toReturnOn: any;
    sharedOn: any;
    returnOn: any;
    reqId: any;
    sharedOnflg: any;
    toReturnOnflg: any;
    loading: any;
    loading1: any;
    receiverDto: any;
    reqstatusid: any;
    unsubscribeBackEvent: any;

    constructor(
      public navParams: NavParams,
      public viewCtrl: ViewController,
      public loadingController: LoadingController,
      public restProvider: RestProvider,
      public toastController: ToastController,
      public modalCtrl: ModalController,
      public platform: Platform,
      private ionicApp: IonicApp
    ) {
      this.reqId = this.navParams.get("reqid");
      this.receiverDto = this.navParams.get("receiverData");
      this.reqstatusid = this.navParams.get("reqstatusid ");
      console.log("receiverDto", this.receiverDto);
      console.log("sid", this.reqstatusid);
      if (
        this.receiverDto != null &&
        this.receiverDto.sharedOnStr != null &&
        this.receiverDto.sharedOnStr != ""
      ) {
        let sharedDate = new Date(this.receiverDto.borrowedOn).toISOString();
        this.sharedOn = sharedDate;

        //this.sharedOn=this.receiverDto.sharedOnStr;
        //this.sharedOn= moment(this.sharedOn).format('DD/MM/YYYY');
        console.log("sharedOn", this.sharedOn);
      }
      if (
        this.receiverDto != null &&
        this.receiverDto.returnByStr != null &&
        this.receiverDto.returnByStr != ""
      ) {
        let returnDate = new Date(this.receiverDto.toBeReturned).toISOString();
        this.toReturnOn = returnDate;
        // this.toReturnOn=this.receiverDto.returnByStr;
        //this.toReturnOn= moment(this.toReturnOn).format('DD/MM/YYYY');
        console.log("toReturnOn", this.toReturnOn);
      }

      if (
        this.receiverDto != null &&
        this.receiverDto.returnOnStr != null &&
        this.receiverDto.returnOnStr != ""
      ) {
        let returnedDt = new Date(this.receiverDto.returnedOn).toISOString();
        this.returnOn = returnedDt;
        //this.returnOn=this.receiverDto.returnOnStr;
        //this.returnOn= moment(this.returnOn).format('DD/MM/YYYY');
        console.log("toReturnOn", this.returnOn);
      }
      this.sharedOnflg = true;
      this.toReturnOnflg = true;
      this.returnOnflg = false;
    }

    btnClick(data: string) {
      this.viewCtrl.dismiss(data);
    }
    closeModal() {
      this.viewCtrl.dismiss(null);
    }
    ionViewWillEnter() {
      this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
        let activePortal = this.ionicApp._modalPortal.getActive();
        if (activePortal) {
          activePortal.dismiss();
        } else {
          return true;
        }
      }, 101);
    }
    ionViewWillLeave() {
      this.unsubscribeBackEvent && this.unsubscribeBackEvent();
    }
    save() {
      this.sharedOn = moment(this.sharedOn).format("DD/MM/YYYY");
      console.log("sharedOn", this.sharedOn);

      this.toReturnOn = moment(this.toReturnOn).format("DD/MM/YYYY");
      console.log("toReturnOn", this.toReturnOn);

      this.returnOn = moment(this.returnOn).format("DD/MM/YYYY");
      console.log("toReturnOn", this.returnOn);

      if (this.returnOn != undefined) {
        if (this.receiverDto != null) {
          this.receiverDto.receiverNoteId = this.receiverDto.receiverNoteId;
        } else {
        }
        var data: any;
        if (this.receiverDto != null) {
          data = {
            receiverNoteId: this.receiverDto.receiverNoteId,
            requestId: this.reqId,
            sharedOnStr: this.sharedOn,
            returnByStr: this.toReturnOn,
            returnOnStr: this.returnOn,
          };
        } else {
          data = {
            receiverNoteId: 0,
            requestId: this.reqId,
            sharedOnStr: this.sharedOn,
            returnByStr: this.toReturnOn,
            returnOnStr: this.returnOn,
          };
        }

        this.loading = this.loadingController.create({
          spinner: "bubbles",
        });
        this.loading.present();
        this.restProvider
          .createReminder(data)
          .then((data) => {
            console.log("data", data);
            var result: any = data;

            if (result != null) {
              if (result == "Success") {
                this.viewCtrl.dismiss();
                this.displayMsg("Reminder saved");
              } else {
                this.displayMsg(
                  "Reminder not saved, Please try after sometime"
                );
                this.viewCtrl.dismiss();
              }
            }
            this.loading.dismiss();
          })
          .catch((error) => {
            console.log("error", error);
            this.loading.dismiss();
            this.displayMsg("Please try again later");
          });
      }
    }
    displayMsg(msg) {
      const modal = this.modalCtrl.create(
        "CustomDialogPage",
        {
          dialogFor: "info",
          iconName: "",
          titleName: "",
          bodyTxt: msg,
          okBtnNm: "Ok",
        },
        { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
      );
      modal.present();
      modal.onDidDismiss((data) => {
        if (data == "Ok") {
        }
      });
    }
    presentToast(params) {
      let toast = this.toastController.create({
        message: params,
        duration: 2000,
      });
      toast.present();
    }

    updateNote() {
      this.loading1 = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading1.present();
      var data: any;
      data = {
        requestId: this.reqId,
        sharedOnStr: this.sharedOn,
        returnByStr: this.toReturnOn,
        returnOnStr: "",
      };
      this.restProvider
        .updateReminder(data)
        .then((data) => {
          console.log("data", data);
          var result: any = data;

          if (result != null) {
            if (result == "success") {
              this.viewCtrl.dismiss();
            } else {
              this.displayMsg("Reminder not saved, Please try after sometime");
              this.viewCtrl.dismiss();
            }
          }
          this.loading.dismiss();
        })
        .catch((error) => {
          console.log("error", error);
          this.loading1.dismiss();
          this.displayMsg("Please try again later");
        });
    }
    displayAlert() {
      const modal = this.modalCtrl.create(
        "CustomDialogPage",
        {
          titleName: "",
          bodyTxt: "Reminder not saved, Please try after sometime!",
          okBtnNm: "Ok",
        },
        { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
      );
      modal.present();
      modal.onDidDismiss((data) => {
        if (data == "Ok") {
        }
      });
    }
  }
  
  
  
        
  