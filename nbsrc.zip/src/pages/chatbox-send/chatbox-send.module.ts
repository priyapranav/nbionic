import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChatboxSendPage } from './chatbox-send';

@NgModule({
  declarations: [
    ChatboxSendPage,
  ],
  imports: [
    IonicPageModule.forChild(ChatboxSendPage),
  ],
})
export class ChatboxSendPageModule {}
