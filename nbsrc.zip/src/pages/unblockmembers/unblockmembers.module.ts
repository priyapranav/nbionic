import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UnblockmembersPage } from './unblockmembers';

@NgModule({
  declarations: [
    UnblockmembersPage,
  ],
  imports: [
    IonicPageModule.forChild(UnblockmembersPage),
  ],
})
export class UnblockmembersPageModule {}
