import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, ModalController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from '@ionic/storage';
/**
 * Generated class for the UnblockmembersPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-unblockmembers',
  templateUrl: 'unblockmembers.html',
})
export class UnblockmembersPage {
  loading: any;
  getDetails: any;
  userMemberId: any;
  getblocklist: any;
  imgUrl: any;
  unblockFlg:boolean;
  loading1: any;
  constructor(public navCtrl: NavController,  public modalCtrl: ModalController,public loadingController: LoadingController,public toastController: ToastController,public restProvider: RestProvider,private storage: Storage,public navParams: NavParams) {
    this.imgUrl=this.restProvider.imgUrl;  
  }
  async ngOnInit(){
    this.getDetails= await this.storage.get("memberDetails");
    this.userMemberId=this.getDetails.memberId;
 this.getblockMemberlist();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad UnblockmembersPage');
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  getblockMemberlist(){
    return new Promise((resolve, reject) => {
      this.loading = this.loadingController.create({
        spinner: "bubbles"
      });
      this.loading.present();
      this.restProvider
      .getblocklistMember(this.getDetails.memberId)
      .then((data) => { 
        console.log("data",data);
        var result : any = data;
      this.getblocklist=data;
      if(this.getblocklist.length >0){
        this.unblockFlg=true;
      }
      else{
        this.unblockFlg=false;
      }
        this.loading.dismiss();
      
    })
    .catch(error => {
      console.log("error",error);
      this.loading.dismiss();
    this.displayAlert("Please try again later");
    });
  });

  
}
  unblock(reqid, name) {
    var msg =
      "Unblock will allow the member to interact with you again. Do you want to Unblock "+name;
  const modal = this.modalCtrl.create(
    'CustomDialogPage',
    {
     // titleName: "Unblock Member",
      bodyTxt: msg,
      okBtnNm: "Yes",
      cancelBtnNm:"No"
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
  modal.onDidDismiss((data) => {
    if (data == "Yes") {
   this.unblockrequest(reqid,name);
    } 
    else if(data =="No"){

    }
  });
}
unblockrequest(reqid,name){
  return new Promise((resolve, reject) => {
    this.loading1 = this.loadingController.create({
      spinner: "bubbles"
    });
    this.loading1.present();
    this.restProvider
    .getunblocklistMember(reqid,this.getDetails.memberId)
    .then((data) => { 
      console.log("data",data);
      var result : any = data;
   if(result.trim()== "success"){
this.displayAlert("Unblocked "+name);
this.getblockMemberlist();

   }
   else if(result.trim()== "fail"){
this.displayAlert("please try again...");
   }
   else{
    this.displayAlert("Server Down... Please try again");
   }
      this.loading1.dismiss();
    
  })
  .catch(error => {
    console.log("error",error);
    this.loading1.dismiss();
  this.displayAlert("Please try again later");
  });
});
}
presentToast(params) {
  let toast = this.toastController.create({
  message: params,
  duration: 2000
  });
  toast.present();
  }
}
