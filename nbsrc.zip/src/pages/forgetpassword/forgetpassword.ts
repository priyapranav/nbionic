import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


import { RestProvider } from '../../providers/rest/rest';

/**
 * Generated class for the ForgetpasswordPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-forgetpassword',
  templateUrl: 'forgetpassword.html',
})
export class ForgetpasswordPage {
  email:any;
  forgetPwdForm: FormGroup;loading: any;
;
 
  constructor(public navCtrl: NavController, public modalCtrl: ModalController,public toastController:ToastController,public restProvider: RestProvider,public loadingController:LoadingController,public navParams: NavParams,private formBuilder: FormBuilder) {

    this.forgetPwdForm = this.formBuilder.group({
     
      email: ["", [Validators.email, Validators.required]],
      
    });
  }
  validation_messages={
    email:[
      {
        type:'email',message:'Invalid Email Address'
      },
      {
        type:'required',message:'Email is required'
      }
    ],
  };

  ionViewDidLoad() {
    console.log('ionViewDidLoad ForgetpasswordPage');
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  forgetPwd(){
 

      this.loading = this.loadingController.create({
        spinner: "bubbles"
      });

      this.loading.present();
 
      this.restProvider
        .sendPassword(this.email)
        .then((data) => {
          console.log(data);
          var result:any=data;
        var sts=result;

          if(result.status == "success"){
          this.displayAlert("Will Send Password To Your Email");
         // this.navCtrl.pop();
        }
        else if(result.status == "fail"){
          this.displayAlert("Give Valid UserEmail");
        }
       
        this.loading.dismiss(); 
      })
      .catch(error => {
        this.loading.dismiss();
        this.displayAlert("Please try again later");
      });
    
  }
  

  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000
    });
    toast.present();
  }

  clearPwd(){
    this.email="";
  }





}
