import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GetusercontactdetailsPage } from './getusercontactdetails';

@NgModule({
  declarations: [
    GetusercontactdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(GetusercontactdetailsPage),
  ],
})
export class GetusercontactdetailsPageModule {}
