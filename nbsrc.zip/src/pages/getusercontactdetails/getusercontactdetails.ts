import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from "@ionic/storage";
import { UsefulcontactsPage } from '../usefulcontacts/usefulcontacts';
import { AddcontactlistPage } from '../addcontactlist/addcontactlist';

/**
 * Generated class for the GetusercontactdetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-getusercontactdetails',
  templateUrl: 'getusercontactdetails.html',
})
export class GetusercontactdetailsPage {
  listId: any;
  getDetails: any;
  loading: any;
  contactDetails: any;
  contactAddress: string;
  createMemberId: any;
  moderator_flg: any;
  showChangebtn: boolean;
  showRemovebtn: boolean;
  contactListid: any;
  loading2: any;
  feedbackDetails: any;
  showContact: boolean;
  categoryName: any;
  name: any;
  email: any;
  createdMemberName: any;
  mobile: any;
  networkId: any;
  userContacts: any;
  

  constructor(public navCtrl: NavController,public modalCtrl: ModalController, public toastController: ToastController,public loadingController: LoadingController,public restProvider: RestProvider,public storage:Storage,public navParams: NavParams) {
    this.listId=this.navParams.get("list");
    this.userContacts=this.navParams.get("contact");
  }
  async ngOnInit() {
    this.getDetails= await this.storage.get("memberDetails");
       console.log(this.getDetails.memberId);
   this.getuserdetails();
      
     }
  ionViewDidLoad() {
    console.log('ionViewDidLoad GetusercontactdetailsPage');
  }
  goBackbtn(){
    this.navCtrl.pop();
  }

  getuserdetails(){
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    
       
    this.restProvider
  .getuserInfo(this.listId,this.getDetails.memberId)
  .then( (data) => { 
    var result : any = data;
   
    console.log("result",data);
   
      
      this.contactDetails=result.networkContactListDto;
      this.networkId=this.contactDetails.networkId
      this.categoryName=this.contactDetails.categoryName;
      this.name=this.contactDetails.name;
      this.mobile=this.contactDetails.mobile;
      this.email=this.contactDetails.email;
      this.createdMemberName=this.contactDetails.createdMemberName
      this.feedbackDetails= result.networkContactListFeedbackDtos;

       this.contactListid=this.contactDetails.listId;
      if(this.contactDetails.address1 !=null){
        if(this.contactDetails.address2 !=null){
          this.contactAddress=this.contactDetails.address1 +" ,"+this.contactDetails.address2;
        }
        else{
         this.contactAddress=this.contactDetails.address1;
        }
      }
      else if(this.contactDetails.address2 !=null){
       this.contactAddress=this.contactDetails.address2;
      }
      this.createMemberId=this.contactDetails.createdMemberId;
      this.moderator_flg=this.contactDetails.moderator_flag;
   
      if(this.getDetails.memberId == this.createMemberId || this.moderator_flg == 1){
        this.showChangebtn=true;
        this.showRemovebtn=true;
      }
      else{
       this.showChangebtn=false;
       this.showRemovebtn=false;
      }
    
   
   
    this.loading.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading.dismiss();
  
    this.displayAlert("Please try again later");
  });
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  remove(){
    const modal = this.modalCtrl.create(
      'CustomDialogPage',
      {
        titleName: "Update Listing",
        bodyTxt: "Removing the Contact will erase all this contact detail.Do you want to remove?",
        okBtnNm: "Yes",
       
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Yes") {
     this.delete();
      } 
    });

  
  }
  delete(){
    this.loading2 = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading2.present();
    
       
    this.restProvider
  .removeContact(this.contactListid)
  .then( (data) => { 
    var result : any = data;
   
    console.log("result",data);
   if(result == "success"){
this.displayAlert("Contact list deleted!");
this.navCtrl.push(UsefulcontactsPage,{data:this.networkId});
//this.navCtrl.setRoot(UsefulcontactsPage,{data:this.networkId});
   }else if(result == "fail"){
    this.displayAlert("Problem in deleting contact list!");
  
   }
    this.loading2.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading2.dismiss();
  
    this.displayAlert("Please try again later");
  });
  }
  change(){
this.navCtrl.push(AddcontactlistPage,{listid:this.contactListid,data:this.networkId,contact:this.userContacts})
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }
}
