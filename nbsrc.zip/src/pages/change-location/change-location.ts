import { Component, ElementRef, ViewChild, NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController } from 'ionic-angular';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Geolocation } from "@ionic-native/geolocation";
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from "@ionic/storage";
/**
 * Generated class for the ChangeLocationPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
declare var google;
@IonicPage()
@Component({
  selector: 'page-change-location',
  templateUrl: 'change-location.html',
})
export class ChangeLocationPage {
  @ViewChild("map") mapElement: ElementRef;
  locationForm: FormGroup;
  getDetails: any;
  userLat: any;
  userlong: any;
  usermemberId: any;
  userlatlng: { lat: any; lng: any; };
  geocoder: any;
  mapCenterLoc: any;
  map: any;
  pickup: any;
  continue: boolean;
  fromLocation: any;
  sendFrom: any;
  senderLocation: any;
  state: any;
  country: any;
  loading: any;
  latitude: any;
  longitude: any;
  pincode: any;
  area: any;
  city: any;
  pickedLocation: any;
  autocompleteAddressItems: any[];
  GoogleAutocomplete: any;
  latlng: { lat: number; lng: number; };
  constructor(public navCtrl: NavController,   private zone: NgZone,public modalCtrl: ModalController,public geo: Geolocation,  public restProvider: RestProvider,public loadingController: LoadingController, public toastController: ToastController,
    public loadingCtrl: LoadingController,public storage:Storage,private formBuilder: FormBuilder,public navParams: NavParams) {
    this.locationForm = this.formBuilder.group({
      pickup: ["", [Validators.required]],
    });
    if (typeof google != "undefined") {
      this.GoogleAutocomplete = new google.maps.places.AutocompleteService();
      this.geocoder = new google.maps.Geocoder();
    }
    
    this.autocompleteAddressItems = [];
    this.mapCenterLoc = new google.maps.LatLng(20.5937,78.9629);
    //this.mapCenterLoc = new google.maps.LatLng(13.0279, 80.2605);
    //this.pickedLocation = navParams.get("data");
    //console.log("loc", this.pickedLocation);
    //this.getDetails =  this.storage.get("memberDetails");

    this.storage.get("memberDetails").then((val)=>{
     
        this.getDetails=val;
        console.log("details==>",val);

        if (
          val == undefined ||
          val == "" ||
          val == null
        ) {
          this.loading = this.loadingCtrl.create({
            spinner: "bubbles",
          });
          this.loading.present();
          var view = this;
          this.geo
            .getCurrentPosition({
              timeout: 4000,
              enableHighAccuracy: true,
              maximumAge: 3600,
            })
            .then(
              (position) => {
                if (typeof google != "undefined") {
                  let latLng = new google.maps.LatLng(
                    position.coords.latitude,
                    position.coords.longitude
                  );
                  this.mapCenterLoc = new google.maps.LatLng(
                    position.coords.latitude,
                    position.coords.longitude
                  );
                  this.map.setCenter(this.mapCenterLoc);
                  view.geocodeLatLng(latLng, function () {
                    view.fromLocation = view.pickup;
                    view.loading.dismiss();
                  });
                } else {
                  view.loading.dismiss();
                  this.presentToast("*No Internet connection");
                }
              },
              (err) => {
                this.loading.dismiss();
                this.storage.get("MemberDetails").then((val) => {
                  this.pickup = val.address;
                  this.latitude = val.latitude;
                  this.longitude = val.longitude;
                  this.area = val.area;
                 
                    (this.mapCenterLoc = new google.maps.LatLng(
                      this.latitude,
                      this.longitude
                    ));
                  this.map.setCenter(this.mapCenterLoc);
                });
              }
            );
        } else {
          this.pickup= this.getDetails.address;
    
          this.latitude= this.getDetails.latitude;
          this.longitude= this.getDetails.longitude;
          this.userlatlng = {
            lat: this.latitude,
            lng: this.longitude,
          };
    
          var latlng = this.userlatlng;
          this.latitude = latlng.lat;
          this.longitude = latlng.lng;
          this.area=  this.getDetails.area;
    
          console.log("addr", this.pickup)
       
         
          this.mapCenterLoc = new google.maps.LatLng(this.latitude, this.longitude);
          this.map.setCenter(this.mapCenterLoc);
        }
      

    });
  
    
    
  }
  
  
  geocodeLatLng(latlong, callback) {
    var view = this;
    var input = latlong;
    var latlng = { lat: parseFloat(input.lat()), lng: parseFloat(input.lng()) };
    this.geocoder.geocode({ location: latlng }, function (results, status) {
      if (status === "OK") {
        if (results[0]) {
          view.pickup = results[0].formatted_address;
          view.latitude = parseFloat(input.lat());
          view.longitude = parseFloat(input.lng());
          results[0].address_components.forEach((val) => {
            if (val.types[0] == "locality") {
              view.city = val.short_name;
            }
            if (val.types[2] == "sublocality_level_1") {
              view.area  = val.short_name;
            }
            if (val.types[0] == "administrative_area_level_1") {
              view.state = val.short_name;
            }
            if (val.types[0] == "country") {
              view.country = val.short_name;
            }
          });

          // view.ref.detectChanges();
        } else {
          window.alert("No results found");
        }
      } else {
        window.alert("Geocoder failed due to: " + status);
      }
      callback();
    });
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }
  ionViewDidLoad() {
    this.loadMap();
  }
  updateAddressSearchResults() {
    if (this.pickup == "") {
      this.autocompleteAddressItems = [];
    
     
      return;
    }
    if(this.pickup.length>=5){
      if (this.GoogleAutocomplete != undefined) {
        this.GoogleAutocomplete.getPlacePredictions(
          { input: this.pickup },
          (predictions, status) => {
            this.autocompleteAddressItems = [];
            this.zone.run(() => {
              if (
                predictions != undefined &&
                predictions != "" &&
                predictions != null
              ) {
                predictions.forEach((prediction) => {
                  this.autocompleteAddressItems.push(prediction);
                });
              } else {
                this.presentToast(
                  "Location not found, please search nearby location"
                );
              }
            });
          }
        );
      } else {
        this.presentToast("Please check your internet connection");
      }
    }
    
  }
  selectAddressSearchResult(item) {
    this.autocompleteAddressItems = [];
   this.pickup = item.description;
    this.geocoder.geocode({ placeId: item.place_id }, (results, status) => {
      if (status === "OK" && results[0]) {
        var lat = parseFloat(results[0].geometry.location.lat());
        var lng = parseFloat(results[0].geometry.location.lng());
        var latlng = {
          lat: lat,
          lng: lng,
        };
        this.latlng=latlng;
        this.latitude = this.latlng.lat;
      this.longitude = this.latlng.lng;
        
        results[0].address_components.forEach((val) => {
          if (val.types[0] == "locality") {
            this.city = val.short_name;
          }
          if (val.types[0] == "administrative_area_level_1") {
            this.state = val.short_name;
          }
          if (val.types[0] == "country") {
            this.country = val.short_name;
          }
          if (val.types[2] == "sublocality_level_1") {
            this.area = val.short_name;
          }
        });
       
     
    if(this.latlng !=undefined) {
      this.showMap();
     
    }
  

      }
    });
  }
  showMap(){
    this.mapCenterLoc = new google.maps.LatLng( this.latlng.lat, this.latlng.lng);
    this.loadMap();
  }
  changeLocation(){
    if (!this.locationForm.invalid) {
     
     
     /* this.storage.get("memberDetails").then((val)=>{
        if(val !=undefined && val !=null && val !=""){
          this.getDetails=val;*/

          this.loading = this.loadingController.create({
            spinner: "bubbles",
          });
          this.loading.present();
          
          var data:any;
          data={
            latitude:this.latitude,
            longitude:this.longitude,
            pincode:this.pincode,
            memberId:this.getDetails.memberId,
            address:this.pickup,
            area:this.area,
            firstName:this.getDetails.firstName,
            lastName:this.getDetails.lastName,
            email:this.getDetails.email,
            searchRadius:this.getDetails.searchRadius,
          }      
          this.restProvider
        .updatelocation(data)
        .then( (data) => { 
          var result : any = data;
         
          console.log("result",data);
          if(result.status =="success"){
            this.pickup=result.memberDto.address;
            var reqdata:any;
            reqdata={
              memberId:result.memberDto.memberId,
              firstName:result.memberDto.firstName,
              lastName:result.memberDto.lastName,
              contactNumber:this.getDetails.contactNumber,
              address:result.memberDto.address,
              pincode:result.memberDto.pincode,
              area:result.memberDto.area,
              searchRadius:this.getDetails.searchRadius,
              latitude:result.memberDto.latitude,
              longitude:result.memberDto.longitude,
              createdDateTime: result.memberDto.createdDateTime,
              deviceToken:result.memberDto.deviceToken,
              email:result.memberDto.email,
              inviteFlag:result.memberDto.inviteFlag,
              isActive:result.memberDto.userisActive,
              isDeleted:result.memberDto.userisDeleted,
              mailVerifyFlag:result.memberDto.mailVerifyFlag,
              memberProfilePic:result.memberDto.memberProfilePic,
              memberTypeId: result.memberDto.memberTypeId,
              networkId: result.memberDto.networkId,
              password: this.getDetails.password,
              picture: this.getDetails.picture,
              statusId:result.memberDto.statusId,
              aboutMe:this.getDetails.aboutMe,
  
            }
            this.storage.set("memberDetails",reqdata);
            //result.memberDto
            this.displaylocationMsg("Location Changed successfully!");
            //this.navCtrl.pop();
            
          }
          else{
            this.displayAlert(" Update Failed. Please try again");
          }
         
          this.loading.dismiss();
        })
        .catch(error => {
          console.log("error",error);
          this.loading.dismiss();
        
          this.displayAlert("Please try again later");
        });
        }
     
      

       
  //});
      
    //}
  }
  displaylocationMsg(message){
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if(data == "Ok"){
        this.navCtrl.pop();
      }

    });
  }
  displayAlert(message) {
 
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  loadMap() {
    const mapStyle = [
      {
        featureType: "all",
        elementType: "labels.text.fill",
        stylers: [
          {
            color: "#7c93a3",
          },
          {
            lightness: "-10",
          },
        ],
      },
      {
        featureType: "administrative.country",
        elementType: "geometry",
        stylers: [
          {
            visibility: "on",
          },
        ],
      },
      {
        featureType: "administrative.country",
        elementType: "geometry.stroke",
        stylers: [
          {
            color: "#a0a4a5",
          },
        ],
      },
      {
        featureType: "administrative.province",
        elementType: "geometry.stroke",
        stylers: [
          {
            color: "#62838e",
          },
        ],
      },
      {
        featureType: "landscape",
        elementType: "geometry.fill",
        stylers: [
          {
            color: "#eff1ea",
          },
        ],
      },
      {
        featureType: "landscape.man_made",
        elementType: "geometry.stroke",
        stylers: [
          {
            color: "#7c93a3",
          },
          {
            weight: "0.10",
          },
        ],
      },
      {
        featureType: "poi",
        elementType: "all",
        stylers: [
          {
            visibility: "simplified",
          },
        ],
      },
      {
        featureType: "poi.attraction",
        elementType: "all",
        stylers: [
          {
            visibility: "on",
          },
        ],
      },
      {
        featureType: "poi.business",
        elementType: "all",
        stylers: [
          {
            visibility: "on",
          },
        ],
      },
      {
        featureType: "poi.government",
        elementType: "all",
        stylers: [
          {
            visibility: "on",
          },
        ],
      },
      {
        featureType: "poi.park",
        elementType: "all",
        stylers: [
          {
            visibility: "on",
          },
        ],
      },
      {
        featureType: "poi.place_of_worship",
        elementType: "all",
        stylers: [
          {
            visibility: "on",
          },
        ],
      },
      {
        featureType: "poi.school",
        elementType: "all",
        stylers: [
          {
            visibility: "on",
          },
        ],
      },
      {
        featureType: "poi.sports_complex",
        elementType: "all",
        stylers: [
          {
            visibility: "on",
          },
        ],
      },
      {
        featureType: "road",
        elementType: "all",
        stylers: [
          {
            saturation: "-100",
          },
          {
            visibility: "on",
          },
        ],
      },
      {
        featureType: "road",
        elementType: "geometry.stroke",
        stylers: [
          {
            visibility: "off",
          },
        ],
      },
      {
        featureType: "road.highway",
        elementType: "geometry.fill",
        stylers: [
          {
            color: "#bbcacf",
          },
        ],
      },
      {
        featureType: "road.highway",
        elementType: "geometry.stroke",
        stylers: [
          {
            lightness: "0",
          },
          {
            color: "#bbcacf",
          },
          {
            weight: "0.50",
          },
        ],
      },
      {
        featureType: "road.highway",
        elementType: "labels",
        stylers: [
          {
            visibility: "on",
          },
        ],
      },
      {
        featureType: "road.highway",
        elementType: "labels.text",
        stylers: [
          {
            visibility: "on",
          },
        ],
      },
      {
        featureType: "road.highway.controlled_access",
        elementType: "geometry.fill",
        stylers: [
          {
            color: "#ffffff",
          },
        ],
      },
      {
        featureType: "road.highway.controlled_access",
        elementType: "geometry.stroke",
        stylers: [
          {
            color: "#a9b4b8",
          },
        ],
      },
      {
        featureType: "road.arterial",
        elementType: "labels.icon",
        stylers: [
          {
            invert_lightness: true,
          },
          {
            saturation: "-7",
          },
          {
            lightness: "3",
          },
          {
            gamma: "1.80",
          },
          {
            weight: "0.01",
          },
        ],
      },
      {
        featureType: "transit",
        elementType: "all",
        stylers: [
          {
            visibility: "off",
          },
        ],
      },
      {
        featureType: "water",
        elementType: "geometry.fill",
        stylers: [
          {
            color: "#a3c7df",
          },
        ],
      },
    ];

    let mapOptions = {
      center: this.mapCenterLoc,
      zoom: 17,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      zoomControl: false,
      styles: mapStyle,
      fullscreenControl: false,
      mapTypeControl: false,
      streetViewControl: false,
    };

    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
    google.maps.event.addListener(this.map, "dragstart", () => {
      this.pickup = "Loading...";
      this.continue = true;
    });
    google.maps.event.addListener(this.map, "dragend", () => {
      let latlng = {
        lat: this.map.getCenter().lat(),
        lng: this.map.getCenter().lng(),
      };
      this.fromMap(latlng);
    });
  }
  fromMap(latlng) {
    this.geocoder.geocode({ location: latlng }, (results, status) => {
      if (status === "OK" && results[0]) {
        var latlng = {
          lat: parseFloat(results[0].geometry.location.lat()),
          lng: parseFloat(results[0].geometry.location.lng()),
        };
        this.latitude=latlng.lat;
        this.longitude=latlng.lng;

        this.fromLocation = results[0].formatted_address;
        this.pickup = results[0].formatted_address;
         this.continue = false;

        results[0].address_components.forEach((val) => {
          if (val.types[0] == "locality") {
            this.city = val.short_name;
          }
          if (val.types[0] == "postal_code") {

            this.pincode = val.short_name;
            console.log(this.pincode);
          }
          if (val.types[2] == "sublocality_level_1") {
            this.area = val.short_name;
          }

          if (val.types[0] == "administrative_area_level_1") {
            this.state = val.short_name;
          }
          if (val.types[0] == "country") {
            this.country = val.short_name;
          }
        });
      }
      
    });
  }
  validation_messages = {
   
  pickup:[{
    type: "required", message: "Address is required"
  }
],
  }
}
