import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ProfilePage } from '../profile/profile';
import { ProfilepicturePage } from '../profilepicture/profilepicture';
import { ChangeemailPage } from '../changeemail/changeemail';
import { ChangeLocationPage } from '../change-location/change-location';
import { ResetpasswordPage } from '../resetpassword/resetpassword';
import { MapModelProfile } from '../home/home';
import { Storage } from "@ionic/storage";
import { LoginPage } from '../login/login';
import { LoginNewPage } from '../login-new/login-new';
/**
 * Generated class for the ProfileinfoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-profileinfo",
  templateUrl: "profileinfo.html",
})
export class ProfileinfoPage {
  getDetails: any;
  pickup: any;
  area: any;
  latitude: any;
  longitude: any;
  userlatlng: { lat: any; lng: any };
  pincode: string;
  userName: any;
 

  constructor(
    public navCtrl: NavController,
    public storage: Storage,
    public navParams: NavParams
  ) {}

  async ngOnInit() {
    this.getDetails = await this.storage.get("memberDetails");
    console.log("details", this.getDetails);
     this.userName = this.getDetails.firstName;

    this.pickup = this.getDetails.address;
    this.area = this.getDetails.area;
    this.latitude = this.getDetails.latitude;
    this.longitude = this.getDetails.longitude;
    this.userlatlng = {
      lat: this.latitude,
      lng: this.longitude,
    };
    if (this.getDetails.pincode == null) {
      this.pincode = "0";
    } else {
      this.pincode = this.getDetails.pincode;
    }
  }
  ionViewDidLoad() {
    console.log("ionViewDidLoad ProfileinfoPage");
  }
  profileInfo() {
    this.navCtrl.push(ProfilePage);
  }
  profilePic() {
    this.navCtrl.push(ProfilepicturePage);
  }
  changeemail() {
    this.navCtrl.push(ChangeemailPage);
  }
  changeLocation() {
    /*var mapLoad={
      latLong: this.userlatlng,
      subLocation: this.getDetails.area,
      location: this.getDetails.address,
     memberid:this.getDetails.memberId
    }
    console.log("data",mapLoad);
    //,{data:mapLoad}*/
    this.navCtrl.push(ChangeLocationPage);
  }
  resetPwd() {
    this.navCtrl.push(ResetpasswordPage);
  }
  logout() {
    this.storage.clear();
    //this.navCtrl.setRoot(LoginPage);
    this.navCtrl.setRoot(LoginNewPage);
  }
}
