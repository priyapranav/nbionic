import { Component, ElementRef, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, ModalController, ViewController, Platform, IonicApp, Events } from 'ionic-angular';
import { ImageProcess } from '../../providers/rest/ImageProcess';
import { Storage } from "@ionic/storage";
import { RestProvider } from '../../providers/rest/rest';
import { Observable, Observer } from 'rxjs';
/**
 * Generated class for the ProfilepicturePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-profilepicture',
  templateUrl: 'profilepicture.html',
})
export class ProfilepicturePage {
  @ViewChild('fileInput') fileInput: ElementRef;
  aboutMe:any;
  image: any;
  galFlg: boolean;
  accessFlg: boolean;
  camimage: any;
  getDetails: any;
  userpicture: any;
  addLocalFile: any="../assets/imgs/NoImg.png";
  imageSrc: any;
  loading: any;
  bytesformat: any;
  imgArr: any[]=[];
  kbytes: number;
  imageUrl: any;
  
  byteArr: any;
  shownoImgflg: boolean;
  productImage: string;
  uploadFlg: boolean;
  photouploadFlg: boolean;
  constructor(public navCtrl: NavController,  public events: Events,public modalCtrl: ModalController,public loadingController: LoadingController,public restProvider: RestProvider,public storage:Storage,public toastController: ToastController,public imageProcess: ImageProcess,public navParams: NavParams) {
    this.imageUrl = restProvider.imgUrl;
  }
async ngOnInit() {
   
    this.getDetails= await this.storage.get("memberDetails");
  console.log(this.getDetails);
    this.userpicture=this.getDetails.picture;
    if(this.userpicture == null || this.userpicture == "No Image" || this.userpicture == ""){
      this.imageSrc=this.addLocalFile;
      this.shownoImgflg=true;
      this.uploadFlg=true;
    }
    else{
      this.imageSrc=this.imageUrl+this.userpicture;
      this.shownoImgflg=true;
    }
    this.aboutMe=this.getDetails.aboutMe;
    console.log("img", this.userpicture)
   
    //this.presentToast("img"+this.imageSrc+this.aboutMe);
  }
  ionViewDidLoad() {
    
    console.log('ionViewDidLoad ProfilepicturePage');
  }
 

  presentActionSheet() {
    const modal = this.modalCtrl.create(
      ChooseImagePop,
      {},
      { cssClass: "customModal1" }
    );
    modal.present();
    modal.onDidDismiss((data) => {
       if (data == "1") {
       
       this.imageProcess.AccessCamera().then((res) => {
          this.image = res;
          this.shownoImgflg=false;
     //this.photouploadFlg=true;
    
         this.convertImgtoBinary(this.image);
      
        });
        return true;
      } else if (data == "2") {
        this.imageProcess.AccessGallery().then((res) => {
          this.image = res;
          this.shownoImgflg=false;
         // this.photouploadFlg=true;
     
          this.convertImgtoBinary(this.image);
         
      
        });
        return true;
      }
    });
  }
convertImgtoBinary(image){
  
  console.log("base64",image)
  var raw = window.atob(image);
  console.log("raw",raw)
  var rawLength = raw.length;
  console.log("rawLength",rawLength)
  var array = new Uint8Array(new ArrayBuffer(rawLength));
  console.log("array",array)
  this.imgArr=[];
  for(var i = 0; i < rawLength; i++) {
    array[i] = raw.charCodeAt(i);
    this.imgArr.push(raw.charCodeAt(i));
  }
  console.log("array",array)
  return array;
 
}
  convertDataURIToBinary(dataURI) {
    console.log("data",dataURI)
    var base64Index = dataURI.indexOf(';base64,') + ';base64,'.length;
    console.log("base64Index",base64Index)
    var base64 = dataURI.substring(base64Index);
    console.log("base64",base64)
    var raw = window.atob(base64);
    console.log("raw",raw)
    var rawLength = raw.length;
    console.log("rawLength",rawLength)
    var array = new Uint8Array(new ArrayBuffer(rawLength));
    this.imgArr=[];
    for(var i = 0; i < rawLength; i++) {
      array[i] = raw.charCodeAt(i);
     this.imgArr.push(raw.charCodeAt(i));
    }
   
    console.log("bytt", this.imgArr)
    return array;
   
  }
  convertToDataURLviaCanvas(url, outputFormat){
    return new Promise((resolve, reject) => {
      let img = new Image();
      img.setAttribute('crossOrigin', 'anonymous');
      img.onload = () => {
        let canvas = <HTMLCanvasElement> document.createElement('CANVAS'),
          ctx = canvas.getContext('2d'),
          dataURL;
        canvas.height = 300;
        canvas.width = 250;
        ctx.drawImage(img, 0, 0);
        dataURL = canvas.toDataURL(outputFormat);
        resolve(dataURL);
        console.log("dataurl"+dataURL)
        //this.presentToast("dataurl"+dataURL);
        canvas = null;
      };
      img.src = url;
    });
  }
 /*upload() {
  this.productImage="https://neighbourbase.com/nbasedemo/member/images/shareligionresources/237/productListing_Mon%20Jan%2003%2008-27-44%20UTC%202022.jpg"
  this.convertToDataURLviaCanvas(this.productImage, "image/jpeg").then((data:any) =>{
  
    
    console.log("base64"+base64)
    var base64Index = data.indexOf(';base64,') + ';base64,'.length;
    console.log("base64Index",base64Index);
  var base64 = data.substring(base64Index);
    console.log("base64",base64)
    var raw = window.atob(base64);
    console.log("raw",raw)
    var rawLength = raw.length;
    console.log("rawLength",rawLength)
    var array = new Uint8Array(new ArrayBuffer(rawLength));
    console.log("array",array)
    this.imgArr=[];
    for(var i = 0; i < rawLength; i++) {
      array[i] = raw.charCodeAt(i);
      this.imgArr.push(raw.charCodeAt(i));
    }
  });
  
   const file = (<HTMLInputElement>document.getElementById('file')).files[0];
    
    const preview = document.getElementById('preview'); 
    const reader = new FileReader();
    let byteArray;
  var view=this;
    reader.addEventListener("loadend", function () {
      // convert image file to base64 string
      console.log('base64', reader.result);
      //preview.src = reader.result;
      byteArray = view.convertDataURIToBinary(reader.result);
     
      
      console.log('byte array', byteArray);
    }, false);
  
    if (file) {
      reader.readAsDataURL(file);
    }
  }*/
 

  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000
    });
    toast.present();
  }
  displayMsg(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  displayProfileMsg(message){
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if(data == "Ok"){
        this.navCtrl.pop();
      }

    });
  }
  Change(){
    //&& this.aboutMe !=undefined
    if(!this.shownoImgflg){   
      if(this.imgArr !=undefined ){
        this.loading = this.loadingController.create({
          spinner: "bubbles",
        });
        this.loading.present();
          var data:any;
          
          
          data={
              memberProfilePic:this.imgArr,
              aboutMe:this.aboutMe,
              memberId:this.getDetails.memberId,
              picture:this.getDetails.picture,
      
            }
          console.log("data",data);
      
          this.restProvider
            .updateProfilePic(data )
            .then( (data) => { 
             var result:any=data;
             console.log("data",data);
    
            if(result.status =="success"){
              this.imageSrc=this.imageUrl+result.memberDto.picture;
              this.aboutMe=result.memberDto.aboutMe;
              var reqdata:any;
              reqdata={
                memberId:this.getDetails.memberId,
                firstName:this.getDetails.firstName,
                lastName:this.getDetails.lastName,
                contactNumber:this.getDetails.contactNumber,
                address:this.getDetails.address,
                pincode:this.getDetails.pincode,
                area:this.getDetails.area,
                searchRadius:this.getDetails.searchRadius,
                latitude:this.getDetails.latitude,
                longitude:this.getDetails.longitude,
                createdDateTime: this.getDetails.createdDateTime,
                deviceToken:this.getDetails.deviceToken,
                email:this.getDetails.email,
                inviteFlag:this.getDetails.inviteFlag,
                isActive:this.getDetails.userisActive,
                isDeleted:this.getDetails.userisDeleted,
                mailVerifyFlag:this.getDetails.mailVerifyFlag,
                memberProfilePic:this.getDetails.memberProfilePic,
                memberTypeId:this.getDetails.memberTypeId,
                networkId:this.getDetails.networkId,
                password:this.getDetails.password,
                picture:result.memberDto.picture,
                statusId:this.getDetails.statusId,
                aboutMe:this.aboutMe,
    
              }
              
              this.storage.set("memberDetails", reqdata).then((data)=>{
                this.displayProfileMsg("Profile changes made");
              });
            }
            else{
              this.displayMsg("Profile Picture Updated Failed. Please try again");
            }
              
              this.loading.dismiss();
               
            })
            .catch(error => {
              console.log("error",error);
            this.loading.dismiss();
            this.displayMsg("Please try again later");
          });
     
        
      }
      else{
        this.displayAlert("Please Upload picture to Proceed!");
      }
     
        
    }
    else if(this.shownoImgflg){
      if(this.userpicture == null || this.userpicture == "No Image" || this.userpicture == ""){
        this.imgArr=null;
        this.loading = this.loadingController.create({
          spinner: "bubbles",
        });
        this.loading.present();
          var data:any;
          
          
          data={
              memberProfilePic:this.imgArr,
              aboutMe:this.aboutMe,
              memberId:this.getDetails.memberId,
              picture:this.getDetails.picture,
      
            }
          console.log("data",data);
     
          this.restProvider
            .updateProfilePic(data )
            .then( (data) => { 
             var result:any=data;
             console.log("data",data);
    
            if(result.status =="success"){
              this.imageSrc=this.imageUrl+result.memberDto.picture;
              this.aboutMe=result.memberDto.aboutMe;
              var reqdata:any;
              reqdata={
                memberId:this.getDetails.memberId,
                firstName:this.getDetails.firstName,
                lastName:this.getDetails.lastName,
                contactNumber:this.getDetails.contactNumber,
                address:this.getDetails.address,
                pincode:this.getDetails.pincode,
                area:this.getDetails.area,
                searchRadius:this.getDetails.searchRadius,
                latitude:this.getDetails.latitude,
                longitude:this.getDetails.longitude,
                createdDateTime: this.getDetails.createdDateTime,
                deviceToken:this.getDetails.deviceToken,
                email:this.getDetails.email,
                inviteFlag:this.getDetails.inviteFlag,
                isActive:this.getDetails.userisActive,
                isDeleted:this.getDetails.userisDeleted,
                mailVerifyFlag:this.getDetails.mailVerifyFlag,
                memberProfilePic:this.getDetails.memberProfilePic,
                memberTypeId:this.getDetails.memberTypeId,
                networkId:this.getDetails.networkId,
                password:this.getDetails.password,
                picture:result.memberDto.picture,
                statusId:this.getDetails.statusId,
                aboutMe:this.aboutMe,
    
              }
             
              this.storage.set("memberDetails", reqdata).then((data)=>{
                this.displayProfileMsg("Profile changes made");
              });
            }
            else{
              this.displayMsg("Profile Picture Updated Failed. Please try again");
            }
              
              this.loading.dismiss();
               
            })
            .catch(error => {
              console.log("error",error);
            this.loading.dismiss();
            this.displayMsg("Please try again later");
          });
      }
      else{
       // alert(this.imageSrc);
       // this.convertToDataURLviaCanvas(this.imageSrc, "image/jpeg").then((data:any) =>{
        
          //this.base64Image = 'data:image/jpg;base64,'+base64data;
          /*alert(data);

          console.log("base64"+data)
          var base64Index = data.indexOf(';base64,') + ';base64,'.length;
          console.log("base64Index",base64Index);
        var base64 = data.substring(base64Index);
          console.log("base64",base64)
          var raw = window.atob(base64);
          console.log("raw",raw)
          var rawLength = raw.length;
          console.log("rawLength",rawLength)
          var array = new Uint8Array(new ArrayBuffer(rawLength));
          console.log("array",array)
          this.imgArr=[];
          for(var i = 0; i < rawLength; i++) {
            array[i] = raw.charCodeAt(i);
            this.imgArr.push(raw.charCodeAt(i));
          }*/
          this.imgArr=null;
  
          this.loading = this.loadingController.create({
            spinner: "bubbles",
          });
          this.loading.present();
            var data:any;
            
            
            data={
                memberProfilePic:this.imgArr,
                aboutMe:this.aboutMe,
                memberId:this.getDetails.memberId,
                picture:this.getDetails.picture,
        
              }
            console.log("data",data);
       
            this.restProvider
              .updateProfilePic(data )
              .then( (data) => { 
               var result:any=data;
               console.log("data",data);
      
              if(result.status =="success"){
                this.imageSrc=this.imageUrl+result.memberDto.picture;
                this.aboutMe=result.memberDto.aboutMe;
                var reqdata:any;
                reqdata={
                  memberId:this.getDetails.memberId,
                  firstName:this.getDetails.firstName,
                  lastName:this.getDetails.lastName,
                  contactNumber:this.getDetails.contactNumber,
                  address:this.getDetails.address,
                  pincode:this.getDetails.pincode,
                  area:this.getDetails.area,
                  searchRadius:this.getDetails.searchRadius,
                  latitude:this.getDetails.latitude,
                  longitude:this.getDetails.longitude,
                  createdDateTime: this.getDetails.createdDateTime,
                  deviceToken:this.getDetails.deviceToken,
                  email:this.getDetails.email,
                  inviteFlag:this.getDetails.inviteFlag,
                  isActive:this.getDetails.userisActive,
                  isDeleted:this.getDetails.userisDeleted,
                  mailVerifyFlag:this.getDetails.mailVerifyFlag,
                  memberProfilePic:this.getDetails.memberProfilePic,
                  memberTypeId:this.getDetails.memberTypeId,
                  networkId:this.getDetails.networkId,
                  password:this.getDetails.password,
                  picture:result.memberDto.picture,
                  statusId:this.getDetails.statusId,
                  aboutMe:this.aboutMe,
      
                }
               
                this.storage.set("memberDetails", reqdata).then((data)=>{
                  this.displayProfileMsg("Profile changes made");
                });
                //this.storage.set("memberDetails",result.memberDto);
               
                
              }
              else{
                this.displayMsg("Profile Picture Updated Failed. Please try again");
              }
                
                this.loading.dismiss();
                 
              })
              .catch(error => {
                console.log("error",error);
              this.loading.dismiss();
              this.displayMsg("Please try again later");
            });
       
      // });
      }
      
    }
    
    

  }
  

/*getBase64ImageFromURL(url: string) {
  return Observable.create((observer: Observer<string>) => {
    let img = new Image();
    img.crossOrigin = 'Anonymous';
    img.src = url;
    if (!img.complete) {
      img.onload = () => {
        observer.next(this.getBase64Image(img));
        observer.complete();
      };
      img.onerror = (err) => {
        observer.error(err);
      };
    } else {
      observer.next(this.getBase64Image(img));
      observer.complete();
    }
  });
}
getBase64Image(img: HTMLImageElement) {
  var canvas = document.createElement("canvas");
  canvas.width =250;
  canvas.height =300;
  var ctx = canvas.getContext("2d");
  ctx.drawImage(img, 0, 0);
  var dataURL = canvas.toDataURL("image/jpeg");
  return dataURL;
}*/

  displayAlert(msg){
    const modal = this.modalCtrl.create(
      'CustomDialogPage',
      {
        titleName: "Change Photo",
        bodyTxt:msg,
        okBtnNm: "Ok",
       
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Ok") {
    
      } 
    });
  
  }
}
@Component({
  selector: "request-success-pop",
  template: `
    <ion-content>
      <ion-label text-center>
        <ion-icon
          ngClass="hdrIcon"
          name="ios-checkmark-circle-outline"
          class="larger"
        ></ion-icon>
        <ion-label ngClass="hdrTxt"
          >Choose your image to upload</ion-label
        >
      </ion-label>
      <ion-row>
        <ion-item>
          <ion-label class="actionItemCls" (click)="btnClick(1)"
            >Capture Image
            <ion-icon
              name="ios-camera-outline"
              class="larger iconCls"
            ></ion-icon>
          </ion-label>
        </ion-item>
      </ion-row>
      <ion-row>
        <ion-item>
          <ion-label class="actionItemCls" (click)="btnClick(2)"
            >Choose from gallery
            <ion-icon
              name="ios-images-outline"
              class="larger iconCls"
            ></ion-icon>
          </ion-label>
        </ion-item>
      </ion-row>

      <ion-row text-center ngClass="btnMainCls">
        <button
          ngClass="btnCls"
          text-center
          ion-button
          color="bright"
          text-capitalize
          text-center
          round
          type="submit"
          (click)="btnClick('Close')"
        >
          Close
        </button>
      </ion-row>
    </ion-content>
  `,
})
export class ChooseImagePop {
  unsubscribeBackEvent: any;
  constructor(
    public platform: Platform,
    private ionicApp: IonicApp,
    public viewCtrl: ViewController,

  ) {}
  ionViewWillEnter() {
    this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
      let activePortal=this.ionicApp._modalPortal.getActive();
        if(activePortal){
          activePortal.dismiss();
        } else {
        return true;
      }
    }, 101);
  }
  ionViewWillLeave() {
    this.unsubscribeBackEvent && this.unsubscribeBackEvent();
  }
  btnClick(data: string) {
    this.viewCtrl.dismiss(data);
  }
}




