import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProfilepicturePage } from './profilepicture';

@NgModule({
  declarations: [
    ProfilepicturePage,
  ],
  imports: [
    IonicPageModule.forChild(ProfilepicturePage),
  ],
})
export class ProfilepicturePageModule {}
