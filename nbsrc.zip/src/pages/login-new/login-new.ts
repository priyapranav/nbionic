import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Storage } from '@ionic/storage';
import { Events, IonicPage, LoadingController, ModalController, NavController, NavParams, ToastController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { CnfrmPage } from '../cnfrm/cnfrm';

/**
 * Generated class for the LoginNewPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-login-new",
  templateUrl: "login-new.html",
})
export class LoginNewPage {
  mobile: any;

  loginForm: FormGroup;
  loading: any;
  grpId: any;

  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    public toastController: ToastController,
    public restProvider: RestProvider,
    public loadingController: LoadingController,
    private formBuilder: FormBuilder,
    public event: Events,
    public navParams: NavParams,
    private storage: Storage
  ) {
    this.loginForm = this.formBuilder.group({
      mobile: [
        "",
        [
          Validators.minLength(10),
          Validators.maxLength(10),
          Validators.pattern("^[0-9]+$"),
          Validators.required,
        ],
      ],
    });
    
  }

  ionViewDidLoad() {
    console.log("ionViewDidLoad LoginNewPage");
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }

  login() {
    // this.navCtrl.push(CnfrmPage,{mobileNumber:this.mobile});
    if (this.loginForm.valid) {
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();

      this.restProvider
        .loginMobileRest(this.mobile)
        .then((data) => {
          var result: any = data;
          
          console.log("mobile login res" + result)
          if (result) {
            this.navCtrl.push(CnfrmPage,{mobileNumber:this.mobile});
          } else {
            this.displayAlert("Please try again later");
          }
          
          this.loading.dismiss();
        })
        .catch((error) => {
          this.loading.dismiss();
          this.displayAlert("Please try again later");
        });
    }
  }
}
