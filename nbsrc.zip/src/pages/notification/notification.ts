import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController} from 'ionic-angular';
import { RestProvider } from "../../providers/rest/rest";
import { Storage } from '@ionic/storage';

/**
 * Generated class for the NotificationPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-notification',
  templateUrl: 'notification.html',
})
export class NotificationPage {

  loading:any;
  memberId:any;
  showNotifFlg: boolean=false;
  noNotifFlg:boolean=false;
  userMemberId: any;
  getDetails: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public toastController : ToastController,
    public loadingController:LoadingController, public restProvider: RestProvider, private storage:Storage) {
  }


  async ngOnInit() {
    this.getDetails= await this.storage.get("memberDetails");
    console.log(this.getDetails.memberId);

  }
 ionViewDidLoad() {
    console.log('ionViewDidLoad NotificationPage');
     
      
   /* await this.storage.get("memberDetails").then((val)=>{
      if(val !=undefined && val !=null && val !=""){
        this.userMemberId=val.memberId;
      }
    });*/
  }

  notifyMsg(){
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    this.restProvider
    .getNotificationMsg(this.getDetails.memberId)
    .then( (data) => { 
      this.loading.dismiss();
      var result : any = data;
      console.log(result);
     
  })
  .catch(error => {
  this.loading.dismiss();
  this.presentToast("Please try again later");
});
  }
   
   presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000
    });
    toast.present();
  }

}

