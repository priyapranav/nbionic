import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from '@ionic/storage';
/**
 * Generated class for the ReminderPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-reminder',
  templateUrl: 'reminder.html',
})
export class ReminderPage {
  userMemberId: any;
  getDetails: any;
  loading: any;
  loading1: any;
  showMsg: boolean;
  noReminder: boolean;
  issuerReminderlist: any;
  issuerNoteDtoReturnDate: any;
  issuerNoteReturnArr: any[]=[];titleArr: any[]=[];
;
  receiverReminderlist: any;
  receiverNoteDtoReturnDate: any;
  receiverNoteReturnArr: any[]=[];
  showIssuerFlg: boolean;
  showreceiverFlg: boolean;
  issuerNoteDtoproductName: any;
  issuerNoteDtorequesterName: any;
  issuerNoteDtosharedOn: any;
  receiverNoteDtoproductName: any;
  receiverNoteDtorequesterName: any;
  receiverNoteDtosharedOn: any;
  title: string;
  currentEvents: { year: number; month: number; date: number;title:any }[];
  issuerNoteDtoReturnDateArr: any;
  splitday: any;
  splitMonth: any;
  splitYr: any;
  receiverNoteDtoReturnDateArr: any;
  memberId: any;
  currentIdx: any;
  type1:any;
  type2: any;
  today: any;
  todayDate: any;
  todayMonth: any;
  todayYear: any;
  curDateEvent: boolean=false;
 constructor(public navCtrl: NavController, public modalCtrl: ModalController,public loadingController: LoadingController,public toastController: ToastController,public restProvider: RestProvider,private storage: Storage,public navParams: NavParams) {
    /*this.currentEvents = [
      {
        year: 2021,
        month: 11,
        date: 25
      },
      {
        year: 2017,
        month: 11,
        date: 26
      }
    ];*/

    //this.getDetails= this.storage.get("memberDetails");
   // console.log(this.getDetails.memberId);
   this.today = new Date();
   this.todayDate = this.today.getDate();
   this.todayMonth = this.today.getMonth();
   this.todayYear = this.today.getFullYear();
   
   this.storage.get("memberDetails").then(val=>{
    if(val !=undefined && val !='' && val !=null){
      if(val!=undefined){
        this.memberId=val.memberId;
        this.issuerReminder(val.memberId);
        //this.receiverReminder(val.memberId);
      }
    }
        });
      
    
 
}
/*async ngOnInit() {
  this.getDetails= await this.storage.get("memberDetails");
  console.log(this.getDetails.memberId);
  
}*/
displayAlert(message) {
  const modal = this.modalCtrl.create(
    "CustomDialogPage",
    {
      dialogFor: "info",
      iconName: "",
      titleName: "",
      bodyTxt: message,
      okBtnNm: "Ok",
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
}

 ionViewDidLoad() {
 
 
    console.log('ionViewDidLoad ReminderPage');
  }
  onDaySelect(event){
    console.log("dayevent",event);
    this.type1 = false;
    this.type2 = false;
   
    var newArray = {};

    //iterate through each element of array
    this.issuerNoteReturnArr.forEach(function(val) {
      console.log("obj",val);
      var curr = newArray[val.date+"-"+val.month]

      //if array key doesnt exist, init with empty array
      if (!curr) {
        newArray[val.date + "-" + val.month] = [];
      }

      //append title to this key
      newArray[val.date + "-" + val.month].push({
        title: val.title,
        type: val.type,
      });
      
    });
    console.log("newarrr",newArray);
 
    if(event.hasEvent){
      this.titleArr=[];
      for (let nidx in newArray[event.date + "-" + event.month]) {
        console.log("1st", newArray[event.date + "-" + event.month]);

        console.log(
          "2nd",
          newArray[event.date + "-" + event.month][nidx].title
        );
        this.titleArr.push({
          msg: newArray[event.date + "-" + event.month][nidx].title,
          type: newArray[event.date + "-" + event.month][nidx].type,
        });
        if (newArray[event.date + "-" + event.month][nidx].type == 1) {
          this.type1 = true;
        }
        if (newArray[event.date + "-" + event.month][nidx].type == 2) {
          this.type2 = true;
        }
        this.showMsg = true;
        this.noReminder = false;
      }
    }
    else {
       this.titleArr = [];
      this.showMsg = false;
      this.noReminder = true;
      this.titleArr.push({ msg: "No reminders have been set for this day." ,type:1});
    }
   
    /*if(event.hasEvent){
      
      if(event.date == newArray[event.date]){
        console.log("1st",newArray[event.date]);
       for(let nid in newArray[event.date]){
         console.log("newArrDt:",newArray[event.date])
       this.title= newArray[event.date][nid];
       console.log("newArrDtval:",newArray[event.date][nid])
       this.showMsg=true;
       }
      }
    }
    else{
      this.showMsg=false;
    }*/
 
    /*if(newArray!=undefined){
    for(let nIdx in newArray){
      console.log("newarrr==>",newArray);
      if(event.hasEvent){
        if(newArray[nIdx] == event.date){
          this.showMsg=true;
          this.title=newArray[nIdx].title;
        }
        else{
          this.showMsg=false;
        }
      }
    }
    }*/
/*if(this.issuerNoteReturnArr!=undefined){
    for(let indx in this.issuerNoteReturnArr){
      if(event.hasEvent){
      if(this.issuerNoteReturnArr[indx].date == event.date && this.issuerNoteReturnArr[indx].month == event.month && this.issuerNoteReturnArr[indx].year == event.year){
        this.showMsg=true;
        this.title=this.issuerNoteReturnArr[indx].title;
      }
    }
    else{
      this.showMsg=false;
    }
    }

}*/
  }
  onMonthSelect(event){
    this.showMsg = false;
    this.noReminder = false;
    console.log("monthevent",event);
  }

  issuerReminder(mid){
    return new Promise((resolve, reject) => {
      this.loading = this.loadingController.create({
        spinner: "bubbles"
      });
      this.loading.present();
       this.restProvider
      .getissuerRemindlist(mid)
      .then((data) => { 
        console.log("data",data);
        var result : any = data;
        this.issuerReminderlist=result;
        //if(this.issuerReminderlist.length !=0){
       console.log("issuerlist",this.issuerReminderlist);
       /*this.issuerNoteReturnArr=[];
                 for(let issuerIdx in this.issuerReminderlist){
                
                  this.issuerNoteDtoReturnDate=this.issuerReminderlist[issuerIdx].returnByStr;
                  this.issuerNoteDtoproductName=this.issuerReminderlist[issuerIdx].productName;
                  this.issuerNoteDtorequesterName=this.issuerReminderlist[issuerIdx].requesterName;
                  this.issuerNoteDtosharedOn=this.issuerReminderlist[issuerIdx].sharedOnStr;
                  this.issuerNoteDtoReturnDateArr=this.issuerNoteDtoReturnDate.split("/");
                  this.splitday=parseInt(this.issuerNoteDtoReturnDateArr[0]);
                  this.splitMonth=parseInt(this.issuerNoteDtoReturnDateArr[1]);
                  if(this.splitMonth ){
                    this.splitMonth =this.splitMonth -1;
                  }
                  this.splitYr=parseInt(this.issuerNoteDtoReturnDateArr[2]);
             
                  console.log("split",this.issuerNoteDtoReturnDate,this.splitday,this.splitMonth,this.splitday);
                  this.title="Time to get"+ " "+this.issuerNoteDtoproductName+" "+"from"+" "+this.issuerNoteDtorequesterName;
                  this.issuerNoteReturnArr.push({year:this.splitYr,month:this.splitMonth,date:this.splitday ,title:this.title});
                 
                  
                 }
                 console.log(this.issuerNoteReturnArr);*/
                 this.receiverReminder(this.memberId);
                //}
        this.loading.dismiss();
      
    })
    .catch(error => {
      console.log("error",error);
      this.loading.dismiss();
    this.displayAlert("Please try again later");
    });
  });
  }

  receiverReminder(mid){
    return new Promise((resolve, reject) => {
      this.loading1 = this.loadingController.create({
        spinner: "bubbles"
      });
      this.loading1.present();
      this.restProvider
      .getreceiverRemindlist(mid)
      .then((data) => { 
        console.log("data",data);
        var result : any = data;
        this.receiverReminderlist=result;
        //this.issuerNoteReturnArr=[];


        this.issuerNoteReturnArr=[];
                 for(let issuerIdx in this.issuerReminderlist){
                
                  this.issuerNoteDtoReturnDate=this.issuerReminderlist[issuerIdx].returnByStr;
                  this.issuerNoteDtoproductName=this.issuerReminderlist[issuerIdx].productName;
                  this.issuerNoteDtorequesterName=this.issuerReminderlist[issuerIdx].requesterName;
                  this.issuerNoteDtosharedOn=this.issuerReminderlist[issuerIdx].sharedOnStr;
                  this.issuerNoteDtoReturnDateArr=this.issuerNoteDtoReturnDate.split("/");
                  this.splitday=parseInt(this.issuerNoteDtoReturnDateArr[0]);
                  this.splitMonth=parseInt(this.issuerNoteDtoReturnDateArr[1]);
                  if(this.splitMonth ){
                    this.splitMonth =this.splitMonth -1;
                  }
                   this.splitYr = parseInt(this.issuerNoteDtoReturnDateArr[2]);
                   if (this.splitday == this.todayDate && this.splitMonth == this.todayMonth && this.splitYr == this.todayYear) {
                     this.curDateEvent = true;
                   }
             
                  console.log("split",this.issuerNoteDtoReturnDate,this.splitday,this.splitMonth,this.splitday);
                 // this.title="Time to get"+ " "+this.issuerNoteDtoproductName+" "+"from"+" "+this.issuerNoteDtorequesterName;
                 this.title =
                   this.issuerNoteDtoproductName +
                   " " +
                   "lend to " +
                   this.issuerNoteDtorequesterName;
                  this.issuerNoteReturnArr.push({year:this.splitYr,month:this.splitMonth,date:this.splitday ,title:this.title,type:1});
                 
                  /*this.issuerNoteReturnArr=[
                    {
                      year: this.splitYr,
                      month: this.splitMonth,
                      date:this.splitday  
                    }
                  ]*/
         // this.issuerNoteReturnArr.push({date:this.splitday,month:this.splitMonth,year:this.splitYr});
                 }
        if(this.receiverReminderlist.length !=0){
         
         for(let recIdx in this.receiverReminderlist){

          this.receiverNoteDtoReturnDate=this.receiverReminderlist[recIdx].returnByStr;
          this.receiverNoteDtoproductName=this.receiverReminderlist[recIdx].productName;
          this.receiverNoteDtorequesterName=this.receiverReminderlist[recIdx].productOwner;
          this.receiverNoteDtosharedOn=this.receiverReminderlist[recIdx].sharedOnStr;
          this.receiverNoteDtoReturnDateArr=this.receiverNoteDtoReturnDate.split("/");
          this.splitday=parseInt(this.receiverNoteDtoReturnDateArr[0]);
          this.splitMonth=parseInt(this.receiverNoteDtoReturnDateArr[1]);
          if(this.splitMonth ){
            this.splitMonth =this.splitMonth -1;
          }
           if (
             this.splitday == this.todayDate &&
             this.splitMonth == this.todayMonth &&
             this.splitYr == this.todayYear
           ) {
             this.curDateEvent = true;
           }
          this.splitYr=parseInt(this.receiverNoteDtoReturnDateArr[2]);
         // this.title="Time to return"+ " "+this.receiverNoteDtoproductName+" "+"to"+" "+this.receiverNoteDtorequesterName; 
          this.title =
            
            this.receiverNoteDtoproductName +" "+
            "borrowd from " +
           
            this.receiverNoteDtorequesterName;
         /*this.issuerNoteReturnArr=[
            {
              year: this.splitYr,
              month: this.splitMonth,
              date:this.splitday  
            }
          ]*/
          console.log("split",this.issuerNoteReturnArr,this.splitday,this.splitMonth,this.splitday);
          this.issuerNoteReturnArr.push({year:this.splitYr,month:this.splitMonth,date:this.splitday,title:this.title,type:2});

         }
         
         console.log("issuerArr",this.issuerNoteReturnArr);
        }
        this.loading1.dismiss();
        let eve = { date: this.todayDate, month: this.todayMonth, hasEvent: this.curDateEvent };
        this.onDaySelect(eve);
      
    })
    .catch(error => {
      console.log("error",error);
      this.loading1.dismiss();
    this.displayAlert("Please try again later");
    });
  });
  }
  
presentToast(params) {
  let toast = this.toastController.create({
  message: params,
  duration: 2000
  });
  toast.present();
  }
}
