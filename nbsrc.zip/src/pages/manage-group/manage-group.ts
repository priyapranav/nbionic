import { Component } from '@angular/core';
import { Storage } from '@ionic/storage';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { GroupmembersPage } from "../groupmembers/groupmembers";
import { InvitefriendsPage } from '../invitefriends/invitefriends';

/**
 * Generated class for the ManageGroupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-manage-group",
  templateUrl: "manage-group.html",
})
export class ManageGroupPage {
  netwrkName: any;
  netwrkId: any;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public storage: Storage
  ) {
    this.storage.get("networkData").then((val) => {
      this.netwrkName = val.networkName;
      this.netwrkId = val.networkId;
    });
  }

  ionViewDidLoad() {
    console.log("ionViewDidLoad ManageGroupPage");
  }
  members() {
    this.navCtrl.push(GroupmembersPage);
  }
  invite() {
    this.navCtrl.push(InvitefriendsPage, { frmGrp: true });
  }
}
