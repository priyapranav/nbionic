import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, ModalController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from "@ionic/storage";
import { HomePage } from '../home/home';
import { MylistingPage } from '../mylisting/mylisting';
import { GroupinfoPage } from '../groupinfo/groupinfo';

/**
 * Generated class for the SearchPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-search',
  templateUrl: 'search.html',
})
export class SearchPage {
 productName:any;
  groupId:any=2;
  userMemberId: any;
  usersearchRadius: any;
  userLat: any;
  userlong: any;
  searchResults: any;
  getDetails: any;
  searchItems: any[]=[];
  loading: any;
  productlist: any;
  page: any;
  constructor(public navCtrl: NavController, public modalCtrl: ModalController,   public loadingCtrl: LoadingController,public storage: Storage, public toastController: ToastController, public restProvider: RestProvider, public navParams: NavParams) {
 
    this.storage.get("lastPage").then((val) => {
      this.page = val;
      
    });
   this.storage.get("groupId").then((value) => {
     this.groupId = value;
   });

  }
  async ngOnInit() {
  this.getDetails= await this.storage.get("memberDetails");
  console.log(this.getDetails);

  }
   ionViewDidLoad() {
 
   
    console.log('ionViewDidLoad SearchPage');
  }

  getItems(event){
    console.log(event.target.value);
    this.productName=event.target.value;
this.getResult();
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }

  getResult(){
    this.restProvider
    .getProductName(this.productName, this.groupId,this.getDetails.memberId,this.getDetails.searchRadius, this.getDetails.latitude, this.getDetails.longitude)
    .then( (data) => { 
      var result : any = data;
      
      if(result.status =="success" )
    {
       this.searchResults=result.productSearchName;
     
      /* if(this.searchResults.length >0){
        this.searchItems=[];
this.searchItems.push(this.searchResults);
console.log("arr",this.searchItems);
       }*/
     
      }
      else{
        this.displayAlert("No such product available for your need");

     }
  })
  .catch(error => {
  this.displayAlert("Please try again later");
  });
  }
  selectSearchResult(item){
    this.searchItems = []; 
    this.productName = item;
    console.log("prodName",this.productName);
    if(this.productName !=undefined){
     this.getsearchResult();
    }
  }
  getsearchResult(){
    
    this.loading = this.loadingCtrl.create({
      spinner: "bubbles",
    });
    this.loading.present();
    
   
    this.restProvider
  .getsearchresponse(this.productName,this.groupId,this.getDetails.memberId,this.getDetails.searchRadius, this.getDetails.latitude, this.getDetails.longitude)
  .then( (data) => { 
    var result : any = data;
   
    console.log("result",data);
   this.productlist=result.productListingSearchDto;
  // if(this.productlist.length >0){
    console.log("productlist", this.productlist);
    if (this.page == 3) {
      this.navCtrl.push(GroupinfoPage, { prodList: this.productlist });
    } else {
      this.navCtrl.push(HomePage, { prodList: this.productlist });
    }

   /* if (this.page == 1) {
      this.navCtrl.push(HomePage,{prodList:this.productlist});
    } else if (this.page == 2) {
      this.navCtrl.push(MylistingPage, {prodList:this.productlist});
    } else if (this.page == 3) {
      this.navCtrl.push(GroupinfoPage, {prodList:this.productlist});
    }*/
   //this.navCtrl.push(HomePage,{prodList:this.productlist});
   //}
   
   
    this.loading.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading.dismiss();
  
    this.displayAlert("Please try again later");
  });
  }
  
 
presentToast(params) {
let toast = this.toastController.create({
message: params,
duration: 2000
});
toast.present();
}
}
