import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, ModalController } from 'ionic-angular';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from '@ionic/storage';
import { Contacts } from "@ionic-native/contacts";
/**
 * Generated class for the InvitefriendsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-invitefriends",
  templateUrl: "invitefriends.html",
})
export class InvitefriendsPage {
  inviteForm: FormGroup;
  email: any;
  mobile: any;
  productType: any;
  emailIdlist: any;
  mobileIdlist: any;
  mobileList: any;
  loading: any;
  getDetails: any;
  userMemberId: any;
  groupDetails: any;
  userAvailableNetwork: any;
  networkNameArr: any[] = [];
  usernetwork: any;
  count = 0;
  emailArr: any[] = [];
  mobileArr: any[] = [];
  emailList: any;
  emailListIds: any;
  mobileListIds: any;
  userSelectednetwrkId: any;
  frmGrp: any;
  netwrkName: any;
  netwrkId: any;

  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    private storage: Storage,
    public toastController: ToastController,
    public loadingController: LoadingController,
    public restProvider: RestProvider,
    private formBuilder: FormBuilder,
    public navParams: NavParams,
    private contacts: Contacts,
    
  ) {
    this.inviteForm = this.formBuilder.group({
      email: [""],
      mobile: [""],
      productType: [""],
      emailListIds: [""],
      mobileListIds: [""],
    });
    this.frmGrp = navParams.get("frmGrp");
    if (this.frmGrp) {
      this.storage.get("networkData").then((val) => {
        this.netwrkName = val.networkName;
        this.netwrkId = val.networkId;
      });
    }
  }
  get eid() {
    return this.inviteForm.get("email") as FormControl;
  }
  get mid() {
    return this.inviteForm.get("mobile") as FormControl;
  }
  get productId() {
    return this.inviteForm.get("productType") as FormControl;
  }
  get emailIds() {
    return this.inviteForm.get("emailListIds") as FormControl;
  }
  get mobileIds() {
    return this.inviteForm.get("mobileListIds") as FormControl;
  }

  async ngOnInit() {
    this.getDetails = await this.storage.get("memberDetails");
    this.userMemberId = this.getDetails.memberId;
    this.getGroup();
  }

  ionViewDidLoad() {
    console.log("ionViewDidLoad InvitefriendsPage");
  }
  displayMsgAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Ok") {
        this.navCtrl.pop();
      }
    });
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  async invite() {
    // this.emailIds.setValidators([Validators.required]);
    // this.emailIds.updateValueAndValidity();

    // this.eid.setValidators(null);
    // this.eid.updateValueAndValidity();
    this.mobileIds.setValidators([Validators.required]);
    this.mobileIds.updateValueAndValidity();

    this.mid.setValidators(null);
    this.mid.updateValueAndValidity();

    this.productId.setValidators([Validators.required]);
    this.productId.updateValueAndValidity();
    if (this.inviteForm.valid) {
      this.count = 0;
      for (let idx in this.groupDetails) {
        if (this.productType == this.groupDetails[idx].networkName) {
          this.userSelectednetwrkId = this.groupDetails[idx].networkId;
        }
      }
      console.log(this.getDetails.memberId);
      return new Promise((resolve, reject) => {
        this.loading = this.loadingController.create({
          spinner: "bubbles",
        });
        this.loading.present();

        if (this.mobileIdlist.length == 0) {
          this.displayAlert(
            "The invite list is empty. Please 'Add' mobile number to this list before you invite"
          );
          return;
        } else {
          var data: any;
          data = {
            memberId: this.getDetails.memberId,
            inviteFlag: 1,
            contactNumber: this.mobileListIds,
            networkId: this.userSelectednetwrkId,
          };

          if (this.productType == "Public") {
            this.restProvider
              .publicInvite(this.getDetails.memberId, this.mobileListIds)
              .then((data) => {
                console.log("data", data);
                var result: any = data;
                if (result.status == "success") {
                  this.mobileListIds = "";
                  this.displayMsgAlert(
                    "Your invite has been sent. Extend more invitations and grow neighbourbase"
                  );
                  //this.navCtrl.pop();
                } else if (result.status == "fail") {
                  this.displayAlert("Invitation Sent Failed");
                }
                this.loading.dismiss();
              })
              .catch((error) => {
                console.log("error", error);
                this.loading.dismiss();
                this.displayAlert("Please try again later");
              });
          } else {
            this.restProvider
              .groupInvite(data)
              .then((data) => {
                var result: any = data;
                if (result.status == "success") {
                  this.mobileListIds = "";
                  this.displayMsgAlert(
                    "Your invite has been sent. Extend more invitations and grow neighbourbase"
                  );
                  //this.navCtrl.pop();
                } else if (result.status == "fail") {
                  this.displayAlert("Invitation Sent Failed");
                }
                this.loading.dismiss();
              })
              .catch((error) => {
                console.log("error", error);
                this.loading.dismiss();
                this.displayAlert("Please try again later");
              });
          }
          /* this.restProvider
         .inviteFriends()
         .then((data) => { 
           var result : any = data;
           this.loading.dismiss();
         
       })
       .catch(error => {
         this.loading.dismiss();
       this.presentToast("Please try again later");
       });*/
        }
      });
    } else {
      this.displayAlert("Please Enter All Fields!");
    }
  }
  getGroup() {
    return new Promise((resolve, reject) => {
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();

      //response came in error callback
      this.restProvider
        .getGroupdet(this.getDetails.memberId)
        .then((data) => {
          console.log("data", data);
          this.groupDetails = data;
          for (let idx in this.groupDetails) {
            this.userAvailableNetwork = this.groupDetails[idx].networkName;
            this.usernetwork = this.groupDetails[idx].networkId;
            this.networkNameArr.push({
              networkName: this.userAvailableNetwork,
              networkid: this.usernetwork,
            });

            console.log(this.networkNameArr);
          }
          if (this.frmGrp) {
            this.productType = this.netwrkName;
          } else {
            this.productType = this.networkNameArr[0].networkName;
          }

          this.loading.dismiss();
        })
        .catch((error) => {
          console.log("error", error);

          this.loading.dismiss();
          this.displayAlert("Please try again later");
        });
    });
  }
  getNetworkname() {
    console.log("productType", this.productType);
  }

  addEmail() {
    /*var mailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^ <>() \[\]\\.,;: \s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      if (this.email.match(mailformat)) {
        console.log("ok");
       
      
      } else {
        
        this.displayAlert("Enter valid email id");
      return;
      }*/
    console.log("count", this.count);
    this.emailIds.setValidators(null);
    this.emailIds.updateValueAndValidity();

    this.eid.setValidators([Validators.required]);
    this.eid.updateValueAndValidity();

    this.productId.setValidators(null);
    this.productId.updateValueAndValidity();
    if (this.inviteForm.valid) {
      if (++this.count == 1) {
        this.emailIdlist = this.email;
        this.emailListIds = this.emailIdlist;
        this.email = "";
      } else if (this.count > 1) {
        this.emailList = "," + this.email;
        this.emailListIds = this.emailListIds + this.emailList;
        this.email = "";
      }
    } else {
      this.displayAlert(
        "The invite list is empty. Please Add email to this list before you invite !"
      );
    }
  }
  addMobile() {
    console.log("count", this.count);
    this.mobileIds.setValidators(null);
    this.mobileIds.updateValueAndValidity();

    this.mid.setValidators([
      Validators.minLength(10),
      Validators.maxLength(10),
      Validators.pattern("^[0-9]+$"),
      Validators.required,
    ]);
    this.mid.updateValueAndValidity();

    this.productId.setValidators(null);
    this.productId.updateValueAndValidity();
    if (this.inviteForm.valid) {
      if (++this.count == 1) {
        this.mobileIdlist = this.mobile;
        this.mobileListIds = this.mobileIdlist;
        this.mobile = "";
      } else if (this.count > 1) {
        this.mobileList = "," + this.mobile;
        this.mobileListIds = this.mobileListIds + this.mobileList;
        this.mobile = "";
      }
    } else {
      this.displayAlert(
        "The invite list is empty. Please Add mobile number to this list before you invite !"
      );
    }
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }

  getContacts() {
   

    
    //this.contactFlg = true;
    this.contacts.pickContact().then((contact) => {
     //this.contactFlg = false;
     // this.name = contact.name.formatted;
      var mob: String = contact.phoneNumbers[0].value;

      mob = mob.replace(/[^\w\s]/gi, "");
      mob = mob.split(" ").join("");
      mob = mob.slice(mob.length - 10);

      this.mobile = mob;
    });
  }
}
