import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController, ViewController, Platform, IonicApp } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from "@ionic/storage";
import { HomePage } from '../home/home';
/**
 * Generated class for the ProductviewPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-productview",
  templateUrl: "productview.html",
})
export class ProductviewPage {
  list: any;
  prodownerName: any;
  prodName: any;
  prodPic: any;
  imgUrl: string;
  prodDesc: any;
  segName: any;
  prodAvailfrom: any;
  prodAvailTo: any;
  prodText: any;
  loading: any;
  getDetails: any;
  prodId: any;
  loading1: any;
  productRating: any;
  ownerRating: any;
  zeroownerFlg: boolean;
  oneownerFlg: boolean;
  twoownerFlg: boolean;
  threeownerFlg: boolean;
  fourownerFlg: boolean;
  zeroprodFlg: boolean;
  oneprodFlg: boolean;
  twoprodFlg: boolean;
  threeprodFlg: boolean;
  fourprodFlg: boolean;
  zeroOwnerRating: boolean;
  zeroProdRating: boolean;
  prodNetworkid: any;
  blockList: any;
  reqList: any;
  reportData: any;
  prodPriceday: any;
  prodPriceweek: any;
  prodPricemonth: any;
  displayName: string;
  sellAmount: any;
  frmGrp: boolean;
  netwrkName: any;
  netwrkId: any;
  category: any;

  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    public toastController: ToastController,
    public storage: Storage,
    public navParams: NavParams,
    public restProvider: RestProvider,
    public loadingController: LoadingController
  ) {
    this.imgUrl = this.restProvider.imgUrl;
    this.list = navParams.get("data");
    this.segName = navParams.get("fieldname");
    this.frmGrp = navParams.get("frmGrp");
    this.category = this.list.rootCategoryName+" / "+this.list.categoryName;
   
    console.log("list", this.list);
    if (this.segName == 1) {
      this.segName = "Borrow";
    } else if (this.segName == 2) {
      this.segName = "Rent";
    } else if (this.segName == 3) {
      this.segName = "Buy";
      this.displayName = "sell";
    } else if (this.segName == 4) {
      this.segName = "Giveaway";
    }

    if (this.list != undefined) {
      this.prodId = this.list.productId;
      this.prodownerName = this.list.ownerName;
      this.prodNetworkid = this.list.networkId;
      this.prodName = this.list.productName;
      this.prodPic = this.list.picture;
      this.prodDesc = this.list.productDescription;
      this.prodAvailfrom = this.list.dayfrom;
      this.prodAvailTo = this.list.dayto;
      if (this.segName == "Rent") {
        this.prodPriceday = this.list.priceperday;
        this.prodPriceweek = this.list.priceperweek;
        this.prodPricemonth = this.list.pricepermonth;
      } else if (this.segName == "Buy") {
        this.sellAmount = this.list.salePrice;
      }
      if (
        this.segName == "Borrow" ||
        this.segName == "Rent" ||
        this.segName == "Buy"
      ) {
        this.prodText =
          "I would like to" +
          " " +
          this.segName +
          " Your" +
          " " +
          this.prodName;
      } else if (this.segName == "Giveaway") {
        this.prodText =
          "I would like to" + " " + "get Your" + " " + this.prodName;
      }

      console.log("list", this.list, this.segName);

      if (this.prodAvailfrom == 1) {
        this.prodAvailfrom = "Sunday";
      } else if (this.prodAvailfrom == 2) {
        this.prodAvailfrom = "Monday";
      } else if (this.prodAvailfrom == 3) {
        this.prodAvailfrom = "Tuesday";
      } else if (this.prodAvailfrom == 4) {
        this.prodAvailfrom = "Wednesday";
      } else if (this.prodAvailfrom == 5) {
        this.prodAvailfrom = "Thursday";
      } else if (this.prodAvailfrom == 6) {
        this.prodAvailfrom = "Friday";
      } else if (this.prodAvailfrom == 7) {
        this.prodAvailfrom = "Saturday";
      }

      if (this.prodAvailfrom != null && this.prodAvailTo != null) {
        if (this.prodAvailTo == 0) {
          this.prodAvailTo = "only";
        } else if (this.prodAvailTo == 1) {
          this.prodAvailTo = " to Sunday";
        } else if (this.prodAvailTo == 2) {
          this.prodAvailTo = "to Monday";
        } else if (this.prodAvailTo == 3) {
          this.prodAvailTo = "to Tuesday";
        } else if (this.prodAvailTo == 4) {
          this.prodAvailTo = "to Wednesday";
        } else if (this.prodAvailTo == 5) {
          this.prodAvailTo = "to Thursday";
        } else if (this.prodAvailTo == 6) {
          this.prodAvailTo = "to Friday";
        } else if (this.prodAvailTo == 7) {
          this.prodAvailTo = "to Saturday";
        }
      } else if (this.prodAvailfrom == null && this.prodAvailTo != null) {
        if (this.prodAvailTo == 0) {
          this.prodAvailTo = "only";
        } else if (this.prodAvailTo == 1) {
          this.prodAvailTo = " Sunday";
        } else if (this.prodAvailTo == 2) {
          this.prodAvailTo = " Monday";
        } else if (this.prodAvailTo == 3) {
          this.prodAvailTo = " Tuesday";
        } else if (this.prodAvailTo == 4) {
          this.prodAvailTo = "Wednesday";
        } else if (this.prodAvailTo == 5) {
          this.prodAvailTo = " Thursday";
        } else if (this.prodAvailTo == 6) {
          this.prodAvailTo = " Friday";
        } else if (this.prodAvailTo == 7) {
          this.prodAvailTo = " Saturday";
        }
      }
    }

     if (this.frmGrp) {
       this.storage.get("networkData").then((val) => {
         this.netwrkName = val.networkName;
         this.netwrkId = val.networkId;
          this.prodNetworkid = this.netwrkId;
       });
     }

   
  }

  async ngOnInit() {
    this.getDetails = await this.storage.get("memberDetails");
    console.log("details", this.getDetails.memberId);
    this.getRating();
    this.getProdRating();
  }
  send() {
    this.loading1 = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading1.present();

    /*var data:any;
    data={
      productId:this.prodId,
      networkId:this.prodNetworkid,
      requestStatusId:2,
      firstReqstMsg:this.prodText
    }*/
    this.restProvider
      .getAllreq(this.prodId, this.getDetails.memberId)
      .then((data) => {
        var result: any = data;

        console.log("result", data);
        this.blockList = result.blockListDto;
        this.reqList = result.requestDtos;
        if (this.prodId == this.reqList.productId) {
          this.displayMsgAlert(
            "There is a similar request already pending, check your message box"
          );
        } else {
          if (this.blockList.length > 0) {
            this.displayMsgAlert(
              "You blocked this member for send request unblock the member"
            );
          } else {
            this.getsendResponse(this.getDetails.memberId);
          }
        }

        this.loading1.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.loading1.dismiss();

        this.displayAlert("Please try again later");
      });
  }

  getsendResponse(id) {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    var data: any;
    data = {
      productId: this.prodId,
      networkId: this.prodNetworkid,
      requestStatusId: 1,
      firstReqstMsg: this.prodText,
    };
    this.restProvider
      .sendreq(data, id)
      .then((data) => {
        var result: any = data;

        console.log("result", data);
        if (result != null) {
          this.displayMsgAlert(
            "Your request has been submitted. Await response."
          );
          //this.navCtrl.pop();
        }

        this.loading.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.loading.dismiss();

        this.displayAlert("Please try again later");
      });
  }
  getRating() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    this.restProvider
      .getOwnerRating(this.getDetails.memberId)
      .then((data) => {
        var result: any = data;

        console.log("result", data);
        this.ownerRating = result.avgRating;
        if (this.ownerRating == 0 || this.ownerRating < 1) {
          // this.zeroOwnerRating=true;
          this.zeroownerFlg = false;
          this.oneownerFlg = false;
          this.twoownerFlg = false;
          this.threeownerFlg = false;
          this.fourownerFlg = false;
        } else if (this.ownerRating == 1 || this.ownerRating < 2) {
          this.zeroownerFlg = true;
          this.oneownerFlg = false;
          this.twoownerFlg = false;
          this.threeownerFlg = false;
          this.fourownerFlg = false;

          this.zeroOwnerRating = false;
        } else if (this.ownerRating == 2 || this.ownerRating < 3) {
          this.zeroownerFlg = true;
          this.oneownerFlg = true;
          this.twoownerFlg = false;
          this.threeownerFlg = false;
          this.fourownerFlg = false;

          this.zeroOwnerRating = false;
        } else if (this.ownerRating == 3 || this.ownerRating < 4) {
          this.zeroownerFlg = true;
          this.oneownerFlg = true;
          this.twoownerFlg = true;
          this.threeownerFlg = false;
          this.fourownerFlg = false;

          this.zeroOwnerRating = false;
        } else if (this.ownerRating == 4 || this.ownerRating < 5) {
          this.zeroownerFlg = true;
          this.oneownerFlg = true;
          this.twoownerFlg = true;
          this.threeownerFlg = true;
          this.fourownerFlg = false;

          this.zeroOwnerRating = false;
        } else if (this.ownerRating == 5) {
          this.zeroownerFlg = true;
          this.oneownerFlg = true;
          this.twoownerFlg = true;
          this.threeownerFlg = true;
          this.fourownerFlg = true;

          this.zeroOwnerRating = false;
        }
        this.loading.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.loading.dismiss();

        this.displayAlert("Please try again later");
      });
  }
  displayMsgAlert(msg) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
       // titleName: "Neighbourbase",
        bodyTxt: msg,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      console.log(data);
      if (data == "Ok") {
        this.navCtrl.pop();
      }
    });
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  getProdRating() {
    this.loading1 = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading1.present();

    this.restProvider
      .getProductRating(this.prodId)
      .then((data) => {
        var result: any = data;
        this.productRating = result.avgRating;
        if (this.productRating == 0 || this.productRating < 1) {
          // this.zeroProdRating=true;

          this.zeroprodFlg = false;
          this.oneprodFlg = false;
          this.twoprodFlg = false;
          this.threeprodFlg = false;
          this.fourprodFlg = false;
        } else if (this.productRating == 1 || this.productRating < 2) {
          this.zeroprodFlg = true;
          this.oneprodFlg = false;
          this.twoprodFlg = false;
          this.threeprodFlg = false;
          this.fourprodFlg = false;

          this.zeroProdRating = false;
        } else if (this.productRating == 2 || this.productRating < 3) {
          this.zeroprodFlg = true;
          this.oneprodFlg = true;
          this.twoprodFlg = false;
          this.threeprodFlg = false;
          this.fourprodFlg = false;

          this.zeroOwnerRating = false;
        } else if (this.productRating == 3 || this.productRating < 4) {
          this.zeroprodFlg = true;
          this.oneprodFlg = true;
          this.twoprodFlg = true;
          this.threeprodFlg = false;
          this.fourprodFlg = false;

          this.zeroProdRating = false;
        } else if (this.productRating == 4 || this.productRating < 5) {
          this.zeroprodFlg = true;
          this.oneprodFlg = true;
          this.twoprodFlg = true;
          this.threeprodFlg = true;
          this.fourprodFlg = false;

          this.zeroProdRating = false;
        } else if (this.productRating == 5) {
          this.zeroprodFlg = true;
          this.oneprodFlg = true;
          this.twoprodFlg = true;
          this.threeprodFlg = true;
          this.fourprodFlg = true;

          this.zeroProdRating = false;
        }
        console.log("result", data);

        this.loading1.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.loading1.dismiss();

        this.displayAlert("Please try again later");
      });
  }
  ionViewDidLoad() {
    console.log("ionViewDidLoad ProductviewPage");
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }
  abuse() {
    const modal = this.modalCtrl.create(
      ReportAbusePop,
      {},
      { cssClass: "customModal1", enableBackdropDismiss: false }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      console.log(data);

      if (data != "Close") {
        this.reportData = data;
        this.getAbuseReport(this.reportData);
      } else {
      }
    });
  }
  getAbuseReport(reportdata) {
    if (reportdata != "Close") {
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();

      var data: any;
      data = {
        reportingMemberId: this.getDetails.memberId,
        networkId: this.prodNetworkid,
        productId: this.prodId,
        remarks: reportdata,
      };
      this.restProvider
        .createAbusereport(data)
        .then((data) => {
          var result: any = data;
          //response came in error callback
          console.log("result", data);
          if (result == "SUCCESS") {
            this.displayMsgAlert(
              "Thanks for reporting this listing. Neighbourbase Admin will review your report and take appropriate action."
            );
            //this.navCtrl.pop();
          } else if (result == "FAIL") {
            this.displayAlert("Abuse can't be reported.. please try again");
          }

          this.loading.dismiss();
        })
        .catch((error) => {
          console.log("error", error);
          this.loading.dismiss();

          this.displayAlert("Please try again later");
        });
    }
  }
}
@Component({
  selector: "fav-name-pop",
  template: `
    <ion-header no-border>
      <ion-toolbar>
        <ion-title text-center>
          <img
            src="assets/imgs/logo.png"
            height="30dp"
            style="padding-top: 5px;"
          />
        </ion-title>

        <ion-buttons end>
          <button
            clear
            ion-button
            style="background-color: transparent;border: none;"
            (click)="closePop()"
          >
            <div>
              <ion-icon style="color: black;" name="ios-close"></ion-icon>
            </div>
          </button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content padding>
      <ion-label
        text-center
        style="color:black;font-size:13px;margin-bottom: 0px;"
      >
        Report any objectionable listings that
      </ion-label>
      <ion-label
        text-center
        style="color:black;font-size:13px;padding:2px;margin:0px"
      >
        offends your sentiments
      </ion-label>

     
        <ion-item text-wrap 
        style="border: 1px solid gray;margin-left:10px;margin-right:10px;margin-top:15px;margin-bottom:15px">
          <ion-textarea
            type="text" style="font-size:14px"
            placeholder="Enter details"
            [(ngModel)]="reportName"
          >
          </ion-textarea>
        </ion-item>
    

      <ion-row text-center ngClass="btnMainCls">
        <button
          ngClass="btnCls"
          text-center
          ion-button
          color="#15B37A"
          text-capitalize
          text-center
          type="submit"
          (click)="submitFav()"
        >
          Report
        </button>
      </ion-row>
    </ion-content>
  `,
})
export class ReportAbusePop {
  public reportName: string;
  unsubscribeBackEvent: any;
  constructor(
    public toastCtrl: ToastController,
    public platform: Platform,
    private ionicApp: IonicApp,
    public viewCtrl: ViewController
  ) {}

  closePop() {
    this.viewCtrl.dismiss("Close");
  }

  ionViewWillEnter() {
    this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
      let activePortal = this.ionicApp._modalPortal.getActive();
      if (activePortal) {
        activePortal.dismiss("Close");
      } else {
        return true;
      }
    }, 101);
  }
  ionViewWillLeave() {
    this.unsubscribeBackEvent && this.unsubscribeBackEvent();
  }
  submitFav() {
    if (this.reportName != "" && this.reportName != undefined) {
      this.viewCtrl.dismiss(this.reportName);
    } else {
      let toast = this.toastCtrl.create({
        message: "Enter details for report ",
        duration: 2000,
        position: "bottom",
      });
      toast.present(toast);
    }
  }
}
