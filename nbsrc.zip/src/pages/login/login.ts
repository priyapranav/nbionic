import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController, Events } from 'ionic-angular';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RegisterPage } from '../register/register';
import { RestProvider } from '../../providers/rest/rest';
import { ForgetpasswordPage } from '../forgetpassword/forgetpassword';
import { HomePage } from '../home/home';
import { Observable } from 'rxjs/Observable';
import { Storage } from '@ionic/storage';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  email: any;
  password: any;
  rememberMe:boolean=false;
  loginForm: FormGroup;
  loading: any;
  constructor(public navCtrl: NavController, public modalCtrl: ModalController,public toastController: ToastController,
    public restProvider: RestProvider,public loadingController: LoadingController,
    private formBuilder: FormBuilder,    public event:Events,
    public navParams: NavParams, private storage: Storage) 
    {
    this.loginForm = this.formBuilder.group({
      email: ["", [Validators.required]],
      password: ["", [Validators.required]],
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

  validation_messages = {
    'email': [
      { type: 'required', message: 'User Name is required' },],
    
      'password':  [{ type: 'required', message: 'Password is required' }]
  }

  register()
  {
    this.navCtrl.push(RegisterPage);
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  login()
  {  

    if (this.loginForm.valid) 
    {
     
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
    
      this.restProvider
        .loginRest( this.email, this.password )
        .then( (data) => { 
           var result:any = data;
          var sts =result.status;
        
        

           
          if(result!=null && sts=="success")
          {

           

             var productDetails={pincode: result.memberDto.pincode, 
          latitude: result.memberDto.latitude, 
          longitude: result.memberDto.longitude,
           memberId:result.memberDto.memberId,radius:result.memberDto.searchRadius}
           
           this.storage.set("memberDetails",result.memberDto);
           this.storage.set("memberAddress",result.memberDto.address);
           this.storage.set("memberId", result.memberDto.memberId);
           this.storage.set("productDet",productDetails);
           this.storage.set("latitude", result.memberDto.latitude);
           this.storage.set("longitude", result.memberDto.longitude);
           this.event.publish(
            "user:created",
            result.memberDto.memberId
         
          );
         
            this.navCtrl.setRoot(HomePage);
           
          }
          else if(result.status =="USERNAME")
          {
            
            this.displayAlert("Please enter valid email ");
          } 
          else if(result.status =="PASSWORD"){
           
            this.displayAlert("Please enter valid password");
          } 
          this.loading.dismiss();
        })
        .catch(error => {
        this.loading.dismiss();
        this.displayAlert("Please try again later");
      });
 
    }

  }
   
   presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000
    });
    toast.present();
  }

  
  forgetPwd()
{
  this.navCtrl.push(ForgetpasswordPage);
}
}