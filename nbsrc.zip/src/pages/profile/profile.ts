import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from "@ionic/storage";
/**
 * Generated class for the ProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage {
  profileForm: FormGroup;
  loading: any;
  firstName: any;
  lastName: any;
  area:any;
  phoneNo: any;
  searchRadius:any;
  address:any;
  pinCode:any;
  memberId:any;
  userMemberId: any;
  userAddress: any;
  userArea: any;
  userLat: any;
  userlong: any;
  usercreatedTime: any;
  usercontactno: any;
  useraboutMe: any;
  userdeviceToken: any;
  useremail: any;
  userfirstName: any;
  usermailVerifyFlag: any;
  usermemberId: any;
  usermemberProfilePic: any;
  usermemberTypeId: any;
  usernetworkId: any;
  userpicture: any;
  userpincode: any;
  usersearchRadius: any;
  userstatusId: any;
  userinviteFlag: any;
  userisActive: any;
  userisDeleted: any;
  userlastName: any;
  userPassword: any;
  getupdatedMemberDto: any;
  getDetails: any;
  constructor(public navCtrl: NavController, public modalCtrl: ModalController, public storage:Storage,public navParams: NavParams, public toastController: ToastController,public restProvider: RestProvider,private formBuilder: FormBuilder,public loadingController: LoadingController,) {
    this.profileForm = this.formBuilder.group({
      firstName: ["", [Validators.required]],
      lastName: [""],
      phoneNo: [
        "",
        [
          Validators.pattern("^[0-9]+$"),
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10),
        ],
      ],
      searchRadius:["",[Validators.required]],
      address:[""], 
     area:["",[Validators.required]],
      pinCode:["",[Validators.required]],
    });
    
     
  }

  async ngOnInit() {
    this.getDetails= await this.storage.get("memberDetails");
    console.log(this.getDetails.memberId);
    this.firstName=this.getDetails.firstName;
    this.lastName=this.getDetails.lastName;
    this.pinCode=this.getDetails.pincode;
    this.address=this.getDetails.address;
    this.area=this.getDetails.area;
    this.searchRadius=this.getDetails.searchRadius;
    this.phoneNo=this.getDetails.contactNumber;
  }
  validation_messages = {
    firstName: [{ type: "required", message: "FirstName is required" }],
   
    searchRadius:[
      {type: "required", message: "SearchRadius is required" }
    
  ],
    
  pinCode:[{
      type: "required", message: "PinCode is required"
    }
  ],
  phoneNo: [
    { type: "required", message: "Phone Number is required" },
    { type: "minlength", message: " Phone Number must be 10 numbers" },
    { type: "maxlength", message: " Phone Number should be 10 numbers" },
    { type: "pattern", message: " Phone Number must be numbers" },
  ],
 
area:[
  {type: "required", message: "Area is required" }
],
    
   
    
  };
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }

  ionViewDidLoad() {
    
  
    console.log('ionViewDidLoad ProfilePage');
  }

  change(){

    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();


    if (this.profileForm.valid) 
    {
     
     

      var data:any;
      
    data={
        memberId:this.getDetails.memberId,
        firstName:this.firstName,
        lastName:this.lastName,
        contactNumber:this.phoneNo,
        address:this.address,
        pincode:parseInt(this.pinCode),
        area:this.area,
        searchRadius:this.searchRadius,
        latitude:this.getDetails.latitude,
        longitude:this.getDetails.longitude
   
      }
      
    
      this.restProvider
        .changeprofile(data )
        .then( (data) => { 
         var result:any=data;
         

          if(result.status == "success")
          {
        this.getupdatedMemberDto=result.memberDto;
       if(this.getupdatedMemberDto !=null){
          this.updateMemberId(this.getupdatedMemberDto);
         
          this.displayProfileMsg("Profile changes made");
          //this.navCtrl.pop();
        }
           
          
            
          }
          else if(result.status == "fail"){
this.displayAlert("Profile change failed please try again");
          }
          
          this.loading.dismiss();
           
        })
        .catch(error => {
        this.loading.dismiss();
        this.displayAlert("Please try again later");
      });
 
    
    }
  }
  displayProfileMsg(message){
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if(data == "Ok"){
        this.navCtrl.pop();
      }

    });
  }
  reset(){
    console.log("reset",this.userfirstName)
this.firstName=this.getDetails.firstName;
this.lastName=this.getDetails.lastName;
this.address=this.getDetails.address;
this.area=this.getDetails.area;
this.pinCode=this.getDetails.pincode;
this.searchRadius=this.getDetails.searchRadius;
this.phoneNo=this.getDetails.contactNumber;
  }

   presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000
    });
    toast.present();
  }

  updateMemberId(val){
    //fn,ln,rad,no
    /*lastName:ln,
    searchRadius:rad,
    contactNumber:no,
    aboutMe:this.useraboutMe,
    address: (this.address!=null ?this.address:this.userAddress),
    area: (this.area!=null ?this.area:this.userArea),
    createdDateTime: this.usercreatedTime,
    deviceToken:this.userdeviceToken,
    email: this.useremail,
    inviteFlag:this.userinviteFlag,
    isActive:this.userisActive,
    isDeleted: this.userisDeleted,
    latitude: this.userLat,
    longitude: this.userlong,
    mailVerifyFlag: this.usermailVerifyFlag,
    memberId: this.usermemberId,
    memberProfilePic:this.usermemberProfilePic,
    memberTypeId: this.usermemberTypeId,
    networkId: this.usernetworkId,
    password: this.userPassword,
    picture:this.userpicture,
    statusId: this.userstatusId,
    pincode: (this.pinCode!=null ?this.pinCode:this.userpincode*/
    this.storage.set("memberDetails",val);
    
 
  }
}


  

