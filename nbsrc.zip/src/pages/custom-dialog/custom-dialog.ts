import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, Events } from 'ionic-angular';

/**
 * Generated class for the CustomDialogPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-custom-dialog',
  templateUrl: 'custom-dialog.html',
})
export class CustomDialogPage {
  
  iconName:string;
  dialogFor:string;
  titleName:string;
  bodyTxt:string;
  okBtnNm:string;
  okBtnEventNm:string;
  cancelBtnNm:string;
  cancelBtnEventNm:string;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    public viewCtrl: ViewController) {
    
      this.iconName = this.navParams.get('iconName');
    this.iconName = this.iconName == undefined ? "" : this.iconName;

    this.dialogFor = this.navParams.get('dialogFor');
    this.dialogFor = this.dialogFor == undefined ? "" : this.dialogFor;

    this.titleName = this.navParams.get('titleName');
    this.titleName = this.titleName == undefined ? "" : this.titleName;

    this.bodyTxt = this.navParams.get('bodyTxt');
    this.bodyTxt = this.bodyTxt == undefined ? "" : this.bodyTxt;

    this.okBtnNm = this.navParams.get('okBtnNm');
    this.okBtnNm = this.okBtnNm == undefined ? "" : this.okBtnNm;

    this.okBtnEventNm = this.navParams.get('okBtnEventNm');
    this.okBtnEventNm = this.okBtnEventNm == undefined ? "" : this.okBtnEventNm;

    this.cancelBtnNm = this.navParams.get('cancelBtnNm');
    this.cancelBtnNm = this.cancelBtnNm == undefined ? "" : this.cancelBtnNm;

    this.cancelBtnEventNm = this.navParams.get('cancelBtnEventNm');
    this.cancelBtnEventNm = this.cancelBtnEventNm == undefined ? "" : this.cancelBtnEventNm;
  }

  ionViewDidLoad() {
  }

  btnClick(data: string) {
  
    this.viewCtrl.dismiss(data);
  }

  closeModal() {
    this.viewCtrl.dismiss();
  }
}
