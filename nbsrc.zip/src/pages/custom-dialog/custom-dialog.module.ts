import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CustomDialogPage } from './custom-dialog';

@NgModule({
  declarations: [
    CustomDialogPage,
  ],
  imports: [
    IonicPageModule.forChild(CustomDialogPage),
  ],
})
export class CustomDialogPageModule {}
