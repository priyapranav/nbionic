import { Component } from '@angular/core';
import { IonicPage, ModalController, NavController, NavParams, ToastController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { HomePage } from '../home/home';
import { Storage } from '@ionic/storage';
import { SelectgroupPage } from '../selectgroup/selectgroup';
import { InvitefriendsPage } from '../invitefriends/invitefriends';
import { UsefulcontactsPage } from '../usefulcontacts/usefulcontacts';
import { GroupinfoPage } from '../groupinfo/groupinfo';

/**
 * Generated class for the GroupmembersPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-groupmembers",
  templateUrl: "groupmembers.html",
})
export class GroupmembersPage {
  //  networkDet: any;
  List: any;
  Length: any;

  memId: any;
  flg: any;
  primaryFlg: any;
  memberId: any;
  imgUrl: any;
  networkId: any;
  networkName: any;
  networkDet: any;
  netwrkImg: any;

  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    public storage: Storage,
    public toastController: ToastController,
    public restProvider: RestProvider,
    public navParams: NavParams
  ) {
    this.imgUrl = restProvider.imgUrl;

    this.storage.get("networkData").then((val) => {
      this.networkId = val.networkId;
      this.networkDet = val;
      this.networkName = val.networkName;
      this.netwrkImg = val.networkImg;
      this.memberId = val.memberId;
      this.memberDetail();
    });
  }

  /*async ngOnInit() {
    this.memberId= await this.storage.get("memberId");
  }*/
  ionViewDidLoad() {
    console.log("ionViewDidLoad GroupmembersPage");
  }
  members() {
    this.navCtrl.push(GroupmembersPage, { memData: this.networkDet });
  }
  goBackbtn() {
    //this.navCtrl.push(GroupinfoPage);
    this.navCtrl.pop();
  }

  home() {
    this.navCtrl.push(HomePage);
  }

  invite() {
    this.navCtrl.push(InvitefriendsPage);
  }
  contacts() {
    this.navCtrl.push(UsefulcontactsPage, { data: this.networkDet.networkId });
  }

  memberDetail() {
    this.restProvider
      .getMemberDetails(this.networkDet.networkId, this.memberId)
      .then((data) => {
        var result: any = data;
        console.log(result);

        if (result != null) {
          this.List = result.privateNetworkDto.networkMemberDtos;

          for (let index in this.List) {
            if (this.List[index].memberId == this.memberId) {
              this.primaryFlg = this.List[index].primaryFlag;
            }
          }

          this.Length = this.List.length;
          console.log("success");
        }
      })
      .catch((error) => {
        console.log(error);
        this.displayAlert("Please try again later");
      });
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }

  exit(memberId, networkId) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        titleName: "",

        bodyTxt: "Are you sure want to leave network?",

        okBtnNm: "Yes",
      },

      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );

    modal.present();

    modal.onDidDismiss((data) => {
      console.log(data);
      console.log("mI" + memberId);

      console.log("nI" + networkId);
      if (data == "Yes") {
        this.exitAlert(memberId, networkId);
      }
    });
  }

  alertBox() {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        titleName: "",

        bodyTxt:
          "Network must have a moderator. Please assign moderator and leave",

        okBtnNm: "Ok",
      },

      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: false }
    );

    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Ok") {
        return;
      }
    });
  }

  exitAlert(memberId, networkId) {
    this.restProvider
      .exitMember(memberId, networkId)
      .then((data) => {
        var result: any = data;
        
        console.log(result);
        const modal = this.modalCtrl.create(
          "CustomDialogPage",
          {
            titleName: "",

            bodyTxt: result,

            okBtnNm: "",
          },

          {
            cssClass: "customModal1 customHrdTxt1",
            enableBackdropDismiss: true,
          }
        );

        modal.present();

        modal.onDidDismiss((data) => {
          this.navCtrl.push(SelectgroupPage);
        });

        // if (result == "SUCCESS") {
          
        // } else if (result == "FAIL") {
        //   const modal = this.modalCtrl.create(
        //     "CustomDialogPage",
        //     {
        //       titleName: "",

        //       bodyTxt: "Member Can't be Removed, Please try again...",

        //       okBtnNm: "Ok",
        //     },

        //     {
        //       cssClass: "customModal1 customHrdTxt1",
        //       enableBackdropDismiss: true,
        //     }
        //   );

        //   modal.present();
        //   modal.onDidDismiss((data) => {
        //     return;
        //   });
        // }
      })
      .catch((error) => {
        console.log(error);
        this.displayAlert("Please try again later");
      });
  }

  assign(memberId, networkId) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        titleName: "",

        bodyTxt: "Are you sure want to add moderator?",

        okBtnNm: "Yes",
      },

      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );

    modal.present();

    modal.onDidDismiss((data) => {
      if (data == "Yes") {
        this.assignAlert(memberId, networkId);
      }
    });
  }

  assignAlert(memberId, networkId) {
    this.restProvider
      .assignMember(memberId, networkId)
      .then((data) => {
        var result: any = data;
        console.log(result);

        if (result == "SUCCESS") {
          const modal = this.modalCtrl.create(
            "CustomDialogPage",
            {
              titleName: "",

              bodyTxt: "Moderator Is Added Successfully",

              okBtnNm: "",
            },

            {
              cssClass: "customModal1 customHrdTxt1",
              enableBackdropDismiss: true,
            }
          );

          modal.present();

          modal.onDidDismiss((data) => {
            this.memberDetail();
          });
        } else if (result == "FAIL") {
          const modal = this.modalCtrl.create(
            "CustomDialogPage",
            {
              titleName: "",

              bodyTxt: "Moderator Add Failed",

              okBtnNm: "Ok",
            },

            {
              cssClass: "customModal1 customHrdTxt1",
              enableBackdropDismiss: true,
            }
          );

          modal.present();
          modal.onDidDismiss((data) => {
            return;
          });
        }
      })
      .catch((error) => {
        console.log(error);
        this.displayAlert("Please try again later");
      });
  }

  remove(memberId, networkId) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        titleName: "",

        bodyTxt:
          "Are you sure want to remove member from your private network?",

        okBtnNm: "Yes",
      },

      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );

    modal.present();

    modal.onDidDismiss((data) => {
      if (data == "Yes") {
        this.removeAlert(memberId, networkId);
      }
    });
  }

  removeAlert(memberId, networkId) {
    this.restProvider
      .removeMember(memberId, networkId)
      .then((data) => {
        var result: any = data;
        console.log(result);

        if (result == "SUCCESS") {
          const modal = this.modalCtrl.create(
            "CustomDialogPage",
            {
              titleName: "",

              bodyTxt: "Member Is Removed From The Network",

              okBtnNm: "",
            },

            {
              cssClass: "customModal1 customHrdTxt1",
              enableBackdropDismiss: true,
            }
          );

          modal.present();

          modal.onDidDismiss((data) => {
            this.navCtrl.push(SelectgroupPage);
          });
        } else if (result == "FAIL") {
          const modal = this.modalCtrl.create(
            "CustomDialogPage",
            {
              titleName: "",

              bodyTxt: "Member Cannot Be Removed, Please try again...",

              okBtnNm: "Ok",
            },

            {
              cssClass: "customModal1 customHrdTxt1",
              enableBackdropDismiss: true,
            }
          );

          modal.present();
          modal.onDidDismiss((data) => {
            return;
          });
        } else {
          const modal = this.modalCtrl.create(
            "CustomDialogPage",
            {
              titleName: "",

              bodyTxt: "Server Down... Please try again",

              okBtnNm: "",
            },

            {
              cssClass: "customModal1 customHrdTxt1",
              enableBackdropDismiss: true,
            }
          );

          modal.present();
          modal.onDidDismiss((data) => {
            return;
          });
        }
      })
      .catch((error) => {
        console.log(error);
        this.displayAlert("Please try again later");
      });
  }
}

