import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, LoadingController, ToastController, ViewController, Platform, IonicApp, Nav, MenuController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { AddcontactlistPage } from '../addcontactlist/addcontactlist';
import { Storage } from "@ionic/storage";
import { GetusercontactdetailsPage } from '../getusercontactdetails/getusercontactdetails';
import { NotificationPage } from '../notification/notification';
import { SearchPage } from '../search/search';
import { MessageboxPage } from '../messagebox/messagebox';
import { GroupinfoPage } from '../groupinfo/groupinfo';
import { ProfileinfoPage } from '../profileinfo/profileinfo';


@IonicPage()
@Component({
  selector: "page-usefulcontacts",
  templateUrl: "usefulcontacts.html",
})
export class UsefulcontactsPage {
  getDetails: any;
  loading1: any;
  categoryName: any;
  loading: any;
  netwrkid: any;
  privateNetworklist: any;
  loggedMemberId: any;
  privateMembernetworklist: any;
  memberFlg: any;
  getAllcategorylist: any;
  categoryId: any = 0;
  loading2: any;
  getAllcontactcategorylist: any;
  showNocontactlist: boolean;
  feedback: any;
  contactId: any;
  netid: any;
  rootPage: any;
  showMenuFlg: true;
  unsubscribeBackEvent: any;
  constructor(
    public navCtrl: NavController,
    private menuCtrl: MenuController,
    public toastController: ToastController,
    public modalCtrl: ModalController,
    public loadingController: LoadingController,
    public restProvider: RestProvider,
    public storage: Storage,
    public navParams: NavParams,
    public platform: Platform
  ) {
    this.storage.get("networkData").then((val) => {
      this.netwrkid = val.networkId;
      console.log("nid" + this.netwrkid);
      this.menuCtrl.enable(true, "mymenu");
      this.menuCtrl.close("sideMenu");
      this.getMemberDet();
      
    });
  }
 async getMemberDet() {
     this.getDetails = await this.storage.get("memberDetails");
     console.log(this.getDetails.memberId);
     this.getnetworkDetails();
     this.getCategoryList();
     this.getcontactlistbycategory();
    
  }
  async ngOnInit() {
   
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  // ionViewWillEnter() {
  //   this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
  //     this.navCtrl.pop();

  //   }, 101);
  // }
  // ionViewWillLeave() {
  //   this.unsubscribeBackEvent && this.unsubscribeBackEvent();
  // }
  getnetworkDetails() {
    this.loading1 = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading1.present();

    this.restProvider
      .getNetworkDetails(this.netwrkid, this.getDetails.memberId)
      .then((data) => {
        var result: any = data;

        console.log("result", data);
        this.privateNetworklist = result.privateNetworkDto;
        this.loggedMemberId = this.privateNetworklist.loggedInMemberId;
        this.privateMembernetworklist =
          this.privateNetworklist.networkMemberDtos;
        for (let nidx in this.privateMembernetworklist) {
          if (
            this.privateMembernetworklist[nidx].memberId ==
            this.getDetails.memberId
          ) {
            this.memberFlg = this.privateMembernetworklist[nidx].flag;
          }
        }

        this.loading1.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.loading1.dismiss();

        this.displayAlert("Please try again later");
      });
  }
  search() {
    this.navCtrl.push(SearchPage);
  }
  messagebox() {
    this.navCtrl.push(MessageboxPage);
  }

  getCategoryList() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    this.restProvider
      .getCategoryList(this.netwrkid)
      .then((data) => {
        var result: any = data;

        console.log("result", data);
        this.getAllcategorylist = result;

        this.loading.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.loading.dismiss();

        this.displayAlert("Please try again later");
      });
  }
  showlist(catid) {
    this.categoryId = catid;
    this.getcontactlistbycategory();
  }
  getcontactlistbycategory() {
    this.loading2 = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading2.present();

    this.restProvider
      .getcontactlistbycat(this.categoryId, this.netwrkid)
      .then((data) => {
        var result: any = data;

        console.log("result", data);
        this.getAllcontactcategorylist = result;
        if (this.getAllcontactcategorylist.length == 0) {
          this.showNocontactlist = true;
        } else {
          this.showNocontactlist = false;
        }

        this.loading2.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.loading2.dismiss();

        this.displayAlert("Please try again later");
      });
  }
  goBackbtn() {
    //this.navCtrl.push(GroupinfoPage);
    this.navCtrl.pop();
  }
  profile() {
    this.navCtrl.push(ProfileinfoPage);
  }
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }
  inforeq(listid, contacts) {
    this.navCtrl.push(GetusercontactdetailsPage, {
      list: listid,
      contact: contacts,
    });
  }
  postreq(listid, netid) {
    this.contactId = listid;
    this.netid = netid;
    const modal = this.modalCtrl.create(
      FeedbackPop,
      {},
      { cssClass: "customModal1", enableBackdropDismiss: false }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      //this.presentToast(data);
      if (data != undefined&& data!="") {
        this.feedback = data;
        this.addfeedbacklist();
      }
    });
  }
  addfeedbacklist() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    var data: any;
    data = {
      feedbackMessage: this.feedback,
      networkId: this.netid,
      memberId: this.getDetails.memberId,
      contactId: this.contactId,
    };
    this.restProvider
      .addfeedbackList(data)
      .then((data) => {
        var result: any = data;

        console.log("result", data);
        if (result.trim() == "success") {
          this.displayAlert("Thank You for your feedback!");
        } else if (result.trim() == "fail") {
          this.displayAlert("process failed try again");
        }

        this.loading.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.loading.dismiss();

        this.displayAlert("Please try again later");
      });
  }
  ionViewDidLoad() {
    console.log("ionViewDidLoad UsefulcontactsPage");
  }
  addcontact() {
    this.navCtrl.push(AddcontactlistPage, { data: this.netwrkid });
  }
  addcategroy() {
    const modal = this.modalCtrl.create(
      AddCategoryPop,
      {},
      { cssClass: "customModal1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data != undefined && data!="" && data!= null) {
        this.categoryName = data;
        this.addCategorylist();
      }
    });
  }
  addCategorylist() {
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();

    var data: any;
    data = {
      categoryName: this.categoryName,
      networkId: this.netwrkid,
    };
    this.restProvider
      .addCategoryList(data)
      .then((data) => {
        var result: any = data;

        console.log("result", data);
        if (result.trim() == "success") {
          this.displayAlert("Category added Successfully!");
        } else if (result.trim() == "fail") {
          this.displayAlert("Category added failed, try again");
        }

        this.loading.dismiss();
      })
      .catch((error) => {
        console.log("error", error);
        this.loading.dismiss();

        this.displayAlert("Please try again later");
      });
  }
}
@Component({
  selector: "fav-name-pop",
  template: `
    <ion-header no-border>
      <ion-toolbar>
        <ion-title>
          <img
            src="assets/imgs/logo.png"
            height="30dp"
            style="padding-top: 5px;"
          />
        </ion-title>

        <ion-buttons end>
          <button ion-button icon-only (click)="closePop()">
            <ion-icon name="ios-close" style="color: black;"></ion-icon>
          </button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>
    <ion-content padding text-center>
      <ion-label text-center>
        <ion-label style="font-size:16px">Add category</ion-label>
      </ion-label>

      <ion-item text-wrap style="padding-bottom:3px;border:1px solid grey">
        <ion-textarea
          style="font-size:16px"
          type="text"
          [(ngModel)]="catName"
          placeholder="Enter category name"
        >
        </ion-textarea>
      </ion-item>

      <button
        style="padding:10px"
        text-center
        ion-button
        color="bright"
        text-capitalize
        text-center
        type="submit"
        (click)="submitFav()"
      >
        Save
      </button>
      <!--<button ngClass="btnCls custBtnCls1" text-center ion-button color="light" text-capitalize text-center round type="submit" (click)="closePop()">Cancel</button>-->
    </ion-content>
  `,
})
export class AddCategoryPop {
  public catName: string;
  unsubscribeBackEvent: Function;
  constructor(
    public toastCtrl: ToastController,
    public platform: Platform,
    private ionicApp: IonicApp,
    public viewCtrl: ViewController
  ) {}

  closePop() {
    this.viewCtrl.dismiss("");
  }
  ionViewWillEnter() {
    this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
      let activePortal = this.ionicApp._modalPortal.getActive();
      if (activePortal) {
        activePortal.dismiss();
      } else {
        return true;
      }
    }, 101);
  }
  ionViewWillLeave() {
    this.unsubscribeBackEvent && this.unsubscribeBackEvent();
  }
  submitFav() {
    if (this.catName != "" && this.catName != undefined) {
      this.viewCtrl.dismiss(this.catName);
    } else {
      let toast = this.toastCtrl.create({
        message: "Enter category Name to add ",
        duration: 2000,
        position: "bottom",
      });
      toast.present(toast);
    }
  }
}
@Component({
  selector: "fav-name-pop",
  template: `
    <ion-header no-border>
      <ion-toolbar>
        <ion-title text-center>
          <img
            src="assets/imgs/logo.png"
            height="30dp"
            style="padding-top: 5px;"
          />
        </ion-title>

        <ion-buttons end>
          <button
            clear
            ion-button
            style="background-color: transparent;border: none;"
            (click)="closePop()"
          >
            <div>
              <ion-icon style="color: black;" name="ios-close"></ion-icon>
            </div>
          </button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>
    <ion-content>
      <ion-label text-wrap text-center>
        This is to feedback about the service
      </ion-label>

      <ion-item text-wrap style="padding-bottom:3px;border:1px solid grey">
        <ion-textarea
          style="font-size:16px"
          type="text"
          [(ngModel)]="feedbackDet"
          placeholder="Enter Details"
        >
        </ion-textarea>
      </ion-item>

      <ion-row text-center ngClass="btnMainCls">
        <button
          ngClass="btnCls"
          text-center
          ion-button
          color="bright"
          text-capitalize
          text-center
          type="submit"
          (click)="feedback()"
        >
          POST
        </button>
      </ion-row>
    </ion-content>
  `,
})
export class FeedbackPop {
  public feedbackDet: string;
  unsubscribeBackEvent: any;
  constructor(
    public toastCtrl: ToastController,
    public platform: Platform,
    private ionicApp: IonicApp,
    public viewCtrl: ViewController
  ) {}

  closePop() {
    this.viewCtrl.dismiss("");
  }
  ionViewWillEnter() {
    this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
      let activePortal = this.ionicApp._modalPortal.getActive();
      if (activePortal) {
        activePortal.dismiss();
      } else {
        return true;
      }
    }, 101);
  }
  ionViewWillLeave() {
    this.unsubscribeBackEvent && this.unsubscribeBackEvent();
  }
  feedback() {
    if (this.feedbackDet != "" && this.feedbackDet != undefined) {
      this.viewCtrl.dismiss(this.feedbackDet);
    } else {
      let toast = this.toastCtrl.create({
        message: "Enter feedback ",
        duration: 2000,
        position: "bottom",
      });
      toast.present(toast);
    }
  }
}



