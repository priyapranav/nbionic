
import { Component, ViewChild } from '@angular/core';
import { NavController,  ModalController, ToastController, LoadingController, NavParams, ViewController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { ForgetpasswordPage } from '../forgetpassword/forgetpassword';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from "@ionic/storage";
import { RegisterPage } from '../register/register';
import { ChangeLocationPage } from '../change-location/change-location';
import { NotificationPage } from '../notification/notification';
import { GroupmembersPage } from '../groupmembers/groupmembers';
import { HomePage } from '../home/home';
import { ProductviewPage } from '../productview/productview';
import { UsefulcontactsPage } from '../usefulcontacts/usefulcontacts';
import { InvitefriendsPage } from '../invitefriends/invitefriends';


@Component({
  selector: 'page-groupinfo',
  templateUrl: 'groupinfo.html',
})
export class GroupinfoPage {
  borrowDetails:any;
  rentDetails:any;
  buyDetails:any;
  giveawayDetails:any;
  loading: any;
borrowFlg: boolean=false;
buyFlg: boolean=false;
rentFlg: boolean=false;
giveawayFlg: boolean=false;
productList:any;
imgUrl:any;
Owner:any;
groupname:any;
  productid: any;
  groupList:any;
  groupId:any;
  networkDet: any;
  productListing: any;
  borrowlist: any[];
listType:any="borrow";
transTypeId:any;
  categoryId: number;
  memberId: any;
  list: any;
  fname: any;
  netwrkid: any;
  pageno: any = 0;
  catId:any=0;
  isScroll: boolean = true;
  prodList: any;
  searchFlg: boolean;
  transId: any;
  count: any = 0;
  netwrkName: any;
  netwrkImg: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public toastController: ToastController,
    public storage:Storage, private modalCtrl: ModalController,
    public restProvider: RestProvider, private formBuilder: FormBuilder, public loadingController: LoadingController) {
      this.storage.set("lastPage",3);
      this.prodList=this.navParams.get("prodList");
      this.catId = this.navParams.get("id");
    this.imgUrl = restProvider.imgUrl;
    

      if(this.prodList!=undefined){
        this.count=1;
           for(let Idx in this.prodList){
            this.transTypeId=this.prodList[Idx].transTypeId;
            this.transId=this.transTypeId;
           }
          
          
           console.log("transid",this.transTypeId,this.prodList );
         }
      //var Data= this.navParams.get("data");
      //this.netwrkid=Data.networkId;
      //this.networkDet=Data;
      if (this.catId == undefined) {
        this.catId = 0;
      }
  
      if(this.listType=="borrow")
      {
this.transTypeId=1;
      }
     
        this.storage.get("networkData").then((val) => {
          this.netwrkid = val.networkId;
          this.networkDet = val;
          this.netwrkName = val.networkName;
          this.netwrkImg = val.networkImg;
          
        this.storage.set("groupId", this.netwrkid);
  
        this.storage.get("memberDetails").then((value) => {
          this.memberId = value.memberId;
          if(this.transId!=undefined){
            if(this.transId == 1){
              this.listType="borrow";
              this.borrow();
                }
                else if(this.transId == 2){
                  this.listType="rent";
                  this.rent();
                }
                if(this.transId == 3){
                  this.listType="buy";
                  this.buy();
                }
                else if(this.transId == 4){
                  this.listType="giveaway";
              this.giveaway();
                }
          }
          else{
            //this.productDetails();
            this.borrow();
          }
         
        });
            
      });
      
     

   
  }
  ngOnInit(){
   
  
    //this.MemberDetails();



}
doInfinite(infiniteScroll) {
  if (!this.isScroll) {
    return;
  }

  this.pageno++;


  this.groupId = this.networkDet.networkId;

  this.restProvider
    .groupProductListScroll(
      this.transTypeId,
      this.catId,
      this.groupId,
      this.memberId,
      this.pageno
    )
    .then((data) => {
      var result: any = data;
     
      var listScroll = result.productListingDto;
      if (this.list.length > 0) {
        this.list = this.list.concat(listScroll);
      } else {
        this.isScroll = false;
      }
    })
    .catch((error) => {
      this.presentToast("Please try again later");
    });
  infiniteScroll.complete();
}

invite(){
  this.navCtrl.push(InvitefriendsPage);
} 
members(){
this.navCtrl.push(GroupmembersPage, {memData: this.networkDet});
     }

     home(){
      this.navCtrl.push(HomePage);
    }

productDetails(){

 
  this.isScroll = true;
  
  if(this.searchFlg == true ){
    this.searchFlg=false;
    this.count=0;
  }
  console.log(this.searchFlg);
 this.categoryId=0;
 this.groupId=this.networkDet.networkId;



 //this.memberId=this.networkDet.memberId,this.categoryId;
    this.restProvider
    .groupProductList(this.transTypeId,this.catId,this.groupId,this.memberId)
    .then( (data) => { 
      var result : any = data;
     
      console.log(result);

      if(result!=null)
      {
        this.list=result.productListingDto;
        if(this.prodList!=undefined && (this.transTypeId == this.transId) && this.count == 1){
          this.searchFlg=true;
          this.list = this.prodList;
          
          console.log(this.searchFlg);
        }
        else{
          this.searchFlg=false;
          this.list=result.productListingDto; 
          console.log(this.searchFlg);
        }
        console.log("success");
      
      }
     
     
    })
    .catch(error => {
  
    console.log(error);
  
      this.displayAlert("Please try again later");
  
  });
}
displayAlert(message) {
  const modal = this.modalCtrl.create(
    "CustomDialogPage",
    {
      dialogFor: "info",
      iconName: "",
      titleName: "",
      bodyTxt: message,
      okBtnNm: "Ok",
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
}
  
  showProduct(list,name){
    console.log(name);
    this.fname=name;
       this.navCtrl.push(ProductviewPage,{
         data:list,
         fieldname: this.fname,
       frmGrp:true});
     }
     presentToast(params) {
       let toast = this.toastController.create({
         message: params,
         duration: 2000
       });
       toast.present();
     }
 

  MemberDetails(){

    this.restProvider
    .getMemberDetails(this.groupId,this.memberId)
    .then( (data) => { 
      var result : any = data;
      console.log(result);

      if(result!=null)
      {
     
        console.log("success");

      }
      
    })
    .catch(error => {
  
    console.log(error);

      this.displayAlert("Please try again later");
  
  });
  }

  contacts(){
    this.navCtrl.push(UsefulcontactsPage,{data:this.netwrkid});
  }
  borrow(){
   
 
    this.borrowFlg=true;
    this.rentFlg=false;
    this.buyFlg=false;
    this.giveawayFlg=false;

    this.transTypeId=1;
    this.productDetails();
    }

  
    rent(){
     
      this.borrowFlg=false;
      this.rentFlg=true;
      this.buyFlg=false;
      this.giveawayFlg=false;

      this.transTypeId=2;
      this.productDetails();
        } 
        

        buy(){
         
          this.borrowFlg=false;
          this.rentFlg=false;
          this.buyFlg=true;
          this.giveawayFlg=false;

          this.transTypeId=3;
          this.productDetails();
            } 

            giveaway(){
             
              this.borrowFlg=false;
              this.rentFlg=false;
              this.buyFlg=false;
              this.giveawayFlg=true;

              this.transTypeId=4;
              this.productDetails();
      }
    }