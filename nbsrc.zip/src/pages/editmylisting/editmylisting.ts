import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, ModalController, ViewController, Platform, IonicApp } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from "@ionic/storage";
import { Validators, FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { MylistingPage } from '../mylisting/mylisting';
import { ImageProcess } from '../../providers/rest/ImageProcess';
/**
 * Generated class for the EditmylistingPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-editmylisting',
  templateUrl: 'editmylisting.html',
})
export class EditmylistingPage {
  categoryList: any;
  editprodlist: any;
  loading: any;
  addProductForm: FormGroup;
  editlistings: any;
  productName: any;
  productDesc: any;
  rootId: number;
  category: any;
  categoryType: any;
  getDetails: any;
  networkList: any[]=[];
  netwrkName: any;
  networkType: any;
  subCategoryList: any;
  subCategoryType: any;
  subCategory: any;
  productAvailableOn:any="From";
  showdayFrom: boolean=false;
  showdayTo: boolean=true;
  dayTo:any=7;
  dayFrom:any=1;
  listType: number;
  catId: any;
  subCategoryId: any;
  count:any=0;
  networkidList: any;
  netwrkid: any;
  rentalDay: any;
  rentalWeek: any;
  rentalMonth: any;
  salePrice: any;
  networkArr: any[]=[];
  netid: any;
  netids: any;
  image: any;
  bytesformat: any;
  imgArr: any[]=[];
  kbytes: number;
  productImage: any;
  imageUrl:any;
  uploadFlg: boolean;
  addPhotoFlg: boolean;
  shownoImgflg: boolean;
  fromToselected:any;
  toFromselected:any;
  picturePath: any;
  categoryName: any;
  toolsFlg: boolean;
  rootCatgry: any;
  subcategroyName: any;
  
  constructor(public navCtrl: NavController, public imageProcess: ImageProcess,public modalCtrl: ModalController,private formBuilder: FormBuilder,public loadingController: LoadingController,public toastController: ToastController ,public restProvider: RestProvider, public storage: Storage, public navParams: NavParams) {
    this.imageUrl = restProvider.imgUrl;
    this.addProductForm = this.formBuilder.group({
      listType:[""],
      productName:["",  [Validators.required]],
      productDesc:["", [Validators.required]],
      productAvailableOn:[""],
      // dayFrom:[""],
      // dayTo:[""],
      categoryType:["", [Validators.required]],
      subCategoryType:[""],
      networkType:["",  [Validators.required]],
      rentalDay:[""],
      rentalWeek:[""],
      rentalMonth:[""],
      salePrice:[""],
    });
    this.editprodlist=this.navParams.get("data");
    this.rootId= this.editprodlist.rootCategoryId;
  }
  async ngOnInit() {
    this.getDetails= await this.storage.get("memberDetails");
    console.log(this.getDetails.memberId);
    this.rootCategory();
    this.getNetworkDetails();
    this.availableCategory();
    this.geteditlist();
  }
  getNetworkDetails(){
    
  
    this.restProvider
    .getNetworkName(this.getDetails.memberId)
    .then( (data) => { 
      var result : any = data;
      var sts =result.status;
  
      this.networkList= result;
      console.log(result);
   
       
      if(result!=null && sts=="success")
      {
     console.log("success");
      }
    })
    .catch(error => {
     
      this.displayAlert("Please try again later");
    });
  
 
  }
  
  getnetworkName(event){
 
console.log("netwrk",this.networkType,  this.netids);

  }
  geteditlist(){
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    
        
    this.restProvider
  .editlist(this.editprodlist.productId)
  .then( (data) => { 
    var result : any = data;
   this.editlistings=result;
   this.listType=this.editlistings.transTypeId;
  
   this.rentalDay=this.editlistings.priceperday;
   this.rentalWeek=this.editlistings.priceperweek;
   this.rentalMonth=this.editlistings.pricepermonth;
   this.salePrice=this.editlistings.salePrice;
   this.productName=this.editlistings.productName;
   this.rootCatgry=this.editlistings.rootCategoryId
   this.subCategoryId=this.editlistings.categoryId;
   this.subcategroyName=this.editlistings.categoryName
  this.productDesc= this.editlistings.productDescription;
  this.networkType=this.editlistings.networkids;
 
  this.productImage=this.editlistings.picture;
  console.log("picture",this.productImage);

  if(this.productImage =='No Image' || this.productImage==null||this.productImage==''){
    this.productImage ="../assets/imgs/NoImg.png";
    this.uploadFlg=true;
    this.shownoImgflg=true;
  }
  else{
    this.uploadFlg=false;
    this.productImage =this.imageUrl+this.productImage;
    this.shownoImgflg=true;
  }
 
  this.subCategory=this.editlistings.categoryName;
  // this.dayTo=this.editlistings.dayto;
  // this.dayFrom=this.editlistings.dayfrom;
  // if(this.dayFrom!=null && this.dayTo !=null){
  //   this.showdayFrom=true;
  //   this.showdayTo=true;
  //   this.fromToselected=true;
  //   this.toFromselected=true;

  // }
  // else if(this.dayTo !=null && this.dayFrom == null){
  //   this.showdayTo=true;
  //   this.showdayFrom=false;
  //   this.fromToselected=false;
  //   this.toFromselected=true;
  //   //this.productAvailableOn="only";
  // }

  if(this.categoryList !=undefined){
    for(let idx in this.categoryList){
      if(this.categoryList[idx].categoryId == this.rootCatgry) {
        this.categoryType=this.categoryList[idx].categoryId;
        
      } 
     }
  }
if(this.editlistings.level1CategoryList !=null && this.editlistings.level1CategoryList!=''){
  this.toolsFlg=true;
  for(let subIdx in this.subCategoryList){
    if(this.subCategoryList[subIdx].categoryName == this.subcategroyName){
      this.subCategoryType=this.subCategoryList[subIdx].categoryId;
      this.catId= this.subCategoryType;
      //this.subCategoryId=this.subCategoryList[subIdx].categoryId;
    }
}
}
else{
  this.toolsFlg=false;
  this.catId =  this.categoryType;
}
  
  /*if(this.subCategoryList.length>0){
    this.toolsFlg=true;
    for(let subIdx in this.subCategoryList){
      if(this.subCategoryList[subIdx].categoryId == this.subCategoryId){
        this.subCategoryType=this.subCategoryList[subIdx].categoryId;
        //this.subCategoryId=this.subCategoryList[subIdx].categoryId;
      }
  }
  
  }
  else{
    this.toolsFlg=false;
  }*/
  

    console.log("result",data);
   
   
    this.loading.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading.dismiss();
  
    this.displayAlert("Please try again later");
  });
  }
  // radioEvent(event){
  //   if(event == "From"){
  //     this.showdayFrom=true;
  //     this.showdayTo=true;
  //     //this.fromToselected=true;
  //     //this.toFromselected=true;
  //   }
  //   else if(event == "only"){
  //     this.dayFrom=null;
  //     this.showdayFrom=false;
  //     this.showdayTo=true;
  //     //this.fromToselected=false;
  //  // this.toFromselected=true;
  //   }

  // }
//   getdayFrom(event){
// this.dayFrom=event;
// if(this.listType == 1){
//   this.dayto.setValidators([Validators.required]);
//   this.dayfrom.setValidators([Validators.required]);
// }
// else{
//   this.dayto.setValidators(null);
//   this.dayfrom.setValidators(null);
// }
// this.dayto.updateValueAndValidity();
// this.dayfrom.updateValueAndValidity();
//   }
//   getdayTo(event){
// this.dayTo=event;
// if(this.listType == 1){
//   this.dayfrom.setValidators(null);
//   this.dayto.setValidators([Validators.required]);
// }
// else{
//   this.dayfrom.setValidators(null);
//   this.dayto.setValidators(null);
// }
// this.dayto.updateValueAndValidity();
// this.dayfrom.updateValueAndValidity();
//   }
  updatelisttype(event){
   
      this.listType=event;
      if(this.listType == 1){
       
        // this.productAvailable.setValidators([Validators.required]);
        // if(this.productAvailableOn =="From"){
        //   this.dayfrom.setValidators([Validators.required]);
        //   this.dayto.setValidators([Validators.required]);
        // }
        // else if(this.productAvailableOn =="only"){
        //   this.dayto.setValidators([Validators.required]);
        // }
        this.rentperday.setValidators(null);
        this.rentperweek.setValidators(null);
        this.rentpermonth.setValidators(null);
        this.saleprice.setValidators(null);
      }
      else if(this.listType == 2){
       
      
        // this.rentperday.setValidators([Validators.required]);
        // this.rentperweek.setValidators([Validators.required]);
        // this.rentpermonth.setValidators([Validators.required]);          
        this.productAvailable.setValidators(null);
        // this.dayfrom.setValidators(null);
        // this.dayto.setValidators(null);
        this.saleprice.setValidators(null);
      }
      else if(this.listType == 3){
      
        this.saleprice.setValidators([Validators.required]);
        this.productAvailable.setValidators(null);
        // this.dayfrom.setValidators(null); 
        // this.dayto.setValidators(null);
        this.rentperday.setValidators(null);
        this.rentperweek.setValidators(null);
        this.rentpermonth.setValidators(null);
  
      }
      else if(this.listType == 4){
       
        this.productAvailable.setValidators(null);
        // this.dayfrom.setValidators(null);
        // this.dayto.setValidators(null);
        this.rentperday.setValidators(null);
        this.rentperweek.setValidators(null);
        this.rentpermonth.setValidators(null);
        this.saleprice.setValidators(null);
      }
      this.productAvailable.updateValueAndValidity();
      // this.dayfrom.updateValueAndValidity();
      // this.dayto.updateValueAndValidity();
      this.rentperday.updateValueAndValidity();
      this.rentperweek.updateValueAndValidity();
      this.rentpermonth.updateValueAndValidity();
      this.saleprice.updateValueAndValidity();

  }
  get productAvailable() {
    return this.addProductForm.get("productAvailableOn") as FormControl;
  }
  get subCategorylist() {
    return this.addProductForm.get("subCategoryType") as FormControl;
  }
  // get dayfrom() {
  //   return this.addProductForm.get("dayFrom") as FormControl;
  // }
  // get dayto() {
  //   return this.addProductForm.get("dayTo") as FormControl;
  // }
  get rentperday() {
    return this.addProductForm.get("rentalDay") as FormControl;
  }
  get rentperweek() {
    return this.addProductForm.get("rentalWeek") as FormControl;
  }
  get  rentpermonth() {
    return this.addProductForm.get("rentalMonth") as FormControl;
  }
  get saleprice() {
    return this.addProductForm.get("salePrice") as FormControl;
  }
  presentActionSheet() {
    const modal = this.modalCtrl.create(
     ImagePopup,
      {},
      { cssClass: "customModal1" }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "1") {
       
        this.imageProcess.AccessCamera().then((res) => {
          this.image = res;
          this.convertImgtoBinary(this.image);
        this.shownoImgflg=false;
        this.uploadFlg=false;
        this.addPhotoFlg=true;
        });
        return true;
      } else if (data == "2") {
        this.imageProcess.AccessGallery().then((res) => {
          this.image = res;
          this.shownoImgflg=false;
          this.uploadFlg=false;
          this.addPhotoFlg=true;
          this.convertImgtoBinary(this.image);
        });
        return true;
      }
    });
  }
  convertImgtoBinary(image){ 
  
    console.log("base64",image)
    var raw = window.atob(image);
    console.log("raw",raw)
    var rawLength = raw.length;
    console.log("rawLength",rawLength)
    var array = new Uint8Array(new ArrayBuffer(rawLength));
    console.log("array",array)
    this.imgArr=[];
    for(var i = 0; i < rawLength; i++) {
      array[i] = raw.charCodeAt(i);
      this.imgArr.push(raw.charCodeAt(i));
    }
    
   
   
  }
  displayAlert(message) {
 
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  uploadPhotopop(){
    const modal = this.modalCtrl.create(
      'CustomDialogPage',
      {
        titleName: "Upload Photo",
        bodyTxt: "Listings with photos generate more intrest. Would you like to proceed anyway?",
        okBtnNm: "Yes",
        cancelBtnNm:"No"
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
    modal.onDidDismiss((data) => {
      if (data == "Yes") {
        this.uploadFlg=false;
       this.updateproduct();
      } 
      else if(data == "No"){
        this.uploadFlg=false;
       this.addPhotoFlg=true;
        this.presentActionSheet();
      }
    });
  }
  updateproduct(){
    if(this.addProductForm.valid){
      if(this.uploadFlg){
        this.uploadPhotopop();
      }
      else if(!this.uploadFlg && this.addPhotoFlg){
       
        this.loading = this.loadingController.create({
          spinner: "bubbles",
        });
        this.loading.present();
        var data:any;
       
        
       
      
        if(this.listType == 1){
          data={
            productId:this.editprodlist.productId,
            productDescription:this.productDesc,
            memberId:this.getDetails.memberId,
            productName:this.productName,
            networkId:this.editprodlist.networkId,
            networkids:this.networkType,
            transTypeId:this.listType,
            categoryId:this.catId,
            // dayfrom:this.dayFrom,
            // dayto:this.dayTo,
            productImage:this.imgArr,
          }
      
        }  
        else if (this.listType == 2) {
          if (
            this.rentalDay == "" ||
            this.rentalDay == undefined ||
            this.rentalDay == null
          ) {
            this.rentalDay = 0;
          }
          if (
            this.rentalWeek == "" ||
            this.rentalWeek == undefined ||
            this.rentalWeek == null
          ) {
            this.rentalWeek = 0;
          }
          if (
            this.rentalMonth == "" ||
            this.rentalMonth == null ||
            this.rentalMonth == undefined
          ) {
            this.rentalMonth = 0;
          }
          if(this.rentalDay == 0 &&  this.rentalWeek == 0 &&  this.rentalMonth == 0){
            this.displayAlert("Enter at least any one the Rental price field");
            this.loading.dismiss();
            return;
                   }
          data={
            productId:this.editprodlist.productId,
            productDescription:this.productDesc,
            memberId:this.getDetails.memberId,
            productName:this.productName,
            networkId:this.editprodlist.networkId,
            networkids:this.networkType,
            transTypeId:this.listType,
            categoryId:this.catId,
            //dayfrom:this.dayFrom,
            //dayto:this.dayTo,
            priceperday:this.rentalDay,
            pricepermonth:this.rentalMonth,
            priceperweek:this.rentalWeek,
            productImage:this.imgArr,
          }
        }
        else if(this.listType == 3){
          if(this.salePrice == 0){
            this.displayAlert("Enter Sale Price more than Zero!");
            this.loading.dismiss();
            return;
          }
          data={
            productId:this.editprodlist.productId,
            productDescription:this.productDesc,
            memberId:this.getDetails.memberId,
            productName:this.productName,
            networkId:this.editprodlist.networkId,
            networkids:this.networkType,
            transTypeId:this.listType,
            categoryId:this.catId,
            salePrice:this.salePrice,
            productImage:this.imgArr,
          }
        }
        else if(this.listType == 4){
          data={
            productId:this.editprodlist.productId,
            productDescription:this.productDesc,
            memberId:this.getDetails.memberId,
            productName:this.productName,
            networkId:this.editprodlist.networkId,
            networkids:this.networkType,
            transTypeId:this.listType,
            categoryId:this.catId,
            productImage:this.imgArr,
          }
        } 
         
         
        
        
      
        this.restProvider
      .updatelist(data)
      .then( (data) => { 
        var result : any = data;
       
      
      
        console.log("result",data);
       if(result.status=="success"){
        const modal = this.modalCtrl.create(
          'CustomDialogPage',
          {
            titleName: "Update Listing",
            bodyTxt: "Your listing has been changed",
            okBtnNm: "Ok",
           
          },
          { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
        );
        modal.present();
        modal.onDidDismiss((data) => {
          if (data == "Ok") {
           // this.navCtrl.pop();
          this.navCtrl.setRoot(MylistingPage);
          } 
        });
      
         
       }
       
        this.loading.dismiss();
      })
      .catch(error => {
        console.log("error",error);
        this.loading.dismiss();
      
        this.displayAlert("Please try again later");
      });
      
      
      }
      
      else if(!this.uploadFlg && this.addPhotoFlg == undefined){
      // alert(this.editlistings.picture);
        if(this.editlistings.picture =='No Image' || this.editlistings.picture == null){
          this.loading = this.loadingController.create({
            spinner: "bubbles",
          });
          this.loading.present();
          var data:any;
         
          if(this.listType == 1){
            data={
              productId:this.editprodlist.productId,
              productDescription:this.productDesc,
              memberId:this.getDetails.memberId,
              productName:this.productName,
              networkId:this.editprodlist.networkId,
              networkids:this.networkType,
              transTypeId:this.listType,
              categoryId:this.catId,
              // dayfrom:this.dayFrom,
              // dayto:this.dayTo,
              
            }
        
          }  
          else if (this.listType == 2) {
            if (
              this.rentalDay == "" ||
              this.rentalDay == undefined ||
              this.rentalDay == null
            ) {
              this.rentalDay = 0;
            }
            if (
              this.rentalWeek == "" ||
              this.rentalWeek == undefined ||
              this.rentalWeek == null
            ) {
              this.rentalWeek = 0;
            }
            if (
              this.rentalMonth == "" ||
              this.rentalMonth == null ||
              this.rentalMonth == undefined
            ) {
              this.rentalMonth = 0;
            }
            if(this.rentalDay == 0 &&  this.rentalWeek == 0 &&  this.rentalMonth == 0){
              this.displayAlert("Enter at least any one the Rental price field");
              this.loading.dismiss();
              return;
                     }
            data={
              productId:this.editprodlist.productId,
              productDescription:this.productDesc,
              memberId:this.getDetails.memberId,
              productName:this.productName,
              networkId:this.editprodlist.networkId,
              networkids:this.networkType,
              transTypeId:this.listType,
              categoryId:this.catId,
             // dayfrom:this.dayFrom,
              //dayto:this.dayTo,
              priceperday:this.rentalDay,
              pricepermonth:this.rentalMonth,
              priceperweek:this.rentalWeek,
             
            }
          }
          else if(this.listType == 3){
            if(this.salePrice == 0){
              this.displayAlert("Enter Sale Price more than Zero!");
              this.loading.dismiss();
              return;
            }
            data={
              productId:this.editprodlist.productId,
              productDescription:this.productDesc,
              memberId:this.getDetails.memberId,
              productName:this.productName,
              networkId:this.editprodlist.networkId,
              networkids:this.networkType,
              transTypeId:this.listType,
              categoryId:this.catId,
              salePrice:this.salePrice,
             
            }
          }
          else if(this.listType == 4){
            data={
              productId:this.editprodlist.productId,
              productDescription:this.productDesc,
              memberId:this.getDetails.memberId,
              productName:this.productName,
              networkId:this.editprodlist.networkId,
              networkids:this.networkType,
              transTypeId:this.listType,
              categoryId:this.catId,
             
            }
          }      
          this.restProvider
        .updatelist(data)
        .then( (data) => { 
          var result : any = data;
        
          console.log("result",data);
         if(result.status=="success"){
          const modal = this.modalCtrl.create(
            'CustomDialogPage',
            {
              titleName: "Update Listing",
              bodyTxt: "Your listing has been changed",
              okBtnNm: "Ok",
             
            },
            { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
          );
          modal.present();
          modal.onDidDismiss((data) => {
            if (data == "Ok") {
              //this.navCtrl.pop();
           this.navCtrl.setRoot(MylistingPage);
            } 
          });
        
           
         }
         
          this.loading.dismiss();
        })
        .catch(error => {
          console.log("error",error);
          this.loading.dismiss();
        
          this.displayAlert("Please try again later");
        });
        
        }
        else{
          this.imgArr=null;
          //alert(this.editlistings.picture);
         // var proxyUrl = 'https://cors-anywhere.herokuapp.com/';
          /*this.convertToDataURLviaCanvas(this.productImage, "image/jpeg").then((data:any) =>{
        
            alert(this.productImage);
            console.log("base64"+base64)
            var base64Index = data.indexOf(';base64,') + ';base64,'.length;
            console.log("base64Index",base64Index);
          var base64 = data.substring(base64Index);
            console.log("base64",base64)
            var raw = window.atob(base64);
            console.log("raw",raw)
            var rawLength = raw.length;
            console.log("rawLength",rawLength)
            var array = new Uint8Array(new ArrayBuffer(rawLength));
            console.log("array",array)
            this.imgArr=[];
            for(var i = 0; i < rawLength; i++) {
              array[i] = raw.charCodeAt(i);
              this.imgArr.push(raw.charCodeAt(i));
            }*/
            this.loading = this.loadingController.create({
              spinner: "bubbles",
            });
            this.loading.present();
            var data:any;
           
            
           
           //this.editlistings.transTypeId
            if(this.listType == 1){
              data={
                productId:this.editprodlist.productId,
                productDescription:this.productDesc,
                memberId:this.getDetails.memberId,
                productName:this.productName,
                networkId:this.editprodlist.networkId,
                networkids:this.networkType,
                transTypeId:this.listType,
                categoryId:this.catId,
                // dayfrom:this.dayFrom,
                // dayto:this.dayTo,
                productImage:this.imgArr,
              }
          
            }  
            else if (this.listType == 2) {
              if (
                this.rentalDay == "" ||
                this.rentalDay == undefined ||
                this.rentalDay == null
              ) {
                this.rentalDay = 0;
              }
              if (
                this.rentalWeek == "" ||
                this.rentalWeek == undefined ||
                this.rentalWeek == null
              ) {
                this.rentalWeek = 0;
              }
              if (
                this.rentalMonth == "" ||
                this.rentalMonth == null ||
                this.rentalMonth == undefined
              ) {
                this.rentalMonth = 0;
              }
              if(this.rentalDay == 0 &&  this.rentalWeek == 0 &&  this.rentalMonth == 0){
                this.displayAlert("Enter at least any one the Rental price field");
                this.loading.dismiss();
                return;
                       }
              data={
                productId:this.editprodlist.productId,
                productDescription:this.productDesc,
                memberId:this.getDetails.memberId,
                productName:this.productName,
                networkId:this.editprodlist.networkId,
                networkids:this.networkType,
                transTypeId:this.listType,
                categoryId:this.catId,
               // dayfrom:this.dayFrom,
               // dayto:this.dayTo,
                priceperday:this.rentalDay,
                pricepermonth:this.rentalMonth,
                priceperweek:this.rentalWeek,
                productImage:this.imgArr,
              }
            }
            else if(this.listType == 3){
              if(this.salePrice == 0){
                this.displayAlert("Enter Sale Price more than Zero!");
                this.loading.dismiss();
                return;
              }
              data={
                productId:this.editprodlist.productId,
                productDescription:this.productDesc,
                memberId:this.getDetails.memberId,
                productName:this.productName,
                networkId:this.editprodlist.networkId,
                networkids:this.networkType,
                transTypeId:this.listType,
                categoryId:this.catId,
                salePrice:this.salePrice,
                productImage:this.imgArr,
              }
            }
            else if(this.listType == 4){
              data={
                productId:this.editprodlist.productId,
                productDescription:this.productDesc,
                memberId:this.getDetails.memberId,
                productName:this.productName,
                networkId:this.editprodlist.networkId,
                networkids:this.networkType,
                transTypeId:this.listType,
                categoryId:this.catId,
                productImage:this.imgArr,
              }
            } 
             
             
            
          
            this.restProvider
          .updatelist(data)
          .then( (data) => { 
            var result : any = data;
           
          
          
            console.log("result",data);
           if(result.status=="success"){
            const modal = this.modalCtrl.create(
              'CustomDialogPage',
              {
                titleName: "Update Listing",
                bodyTxt: "Your listing has been changed",
                okBtnNm: "Ok",
               
              },
              { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
            );
            modal.present();
            modal.onDidDismiss((data) => {
              if (data == "Ok") {
               // this.navCtrl.pop();
             this.navCtrl.setRoot(MylistingPage);
              } 
            });
          
             
           }
           
            this.loading.dismiss();
          })
          .catch(error => {
            console.log("error",error);
            this.loading.dismiss();
          
            this.displayAlert("Please try again later");
          });
         // });
        }
        }
        
    }
    else{
      this.displayAlert("Please Enter Mandatory Fields!");
    }

  }
 

  convertToDataURLviaCanvas(url, outputFormat){
    return new Promise((resolve, reject) => {
      let img = new Image();
      img.setAttribute('crossOrigin', 'anonymous');
      img.onload = () => {
        let canvas = <HTMLCanvasElement> document.createElement('CANVAS'),
          ctx = canvas.getContext('2d'),
          dataURL;
        canvas.height = 300;
        canvas.width = 250;
        ctx.drawImage(img, 0, 0);
        dataURL = canvas.toDataURL(outputFormat);
        resolve(dataURL);
        console.log("dataurl"+dataURL)
        this.presentToast("dataurl"+dataURL);
        canvas = null;
      };
      img.src = url;
    });
  }
  calculateImageSize(base64String) {
    let padding, inBytes, base64StringLength;
    if (base64String.endsWith("==")) padding = 2;
    else if (base64String.endsWith("=")) padding = 1;
    else padding = 0;

    base64StringLength = base64String.length;
    
    inBytes = (base64StringLength / 4) * 3 - padding;
    
    this.kbytes = inBytes / 1000;
   // this.presentToast("bytes"+this.kbytes);
   // alert(this.kbytes);
     this.bytesformat=this.kbytes;
     this.imgArr=[];
     this.imgArr.push(this.bytesformat);
  }
  ionViewDidLoad() {
   
    console.log('ionViewDidLoad EditmylistingPage');
  }
  rootCategory(){
    
    this.restProvider
    .loadRootCategory(this.getDetails.memberId)
    .then( (data) => { 
      var result : any = data;
      var sts =result.status;
  
      if(result!=null && sts=="success")
      {
        
      this.categoryList= result.categoryDto;
      console.log(result);
     console.log("success");
      }
    })
    .catch(error => {
     
      this.displayAlert("Please try again later");
    });
  
 
  
  }
  getCategory(categoryId, categoryname) {
    this.rootId = categoryId;
    this.categoryType=this.rootId;
    this.catId =  this.categoryType;
    this.categoryName = categoryname;
    this.availableCategory();
  }
  availableCategory(){
   
    this.restProvider
  .getAvailableCategory(this.rootId)
  .then((data) => {
    console.log(this.rootId);
    console.log(data);
    var result: any=data;
  
      
    
    if (result.status == "success" ) {
      this.subCategoryList = result.categoryDto;
      console.log("success");
      if (this.subCategoryList.length>0) {
        this.subCategorylist.setValidators([Validators.required]);
        this.toolsFlg = true;
      
      } 
      else{
        this.catId = this.categoryType;
        this.subCategorylist.setValidators(null);
        this.toolsFlg = false;
      }
      this.subCategorylist.updateValueAndValidity();
    }
    else if(result.status == "fail") {
      this.catId = this.categoryType;
      this.subCategorylist.setValidators(null);
      this.toolsFlg = false;
      }
  
  
  })
  .catch(error => {
    console.log(error);
  });
    
    }
    getsubCategory(event){
      this.subCategoryType = event;
      this.catId = event;

    }
 
  
  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000
    });
    toast.present();
    }
    validation_messages = {
      productName: [{ type: "required", message: "Product Name is required" }],
      productDesc: [{ type: "required", message: " Product Description is required" }],
      productAvailableOn: [{ type: "required", message: "Duration is required" }],
      // dayFrom: [{ type: "required", message: "Day is required" }],
      // dayTo: [{ type: "required", message: "Day is required" }],
      categoryType: [{ type: "required", message: "Category Type is required" }],
      subCategoryType: [{ type: "required", message: "Subcategory Type is required" }],
      networkType: [{ type: "required", message: "Network Type is required" }],
      rentalDay:  [{ type: "required", message: "Rental Price is required" }],
      rentalWeek: [{ type: "required", message:"Rental Price  is required" }],
      rentalMonth: [{ type: "required", message:"Rental Price  is required" }],
      salePrice: [{ type: "required", message: "Rental Price  is required" }],
    };
  

}
@Component({
  selector: "request-success-pop",
  template: `
    <ion-content>
      <ion-label text-center>
        <ion-icon
          ngClass="hdrIcon"
          name="ios-checkmark-circle-outline"
          class="larger"
        ></ion-icon>
        <ion-label ngClass="hdrTxt"
          >Choose your image to upload</ion-label
        >
      </ion-label>
      <ion-row>
        <ion-item>
          <ion-label class="actionItemCls" (click)="btnClick(1)"
            >Capture Image
            <ion-icon
              name="ios-camera-outline"
              class="larger iconCls"
            ></ion-icon>
          </ion-label>
        </ion-item>
      </ion-row>
      <ion-row>
        <ion-item>
          <ion-label class="actionItemCls" (click)="btnClick(2)"
            >Choose from gallery
            <ion-icon
              name="ios-images-outline"
              class="larger iconCls"
            ></ion-icon>
          </ion-label>
        </ion-item>
      </ion-row>

      <ion-row text-center ngClass="btnMainCls">
        <button
          ngClass="btnCls"
          text-center
          ion-button
          color="bright"
          text-capitalize
          text-center
          round
          type="submit"
          (click)="btnClick('Close')"
        >
          Close
        </button>
      </ion-row>
    </ion-content>
  `,
})
export class ImagePopup {
  unsubscribeBackEvent: any;
  constructor(
    public platform: Platform,
    private ionicApp: IonicApp,
    public viewCtrl: ViewController,

  ) {}
  ionViewWillEnter() {
    this.unsubscribeBackEvent = this.platform.registerBackButtonAction(() => {
      let activePortal=this.ionicApp._modalPortal.getActive();
        if(activePortal){
          activePortal.dismiss();
        } else {
        return true;
      }
    }, 101);
  }
  ionViewWillLeave() {
    this.unsubscribeBackEvent && this.unsubscribeBackEvent();
  }
  btnClick(data: string) {
    this.viewCtrl.dismiss(data);
  }
}

