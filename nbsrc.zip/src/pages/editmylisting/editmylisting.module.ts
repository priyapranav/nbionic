import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditmylistingPage } from './editmylisting';

@NgModule({
  declarations: [
    EditmylistingPage,
  ],
  imports: [
    IonicPageModule.forChild(EditmylistingPage),
  ],
})
export class EditmylistingPageModule {}
