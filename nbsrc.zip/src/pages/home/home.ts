import { Component, ViewChild, ElementRef, NgZone } from '@angular/core';
import { NavController,  ModalController, ToastController, LoadingController, NavParams, ViewController, Platform, App } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { ForgetpasswordPage } from '../forgetpassword/forgetpassword';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from "@ionic/storage";
import { RegisterPage } from '../register/register';
import { ChangeLocationPage } from '../change-location/change-location';
import { NotificationPage } from '../notification/notification';
import { Geolocation } from "@ionic-native/geolocation";
import { ProductviewPage } from '../productview/productview';
import { DatePipe } from '@angular/common';


declare var google;
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  borrowDetails:any;
  rentDetails:any;
  buyDetails:any;
  giveawayDetails:any;
  loading: any;
borrowFlg: boolean=false;
buyFlg: boolean=false;
rentFlg: boolean=false;
giveawayFlg: boolean=false;
productList:any;
imgUrl:any;
Owner:any;
  productid: any;
  listType:any="borrow";
  address: any;
  userArea: any;
  userLat: any;
  userlong: any;
  userlatlng: { lat: any; lng: any; };
  userAddress: any;
  changeLat: any;
  changelong: any;
  changeSubloc: any;
  catId: any;
  categoryId: any;
  getDetails: any;
  fname: any;
  searchRadius: any;
  usermemberId: any;
  pickup: any;
  area: any;
  latitude: any;
  longitude: any;
  pincode: string;
  city: any;
  radius: any;
  getMemberDet: any;
  userlatitude: any;
  userlongitude: any;
  userarea: any;
  userpickup: any;
  userradius: any;
  usermemberlatlng: { lat: any; lng: any; };
  test:any;
  memberId: any;
  mapFlg: boolean=false;
  changedlatitude: any;
  changedlongitude: any;
  changedcity: any;
  changedpincode: any;
  changeduserradius: any;
  changedarea: any;
  loading1: any;
  prodList: any;
  transId: any = 1;
  sharedOn: any;
  count: any=0;
  searchFlg: boolean;
  pageno: any = 0;
  isScroll: boolean = true;
  displayMsg: boolean;
  borrowdisplayMsg: boolean=false;

 
  constructor(public navCtrl: NavController,  public datepipe: DatePipe,public toastController: ToastController,
    public storage:Storage, private modalCtrl: ModalController, public navParams: NavParams,
    public restProvider: RestProvider, private formBuilder: FormBuilder, public loadingController: LoadingController) {
      this.prodList=this.navParams.get("prodList");
      this.storage.set("lastPage", 1);
      this.storage.set("groupId", 2);
  
      console.log("list",this.prodList);
      if(this.prodList!=undefined){
     this.count=1;
        for(let Idx in this.prodList){
          this.transId=this.prodList[Idx].transTypeId;
        }
       
       
        console.log("transid",this.transId );
      }
    this.catId=this.navParams.get("id");
   console.log("catid",this.catId);
   if(this.catId !=undefined){
this.categoryId=this.catId;
   }
   else{
    this.categoryId=0;
   }
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  async ngOnInit(){
   
    this.getDetails=  await this.storage.get("memberDetails");
    console.log("details",this.getDetails);
if(this.getDetails  !=undefined){
  this.usermemberId= this.getDetails.memberId;
  this.pickup= this.getDetails.address;
  this.area=  this.getDetails.area;
  this.latitude= this.getDetails.latitude;
  this.longitude= this.getDetails.longitude;
  this.radius=this.getDetails.searchRadius;
  this.userlatlng = {
    lat: this.latitude,
    lng: this.longitude,
  };
  if(this.getDetails.pincode == null)
  {
    this.pincode = "0";
  }
  else{
    this.pincode=this.getDetails.pincode;
  }
console.log(this.transId);
if(this.transId!=undefined){
  if(this.transId == 1){
    this.listType="borrow";
    console.log("1",this.transId);
    this.borrow();
      }
      else if(this.transId == 2){
        this.listType="rent";
        this.rent();
      }
      if(this.transId == 3){
        this.listType="buy";
        this.buy();
      }
      else if(this.transId == 4){
        this.listType="giveaway";
    this.giveaway();
      }
}
else{
  console.log("2",this.transId);
  this.borrow();
}
  
 
}
   
  }
  ionViewDidLoad(){

  }
  ionViewDidEnter() {
    this.storage.set("lastPage", 1);
   this.storage.set("groupId", 2);
 }

   changeLoc(){
    
        let modal = this.modalCtrl.create(MapModelProfile, );
        modal.onDidDismiss((data) => {
          if (data != "" && data != undefined) {
            this.pickup = data.packagePickupAddress;
          this.mapFlg=true;
              this.changedlatitude=data.latitude;
              this.changedlongitude=data.longitude
              var latlng={
                lat: this.changedlatitude,
                lng: this.changedlongitude
                        }
                        this.changedcity=data.sendFrom;
                        this.changedpincode=data.pincode;
                        this.changeduserradius=data.radius;
                        this.changedarea=data.sublocation;
                       this.memberId=data.memberId;
console.log(this.pickup, this.changedlatitude,this.changedlongitude, this.changeduserradius,this.changedpincode,this.changedcity);
            var data: any;
            this.pincode = this.changedpincode;
            this.latitude = this.changedlatitude;
            this.longitude = this.changedlongitude;
            this.address = this.pickup;
            this.radius = this.changeduserradius;
            this.area= this.changedarea;
                       data={
                        address:this.pickup,
                        latitude: this.changedlatitude,
                        longitude: this.changedlongitude,
                        searchRadius:this.changeduserradius,
                        pincode:this.changedpincode,
                        area: this.changedarea,
                        memberId:this.getDetails.memberId,
                        firstName:this.getDetails.firstName,
                        lastName:this.getDetails.lastName,
                        contactNumber:this.getDetails.contactNumber,
                        createdDateTime:this.getDetails.createdDateTime,
                        aboutMe:this.getDetails.aboutMe,
                        deviceToken:this.getDetails.deviceToken,
                        email:this.getDetails.email,
                        inviteFlag:this.getDetails.inviteFlag,
                        isActive:this.getDetails.isActive,
                        isDeleted:this.getDetails.isDeleted,
                        mailVerifyFlag:this.getDetails.mailVerifyFlag,
                        memberProfilePic:this.getDetails.memberProfilePic,
                        memberTypeId:this.getDetails.memberTypeId,
                        networkId:this.getDetails.networkId,
                        picture:this.getDetails.picture,
                        statusId:this.getDetails.statusId,
                        password:this.getDetails.password,
    
                       };
            this.storage.set("memberDetails", data);
                        if (this.listType == "borrow") {
                          this.transId = 1;
                          this.borrow();
                        } else if (this.listType == "rent") {
                          this.transId = 2;
                          this.rent();
                        } else if (this.listType == "buy") {
                          this.transId = 3;
                          this.buy();
                        } else if (this.listType == "giveaway") {
                          this.transId = 4;
                          this.giveaway();
                        }
                
         
    
          }
        });
    
        modal.present();
   
  

  }
  updatelocation(){
    
    this.loading1 = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading1.present();
    
    var data:any;
    data={
      latitude:this.latitude,
      longitude:this.longitude,
      pincode:this.pincode,
      memberId:this.getDetails.memberId,
      address:this.pickup,
      area:this.area
    }      
    this.restProvider
  .updatelocation(data)
  .then( (data) => { 
    var result : any = data;
   
    console.log("result",data);
    if(result.status =="success"){
      this.pickup=result.memberDto.address;
      this.storage.set("memberDetails",result.memberDto);
      this.displayAlert("Location Changed successfully!");
      
    }
    else{
      this.displayAlert(" Update Failed. Please try again");
    }
   
    this.loading1.dismiss();
  })
  .catch(error => {
    console.log("error",error);
    this.loading1.dismiss();
  
    this.displayAlert("Please try again later");
  });
  
  }

  getProductlist(){
    
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    this.imgUrl=this.restProvider.imgUrl;  
      this.restProvider
        .updateProductlist(this.categoryId,this.pincode,this.radius,this.latitude,this.longitude,this.getDetails.memberId)
        .then( (data) => { 
          var result : any = data;
          var sts =result.status;
          console.log(result);
          this.productList= result.productListingDto; 
          
 
          console.log(this.productList);
          
          if(result!=null && sts=="success")
          {
            this.loading.dismiss();
            if(this.productList.length>0)
            {
                this.borrowFlg=true;
            }
            else{
              this.borrowFlg=false;
            }
          }
          else
          {
            this.loading.dismiss();
            this.displayAlert("Please try again later");
          }  
        })
        .catch(error => {
          this.loading.dismiss();
          this.displayAlert("Please try again later");
        });
  }

  borrow(){
    this.transId = 1;
    this.isScroll = true;

    if(this.searchFlg == true){
      this.searchFlg=false;
      this.count=0;
    }
    this.loading = this.loadingController.create({
      spinner: "bubbles",
    });
    this.loading.present();
    this.imgUrl=this.restProvider.imgUrl;
        this.restProvider
        .borrowproduct(this.categoryId,this.pincode,this.radius,this.latitude,this.longitude,this.getDetails.memberId)
        .then( (data) => { 
          var result : any = data;
          var sts =result.status;
          console.log(result);
         // this.productList= result.productListingDto; 
          if(this.prodList!=undefined && this.transId == 1 &&  this.count ==1 ){
            this.searchFlg=true;
              this.productList= this.prodList;
            
           
          }
          else{
            this.searchFlg=false;
            this.productList= result.productListingDto; 
          }
 
          console.log(this.productList);
          
          if(result!=null && sts=="success")
          {
            this.loading.dismiss();
            if(this.productList.length>0)
            {
                this.borrowFlg=true;
            }
            else{
              this.borrowFlg=false;
            }
          }
          else
          {
            
            this.loading.dismiss();
            this.displayAlert("Please try again later");
          }  
        })
        .catch(error => {
          this.loading.dismiss();
          this.displayAlert("Please try again later");
        }); 
      
      
    
    }

    showProduct(list,name){
   console.log(name);
   this.fname=name;
      this.navCtrl.push(ProductviewPage, {
        data: list,
        fieldname: this.fname,
        frmGrp: false,
      });
    }
    presentToast(params) {
      let toast = this.toastController.create({
        message: params,
        duration: 2000
      });
      toast.present();
    }


    requestModal(ownername, productname, productid, memberid, number){
        
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();
      
     
          
    this.restProvider
    .getViewList(productid)
    .then( (data) => { 
      var result : any = data;
      var sts =result.status;
      console.log(result);
      if(result!=null)
      {
      this.loading.dismiss();
        console.log(productid);
      }
      else
      {
        this.loading.dismiss();
      
        this.presentToast("Please try again later");
      }  
    })
    .catch(error => {
      this.loading.dismiss();
    
      this.presentToast("Please try again later");
    

    this.restProvider
    .getCheckRequestSendOrNot(productid, memberid)
    .then( (data) => { 
      var result : any = data;
      var sts =result.status;
      console.log(result);

    })
    .catch(error => {
      this.loading.dismiss();
    
      this.presentToast("Please try again later");
    });

  }); 
  var newData={ OwnerName:ownername, ProductName:productname, ProductId: productid, MemberId:memberid, Number:number };
      const modal = this.modalCtrl.create(RequestModal, {Data: newData}, {cssClass: 'select-modal'});
          modal.present();
  } 

     
      
  viewModal(productid, image, ownername, productname, description, fromday, endday)
  {
  
    this.storage.set("productId",productid);

    this.loading = this.loadingController.create({
          spinner: "bubbles",
        });
        this.loading.present();
        
                    
  /*    this.restProvider
      .getOwnerRating(memberid)
      .then( (data) => { 
        var result : any = data;
       
        console.log(result);
        this.ownerRating= result.avgRating;
        
        if(result!=null)
        {
        this.loading.dismiss();
        console.log(result);
        }
        else
        {
          this.loading.dismiss();
        
          this.presentToast("Please try again later");
        }
        
        
      })
      .catch(error => {
        this.loading.dismiss();
      
        this.presentToast("Please try again later");
      });


     */
      var newViewData={Image:image, OwnerName: ownername, ProductName:productname, 
        Description:description, FromDay:fromday, EndDay:endday};
      
        this.loading.dismiss();

      const modalview= this.modalCtrl.create(ViewModal,{ Data: newViewData}, {cssClass: 'select-modal2'});
          modalview.present();

  }
  
    rent(){
      this.transId = 2;
      this.isScroll = true;

      if(this.searchFlg == true){
        this.searchFlg=false;
        this.count=0;
      }
      this.loading = this.loadingController.create({
        spinner: "bubbles",
      });
      this.loading.present();

      this.imgUrl=this.restProvider.imgUrl;

     /* if(this.userradius !=undefined){
        this.radius=this.userradius;
        }else{
          this.radius=1500;
        }*/
   
  
          this.restProvider
            .rentproduct(this.categoryId,this.pincode,this.radius,this.latitude,this.longitude,this.getDetails.memberId)
            .then( (data) => { 
              var result : any = data;
              var sts =result.status;
              //this.productList=result.productListingDto;
             
              if(this.prodList!=undefined && this.transId == 2 &&  this.count ==1){
                this.searchFlg=true;
                  this.productList= this.prodList;
                
               
              }
              else{
                this.searchFlg=false;
                this.productList=result.productListingDto;
              }
              if(result!=null && sts=="success")
              {
                this.loading.dismiss();
                if(this.productList.length>0)
                {
                    this.rentFlg=true;
                }
                else{
                  this.rentFlg=false;
                }
              }
              else
              {
                this.loading.dismiss();
                this.displayAlert("Please try again later");
              }  
            })
            .catch(error => {
              this.loading.dismiss();
              this.displayAlert("Please try again later");
            });
         
        } 
        



        buy(){
          this.transId = 3;
          this.isScroll = true;
      
          if(this.searchFlg == true){
            this.searchFlg=false;
            this.count=0;
          }
          this.loading = this.loadingController.create({
            spinner: "bubbles",
          });
          this.loading.present();
          this.imgUrl=this.restProvider.imgUrl;
      
         /* if(this.userradius !=undefined){
            this.radius=this.userradius;
            }else{
              this.radius=1500;
            }*/
      
              this.restProvider
                .buyproduct(this.categoryId,this.pincode,this.radius,this.latitude,this.longitude,this.getDetails.memberId)
                .then( (data) => { 
                  var result : any = data;
                  var sts =result.status;
                  //this.productList=result.productListingDto;
                 

                  if(this.prodList!=undefined && this.transId == 3 &&  this.count ==1){
                    this.searchFlg=true;
               
                      this.productList= this.prodList;
                    
                  }
                  else{
                    this.searchFlg=false;
                    this.productList=result.productListingDto;
                  }
                  if(result!=null && sts=="success")
                  {
                    this.loading.dismiss();
                    if(this.productList.length>0)
                    {
                        this.buyFlg=true;
                    }
                    else{
                      this.buyFlg=false;
                    }
                    
                  }
                  else
                  {
                    this.loading.dismiss();
                    this.displayAlert("Please try again later");
                  }  
                })
                .catch(error => {
                  this.loading.dismiss();
                  this.displayAlert("Please try again later");
                });
           
            } 

  
            doInfinite(infiniteScroll) {
              if (!this.isScroll) {
                return;
               }
          
              this.pageno++;
             
              
              this.imgUrl = this.restProvider.imgUrl;
              this.restProvider
                .loadMoreProduct(
                  this.categoryId,
                  this.pincode,
                  this.radius,
                  this.latitude,
                  this.longitude,
                  this.getDetails.memberId,this.transId,this.pageno
                )
                .then((data) => {
                  var result: any = data;
                  var sts = result.status;
                  console.log(result);
                  if(result.status == "success"){
                    if (this.productList.length > 0) {
                      var loadList = result.productListingDto;
                      this.productList = this.productList.concat(loadList);
                      console.log("prodlist",this.productList);
                  } else {
                    this.isScroll = false;
                   }
                  }
                  else if(result.status =="fail"){

                  }
                  // this.productList= result.productListingDto;
                 
                    
          
                 
                })
                .catch((error) => {
                 
                  this.presentToast("Please try again later");
                }); 
            infiniteScroll.complete();
          } 
          
            giveaway(){
              this.transId = 4;
              this.isScroll = true;
          
              if(this.searchFlg == true){
                this.searchFlg=false;
                this.count=0;
              }
              this.loading = this.loadingController.create({
                spinner: "bubbles",
              });
              this.loading.present();
              this.imgUrl=this.restProvider.imgUrl;
          
              /*if(this.userradius !=undefined){
                this.radius=this.userradius;
                }else{
                  this.radius=1500;
                }*/
          
                  this.restProvider
                    .giveawayproduct(this.categoryId,this.pincode,this.radius,this.latitude,this.longitude,this.getDetails.memberId)
                    .then( (data) => { 
                      var result : any = data;
                      var sts =result.status;
                      //this.productList=result.productListingDto;
                     

                      if(this.prodList!=undefined && this.transId == 4 &&  this.count ==1){
                        this.searchFlg=true;
                          this.productList= this.prodList;
                        
                       
                      }
                      else{
                        this.searchFlg=false;
                        this.productList=result.productListingDto;
                      }
                      if(result!=null && sts=="success")
                      {
                        this.loading.dismiss();
                        if(this.productList.length>0)
                        {
                            this.giveawayFlg=true;
                        }
                        else{
                          this.giveawayFlg=false;
                        }
                        
                      }
                      else
                      {
                        this.loading.dismiss();
                        this.displayAlert("Please try again later");
                      }  
                    })
                    .catch(error => {
                      this.loading.dismiss();
                      this.displayAlert("Please try again later");
                    });
              
                } 
      }


      
@Component({
  selector: "page-home",
  template: `
      <ion-header>
      <button ion-button end (click)="closeModal()" icon-only>
      <ion-icon name=ios-close-outline></ion-icon>
      </button>
      </ion-header>
      <ion-content padding>
        <div>
        Send request to {{newData.OwnerName}} for {{newData.ProductName}}
        </div>
        <ion-input class="inputCls" clearme value="I would like to {{identifier}} your {{newData.ProductName}}">
        </ion-input>
      </ion-content>
      <ion-footer>
      <button end ion-button>Send</button>
      </ion-footer>
  `,
})
export class RequestModal{
  newData:any;
  number:any;
  identifier:any;
  productId:any;
  memberId: any;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public storage: Storage,
    public viewCtrl: ViewController,
    public modalCtrl: ModalController,
    public loadingController: LoadingController,
    public toastController: ToastController,
    public restProvider: RestProvider
  ) {

    this.newData=this.navParams.get("Data");
    this.number= this.newData.Number;
    this.productId=this.newData.ProductId;
    this.memberId=this.newData.MemberId;
    if(this.number==1)
    {
      this.identifier="borrow";
    }
    else if(this.number==2)
    {
      this.identifier="rent";
    }
    else if(this.number==3)
    {
      this.identifier="buy";
    }
    else if(this.number==4)
    {
      this.identifier="get";
    }

    console.log(this.newData);
  }


  closeModal(){
    
      this.navCtrl.pop();
  }
  }



 
      
  @Component({
    selector: "page-home",
    template: `
    <ion-header>
    <button ion-button end (click)="closeModal()" icon-only>
    <ion-icon name=ios-close-outline></ion-icon>
    </button>
    </ion-header>
    <ion-content padding>
  <ion-list>
      <ion-item>
       
      <img class="imgCls" src= "{{picture!='No Image'?imgUrl+picture:''}}">
     </ion-item>

      <ion-item style="color: blue;"> {{newViewData.OwnerName}}'s {{newViewData.ProductName}}
      </ion-item>
      
      <ion-item>Owner Rating
      <br>
      <ion-icon name="ios-star-outline" *ngIf="ogrnflg1" color="secondary"></ion-icon>
      <ion-icon name="ios-star-outline" *ngIf="oflg1"></ion-icon>
      
      <ion-icon name="ios-star-outline" *ngIf="ogrnflg2" color="secondary"></ion-icon>
      <ion-icon name="ios-star-outline" *ngIf="oflg2"></ion-icon>
     
      <ion-icon name="ios-star-outline" *ngIf="ogrnflg3" color="secondary"></ion-icon>
      <ion-icon name="ios-star-outline" *ngIf="oflg3"></ion-icon>
     
      <ion-icon name="ios-star-outline" *ngIf="ogrnflg4" color="secondary"></ion-icon>
      <ion-icon name="ios-star-outline" *ngIf="oflg4"></ion-icon>
      
      <ion-icon name="ios-star-outline" *ngIf="ogrnflg5" color="secondary"></ion-icon>
      <ion-icon name="ios-star-outline" *ngIf="oflg5"></ion-icon>
      
      
      </ion-item>
      <ion-item>Product Rating
      <div>  </div></ion-item>
      
      <ion-item text-wrap>Description
      <br>
      <p>{{newViewData.Description}} </p>
      </ion-item>

      <ion-item> Will be available
      <br> <p> {{firstday}} {{lastday}}
      </p>
      </ion-item>
      </ion-list>
     
    </ion-content>
    <ion-footer>
    <button ion-button icon-only>
    <ion-icon name=ios-flag-outline></ion-icon>
    </button>
    <button end ion-button>Send</button>
    </ion-footer>
`,
  })
  
  export class ViewModal{
    newViewData:any;
    number:any;
    identifier:any;
    productId:any;
    picture:any;
    ownerName:any;
    productName:any;
    ownerRating:any;
    productRating:any;
    description:any;
    frmDay:any;
    toDay:any;
    firstday:any;
    lastday:any;
    memberId:any;
    oflg1:boolean=false;
    oflg2:boolean=false;
    oflg3:boolean=false;
    oflg4:boolean=false;
    oflg5:boolean=false;
    ogrnflg1:boolean=false;
    ogrnflg2:boolean=false;
    ogrnflg3:boolean=false;
    ogrnflg4:boolean=false;
    ogrnflg5:boolean=false;
    ownerData:any;
    loading:any;
   // productid:any;
    memberid:any;
   

    constructor(
      public navCtrl: NavController,
      public navParams: NavParams,
      public storage: Storage,
      public viewCtrl: ViewController,
      public modalCtrl: ModalController,
      public toastController: ToastController,
      public restProvider: RestProvider,
      public loadingController: LoadingController
    ) {
    
      this.newViewData=this.navParams.get("Data");
      console.log(this.newViewData);

      this.picture=this.newViewData.Image;
      this.ownerName=this.newViewData.OwnerName;
      this.productName=this.newViewData.ProductName;
      this.description=this.newViewData.Description;
      this.frmDay=this.newViewData.FromDay;
      this.toDay=this.newViewData.EndDay; 

      if(this.frmDay==1)
      {
        this.firstday="Sunday";
      }
      if(this.frmDay==2)
      {
        this.firstday="Monday";
      }
      if(this.frmDay==3)
      {
        this.firstday="Tuesday";
      }
      if(this.frmDay==4)
      {
        this.firstday="Wednesday";
      }
      if(this.frmDay==5)
      {
        this.firstday="Thursday";
      }
      if(this.frmDay==6)
      {
        this.firstday="Friday";
      }
      if(this.frmDay==7)
      {
        this.firstday="Saturday";
      }

      if(this.toDay==0)
      {
        this.lastday="only"
      }

      if(this.toDay==1)
      {
        this.lastday="to Sunday";
      }
      if(this.toDay==2)
      {
        this.lastday=" to Monday";
      }
      if(this.toDay==3)
      {
        this.lastday="to Tuesday";
      }
      if(this.toDay==4)
      {
        this.lastday="to Wednesday";
      }
      if(this.toDay==5)
      {
        this.lastday="to Thursday";
      }
      if(this.toDay==6)
      {
        this.lastday="to Friday";
      }
      if(this.toDay==7)
      {
        this.lastday="to Saturday";
      }

    if(this.ownerRating==0)
      {
        this.oflg1=true;
        this.oflg2=true;
        this.oflg3=true;
        this.oflg4=true;
        this.oflg5=true;
      }

    if(this.ownerRating>0 && this.ownerRating<1)
      {
        this.ogrnflg1=true;
        this.oflg2=true;
        this.oflg3=true;
        this.oflg4=true;
        this.oflg5=true;
      }

     if(this.ownerRating>=1 && this.ownerRating<2)
      {
        this.ogrnflg1=true;
        this.ogrnflg2=true;
        this.oflg3=true;
        this.oflg4=true;
        this.oflg5=true;
      }

      if(this.ownerRating>=2 && this.ownerRating<3)
      {
        this.ogrnflg1=true;
        this.oflg2=true;
        this.oflg3=true;
        this.oflg4=true;
        this.oflg5=true;
      }

      if(this.ownerRating>=3 && this.ownerRating<4)
      {
        this.ogrnflg1=true;
        this.ogrnflg2=true;
        this.ogrnflg3=true;
        this.oflg4=true;
        this.oflg5=true;
      }

      if(this.ownerRating>=4 && this.ownerRating<5)
      {
        this.ogrnflg1=true;
        this.ogrnflg2=true;
        this.ogrnflg3=true;
        this.ogrnflg4=true;
        this.oflg5=true;
      }

      if(this.ownerRating==5)
      {
        this.ogrnflg1=true;
        this.ogrnflg2=true;
        this.ogrnflg3=true;
        this.ogrnflg4=true;
        this.ogrnflg5=true;
      }

    }

ionViewDidLoad(){

 this.productlist();
this.ownerrate();
this.productrate();
}



ownerrate(){  
  this.storage.get("memberId").then((val)=>{

     var MemberId:any=val;
/*
this.loading = this.loadingController.create({
  spinner: "bubbles",
});
this.loading.present();
*/
            
    console.log(MemberId);
  this.restProvider
  .getOwnerRating(MemberId)
  .then( (data) => { 
    var resultOwner : any = data;
   
    console.log(resultOwner);
    this.ownerRating= resultOwner.avgRating;
   // this.loading.dismiss();
    if(resultOwner!=null)
    {
    
    console.log(resultOwner);
    }

  })
  .catch(error => {
    // this.loading.dismiss();
  
    this.displayAlert("Please try again later");
  });
});
}
displayAlert(message) {
  const modal = this.modalCtrl.create(
    "CustomDialogPage",
    {
      dialogFor: "info",
      iconName: "",
      titleName: "",
      bodyTxt: message,
      okBtnNm: "Ok",
    },
    { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
  );
  modal.present();
}
  

presentToast(params) {
  let toast = this.toastController.create({
    message: params,
    duration: 2000
  });
  toast.present();
}


productlist(){

  
  this.storage.get("productId").then((val)=>{
    var productid: any = val;
  /*
this.loading = this.loadingController.create({
    spinner: "bubbles",
  });
  this.loading.present();*/
  
  
  console.log(productid);
  this.restProvider
  .getViewList(productid)
  .then( (data) => { 
    var result : any = data;
    console.log(result);
    
    if(result!=null)
    {
   
      console.log(productid);
    }
  
 //this.loading.dismiss();
  })
  .catch(error => {
 //this.loading.dismiss();
  
    this.displayAlert("Please try again later");
  });
  });


}
productrate(){
  
 this.storage.get("productId").then((val)=>
 {
  var productid=val;
 /*this.loading = this.loadingController.create({
    spinner: "bubbles",
  });
  this.loading.present(); */
  
  console.log(productid);
this.restProvider
    .getProductRating(productid)
    .then( (data) => {
      var result : any = data;
     
      console.log(result);
      this.ownerRating= result.avgRating;
      
      if(result!=null)
      {
      console.log(result);
      }
     
     //  this.loading.dismiss();
      
    })
    .catch(error => {
    // this.loading.dismiss();
    
      this.displayAlert("Please try again later");
    
});

});
}

    closeModal(){
    
        this.navCtrl.pop();
    }
    }

    @Component({
      selector: "page-home",
      template: `
        <ion-header no-border>
          <ion-toolbar class="headerCls">
            <ion-buttons left>
              <button ion-button icon-only (click)="dismiss()">
                <ion-icon name="arrow-back" style="color: white;"></ion-icon>
              </button>
            </ion-buttons>
            <img
              src="assets/imgs/logo_white.png"
              height="30dp"
              style="padding-top: 5px;padding-left: 5px"
            />
          </ion-toolbar>
        </ion-header>

        <ion-content padding class="noHdrCntentCls mapContentCls">
          <form
            [formGroup]="locationForm"
            (ngSubmit)="postRequest()"
            style="height: 100%;"
          >
            <!-- <button ion-button round  color="light" class="Rectangle_1074"></button>-->
            <ion-searchbar
              formControlName="autocompleteAddress"
              [(ngModel)]="autocompleteAddress.input"
              (ionInput)="updateAddressSearchResults()"
              placeholder="Enter address to search"
            ></ion-searchbar>
            <span *ngIf="errorMessage" class="error">{{ errorMessage }}</span>
            <ion-list class="locSrchResultCls">
              <ion-item
                *ngFor="let item of autocompleteAddressItems"
                tappable
                (click)="selectAddressSearchResult(item)"
              >
                {{ item.description }}
              </ion-item>
            </ion-list>
            <ion-grid no-padding>
              <ion-row no-padding justify-content-center align-items-center>
                <ion-col text-center col-8 no-padding >
                
                    <ion-label text-center style="font-size:12px;margin:0px"
                      >Your search range from your location (KM):</ion-label
                    >
                
                </ion-col>
                <ion-col col-2 no-padding text-center>
                  <ion-item
                    no-lines
                    style="border: thin solid grey;margin:0px;padding:5px"
                    text-center
                  >
                    <ion-input
                      type="text"
                      [(ngModel)]="radius"
                      formControlName="radius"
                      (keyup)="updateRadius()"
                    ></ion-input> </ion-item
                ></ion-col>

                <ion-col col-2 ion-item no-lines no-padding text-center>
                  <div text-center>
                    <ion-icon
                      name="ios-search-outline"
                      (click)="resetRadius()"
                      style="color: #000000;
         font-weight: 600;font-weight:1.5rem;"
                      item-end
                    ></ion-icon>
                  </div>
                </ion-col>
              </ion-row>
            </ion-grid>

            <div #map_div id="map_div" text-center>
              <div #map id="map"></div>
              <div id="loc_div">
                <img
                  src="assets/imgs/location_drop.png"
                  style="background-color: transparent;"
                />
              </div>
            </div>
          </form>
        </ion-content>
      `,
    })
    export class MapModelProfile {
      @ViewChild("map") mapElement: ElementRef;
      map: any;
      mapCenterLoc: any;
      geocoder: any;
      searchBarSelect: any;

      sendFrom: any;
      senderLocation: any;
      state: any;
      country: any;
      latitude: any;
      longitude: any;
      toLat: any;
      toLong: any;
      fromLocation: any;
      receiverLocation: any;
      sendTo: any;
      toLocation: any;
      locationForm: FormGroup;
      pickup: any;
      fromFavSelect: any;
      toFavSelect: any;
      continue: boolean = false;

      phone: any;
      pickedLocation: any;
      loading: any;
      area: any;
      pincode: any;
      city: any;
      sublocation: any;
      GoogleAutocomplete: any;
      autocompleteAddress: { input: string };
      autocompleteAddressItems: any[];
      radius: any;
      latlng: { lat: number; lng: number };
      getDetails: any;
      userlatlng: { lat: any; lng: any };
      unsubscribeBackEvent: any;
      mapCircle: any;
      cityCircle: any;

      constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        private formBuilder: FormBuilder,
        public toastController: ToastController,
        private zone: NgZone,
        public geo: Geolocation,
        public loadingCtrl: LoadingController,
        public storage: Storage,
        public viewCtrl: ViewController,
        public modalCtrl: ModalController,
        public platform: Platform,
        private app: App
      ) {
        this.locationForm = this.formBuilder.group({
          autocompleteAddress: ["", [Validators.required]],
          radius: ["", [Validators.required]],
        });

        if (typeof google != "undefined") {
          this.GoogleAutocomplete =
            new google.maps.places.AutocompleteService();
          this.geocoder = new google.maps.Geocoder();
        }
        this.autocompleteAddress = { input: "" };
        this.autocompleteAddressItems = [];
        this.mapCenterLoc = new google.maps.LatLng(20.5937, 78.9629);
        //this.mapCenterLoc = new google.maps.LatLng(13.0279, 80.2605);

        this.storage.get("memberDetails").then((val) => {
          this.getDetails = val;
          console.log("details==>", val);
          if (val == undefined || val == "" || val == null) {
            this.loading = this.loadingCtrl.create({
              spinner: "bubbles",
            });
            this.loading.present();
            var view = this;
            this.geo
              .getCurrentPosition({
                timeout: 4000,
                enableHighAccuracy: true,
                maximumAge: 3600,
              })
              .then(
                (position) => {
                  if (typeof google != "undefined") {
                    let latLng = new google.maps.LatLng(
                      position.coords.latitude,
                      position.coords.longitude
                    );
                    this.mapCenterLoc = new google.maps.LatLng(
                      position.coords.latitude,
                      position.coords.longitude
                    );
                    this.map.setCenter(this.mapCenterLoc);
                    if (
                      this.cityCircle != undefined ||
                      this.cityCircle != null
                    ) {
                      this.cityCircle.setMap(null);
                    }

                    this.cityCircle = new google.maps.Circle({
                      strokeColor: "#FF0000",
                      strokeOpacity: 0.8,
                      strokeWeight: 2,
                      fillColor: "#FF0000",
                      fillOpacity: 0.35,
                      map: this.map,
                      center: this.mapCenterLoc,
                      radius: this.radius * 100,
                    });
                    this.map.fitBounds(this.cityCircle.getBounds());

                    view.geocodeLatLng(latLng, function () {
                      view.fromLocation = view.autocompleteAddress.input;
                      view.loading.dismiss();
                    });
                  } else {
                    view.loading.dismiss();
                    this.presentToast("*No Internet connection");
                  }
                },
                (err) => {
                  this.loading.dismiss();
                  this.storage.get("memberDetails").then((val) => {
                    this.autocompleteAddress.input = val.address;
                    this.latitude = val.latitude;
                    this.longitude = val.longitude;
                    this.area = val.area;

                    this.mapCenterLoc = new google.maps.LatLng(
                      this.latitude,
                      this.longitude
                    );
                    this.map.setCenter(this.mapCenterLoc);
                    if (
                      this.cityCircle != undefined ||
                      this.cityCircle != null
                    ) {
                      this.cityCircle.setMap(null);
                    }
                    this.cityCircle = new google.maps.Circle({
                      strokeColor: "#FF0000",
                      strokeOpacity: 0.8,
                      strokeWeight: 2,
                      fillColor: "#FF0000",
                      fillOpacity: 0.35,
                      map: this.map,
                      center: this.mapCenterLoc,
                      radius: this.radius * 100,
                    });
                    this.map.fitBounds(this.cityCircle.getBounds());
                  });
                }
              );
          } else {
            this.autocompleteAddress.input = this.getDetails.address;

            this.latitude = this.getDetails.latitude;
            this.longitude = this.getDetails.longitude;
            this.userlatlng = {
              lat: this.latitude,
              lng: this.longitude,
            };

            var latlng = this.userlatlng;
            this.latitude = latlng.lat;
            this.longitude = latlng.lng;
            this.area = this.getDetails.area;
            this.radius = this.getDetails.searchRadius;
            this.pincode = this.getDetails.pincode;
            console.log("addr", this.autocompleteAddress.input);

            this.mapCenterLoc = new google.maps.LatLng(
              this.latitude,
              this.longitude
            );
            this.map.setCenter(this.mapCenterLoc);
            if (this.cityCircle != undefined || this.cityCircle != null) {
              this.cityCircle.setMap(null);
            }
            this.cityCircle = new google.maps.Circle({
              strokeColor: "#FF0000",
              strokeOpacity: 0.8,
              strokeWeight: 2,
              fillColor: "#FF0000",
              fillOpacity: 0.35,
              map: this.map,
              center: this.mapCenterLoc,
              radius: this.radius * 100,
            });
            this.map.fitBounds(this.cityCircle.getBounds());
          }
        });
      }

      updateRadius() {
        if (
          this.radius != "" &&
          this.radius != undefined &&
          this.radius != null
        ) {
          if (this.cityCircle != undefined || this.cityCircle != null) {
            this.cityCircle.setMap(null);
          }
          this.cityCircle = new google.maps.Circle({
            strokeColor: "#FF0000",
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: "#FF0000",
            fillOpacity: 0.35,
            map: this.map,
            center: this.mapCenterLoc,
            radius: this.radius * 100,
          });
          this.map.fitBounds(this.cityCircle.getBounds());
        }
      }
      resetRadius() {
        if (!this.locationForm.invalid) {
          this.fromFavSelect = {
            packagePickupAddress: this.autocompleteAddress.input,
            latitude: this.latitude,
            longitude: this.longitude,
            sendFrom: this.city,
            sublocation: this.area,
            pincode: this.pincode,
            radius: this.radius,
            memberId: this.getDetails.memberId,
          };
          this.viewCtrl.dismiss(this.fromFavSelect);
          this.map.setCenter(this.mapCenterLoc);
          if (this.cityCircle != undefined || this.cityCircle != null) {
            this.cityCircle.setMap(null);
          }
          this.cityCircle = new google.maps.Circle({
            strokeColor: "#FF0000",
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: "#FF0000",
            fillOpacity: 0.35,
            map: this.map,
            center: this.mapCenterLoc,
            radius: this.radius * 100,
          });
          this.map.fitBounds(this.cityCircle.getBounds());
        }
      }

      // profileBox() {
      //   this.viewCtrl.dismiss();
      //   this.navCtrl.push(ProfileinfoPage);

      // }
      updateAddressSearchResults() {
        if (this.autocompleteAddress.input == "") {
          this.autocompleteAddressItems = [];

          return;
        }
        if (this.autocompleteAddress.input.length >= 5) {
          if (this.GoogleAutocomplete != undefined) {
            this.GoogleAutocomplete.getPlacePredictions(
              { input: this.autocompleteAddress.input },
              (predictions, status) => {
                this.autocompleteAddressItems = [];
                this.zone.run(() => {
                  if (
                    predictions != undefined &&
                    predictions != "" &&
                    predictions != null
                  ) {
                    predictions.forEach((prediction) => {
                      this.autocompleteAddressItems.push(prediction);
                    });
                  } else {
                    this.presentToast(
                      "Location not found, please search nearby location"
                    );
                  }
                });
              }
            );
          } else {
            this.presentToast("Please check your internet connection");
          }
        }
      }
      displayWarn(message) {
        const modal = this.modalCtrl.create(
          "CustomDialogPage",
          {
            dialogFor: "warning",
            iconName: "",
            titleName: "",
            bodyTxt: message,
            okBtnNm: "Ok",
          },
          {
            cssClass: "customModal1 customHrdTxt1",
            enableBackdropDismiss: true,
          }
        );
        modal.present();
      }
      selectAddressSearchResult(item) {
        this.autocompleteAddressItems = [];
        this.autocompleteAddress.input = item.description;
        this.geocoder.geocode({ placeId: item.place_id }, (results, status) => {
          if (status === "OK" && results[0]) {
            var lat = parseFloat(results[0].geometry.location.lat());
            var lng = parseFloat(results[0].geometry.location.lng());
            var latlng = {
              lat: lat,
              lng: lng,
            };
            this.latlng = latlng;
            this.latitude = this.latlng.lat;
            this.longitude = this.latlng.lng;

            results[0].address_components.forEach((val) => {
              if (val.types[0] == "locality") {
                this.city = val.short_name;
              }
              if (val.types[0] == "administrative_area_level_1") {
                this.state = val.short_name;
              }
              if (val.types[0] == "country") {
                this.country = val.short_name;
              }
              if (val.types[2] == "sublocality_level_1") {
                this.area = val.short_name;
              }
            });

            if (this.latlng != undefined) {
              this.showMap();
              this.getpinCode();
            }
          }
        });
      }
      ionViewWillEnter() {
        this.unsubscribeBackEvent = this.platform.registerBackButtonAction(
          () => {
            let nav = this.app.getActiveNavs()[0];
            let activeView = nav.getActive();
            if (activeView.name === "ModalCmp") {
              this.dismiss();
            } else {
              return true;
            }
          },
          101
        );
      }
      ionViewWillLeave() {
        this.unsubscribeBackEvent && this.unsubscribeBackEvent();
      }
      getpinCode() {
        var view = this;
        console.log("latlng", this.latlng);
        this.geocoder.geocode(
          { location: this.latlng },
          function (results, status) {
            if (status === "OK") {
              if (results[0]) {
                console.log(results[0]);

                results[0].address_components.forEach((val) => {
                  if (val.types[0] == "postal_code") {
                    view.pincode = val.short_name;
                    console.log(view.pincode);
                  }
                });
              }
            }
          }
        );
      }
      showMap() {
        this.mapCenterLoc = new google.maps.LatLng(
          this.latlng.lat,
          this.latlng.lng
        );
        this.loadMap();
         if (this.cityCircle != undefined || this.cityCircle != null) {
           this.cityCircle.setMap(null);
         }
        this.cityCircle = new google.maps.Circle({
          strokeColor: "#FF0000",
          strokeOpacity: 0.8,
          strokeWeight: 2,
          fillColor: "#FF0000",
          fillOpacity: 0.35,
          map: this.map,
          center: this.mapCenterLoc,
          radius: this.radius * 100,
        });
        this.map.fitBounds(this.cityCircle.getBounds());
      }
      geocodeLatLng(latlong, callback) {
        var view = this;
        var input = latlong;
        var latlng = {
          lat: parseFloat(input.lat()),
          lng: parseFloat(input.lng()),
        };
        this.geocoder.geocode({ location: latlng }, function (results, status) {
          if (status === "OK") {
            if (results[0]) {
              view.autocompleteAddress.input = results[0].formatted_address;
              view.latitude = parseFloat(input.lat());
              view.longitude = parseFloat(input.lng());
              results[0].address_components.forEach((val) => {
                if (val.types[0] == "locality") {
                  view.city = val.short_name;
                }
                if (val.types[2] == "sublocality_level_1") {
                  view.area = val.short_name;
                }
                if (val.types[0] == "administrative_area_level_1") {
                  view.state = val.short_name;
                }
                if (val.types[0] == "country") {
                  view.country = val.short_name;
                }
              });

              // view.ref.detectChanges();
            } else {
              window.alert("No results found");
            }
          } else {
            window.alert("Geocoder failed due to: " + status);
          }
          callback();
        });
      }
      ionViewDidLoad() {
        this.loadMap();
      }
      dismiss() {
        if (!this.locationForm.invalid) {
          this.fromFavSelect = {
            packagePickupAddress: this.autocompleteAddress.input,
            latitude: this.latitude,
            longitude: this.longitude,
            sendFrom: this.city,
            sublocation: this.area,
            pincode: this.pincode,
            radius: this.radius,
            memberId: this.getDetails.memberId,
          };
          this.viewCtrl.dismiss(this.fromFavSelect);
        }
      }
      postRequest() {
        if (!this.locationForm.invalid) {
          this.fromFavSelect = {
            packagePickupAddress: this.pickup,
            latitude: this.latitude,
            longitude: this.longitude,
            sendFrom: this.city,
            sublocation: this.area,
            pincode: this.pincode,
            state: this.state,
            country: this.country,
          };
          this.viewCtrl.dismiss(this.fromFavSelect);
        }
      }
      presentToast(params) {
        let toast = this.toastController.create({
          message: params,
          duration: 2000,
        });
        toast.present();
      }
      loadMap() {
        const mapStyle = [
          {
            featureType: "all",
            elementType: "labels.text.fill",
            stylers: [
              {
                color: "#7c93a3",
              },
              {
                lightness: "-10",
              },
            ],
          },
          {
            featureType: "administrative.country",
            elementType: "geometry",
            stylers: [
              {
                visibility: "on",
              },
            ],
          },
          {
            featureType: "administrative.country",
            elementType: "geometry.stroke",
            stylers: [
              {
                color: "#a0a4a5",
              },
            ],
          },
          {
            featureType: "administrative.province",
            elementType: "geometry.stroke",
            stylers: [
              {
                color: "#62838e",
              },
            ],
          },
          {
            featureType: "landscape",
            elementType: "geometry.fill",
            stylers: [
              {
                color: "#eff1ea",
              },
            ],
          },
          {
            featureType: "landscape.man_made",
            elementType: "geometry.stroke",
            stylers: [
              {
                color: "#7c93a3",
              },
              {
                weight: "0.10",
              },
            ],
          },
          {
            featureType: "poi",
            elementType: "all",
            stylers: [
              {
                visibility: "simplified",
              },
            ],
          },
          {
            featureType: "poi.attraction",
            elementType: "all",
            stylers: [
              {
                visibility: "on",
              },
            ],
          },
          {
            featureType: "poi.business",
            elementType: "all",
            stylers: [
              {
                visibility: "on",
              },
            ],
          },
          {
            featureType: "poi.government",
            elementType: "all",
            stylers: [
              {
                visibility: "on",
              },
            ],
          },
          {
            featureType: "poi.park",
            elementType: "all",
            stylers: [
              {
                visibility: "on",
              },
            ],
          },
          {
            featureType: "poi.place_of_worship",
            elementType: "all",
            stylers: [
              {
                visibility: "on",
              },
            ],
          },
          {
            featureType: "poi.school",
            elementType: "all",
            stylers: [
              {
                visibility: "on",
              },
            ],
          },
          {
            featureType: "poi.sports_complex",
            elementType: "all",
            stylers: [
              {
                visibility: "on",
              },
            ],
          },
          {
            featureType: "road",
            elementType: "all",
            stylers: [
              {
                saturation: "-100",
              },
              {
                visibility: "on",
              },
            ],
          },
          {
            featureType: "road",
            elementType: "geometry.stroke",
            stylers: [
              {
                visibility: "off",
              },
            ],
          },
          {
            featureType: "road.highway",
            elementType: "geometry.fill",
            stylers: [
              {
                color: "#bbcacf",
              },
            ],
          },
          {
            featureType: "road.highway",
            elementType: "geometry.stroke",
            stylers: [
              {
                lightness: "0",
              },
              {
                color: "#bbcacf",
              },
              {
                weight: "0.50",
              },
            ],
          },
          {
            featureType: "road.highway",
            elementType: "labels",
            stylers: [
              {
                visibility: "on",
              },
            ],
          },
          {
            featureType: "road.highway",
            elementType: "labels.text",
            stylers: [
              {
                visibility: "on",
              },
            ],
          },
          {
            featureType: "road.highway.controlled_access",
            elementType: "geometry.fill",
            stylers: [
              {
                color: "#ffffff",
              },
            ],
          },
          {
            featureType: "road.highway.controlled_access",
            elementType: "geometry.stroke",
            stylers: [
              {
                color: "#a9b4b8",
              },
            ],
          },
          {
            featureType: "road.arterial",
            elementType: "labels.icon",
            stylers: [
              {
                invert_lightness: true,
              },
              {
                saturation: "-7",
              },
              {
                lightness: "3",
              },
              {
                gamma: "1.80",
              },
              {
                weight: "0.01",
              },
            ],
          },
          {
            featureType: "transit",
            elementType: "all",
            stylers: [
              {
                visibility: "off",
              },
            ],
          },
          {
            featureType: "water",
            elementType: "geometry.fill",
            stylers: [
              {
                color: "#a3c7df",
              },
            ],
          },
        ];

        let mapOptions = {
          draggable: false,
          center: this.mapCenterLoc,
          zoom: 17,
          mapTypeId: google.maps.MapTypeId.ROADMAP,
          zoomControl: false,
          styles: mapStyle,
          fullscreenControl: false,
          mapTypeControl: false,
          streetViewControl: false,
        };

        this.map = new google.maps.Map(
          this.mapElement.nativeElement,
          mapOptions
        );
        this.cityCircle = new google.maps.Circle({
          strokeColor: "#FF0000",
          strokeOpacity: 0.8,
          strokeWeight: 2,
          fillColor: "#FF0000",
          fillOpacity: 0.35,
          map: this.map,
          center: this.mapCenterLoc,
          radius: this.radius * 100,
        });
        google.maps.event.addListener(this.map, "dragstart", () => {
          this.pickup = "Loading...";
          this.continue = true;
        });
        google.maps.event.addListener(this.map, "dragend", () => {
          let latlng = {
            lat: this.map.getCenter().lat(),
            lng: this.map.getCenter().lng(),
          };
          this.fromMap(latlng);
        });
      }
      fromMap(latlng) {
        this.geocoder.geocode({ location: latlng }, (results, status) => {
          if (status === "OK" && results[0]) {
            var latlng = {
              lat: parseFloat(results[0].geometry.location.lat()),
              lng: parseFloat(results[0].geometry.location.lng()),
            };
            this.latitude = latlng.lat;
            this.longitude = latlng.lng;

            this.fromLocation = results[0].formatted_address;
            this.pickup = results[0].formatted_address;
            this.continue = false;

            results[0].address_components.forEach((val) => {
              if (val.types[0] == "locality") {
                this.city = val.short_name;
              }
              if (val.types[0] == "postal_code") {
                this.pincode = val.short_name;
                console.log(this.pincode);
              }
              if (val.types[2] == "sublocality_level_1") {
                this.area = val.short_name;
              }

              if (val.types[0] == "administrative_area_level_1") {
                this.state = val.short_name;
              }
              if (val.types[0] == "country") {
                this.country = val.short_name;
              }
            });
          }
        });
      }
    }
    
    
  
  