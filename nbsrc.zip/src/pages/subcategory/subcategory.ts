import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, ModalController, App } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { HomePage } from '../home/home';
import { MylistingPage } from '../mylisting/mylisting';
import { GroupinfoPage } from '../groupinfo/groupinfo';
import { Storage } from '@ionic/storage';
/**
 * Generated class for the SubcategoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-subcategory',
  templateUrl: 'subcategory.html',
})
export class SubcategoryPage {
  rootId: any;
  loading: any;
  categoryList: any;
  viewName: any;
  currentViews: any;
  pageflg: any;
  page: number;

  constructor(public navCtrl: NavController,     public storage:Storage,
    private app: App, public modalCtrl: ModalController,public navParams: NavParams,public toastController: ToastController, public loadingController: LoadingController,public restProvider: RestProvider) {
   this.rootId=navParams.get("id");
   this.storage.get("lastPage").then((val) => {
    this.page = val;
  });

   //this.page = navParams.get("pageId");

   console.log("id",this.rootId);
   this.getsubCategoryList();
  }
  
  ionViewDidLoad() {
    console.log('ionViewDidLoad SubcategoryPage');
  }
  displayAlert(message) {
    const modal = this.modalCtrl.create(
      "CustomDialogPage",
      {
        dialogFor: "info",
        iconName: "",
        titleName: "",
        bodyTxt: message,
        okBtnNm: "Ok",
      },
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    );
    modal.present();
  }
  getsubCategoryList(){
    return new Promise((resolve, reject) => {
      this.loading = this.loadingController.create({
        spinner: "bubbles"
      });
      this.loading.present();
      this.restProvider
      .getsubCategory(this.rootId)
      .then((data) => { 
        console.log("data",data);
        var result : any = data;
        if(result.status == "success"){
          this.categoryList=result.categoryDto;
         
        }
        else if(result.status == "fail" && result.categoryDto.length ==0){
          this.getProductUsingcategory(this.rootId);
        }
        this.loading.dismiss();
      
    })
    .catch(error => {
      console.log("error",error);
      this.loading.dismiss();
    this.displayAlert("Please try again later");
    });
  }); 
  }
  presentToast(params) {
    let toast = this.toastController.create({
    message: params,
    duration: 2000
    });
    toast.present();
    }
    getProductlist(catId){
   
   
   console.log(this.page);
      if(this.categoryList.length >0){
        if (this.page == 1) {
          this.navCtrl.push(HomePage, { id: catId.categoryId });
        } else if (this.page == 2) {
          this.navCtrl.push(MylistingPage, { id: catId.categoryId });
        } else if (this.page == 3) {
          this.navCtrl.push(GroupinfoPage, { id: catId.categoryId });
        }  
    }    
  }
  getProductUsingcategory(id){
    console.log(this.page);
      if (this.page == 1) {
        this.navCtrl.push(HomePage, { id: id });
      } else if (this.page == 2) {
        this.navCtrl.push(MylistingPage, { id: id });
      } else if (this.page == 3) {
        this.navCtrl.push(GroupinfoPage, { id: id });
      } 
    

  }
    
}
