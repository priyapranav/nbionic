import { Component, ViewChild } from '@angular/core';
import { Platform, App, Nav, LoadingController, ToastController, ModalController, AlertController, IonicApp, Events} from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';

import { FormBuilder, Validators } from '@angular/forms';

import { ForgetpasswordPage } from '../pages/forgetpassword/forgetpassword';


import { RestProvider } from '../providers/rest/rest';
import { Storage } from "@ionic/storage";

import { ProfilePage } from '../pages/profile/profile';
import { MenuController } from 'ionic-angular';

import { ResetpasswordPage } from '../pages/resetpassword/resetpassword';

import { AddproductPage } from '../pages/addproduct/addproduct';
import { InvitefriendsPage } from '../pages/invitefriends/invitefriends';
import { MessageboxPage } from '../pages/messagebox/messagebox';
import { SearchPage } from '../pages/search/search';
import { SelectgroupPage } from '../pages/selectgroup/selectgroup';
import { ManageprofilePage } from '../pages/manageprofile/manageprofile';
import { SettingsPage } from '../pages/settings/settings';
import { ProfileinfoPage } from '../pages/profileinfo/profileinfo';
import { LoginPage } from '../pages/login/login';
import { NotificationPage } from '../pages/notification/notification';

import { SubcategoryPage } from '../pages/subcategory/subcategory';
import { AndroidPermissions } from "@ionic-native/android-permissions";
import { UsefulcontactsPage } from '../pages/usefulcontacts/usefulcontacts';
import { ManageGroupPage } from '../pages/manage-group/manage-group';
import { GroupmembersPage } from '../pages/groupmembers/groupmembers';
import { LoginNewPage } from '../pages/login-new/login-new';
import { Deeplinks } from '@ionic-native/deeplinks';
import { GroupinvitereqPage } from '../pages/groupinvitereq/groupinvitereq';

@Component({
  templateUrl: "app.html",
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;
  pages: Array<{ title: string; component: any }>;
  //menuPages: Array<{ title: string; component: any ;icon: any }>;
  rootPage: any;
  viewName: any;
  pageName: any;
  mail: any;
  courses: any;
  dashBoard: any;
  exams: any;
  feedback: any;
  mailSubscribeForm: any;
  showHeaderFlg: boolean = true;
  showMenuFlg: boolean = false;
  backBtnFlag: boolean = false;
  showFooterFlg: boolean = true;
  homeFooterFlag: boolean = true;
  showProfileFlg: boolean = true;
  grpPageFlg: boolean = false;
  regBackFlag: boolean = true;
  homeIconSize: String = "colWidthHome";
  versionNo: any;
  loading: any;
  versionRes: any;
  toast: any;
  user: any = "User";
  showavailExamsDetails: boolean;
  showpackDetails: boolean;
  showexamHistoryDetails: boolean;
  email: any;
  password: any;
  categroylist: any;
  memberId: any;
  menuPages: any;
  showsearchFlg: any;
  showmessageFlg: any;
  userLoggedRadius: any;
  userLoggedLocation: any;
  latitude: any;
  longitude: any;
  groupFooter: boolean = false;
  homePageFlg : boolean = true;

  constructor(
    private app: App,
    public toastController: ToastController,
    public restProvider: RestProvider,
    public loadingController: LoadingController,
    public platform: Platform,
    public statusBar: StatusBar,
    public splashScreen: SplashScreen,
    private formBuilder: FormBuilder,
    private storage: Storage,
    public modalCtrl: ModalController,
    private menuCtrl: MenuController,
    private alertCtrl: AlertController,
    private ionicApp: IonicApp,
    public events: Events,
    public androidPerm: AndroidPermissions,
    private deeplinks:Deeplinks
  ) {
    this.events.subscribe("user:created", (user) => {
      // user and time are the same arguments passed in `events.publish(user, time)`
      console.log("Welcome", user);
      this.memberId = user;
      this.rootPage = HomePage;
      this.getrootCategoryLogin();
    });
  }
  getrootCategoryLogin() {
    this.restProvider
      .getrootCategory(this.memberId)
      .then((data) => {
        console.log("data" + data);
        var result: any = data;

        if (result != null && result.status == "success") {
          this.categroylist = result.categoryDto;
          this.menuPages = [];
          for (let cIdx in this.categroylist) {
            this.menuPages.push({
              catId: this.categroylist[cIdx].categoryId,
              title: this.categroylist[cIdx].categoryName,
            });
          }
        }
        this.nav.setRoot(HomePage);
      })
      .catch((error) => {
        console.log("please try again");
      });
  }

  ngOnInit() {
    this.platform.ready().then(() => {
      this.splashScreen.hide();
      this.statusBar.hide();
      this.statusBar.styleLightContent();
      this.platform.registerBackButtonAction(() => {
        this.goBack();
      });
    });
    this.initializeApp();
    this.app.viewWillEnter.subscribe((view) => {
      if (
        view.instance.constructor.name == "LoadingCmp" ||
        view.instance.constructor.name == "SelectPopover" ||
        view.instance.constructor.name == "CustomDialogPage" ||
        view.instance.constructor.name == "AlertCmp" ||
        view.instance.constructor.name == "ToastCmp" ||
        view.instance.constructor.name == "InfoPop" ||
        view.instance.constructor.name == "QuickQuestionView" ||
        view.instance.constructor.name == "sectionView" ||
        view.instance.constructor.name == " SlideModel" ||
        view.instance.constructor.name == "reviewsectionView" ||
        view.instance.constructor.name == "QuickView" ||
        view.instance.constructor.name == "ReviewInfo" ||
        view.instance.constructor.name == "ImageZoomDirective" ||
        view.instance.constructor.name == "RequestSuccessPop" ||
        view.instance.constructor.name == "SafePipe" ||
        view.instance.constructor.name == "RequestModal" ||
        view.instance.constructor.name == "UploadPicModal" ||
        view.instance.constructor.name == "UploadPicModal" ||
        view.instance.constructor.name == "ReportAbusePop" ||
        view.instance.constructor.name == "ChooseImagePop" ||
        view.instance.constructor.name == "AddCategoryPop" ||
        view.instance.constructor.name == "FeedbackPop" ||
        view.instance.constructor.name == "ImagePopup" ||
        view.instance.constructor.name == "SuccessPop" ||
        view.instance.constructor.name == "EditGroupPop" ||
        view.instance.constructor.name == "RatingPopup" ||
        view.instance.constructor.name == "ReminderPopup" ||
        view.instance.constructor.name == "sendRatingPopup" ||
        view.instance.constructor.name == "senderReminderPopup" ||
        view.instance.constructor.name == "MapModelProfile" ||
        view.instance.constructor.name == "GrouplistPop"
      ) {
        return;
      }

      this.viewName = view.instance.constructor.name;
      console.log("pagename" + this.viewName);

      if (this.viewName == "HomePage") {
        this.pageName = "Home";
        this.showHeaderFlg = true;
        this.homePageFlg = true;
        this.backBtnFlag = false;
        this.showMenuFlg = true;
        this.showsearchFlg = true;
        this.showmessageFlg = true;
        this.showFooterFlg = true;
        this.homeFooterFlag = true;
        this.showProfileFlg = true;
        this.grpPageFlg = false;
        this.regBackFlag = false;
        this.groupFooter = false;
        this.homeIconSize = "colWidthHome";
      } else if (this.viewName == "RegisterPage") {
        this.pageName = "Register";
        this.showHeaderFlg = true;
        this.homePageFlg = false;
        this.showMenuFlg = false;
        this.backBtnFlag = true;
        this.showsearchFlg = false;
        this.showmessageFlg = false;
        this.showFooterFlg = false;
        this.showProfileFlg = false;
        this.grpPageFlg = false;
        this.regBackFlag = true;
        this.groupFooter = false;
      } else if (this.viewName == "ForgetpasswordPage") {
        this.showHeaderFlg = true;
        this.showMenuFlg = false;
        this.backBtnFlag = true;
        this.showsearchFlg = false;
        this.showmessageFlg = false;
        this.showFooterFlg = false;
        this.showProfileFlg = false;
        this.grpPageFlg = false;
        this.regBackFlag = true;
        this.groupFooter = false;
        this.homePageFlg = false;
      } else if (this.viewName == "TncPage") {
        this.showHeaderFlg = true;
        this.showMenuFlg = false;
        this.backBtnFlag = true;
        this.showsearchFlg = false;
        this.showmessageFlg = false;
        this.showFooterFlg = false;
        this.showProfileFlg = false;
        this.grpPageFlg = false;
        this.regBackFlag = true;
        this.groupFooter = false;
        this.homePageFlg = false;
      } else if (
        this.viewName == "LoginPage" ||
        this.viewName == "LoginNewPage" ||
        this.viewName == "CnfrmPage"
      ) {
        this.showHeaderFlg = false;
        this.showFooterFlg = false;
        this.groupFooter = false;
        this.homePageFlg = false;
      } else if (this.viewName == "GroupinfoPage") {
        this.showHeaderFlg = true;
        this.homePageFlg = true;
        this.showMenuFlg = true;
        this.backBtnFlag = true;
        this.showsearchFlg = true;
        this.showmessageFlg = false;
        this.showFooterFlg = false;
        this.showProfileFlg = true;
        this.grpPageFlg = true;
        this.regBackFlag = false;
        this.groupFooter = true;
      } else if (this.viewName == "UsefulcontactsPage") {
        this.showHeaderFlg = false;
        this.showFooterFlg = false;
        this.groupFooter = false;
        this.homePageFlg = false;
        this.showMenuFlg = false;
        this.showsearchFlg = false;
        this.showmessageFlg = false;
        this.showProfileFlg = true;
      } else if (this.viewName == "GroupmembersPage") {
        this.showHeaderFlg = true;
        this.homePageFlg = false;
        this.showMenuFlg = false;
        this.backBtnFlag = true;
        this.showsearchFlg = false;
        this.showmessageFlg = false;
        this.showProfileFlg = true;
        this.showFooterFlg = false;
        this.groupFooter = false;
        this.grpPageFlg = false;
      } else {
        this.showHeaderFlg = true;
        this.homePageFlg = false;
        this.showMenuFlg = false;
        this.backBtnFlag = true;
        this.showsearchFlg = false;
        this.showmessageFlg = false;
        this.showFooterFlg = true;
        this.homeFooterFlag = false;
        this.showProfileFlg = true;
        this.grpPageFlg = false;
        this.regBackFlag = false;
        this.groupFooter = false;
        this.homeIconSize = "colWidthOther";
      }
      //   } else if (this.viewName == "AddproductPage") {
      //     this.pageName = "Add Product";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = true;
      //     this.backBtnFlag = true;
      //     this.showsearchFlg=true;
      //     this.showmessageFlg=true;
      //   } else if (this.viewName == "SelectgroupPage") {
      //     this.pageName = "Select Group";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = false;
      //     this.backBtnFlag = false;
      //     this.showFooterFlg=false;
      //     this.showsearchFlg = false;
      //     this.showmessageFlg = false;
      //   } else if (this.viewName == "NotificationPage") {
      //       this.pageName = "Notification";
      //       this.showHeaderFlg =true;
      //       this.showMenuFlg = false;
      //       this.backBtnFlag = false;
      //       this.showFooterFlg=false;
      //       this.showsearchFlg = false;
      //       this.showmessageFlg = false;
      //   }
      //   else if(this.viewName =="EditgroupPage"){
      //     this.pageName = "Edit Group";
      //     this.showHeaderFlg = true;
      //     this.backBtnFlag = false;
      //     this.showMenuFlg = false;
      //     this.showsearchFlg=false;
      //     this.showmessageFlg = false;
      //    }
      //   else if (this.viewName == "SearchPage") {
      //     this.pageName = "Neighbourbase";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = false;
      //     this.backBtnFlag = false;
      //     this.showsearchFlg=false;
      //     this.showmessageFlg = false;
      //   }
      //   else if(this.viewName == "ChatboxReceivePage"){
      //     this.showHeaderFlg = false;
      //     this.showFooterFlg=false;

      //   }
      //   else if(this.viewName =="ChatboxSendPage"){
      //     this.showHeaderFlg = false;
      //     this.showFooterFlg=false;
      //   }
      //   else if (this.viewName == "EditmylistingPage") {
      //     this.pageName = "Edit Listing";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = false;
      //     this.backBtnFlag = false;
      //     this.showsearchFlg = false;
      //     this.showmessageFlg = false;
      //   }
      //   else if (this.viewName == "UnblockmembersPage") {
      //     this.pageName = "UnBlock Members";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = false;
      //     this.backBtnFlag = false;
      //     this.showsearchFlg = false;
      //     this.showmessageFlg = false;
      //   }
      //   else if(this.viewName == "ReminderPage"){
      //     this.pageName = "Reminder";
      //     this.showHeaderFlg = true;
      //     this.backBtnFlag = true;
      //     this.showMenuFlg = false;
      //     this.showFooterFlg=false;
      //     this.showsearchFlg=false;
      //     this.showmessageFlg = false;

      //    }
      //   else if (this.viewName == "MylistingPage") {
      //     this.pageName = "My Listing";
      //     this.showHeaderFlg = true;
      //     this.backBtnFlag = true;
      //     this.showMenuFlg = true;
      //     this.showsearchFlg=true;
      //     this.showmessageFlg=true;

      //   }
      //   else if (this.viewName == "SettingsPage") {
      //     this.pageName = "Neighbourbase";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = true;
      //     this.backBtnFlag = true;
      //     this.showsearchFlg=true;
      //     this.showmessageFlg=true;
      //   }
      //   else if (this.viewName == "ManageprofilePage") {
      //     this.pageName = "Neighbourbase";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = true;
      //     this.backBtnFlag = true;
      //     this.showsearchFlg=true;
      //     this.showmessageFlg=true;
      //   }
      //   else if (this.viewName == "MessageboxPage") {
      //     this.pageName = "Message Box";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = true;
      //     this.backBtnFlag = true;
      //   }
      //   else if (this.viewName == "ProfileinfoPage") {
      //     this.pageName = "Neighbourbase";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg =true;
      //     this.backBtnFlag = true;
      //     this.showsearchFlg=true;
      //     this.showmessageFlg=true;
      //   }
      //   else if(this.viewName == "UsefulcontactsPage"){
      //     //this.pageName = "Neighbourbase ";
      //     this.showHeaderFlg =false;
      //    // this.backBtnFlag = true;
      //     this.showMenuFlg =false;
      //   }
      //   else if(this.viewName == "AddcontactlistPage"){
      //    // this.pageName = "Neighbourbase ";
      //     this.showHeaderFlg = false;
      //    // this.backBtnFlag = true;
      //    // this.showsearchFlg=true;
      //    // this.showmessageFlg=true;

      //   }
      //   else if(this.viewName == "GetusercontactdetailsPage"){
      //     this.pageName = "Useful Contacts ";
      //     this.showHeaderFlg = false;
      //     this.showMenuFlg = false;
      //     this.backBtnFlag = false;
      //     this.showFooterFlg=false;
      //     this.showsearchFlg = false;
      //     this.showmessageFlg = false;

      //   }
      //   else if(this.viewName == "ProductsPage"){
      //     this.pageName = "Products";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = false;
      //     this.backBtnFlag = true;
      //     this.showsearchFlg=true;
      //     this.showmessageFlg=true;
      //   }
      //     else if (this.viewName == "ForgetpasswordPage") {
      //     this.pageName = "Forget Password";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg =false;
      //     this.backBtnFlag = true;
      //     this.showsearchFlg=false;
      //     this.showmessageFlg=false;

      //   } else if (this.viewName == "ProfilepicturePage") {
      //     this.pageName = "Profile Picture";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = true;
      //     this.backBtnFlag = true;
      //     this.showsearchFlg=true;
      //     this.showmessageFlg=true;
      //   }
      //   else if(this.viewName =="ChangeLocationPage"){
      //     this.pageName = "Change Location";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = true;
      //     this.backBtnFlag = true;
      //     this.showsearchFlg=true;
      //     this.showmessageFlg=true;
      //   }
      //   else if(this.viewName =="TncPage"){
      //     this.pageName = "Terms and Condition";
      //     this.showHeaderFlg = true;
      //     this.showMenuFlg = false;
      //     this.backBtnFlag = true;
      //     this.showsearchFlg=false;
      //     this.showmessageFlg=false;
      //   }
      //  else if(this.viewName == "ProfilePage"){
      //   this.pageName = "Profile";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = true;
      //   this.showsearchFlg=true;
      //   this.showmessageFlg=true;

      //  }
      //  else if(this.viewName =="ResetpasswordPage"){
      //   this.pageName = "Reset Password";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = true;
      //   this.showsearchFlg=false;
      //   this.showmessageFlg=false;
      //  }
      //  else if(this.viewName =="LoginPage"){
      //   this.pageName = "Login";
      //   this.showHeaderFlg = false;
      //   this.backBtnFlag =false;
      //   this.showMenuFlg = false;
      //   this.showFooterFlg=false;
      //   this.showsearchFlg=false;
      //   this.showmessageFlg=false;
      //  }
      //  else if(this.viewName =="ChangeemailPage"){
      //   this.pageName = "Change Email";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = false;
      //   this.showsearchFlg=true;
      //   this.showmessageFlg=true;
      //  }
      //  else if(this.viewName =="NewgroupPage"){
      //   this.pageName = "New Group";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = true;
      //   this.showsearchFlg=true;
      //   this.showmessageFlg=true;
      //  }
      //  else if(this.viewName == "FeedbackPage"){
      //   this.pageName = "Feedback";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = true;
      //   this.showsearchFlg=true;
      //   this.showmessageFlg=true;
      //  }
      //  else if(this.viewName == "ChangeLocPage"){
      //   this.pageName = "ChangeLoc";
      //   this.showHeaderFlg = false;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = true;
      //   this.showFooterFlg=false;
      //   this.showsearchFlg=true;
      //   this.showmessageFlg=true;
      //  }

      //  else if(this.viewName == "ToolsPage"){
      //   this.pageName = "Tools";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = false;
      //   this.showFooterFlg=true;
      //  }

      //  else if(this.viewName == "SubcategoryPage"){
      //   this.pageName = "Subcategory";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = true;
      //   this.showFooterFlg=true;
      //   this.showsearchFlg=true;
      //   this.showmessageFlg=true;
      //  }
      //  else if(this.viewName == "ProductviewPage"){
      //   this.pageName = "Product View";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = false;
      //   this.showFooterFlg=true;
      //   this.showsearchFlg=true;
      //   this.showmessageFlg=true;
      //  }
      //  else if(this.viewName == "GroupinfoPage"){
      //   this.pageName = "Groupinfo";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = true;
      //   this.showFooterFlg=false;
      //   this.showsearchFlg=true;
      //   this.showmessageFlg=true;
      //  }
      //  else if(this.viewName == "GroupmembersPage"){
      //   this.pageName = "Group Members";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = false;
      //   this.showFooterFlg=false;
      //   this.showsearchFlg=true;
      //   this.showmessageFlg=true;
      //  }
      //  else if(this.viewName == "EditgroupPage"){
      //   this.pageName = "Editgroupinfo";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = true;
      //   this.showFooterFlg=true;
      //   this.showsearchFlg=true;
      //   this.showmessageFlg=true;
      //  }

      //  else if(this.viewName == "GroupinvitereqPage"){
      //   this.pageName = "Group Invites";
      //   this.showHeaderFlg = true;
      //   this.backBtnFlag = true;
      //   this.showMenuFlg = true;
      //   this.showFooterFlg=true;
      //   this.showsearchFlg=true;
      //   this.showmessageFlg=true;
      //  }
    });

    /*this.menuPages = [
      {
        title: "Tools",
        compone;'';';';g; f;'f;l /fl;m fm m,g  mvglk,gv,.gl.;lvgmb.bm≥≤b/;'b ;'b ';vh';,c.gb L<f ;lsd [;
        zd pl[[f;'''''l]]] lnt: SubcategoryPage,
        icon: "ios-contact-outline",
      },
      {
        title: "Home Appliances",
        component: SubcategoryPage,
        icon: "ios-list-box-outline",
      },

      {
        title: "Life Style",
        component:SubcategoryPage,
        icon:"ios-person-add-outline",
      },
      {
        
        title: "Electronic Appliances",
        component: SubcategoryPage,
        icon:"ios-chatbubbles-outline",
      },
      {
        title: "Mobile Phones & Accessories",
        component: SubcategoryPage,
        icon:"ios-cart-outline",
      },
      {
        title: "Cars,Bikes,Bicycle",
        component: SubcategoryPage,
        icon:"ios-cart-outline",
      },
     
      {
        title: "School & College",
        component: SubcategoryPage,
        icon:"ios-cart-outline",
      },
     

      {
        title: "Real Estate",
        component: SubcategoryPage,
        icon:"ios-cart-outline",
      },
     
      {
        title: "Others",
        component: SubcategoryPage,
        icon:"ios-cart-outline",
      },
     
     
    
    ];*/
  }
  getrootCategory() {
    this.storage.get("memberId").then((val) => {
      if (val != null && val != undefined) {
        this.memberId = val;
        this.restProvider
          .getrootCategory(this.memberId)
          .then((data) => {
            console.log("data" + data);
            var result: any = data;

            if (result != null && result.status == "success") {
              this.categroylist = result.categoryDto;
              this.menuPages = [];
              for (let cIdx in this.categroylist) {
                this.menuPages.push({
                  catId: this.categroylist[cIdx].categoryId,
                  title: this.categroylist[cIdx].categoryName,
                });
              }
            }
          })
          .catch((error) => {
            console.log("please try again");
          });
      }
    });
  }
  openPage(rootid) {
    var rootid: any;
    for (let idx in this.categroylist) {
      if (this.categroylist[idx].categoryId == rootid) {
        this.nav.push(SubcategoryPage, { id: rootid });
      }
    }
    /*if(page.title=="Tools")
    {
      rootid = rootid;

  }
  else if(page.title =="Home Appliances"){
    rootid = rootid;

  }
  else if(page.title =="Life Style"){
    rootid = rootid;

  }
  else if(page.title =="Electronic Appliances"){
    rootid = rootid;

  }
  else if(page.title =="Mobile Phones & Accessories"){
    rootid = rootid;

  }
  else if(page.title =="Cars,Bikes,Bicycle"){
    rootid = rootid;

  }
  else if(page.title =="School & College"){
    rootid = rootid;

  }
  else if(page.title =="Real Estate"){
    rootid = rootid;


  }
  else if(page.title =="Others"){
    rootid = rootid;

  }*/
  }
  initializeApp() {
    this.androidPerm.requestPermissions([
      this.androidPerm.PERMISSION.READ_CONTACTS,
      this.androidPerm.PERMISSION.WRITE_CONTACTS,

      this.androidPerm.PERMISSION.CAMERA,
      this.androidPerm.PERMISSION.GET_ACCOUNTS,
    ]);

    this.androidPerm.checkPermission(this.androidPerm.PERMISSION.CAMERA).then(
      (result) => {
      //  alert(result.hasPermission);
        if (!result.hasPermission) {
          this.androidPerm
            .requestPermission(this.androidPerm.PERMISSION.CAMERA)
            .then((cam) => {
         //     alert("permission result " + JSON.stringify(cam));
            })
            .catch((error) => {
             // alert("permission error occured " + JSON.stringify(error));
            });
        } else {
        }
      },
      (err) => {
        this.androidPerm.requestPermission(this.androidPerm.PERMISSION.CAMERA);
      }
    );
// this.storage.get("memberId").then((val) => {
//   if (val != null && val != undefined) {
//     this.memberId = val;
//     this.rootPage = HomePage;
//     this.events.publish("user:created", this.memberId);
//   } else {
//     // this.rootPage = LoginPage;
//     this.rootPage = LoginNewPage;
//   }
// });
     
      this.storage.get("memberId").then((val) => {
        if (val != null && val != undefined) {
          this.memberId = val;
          //this.rootPage = HomePage;
          this.events.publish("user:created", this.memberId);
          this.deeplinks
            .routeWithNavController(this.nav, {
              "/": "",
              "/invite": "",
            })
            .subscribe(
              (match) => {
                // match.$route - the route we matched, which is the matched entry from the arguments to route()
                // match.$args - the args passed in the link
                // match.$link - the full link data
                var argu: any = match.$args;
                var netId = argu.networkId;
                console.log("Successfully matched route login", match.$args);
                this.storage.get("memberDetails").then((val) => {
                  if (val != null && val != undefined) {
                    this.memberId = val.memberId;
                    var email = val.email;
                    this.acceptConfirm(netId,this.memberId,email);
                    
                    
                  }
                });

               
              },
              (nomatch) => {
                // nomatch.$link - the full link data
                console.log("Got a deeplink that didn't match", nomatch);
                
              }
            );
        } else {
          //this.rootPage = LoginPage;
          this.rootPage = LoginNewPage;
          this.deeplinks
            .route({
              "/": "",
              "/invite": "",
            })
            .subscribe(
              (match) => {
                // match.$route - the route we matched, which is the matched entry from the arguments to route()
                // match.$args - the args passed in the link
                // match.$link - the full link data
                 var argu: any = match.$args;
                 var netId = argu.networkId;
                console.log("Successfully matched route logout", match.$args);
                var detail = {
                  grpId:netId
                }
                this.storage.set("grpInvite", detail);
                //  this.storage.get("memberDetails").then((val) => {
                //    if (val != null && val != undefined) {
                //      this.memberId = val.memberId;
                //      var email = val.email;
                //      this.acceptConfirm(netId, this.memberId, email);
                //    }
                //  });
              
                 
              },
              (nomatch) => {
                // nomatch.$link - the full link data
                console.error("Got a deeplink that didn't match", nomatch);
              }
            );

        }
      });

    

   
  }

  acceptConfirm(nid,mid,emailId){

  this.restProvider
  .acceptInvite(nid, mid, emailId)
  .then((data)=>{
    var result : any = data;
    console.log(result);

    if(result == true){
      const modal = this.modalCtrl.create(
        "CustomDialogPage",
        {
          titleName: "",

          bodyTxt:
            "You are now part of group. " ,

          okBtnNm: "",
        },

        { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
      );
    
    modal.present();
   
    modal.onDidDismiss((data) => {

        //this.invite();
 
      });
        

    }
    
    else if(result== false)
    {
      const modal = this.modalCtrl.create('CustomDialogPage',{

        titleName: "Invitation Accept Fail ",
    
        bodyTxt: "you are not included in the group" ,
    
        okBtnNm: "Ok",
    
      },
    
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    
    );
    
    modal.present();
    modal.onDidDismiss((data) => {

    return;
    });
      
    }

    else
    {
      const modal = this.modalCtrl.create('CustomDialogPage',{

        titleName:"",
    
        bodyTxt: "Server Down. Please Try Again",
    
        okBtnNm: "",
    
      },
    
      { cssClass: "customModal1 customHrdTxt1", enableBackdropDismiss: true }
    
    );
    
    modal.present();
    modal.onDidDismiss((data) => {

    return;
    });
      
    }
     
  })
  .catch(error => {
    console.log(error);
    this.presentToast("Please try again later");
});


}

  invite() {

    this.nav.push(InvitefriendsPage, { frmGrp: this.groupFooter });
  }
  navigatePage(page) {
    this.nav.push(page);
  }
  addProduct() {
    this.nav.push(AddproductPage);
  }
  dashboard() {
    this.nav.push(SettingsPage);
  }
  home() {
    this.nav.setRoot(HomePage);
  }
  selectGroup() {
    this.nav.push(SelectgroupPage);
  }

  profileInfo() {
    this.nav.push(ManageprofilePage);
  }
  messagebox() {
    this.nav.push(MessageboxPage);
  }
  goMembers() {
    this.nav.push(GroupmembersPage);
  }
  profile() {
    this.nav.push(ProfileinfoPage);
  }
  search() {
    this.nav.push(SearchPage);
  }
  notification() {
    this.nav.push(NotificationPage);
  }
  contacts() {
    this.nav.push(UsefulcontactsPage);
  }
  manageGrp() {
    this.nav.push(ManageGroupPage);
  }

  goBack() {
    let nav = this.app.getActiveNav();

    if (nav.canGoBack()) {
      nav.pop();
    } else {
      this.storage.get("memberId").then((val2) => {
        if (val2 != null && val2 != undefined) {
          if (this.viewName == "HomePage") {
            if (this.toast) {
              this.toast = null;
              this.platform.exitApp();
            } else {
              this.showToast();
            }
          } else {
            this.nav.setRoot(HomePage);
          }
        }
      });
    }
  }

  showToast() {
    this.toast = true;
    let toast = this.toastController.create({
      message: "press again to exit",
      duration: 1000,
      position: "bottom",
    });

    toast.onDidDismiss(() => {
      this.toast = null;
    });

    toast.present();
  }

  presentToast(params) {
    let toast = this.toastController.create({
      message: params,
      duration: 2000,
    });
    toast.present();
  }

  toolsRes() {
    /*
this.restProvider
  .getToolsList(transtypeid, categoryid, radius, pincode, latitude, longitude, memberid)
  .then( (data) => { 
    var result : any = data;
    console.log(result);
    
    if(result!=null)
    {
   
      console.log("success response");
    }
  
 //this.loading.dismiss();
  })
  .catch(error => {
 //this.loading.dismiss();
  
    this.presentToast("Please try again later");
  });
*/
  }
}
