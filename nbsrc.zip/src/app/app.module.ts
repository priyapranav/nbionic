import { BrowserModule, DomSanitizer } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { MyApp } from './app.component';



import { ForgetpasswordPage } from '../pages/forgetpassword/forgetpassword';


import { FileOpener } from '@ionic-native/file-opener';
import { StreamingMedia, StreamingVideoOptions } from '@ionic-native/streaming-media';
import { RestProvider } from '../providers/rest/rest';
import { HttpClientModule } from '@angular/common/http';
import { IonicStorageModule } from '@ionic/storage';
import { PhotoViewer } from "@ionic-native/photo-viewer";
import { Media } from "@ionic-native/media";
import { YoutubeVideoPlayer } from "@ionic-native/youtube-video-player";
import{DatePipe} from "@angular/common";
import { ProfilePage } from '../pages/profile/profile';
import { RegisterPage } from '../pages/register/register';

import { AddproductPage, RequestSuccessPop } from '../pages/addproduct/addproduct';
import { InvitefriendsPage } from '../pages/invitefriends/invitefriends';

import { SearchPage } from '../pages/search/search';
import { SelectgroupPage } from '../pages/selectgroup/selectgroup';
import { ManageprofilePage, GrouplistPop } from '../pages/manageprofile/manageprofile';
import { GrouplistModel, SettingsPage } from '../pages/settings/settings';
import { ProfileinfoPage } from '../pages/profileinfo/profileinfo';

import { ChangeLocationPage } from '../pages/change-location/change-location';
import { ChangeemailPage } from '../pages/changeemail/changeemail';
import { ProfilepicturePage, ChooseImagePop } from '../pages/profilepicture/profilepicture';
import { ResetpasswordPage } from '../pages/resetpassword/resetpassword';
import { GroupinvitereqPage } from '../pages/groupinvitereq/groupinvitereq';
import { FeedbackPage } from '../pages/feedback/feedback';
import { MylistingPage } from '../pages/mylisting/mylisting';
import { LoginPage } from '../pages/login/login';
import { Camera } from '@ionic-native/camera';
import { ImageProcess } from '../providers/rest/ImageProcess';
import { NotificationPage } from '../pages/notification/notification';

import {HomePage,MapModelProfile  } from '../pages/home/home';
import { SubcategoryPage } from '../pages/subcategory/subcategory';
import { GroupinfoPage } from '../pages/groupinfo/groupinfo';
import { EditgroupPage, EditGroupPop } from '../pages/editgroup/editgroup';
import { GroupmembersPage } from '../pages/groupmembers/groupmembers';
import { Geolocation } from '@ionic-native/geolocation';
import { UnblockmembersPage } from '../pages/unblockmembers/unblockmembers';
import { ReminderPage } from '../pages/reminder/reminder';
import { ProductviewPage, ReportAbusePop } from '../pages/productview/productview';
import { TncPage } from '../pages/tnc/tnc';
import { EditmylistingPage, ImagePopup } from '../pages/editmylisting/editmylisting';
import { AddcontactlistPage } from '../pages/addcontactlist/addcontactlist';
import { AddCategoryPop, UsefulcontactsPage, FeedbackPop } from '../pages/usefulcontacts/usefulcontacts';
import { GetusercontactdetailsPage } from '../pages/getusercontactdetails/getusercontactdetails';
import { ChatboxReceivePage, RatingPopup, ReminderPopup } from '../pages/chatbox-receive/chatbox-receive';
//import { ChatboxSentPage } from '../pages/chatbox-sent/chatbox-sent';

import { PushNotification } from '../providers/rest/pushNotification';
import { MessageboxPage } from '../pages/messagebox/messagebox';
import { CalendarModule } from 'ionic3-calendar-en';
import { ChatboxSendPage, sendRatingPopup, senderReminderPopup } from '../pages/chatbox-send/chatbox-send';
import { NewgroupPage, SuccessPop } from '../pages/newgroup/newgroup';
import { AndroidPermissions } from "@ionic-native/android-permissions";
import { ManageGroupPage } from '../pages/manage-group/manage-group';
import { AddPostPage } from '../pages/add-post/add-post';
import { InAppBrowser } from "@ionic-native/in-app-browser";
import { HelpPage } from '../pages/help/help';
import { LoginNewPage } from '../pages/login-new/login-new';
import { CnfrmPage } from '../pages/cnfrm/cnfrm';
import { Deeplinks } from '@ionic-native/deeplinks';
import {
  Contacts
} from "@ionic-native/contacts";







@NgModule({
  declarations: [
    MyApp,
    HomePage,
    RegisterPage,
    ForgetpasswordPage,
    ProfilePage,
    ProfileinfoPage,
    AddproductPage,
    InvitefriendsPage,
    MessageboxPage,
    SearchPage,
    SuccessPop,
    EditGroupPop,
    EditgroupPage,
    GroupmembersPage,
    SelectgroupPage,
    RequestSuccessPop,
    ManageprofilePage,
    SettingsPage,
    NewgroupPage,
    ChangeLocationPage,
    ChangeemailPage,
    ProfilepicturePage,
    ChooseImagePop,
    ResetpasswordPage,
    GroupinvitereqPage,
    FeedbackPage,
    MylistingPage,
    LoginPage,
    NotificationPage,
    LoginNewPage,
    //RequestModal,
    //ViewModal,
    SubcategoryPage,
    GroupinfoPage,
    MapModelProfile,
    UnblockmembersPage,
    ReminderPage,
    ProductviewPage,
    ReportAbusePop,
    ChangeLocationPage,
    TncPage,
    EditmylistingPage,
    AddcontactlistPage,
    AddCategoryPop,
    UsefulcontactsPage,
    GetusercontactdetailsPage,
    ChatboxReceivePage,
    ChatboxSendPage,
    sendRatingPopup,
    senderReminderPopup,
    FeedbackPop,
    ImagePopup,
    RatingPopup,
    ReminderPopup,
    GrouplistPop,
    GrouplistModel,
    ManageGroupPage,
    AddPostPage,
    HelpPage,
    CnfrmPage,
  ],
  imports: [
    IonicStorageModule.forRoot({
      name: "neighbourbasedb",
      driverOrder: ["sqlite", "indexeddb", "websql"],
    }),
    BrowserModule,
    HttpClientModule,
    CalendarModule,
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    RegisterPage,
    ProfileinfoPage,
    ForgetpasswordPage,
    ProfilePage,
    AddproductPage,
    InvitefriendsPage,
    MessageboxPage,
    SearchPage,
    SelectgroupPage,
    RequestSuccessPop,
    ManageprofilePage,
    SettingsPage,
    SuccessPop,
    EditGroupPop,
    EditgroupPage,
    NewgroupPage,
    ChangeLocationPage,
    ChangeemailPage,
    ProfilepicturePage,
    ChooseImagePop,
    ResetpasswordPage,
    GroupinvitereqPage,
    FeedbackPage,
    MylistingPage,
    LoginPage,
    LoginNewPage,
    NotificationPage,
    // RequestModal,
    // ViewModal,
    SubcategoryPage,
    GroupinfoPage,
    MapModelProfile,
    UnblockmembersPage,
    ReminderPage,
    ProductviewPage,
    ReportAbusePop,
    ChangeLocationPage,
    TncPage,
    EditmylistingPage,
    AddcontactlistPage,
    AddCategoryPop,
    UsefulcontactsPage,
    GetusercontactdetailsPage,
    FeedbackPop,
    ImagePopup,
    ChatboxReceivePage,
    RatingPopup,
    ReminderPopup,
    ChatboxSendPage,
    sendRatingPopup,
    senderReminderPopup,
    GroupmembersPage,
    GrouplistPop,
    GrouplistModel,
    ManageGroupPage,
    AddPostPage,
    HelpPage,
    CnfrmPage,
  ],
  providers: [
    StatusBar,
    DatePipe,
    Camera,
    SplashScreen,
    RestProvider,
    ImageProcess,
    PushNotification,
    FileOpener,
    StreamingMedia,
    { provide: ErrorHandler, useClass: IonicErrorHandler },
    PhotoViewer,
    Media,
    YoutubeVideoPlayer,
    Geolocation,
    AndroidPermissions,
    InAppBrowser,
    Deeplinks,
    Contacts,
   
  ],
})
export class AppModule {}
