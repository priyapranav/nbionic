package info.com.neighbourbase.service;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Random;

import info.com.neighbourbase.R;
import info.com.neighbourbase.activity.DashBoardPage;
import info.com.neighbourbase.activity.HomeScreen;
import info.com.neighbourbase.activity.NotificationMessage;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.DBHelper;
import info.com.neighbourbase.utility.NotificationUtils;
import info.com.neighbourbase.utility.PushMessageListener;

/**
 * Created by user on 21-07-2017.
 */

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = MyFirebaseMessagingService.class.getSimpleName();

    private NotificationUtils notificationUtils;
    SharedPreferences pref;
    private static PushMessageListener mMsgListener;
    String message ="", title="";




    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Log.e(TAG, "From: " + remoteMessage.getData());
        pref = PreferenceManager.getDefaultSharedPreferences(this);


        if (remoteMessage == null)
            return;

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            Log.e(TAG, "Notification Body: " + remoteMessage.getNotification().getBody());
            Log.e(TAG, "Notification title: " + remoteMessage.getNotification().getTitle());

            message = remoteMessage.getNotification().getBody();
            title = remoteMessage.getNotification().getTitle();

            //handleNotification(remoteMessage.getNotification().getBody());
        }

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.e(TAG, "Data Payload: " + remoteMessage.getData().toString());

            try {
                //JSONObject json = new JSONObject(remoteMessage.getData().toString());
                JSONObject json = new JSONObject(String.valueOf(remoteMessage.getData()));
                Integer inviteFlag = json.getInt("inviteFlag");
                if(inviteFlag==0) {
                    Constant.newMessageCount = Constant.newMessageCount + 1;
                    SharedPreferences.Editor se = pref.edit();
                    se.putInt("pushCount", Constant.newMessageCount);
                    se.commit();

                    if (mMsgListener != null) {
                        mMsgListener.pushMessageReceived(Constant.newMessageCount);
                    }
                }
                handleDataMessage(json);
            } catch (Exception e) {
                Log.e(TAG, "Exception: " + e.getMessage());
            }
        }


    }

    private void handleNotification(String message) {
        if (!NotificationUtils.isAppIsInBackground(getApplicationContext())) {
            // app is in foreground, broadcast the push message
            Intent pushNotification = new Intent(Constant.PUSH_NOTIFICATION);
            pushNotification.putExtra("message", message);
            LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);

            // play notification sound
            NotificationUtils notificationUtils = new NotificationUtils(getApplicationContext());
            notificationUtils.playNotificationSound();
        }else{
            // If the app is in background, firebase itself handles the notification

            /*Intent intent = new Intent(this, NotificationMessage.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("neighbourbase")
                    .setContentText(message)
                    .setAutoCancel(true)
                    .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            Random random = new Random();
            int m = random.nextInt(9999 - 1000) + 1000;
            notificationManager.notify(m, notificationBuilder.build());*/
        }
    }

    private void handleDataMessage(JSONObject json) {
        Log.e(TAG, "push json: " + json.toString());

        try {
            //JSONObject data = json.getJSONObject("data");

            Integer memberId = json.getInt("memberId");
            //String message = json.getString("body");
            String timestamp = json.getString("time");
            title = "neighbourbase";

           /* boolean isBackground = data.getBoolean("is_background");
            String imageUrl = data.getString("image");
            String timestamp = data.getString("timestamp");
            JSONObject payload = data.getJSONObject("payload");
            */
           Integer inviteFlag = json.getInt("inviteFlag");
           if(inviteFlag==0) {
               //message = json.getString("message");
               message = "You have received a new message, check your message box, if you have not seen.";
               DBHelper dbHelper = new DBHelper(getApplicationContext());
               boolean insert = dbHelper.insertMessage(memberId, message, timestamp);
           }else if(inviteFlag==1)
               message = "Someone invited you, check dashboard";

            if (!NotificationUtils.isAppIsInBackground(getApplicationContext())) {
                // app is in foreground, broadcast the push message
                Intent pushNotification = new Intent(Constant.PUSH_NOTIFICATION);
                pushNotification.putExtra("message", message);
                LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);

                // play notification sound
                NotificationUtils notificationUtils = new NotificationUtils(getApplicationContext());
                notificationUtils.playNotificationSound();
                if(inviteFlag==0) {
                    Intent resultIntent = new Intent(getApplicationContext(), NotificationMessage.class);
                    resultIntent.putExtra("message", message);
                    showNotificationMessage(getApplicationContext(), title, message, timestamp, resultIntent);
                }else if(inviteFlag==1){
                    Intent resultIntent = new Intent(getApplicationContext(), DashBoardPage.class);
                    resultIntent.putExtra("message", message);
                    showNotificationMessage(getApplicationContext(), title, message, timestamp, resultIntent);
                }
            } else {
                // app is in background, show the notification in notification tray
                if(inviteFlag==0) {
                    Intent resultIntent = new Intent(getApplicationContext(), NotificationMessage.class);
                    resultIntent.putExtra("message", message);
                    showNotificationMessage(getApplicationContext(), title, message, timestamp, resultIntent);
                }else if(inviteFlag==1){
                    Intent resultIntent = new Intent(getApplicationContext(), DashBoardPage.class);
                    resultIntent.putExtra("message", message);
                    showNotificationMessage(getApplicationContext(), title, message, timestamp, resultIntent);
                }

                // check for image attachment
                /*if (TextUtils.isEmpty(imageUrl)) {
                    showNotificationMessage(getApplicationContext(), title, message, timestamp, resultIntent);
                } else {
                    // image is present, show notification with image
                    showNotificationMessageWithBigImage(getApplicationContext(), title, message, timestamp, resultIntent, imageUrl);
                }*/
            }

        } catch (JSONException e) {
            Log.e(TAG, "Json Exception: " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "Exception: " + e.getMessage());
        }
    }

    /**
     * Showing notification with text only
     */
    private void showNotificationMessage(Context context, String title, String message, String timeStamp, Intent intent) {
        notificationUtils = new NotificationUtils(context);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        notificationUtils.showNotificationMessage(title, message, timeStamp, intent);
    }

    /**
     * Showing notification with text and image
     */
    private void showNotificationMessageWithBigImage(Context context, String title, String message, String timeStamp, Intent intent, String imageUrl) {
        notificationUtils = new NotificationUtils(context);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        notificationUtils.showNotificationMessage(title, message, timeStamp, intent, imageUrl);
    }

    public static void bindListener(PushMessageListener listener) {
        mMsgListener = listener;
    }
}
