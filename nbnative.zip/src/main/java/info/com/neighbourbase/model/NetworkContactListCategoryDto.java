package info.com.neighbourbase.model;

import java.util.Date;

public class NetworkContactListCategoryDto {

	private long contactsCategoryId;
	private String categoryName;
	private Long date;
	private int isActive;
	private int isDelete;
	private long networkId;

	public long getContactsCategoryId() {
		return contactsCategoryId;
	}

	public void setContactsCategoryId(long contactsCategoryId) {
		this.contactsCategoryId = contactsCategoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public Long getDate() {
		return date;
	}

	public void setDate(Long date) {
		this.date = date;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public int getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(int isDelete) {
		this.isDelete = isDelete;
	}

	public long getNetworkId() {
		return networkId;
	}

	public void setNetworkId(long networkId) {
		this.networkId = networkId;
	}

}
