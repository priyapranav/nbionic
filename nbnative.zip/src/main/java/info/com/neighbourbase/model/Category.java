package info.com.neighbourbase.model;

import java.util.Date;


public class Category {


	private long categoryId;

	private Long parentId;

	private String categoryName;

	private Date createdDateTime;

	private Date updatedDateTime;

	private String updatedBy;

	private String updateReason;

	private int isDeleted;

	private int isActive;

	public long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Date getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Date updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdateReason() {
		return updateReason;
	}

	public void setUpdateReason(String updateReason) {
		this.updateReason = updateReason;
	}

	public int getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(int isDeleted) {
		this.isDeleted = isDeleted;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	/*
	 * public List<ProductListing> getProductListings() { return
	 * productListings; }
	 * 
	 * public void setProductListings(List<ProductListing> productListings) {
	 * this.productListings = productListings; }
	 */

	
	/*
	 * @OneToMany(mappedBy = "category") private List<ProductListing>
	 * productListings;
	 */

}
