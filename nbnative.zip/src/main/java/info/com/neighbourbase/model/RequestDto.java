package info.com.neighbourbase.model;

import java.util.Date;
import java.util.List;

/**
 * Created by user on 05-06-2017.
 */

public class RequestDto {

    private long requestId;
    private long requestStatusId;
    private String requestStatus;
    private long createdDateTime;
    private int isDeleted;
    private int isActive;
    private int isClosed;
    private String clostureRemarks;
    private long closedDateTime;
    private long memberId;
    private long productId;
    private String ownerEmailId;
    private String requesterEmailId;
    private String productName;
    private List<NotificationThread> notificationMessage;
    private String firstReqstMsg;
    private String createdDateTimeStr;
    private String closedDateTimeStr;
    private String requesterName;
    private String requesterFirstName;
    private String ownerName;
    private int blockedFlag;
    private int isRead;
    private String requesterImage;
    private long ownerMemberId;
    private String ownerImage;
    private long networkId;
    private String networkName;
    private int transTypeId;
    private int permanentDelete;
    private ReceiverFeedback receiverFeedback;
    private IssuerFeedback issuerFeedback;
    private String productImage;
    private String ownerFirstName;
    private int totalRequestPage;
    private int ownerForceClose;
    private int receiverForceClose;
    private String transName;
    private String area;
    private List<NotificationThreadDto> notificationThreadDto;

    public long getRequestId() {
        return requestId;
    }

    public void setRequestId(long requestId) {
        this.requestId = requestId;
    }

    public long getRequestStatusId() {
        return requestStatusId;
    }

    public void setRequestStatusId(long requestStatusId) {
        this.requestStatusId = requestStatusId;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public long getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(long createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public int getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    public int getIsClosed() {
        return isClosed;
    }

    public void setIsClosed(int isClosed) {
        this.isClosed = isClosed;
    }

    public String getClostureRemarks() {
        return clostureRemarks;
    }

    public void setClostureRemarks(String clostureRemarks) {
        this.clostureRemarks = clostureRemarks;
    }


    public void setClosedDateTime(long closedDateTime) {
        this.closedDateTime = closedDateTime;
    }

    public long getMemberId() {
        return memberId;
    }

    public void setMemberId(long memberId) {
        this.memberId = memberId;
    }

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public String getOwnerEmailId() {
        return ownerEmailId;
    }

    public void setOwnerEmailId(String ownerEmailId) {
        this.ownerEmailId = ownerEmailId;
    }

    public String getRequesterEmailId() {
        return requesterEmailId;
    }

    public void setRequesterEmailId(String requesterEmailId) {
        this.requesterEmailId = requesterEmailId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public List<NotificationThread> getNotificationMessage() {
        return notificationMessage;
    }

    public void setNotificationMessage(List<NotificationThread> notificationMessage) {
        this.notificationMessage = notificationMessage;
    }

    public String getFirstReqstMsg() {
        return firstReqstMsg;
    }

    public void setFirstReqstMsg(String firstReqstMsg) {
        this.firstReqstMsg = firstReqstMsg;
    }

    public String getCreatedDateTimeStr() {
        return createdDateTimeStr;
    }

    public void setCreatedDateTimeStr(String createdDateTimeStr) {
        this.createdDateTimeStr = createdDateTimeStr;
    }

    public String getClosedDateTimeStr() {
        return closedDateTimeStr;
    }

    public void setClosedDateTimeStr(String closedDateTimeStr) {
        this.closedDateTimeStr = closedDateTimeStr;
    }

    public String getRequesterName() {
        return requesterName;
    }

    public void setRequesterName(String requesterName) {
        this.requesterName = requesterName;
    }

    public String getRequesterFirstName() {
        return requesterFirstName;
    }

    public void setRequesterFirstName(String requesterFirstName) {
        this.requesterFirstName = requesterFirstName;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public int getBlockedFlag() {
        return blockedFlag;
    }

    public void setBlockedFlag(int blockedFlag) {
        this.blockedFlag = blockedFlag;
    }

    public int getIsRead() {
        return isRead;
    }

    public void setIsRead(int isRead) {
        this.isRead = isRead;
    }

    public String getRequesterImage() {
        return requesterImage;
    }

    public void setRequesterImage(String requesterImage) {
        this.requesterImage = requesterImage;
    }

    public long getOwnerMemberId() {
        return ownerMemberId;
    }

    public void setOwnerMemberId(long ownerMemberId) {
        this.ownerMemberId = ownerMemberId;
    }

    public String getOwnerImage() {
        return ownerImage;
    }

    public void setOwnerImage(String ownerImage) {
        this.ownerImage = ownerImage;
    }

    public long getNetworkId() {
        return networkId;
    }

    public void setNetworkId(long networkId) {
        this.networkId = networkId;
    }

    public String getNetworkName() {
        return networkName;
    }

    public void setNetworkName(String networkName) {
        this.networkName = networkName;
    }

    public int getTransTypeId() {
        return transTypeId;
    }

    public void setTransTypeId(int transTypeId) {
        this.transTypeId = transTypeId;
    }

    public int getPermanentDelete() {
        return permanentDelete;
    }

    public void setPermanentDelete(int permanentDelete) {
        this.permanentDelete = permanentDelete;
    }

    public ReceiverFeedback getReceiverFeedback() {
        return receiverFeedback;
    }

    public void setReceiverFeedback(ReceiverFeedback receiverFeedback) {
        this.receiverFeedback = receiverFeedback;
    }

    public IssuerFeedback getIssuerFeedback() {
        return issuerFeedback;
    }

    public void setIssuerFeedback(IssuerFeedback issuerFeedback) {
        this.issuerFeedback = issuerFeedback;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getOwnerFirstName() {
        return ownerFirstName;
    }

    public void setOwnerFirstName(String ownerFirstName) {
        this.ownerFirstName = ownerFirstName;
    }

    public int getTotalRequestPage() {
        return totalRequestPage;
    }

    public void setTotalRequestPage(int totalRequestPage) {
        this.totalRequestPage = totalRequestPage;
    }

    public int getOwnerForceClose() {
        return ownerForceClose;
    }

    public void setOwnerForceClose(int ownerForceClose) {
        this.ownerForceClose = ownerForceClose;
    }

    public int getReceiverForceClose() {
        return receiverForceClose;
    }

    public void setReceiverForceClose(int receiverForceClose) {
        this.receiverForceClose = receiverForceClose;
    }

    public String getTransName() {
        return transName;
    }

    public void setTransName(String transName) {
        this.transName = transName;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public long getClosedDateTime() {
        return closedDateTime;
    }

    public List<NotificationThreadDto> getNotificationThreadDto() {
        return notificationThreadDto;
    }

    public void setNotificationThreadDto(List<NotificationThreadDto> notificationThreadDto) {
        this.notificationThreadDto = notificationThreadDto;
    }
}
