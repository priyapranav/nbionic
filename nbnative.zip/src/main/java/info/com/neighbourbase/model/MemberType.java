package info.com.neighbourbase.model;



public class MemberType {

	private int typeId;

	private String typeName;

	/*
	 * @OneToMany(fetch = FetchType.EAGER, mappedBy = "memberType", cascade =
	 * CascadeType.ALL) private List<Member> members;
	 */

	public int getTypeId() {
		return typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	/*
	 * public List<Member> getMembers() { return members; }
	 * 
	 * public void setMembers(List<Member> members) { this.members = members; }
	 */
}
