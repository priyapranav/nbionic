package info.com.neighbourbase.model;

public class IssuerFeedbackDto {
	private long issuerFeedbackId;
	private int receiverRating;
	private int productConditionRating;
	private long requestId;
	private String remarks;
	private long reviwerMemberId;
	private String reviewerEmailId;
	private long borrowerMemberId;
	private String borrowerEmailId;
	private String reviewerName;
	private String reviewerPic;
	private String productName;
	private String transTypeName;
	private long productId;

	public long getIssuerFeedbackId() {
		return issuerFeedbackId;
	}

	public void setIssuerFeedbackId(long issuerFeedbackId) {
		this.issuerFeedbackId = issuerFeedbackId;
	}

	public int getReceiverRating() {
		return receiverRating;
	}

	public void setReceiverRating(int receiverRating) {
		this.receiverRating = receiverRating;
	}

	public int getProductConditionRating() {
		return productConditionRating;
	}

	public void setProductConditionRating(int productConditionRating) {
		this.productConditionRating = productConditionRating;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public long getReviwerMemberId() {
		return reviwerMemberId;
	}

	public void setReviwerMemberId(long reviwerMemberId) {
		this.reviwerMemberId = reviwerMemberId;
	}

	public String getReviewerEmailId() {
		return reviewerEmailId;
	}

	public void setReviewerEmailId(String reviewerEmailId) {
		this.reviewerEmailId = reviewerEmailId;
	}

	public long getBorrowerMemberId() {
		return borrowerMemberId;
	}

	public void setBorrowerMemberId(long borrowerMemberId) {
		this.borrowerMemberId = borrowerMemberId;
	}

	public String getBorrowerEmailId() {
		return borrowerEmailId;
	}

	public void setBorrowerEmailId(String borrowerEmailId) {
		this.borrowerEmailId = borrowerEmailId;
	}

	public String getReviewerName() {
		return reviewerName;
	}

	public void setReviewerName(String reviewerName) {
		this.reviewerName = reviewerName;
	}

	public String getReviewerPic() {
		return reviewerPic;
	}

	public void setReviewerPic(String reviewerPic) {
		this.reviewerPic = reviewerPic;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getTransTypeName() {
		return transTypeName;
	}

	public void setTransTypeName(String transTypeName) {
		this.transTypeName = transTypeName;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

}
