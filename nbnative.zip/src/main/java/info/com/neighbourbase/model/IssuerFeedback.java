package info.com.neighbourbase.model;

/**
 * Created by user on 05-06-2017.
 */

public class IssuerFeedback {

    private Long issuerFeedbackId;
    private int receiverRating;
    private int productConditionRating;
    //private Request request;
    private String remarks;

    public Long getIssuerFeedbackId() {
        return issuerFeedbackId;
    }

    public void setIssuerFeedbackId(Long issuerFeedbackId) {
        this.issuerFeedbackId = issuerFeedbackId;
    }

    public int getReceiverRating() {
        return receiverRating;
    }

    public void setReceiverRating(int receiverRating) {
        this.receiverRating = receiverRating;
    }

    public int getProductConditionRating() {
        return productConditionRating;
    }

    public void setProductConditionRating(int productConditionRating) {
        this.productConditionRating = productConditionRating;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
