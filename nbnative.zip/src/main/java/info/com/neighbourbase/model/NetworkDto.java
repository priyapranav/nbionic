package info.com.neighbourbase.model;


public class NetworkDto {
	private long networkId;
	private String name;
	private String dateTime;
	private long memberId;
	private String addressline1;
	private String addressline2;
	private String city;
	private long contactNumber;
	private long landlineNumber;
	private String contactEmail;
	private int approvalFlag;
	private String acceptDescription;
	private String rejectDescription;
	private String pendingDescription;
	private long licenseId;
	private String status;
	private int pincode;
	private String networkDetails;
	private String allowSecondaryMember;
	private int secondaryMemberCount;
	private String picture;
	private int memberFlag; // 1 - primary member , 2 - secondary member , 3 -
							// moderator
	private String area;
	private String createdDateTimeStr;
	private int primaryFlag; // if memberFlag is 3, primaryFlag can be either
								// 1(primary mod) or 2(secondary mod); else
								// memberFlag will be 0(member)
	private long networkTypeId;
	private String networkTypeName;
	private String location;
	private double latitude;
	private double longitude;
	private int user;
	private float payment;

	
	private byte[] networkImage;
	
	
	


	public byte[] getNetworkImage() {
		return networkImage;
	}

	public void setNetworkImage(byte[] networkImage) {
		this.networkImage = networkImage;
	}

	public String getAllowSecondaryMember() {
		return allowSecondaryMember;
	}

	public void setAllowSecondaryMember(String allowSecondaryMember) {
		this.allowSecondaryMember = allowSecondaryMember;
	}

	public int getSecondaryMemberCount() {
		return secondaryMemberCount;
	}

	public void setSecondaryMemberCount(int secondaryMemberCount) {
		this.secondaryMemberCount = secondaryMemberCount;
	}

	public long getNetworkId() {
		return networkId;
	}

	public void setNetworkId(long networkId) {
		this.networkId = networkId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public long getMemberId() {
		return memberId;
	}

	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public long getLicenseId() {
		return licenseId;
	}

	public void setLicenseId(long licenseId) {
		this.licenseId = licenseId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public int getApprovalFlag() {
		return approvalFlag;
	}

	public void setApprovalFlag(int approvalFlag) {
		this.approvalFlag = approvalFlag;
	}

	public String getAcceptDescription() {
		return acceptDescription;
	}

	public void setAcceptDescription(String acceptDescription) {
		this.acceptDescription = acceptDescription;
	}

	public String getRejectDescription() {
		return rejectDescription;
	}

	public void setRejectDescription(String rejectDescription) {
		this.rejectDescription = rejectDescription;
	}

	public String getNetworkDetails() {
		return networkDetails;
	}

	public void setNetworkDetails(String networkDetails) {
		this.networkDetails = networkDetails;
	}

	public String getAddressline1() {
		return addressline1;
	}

	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}

	public String getAddressline2() {
		return addressline2;
	}

	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public int getMemberFlag() {
		return memberFlag;
	}

	public void setMemberFlag(int memberFlag) {
		this.memberFlag = memberFlag;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getCreatedDateTimeStr() {
		return createdDateTimeStr;
	}

	public void setCreatedDateTimeStr(String createdDateTimeStr) {
		this.createdDateTimeStr = createdDateTimeStr;
	}

	public int getPrimaryFlag() {
		return primaryFlag;
	}

	public void setPrimaryFlag(int primaryFlag) {
		this.primaryFlag = primaryFlag;
	}

	public long getNetworkTypeId() {
		return networkTypeId;
	}

	public void setNetworkTypeId(long networkTypeId) {
		this.networkTypeId = networkTypeId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getNetworkTypeName() {
		return networkTypeName;
	}

	public void setNetworkTypeName(String networkTypeName) {
		this.networkTypeName = networkTypeName;
	}

	public int getUser() {
		return user;
	}

	public void setUser(int user) {
		this.user = user;
	}

	public float getPayment() {
		return payment;
	}

	public void setPayment(float payment) {
		this.payment = payment;
	}

	public String getPendingDescription() {
		return pendingDescription;
	}

	public void setPendingDescription(String pendingDescription) {
		this.pendingDescription = pendingDescription;
	}

	public long getLandlineNumber() {
		return landlineNumber;
	}

	public void setLandlineNumber(long landlineNumber) {
		this.landlineNumber = landlineNumber;
	}

}
