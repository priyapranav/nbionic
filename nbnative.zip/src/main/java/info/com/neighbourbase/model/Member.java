package info.com.neighbourbase.model;

import java.util.Date;
import java.util.List;

public class Member {

	private long memberId;

	private String firstName;

	private String lastName;

	private String email;

	private String password;

	private String address;

	private String pincode;

	private String area;

	private Long createdDateTime;

	private Long updatedDateTime;

	private String updatedBy;
	private int updateReason;

	private int isDeleted;

	private int isActive;

	private long contactNumber;

	private Status status;

	private MemberType memberType;

	private String aboutMe;

	private String picture;

	private List<NetworkMember> networkMembers;

	private List<NetworkModerator> networkModerators;

	private String accessToken;

	private double latitude;
	

	private double longitude;
	/*
	 * @OneToMany(mappedBy = "member", cascade = CascadeType.ALL) private
	 * List<Request> requests;
	 */

	/*
	 * @OneToMany(mappedBy = "member", cascade = CascadeType.ALL) private
	 * List<NotificationThread> notificationThreads;
	 */


	private List<ProductListing> productListings;


	private int mailVerifyFlag;

	private double searchRadius;

	private String  deviceToken;

	public String getFirstName() {
		return firstName;
	}

	public long getMemberId() {
		return memberId;
	}

	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Long createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Long getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Long updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public int getUpdateReason() {
		return updateReason;
	}

	public void setUpdateReason(int updateReason) {
		this.updateReason = updateReason;
	}

	public int getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(int isDeleted) {
		this.isDeleted = isDeleted;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}


	public List<NetworkMember> getNetworkMembers() {
		return networkMembers;
	}

	public void setNetworkMembers(List<NetworkMember> networkMembers) {
		this.networkMembers = networkMembers;
	}


	public List<NetworkModerator> getNetworkModerators() {
		return networkModerators;
	}

	public void setNetworkModerators(List<NetworkModerator> networkModerators) {
		this.networkModerators = networkModerators;
	}

	/*
	 * public List<Request> getRequests() { return requests; }
	 * 
	 * public void setRequests(List<Request> requests) { this.requests =
	 * requests; }
	 */

	/*
	 * public List<NotificationThread> getNotificationThreads() { return
	 * notificationThreads; }
	 * 
	 * public void setNotificationThreads( List<NotificationThread>
	 * notificationThreads) { this.notificationThreads = notificationThreads; }
	 */

	public MemberType getMemberType() {
		return memberType;
	}

	public void setMemberType(MemberType memberType) {
		this.memberType = memberType;
	}

	public String getAboutMe() {
		return aboutMe;
	}

	public void setAboutMe(String aboutMe) {
		this.aboutMe = aboutMe;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public int getMailVerifyFlag() {
		return mailVerifyFlag;
	}

	public void setMailVerifyFlag(int mailVerifyFlag) {
		this.mailVerifyFlag = mailVerifyFlag;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getSearchRadius() {
		return searchRadius;
	}

	public void setSearchRadius(double searchRadius) {
		this.searchRadius = searchRadius;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	
	/*
	 * public List<ProductListing> getProductListings() { return
	 * productListings; }
	 * 
	 * public void setProductListings(List<ProductListing> productListings) {
	 * this.productListings = productListings; }
	 */

}
