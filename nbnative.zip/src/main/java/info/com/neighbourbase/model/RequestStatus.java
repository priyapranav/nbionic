package info.com.neighbourbase.model;

/**
 * Created by user on 05-06-2017.
 */

public class RequestStatus {
    private long requestStatusId;

    private String name;

    public long getRequestStatusId() {
        return requestStatusId;
    }

    public void setRequestStatusId(long requestStatusId) {
        this.requestStatusId = requestStatusId;
    }
}
