package info.com.neighbourbase.model;

/**
 * Created by user on 05-06-2017.
 */

public class ReceiverFeedback {

    private long receiverFeedbackId;
    private int issuerRating;
    private int productRating;
    //private Request request;
    private String issuerRemarks;
    private String productRemarks;

    public long getReceiverFeedbackId() {
        return receiverFeedbackId;
    }

    public void setReceiverFeedbackId(long receiverFeedbackId) {
        this.receiverFeedbackId = receiverFeedbackId;
    }

    public int getIssuerRating() {
        return issuerRating;
    }

    public void setIssuerRating(int issuerRating) {
        this.issuerRating = issuerRating;
    }

    public int getProductRating() {
        return productRating;
    }

    public void setProductRating(int productRating) {
        this.productRating = productRating;
    }

    public String getIssuerRemarks() {
        return issuerRemarks;
    }

    public void setIssuerRemarks(String issuerRemarks) {
        this.issuerRemarks = issuerRemarks;
    }

    public String getProductRemarks() {
        return productRemarks;
    }

    public void setProductRemarks(String productRemarks) {
        this.productRemarks = productRemarks;
    }
}
