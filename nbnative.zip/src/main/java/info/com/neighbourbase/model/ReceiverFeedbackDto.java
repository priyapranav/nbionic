package info.com.neighbourbase.model;

public class ReceiverFeedbackDto {
	private long receiverFeedbackId;
	private int issuerRating;
	private int productRating;
	private long requestId;
	private String productRemarks;
	private String issuerRemarks;
	private long feedbackOwnerId;
	private long productId;
	private String feebbackOwnerPicture;
	private String feedbackOwnerName;
	private String productName;
	private String transTypeName;

	public long getReceiverFeedbackId() {
		return receiverFeedbackId;
	}

	public void setReceiverFeedbackId(long receiverFeedbackId) {
		this.receiverFeedbackId = receiverFeedbackId;
	}

	public int getIssuerRating() {
		return issuerRating;
	}

	public void setIssuerRating(int issuerRating) {
		this.issuerRating = issuerRating;
	}

	public int getProductRating() {
		return productRating;
	}

	public void setProductRating(int productRating) {
		this.productRating = productRating;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getProductRemarks() {
		return productRemarks;
	}

	public void setProductRemarks(String productRemarks) {
		this.productRemarks = productRemarks;
	}

	public String getIssuerRemarks() {
		return issuerRemarks;
	}

	public void setIssuerRemarks(String issuerRemarks) {
		this.issuerRemarks = issuerRemarks;
	}

	public long getFeedbackOwnerId() {
		return feedbackOwnerId;
	}

	public void setFeedbackOwnerId(long feedbackOwnerId) {
		this.feedbackOwnerId = feedbackOwnerId;
	}

	public String getFeebbackOwnerPicture() {
		return feebbackOwnerPicture;
	}

	public void setFeebbackOwnerPicture(String feebbackOwnerPicture) {
		this.feebbackOwnerPicture = feebbackOwnerPicture;
	}

	public String getFeedbackOwnerName() {
		return feedbackOwnerName;
	}

	public void setFeedbackOwnerName(String feedbackOwnerName) {
		this.feedbackOwnerName = feedbackOwnerName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getTransTypeName() {
		return transTypeName;
	}

	public void setTransTypeName(String transTypeName) {
		this.transTypeName = transTypeName;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

}
