package info.com.neighbourbase.model;

import java.util.Date;

/**
 * Created by user on 05-06-2017.
 */

public class NotificationThread {

    private long notificationId;
    private long dateTime;
    private String message;
    //private Member member;
    private RequestStatus requestStatus;
    //private Request request;
    private int isOwnerMessage;
    private int blockedFlag;
    private int isDelete;
    private int isReadOwnerFlag;
    private int isReadReceiverFlag;

    public long getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(long notificationId) {
        this.notificationId = notificationId;
    }

    public long getDateTime() {
        return dateTime;
    }

    public void setDateTime(long dateTime) {
        this.dateTime = dateTime;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public RequestStatus getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(RequestStatus requestStatus) {
        this.requestStatus = requestStatus;
    }

    public int getIsOwnerMessage() {
        return isOwnerMessage;
    }

    public void setIsOwnerMessage(int isOwnerMessage) {
        this.isOwnerMessage = isOwnerMessage;
    }

    public int getBlockedFlag() {
        return blockedFlag;
    }

    public void setBlockedFlag(int blockedFlag) {
        this.blockedFlag = blockedFlag;
    }

    public int getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }

    public int getIsReadOwnerFlag() {
        return isReadOwnerFlag;
    }

    public void setIsReadOwnerFlag(int isReadOwnerFlag) {
        this.isReadOwnerFlag = isReadOwnerFlag;
    }

    public int getIsReadReceiverFlag() {
        return isReadReceiverFlag;
    }

    public void setIsReadReceiverFlag(int isReadReceiverFlag) {
        this.isReadReceiverFlag = isReadReceiverFlag;
    }
}
