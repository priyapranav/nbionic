package info.com.neighbourbase.model;

public class BlockListDto {
	private long blockId;
	private long memberId;
	private long requestId;
	private String date;
	private long requestedMemberId;
	private int blockedFlag;
	private String requesterName;
	private String requesterImage;

	public long getBlockId() {
		return blockId;
	}

	public void setBlockId(long blockId) {
		this.blockId = blockId;
	}

	public long getMemberId() {
		return memberId;
	}

	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public long getRequestedMemberId() {
		return requestedMemberId;
	}

	public void setRequestedMemberId(long requestedMemberId) {
		this.requestedMemberId = requestedMemberId;
	}

	public int getBlockedFlag() {
		return blockedFlag;
	}

	public void setBlockedFlag(int blockedFlag) {
		this.blockedFlag = blockedFlag;
	}

	public String getRequesterName() {
		return requesterName;
	}

	public void setRequesterName(String requesterName) {
		this.requesterName = requesterName;
	}

	public String getRequesterImage() {
		return requesterImage;
	}

	public void setRequesterImage(String requesterImage) {
		this.requesterImage = requesterImage;
	}

}
