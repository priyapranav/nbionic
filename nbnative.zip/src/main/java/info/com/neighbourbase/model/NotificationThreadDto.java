package info.com.neighbourbase.model;

import java.util.Date;

/**
 * Created by user on 05-06-2017.
 */

public class NotificationThreadDto {

    private long notificationId;
    private long dateTime;
    private String message;
    private long requestStatusId;
    private long requestId;
    private long memberId;
    private int isOwnerMessage;
    private String createdDateTime;
    private int blockedFlag;
    private String requestStatus;
    private int isDelete;
    private int isReadOwnerFlag;
    private int isReadReceiverFlag;

    public long getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(long notificationId) {
        this.notificationId = notificationId;
    }

    public long getDateTime() {
        return dateTime;
    }

    public void setDateTime(long dateTime) {
        this.dateTime = dateTime;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getRequestStatusId() {
        return requestStatusId;
    }

    public void setRequestStatusId(long requestStatusId) {
        this.requestStatusId = requestStatusId;
    }

    public long getRequestId() {
        return requestId;
    }

    public void setRequestId(long requestId) {
        this.requestId = requestId;
    }

    public long getMemberId() {
        return memberId;
    }

    public void setMemberId(long memberId) {
        this.memberId = memberId;
    }

    public int getIsOwnerMessage() {
        return isOwnerMessage;
    }

    public void setIsOwnerMessage(int isOwnerMessage) {
        this.isOwnerMessage = isOwnerMessage;
    }

    public String getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(String createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public int getBlockedFlag() {
        return blockedFlag;
    }

    public void setBlockedFlag(int blockedFlag) {
        this.blockedFlag = blockedFlag;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public int getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }

    public int getIsReadOwnerFlag() {
        return isReadOwnerFlag;
    }

    public void setIsReadOwnerFlag(int isReadOwnerFlag) {
        this.isReadOwnerFlag = isReadOwnerFlag;
    }

    public int getIsReadReceiverFlag() {
        return isReadReceiverFlag;
    }

    public void setIsReadReceiverFlag(int isReadReceiverFlag) {
        this.isReadReceiverFlag = isReadReceiverFlag;
    }
}
