package info.com.neighbourbase.model;


public class ReceiverNoteDto {
	private long receiverNoteId;
	private long borrowedOn;
	private long toBeReturned;
	private long returnedOn;
	private long requestId;
	private String returnByStr;
	private String returnOnStr;
	private String sharedOnStr;
	private String productName;
	private String productOwner;

	public String getReturnByStr() {
		return returnByStr;
	}

	public void setReturnByStr(String returnByStr) {
		this.returnByStr = returnByStr;
	}

	public String getReturnOnStr() {
		return returnOnStr;
	}

	public void setReturnOnStr(String returnOnStr) {
		this.returnOnStr = returnOnStr;
	}

	public String getSharedOnStr() {
		return sharedOnStr;
	}

	public void setSharedOnStr(String sharedOnStr) {
		this.sharedOnStr = sharedOnStr;
	}

	public long getReceiverNoteId() {
		return receiverNoteId;
	}

	public void setReceiverNoteId(long receiverNoteId) {
		this.receiverNoteId = receiverNoteId;
	}

	public long getBorrowedOn() {
		return borrowedOn;
	}

	public void setBorrowedOn(long borrowedOn) {
		this.borrowedOn = borrowedOn;
	}

	public long getToBeReturned() {
		return toBeReturned;
	}

	public void setToBeReturned(long toBeReturned) {
		this.toBeReturned = toBeReturned;
	}

	public long getReturnedOn() {
		return returnedOn;
	}

	public void setReturnedOn(long returnedOn) {
		this.returnedOn = returnedOn;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductOwner() {
		return productOwner;
	}

	public void setProductOwner(String productOwner) {
		this.productOwner = productOwner;
	}
}
