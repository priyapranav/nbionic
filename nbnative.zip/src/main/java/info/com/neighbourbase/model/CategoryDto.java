package info.com.neighbourbase.model;

/**
 * Created by Priya on 15-05-2017.
 */

import java.util.List;

public class CategoryDto {
    private long categoryId;
    private Long parentId;
    private String categoryName;
    private int isActive;
    private int isDeleted;
    private boolean selected;
    private int category_level;
    private List<String> cat_level1;
    private List<String> cat_level2;

    public long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    public int getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public int getCategory_level() {
        return category_level;
    }

    public void setCategory_level(int category_level) {
        this.category_level = category_level;
    }

    public List<String> getCat_level1() {
        return cat_level1;
    }

    public void setCat_level1(List<String> cat_level1) {
        this.cat_level1 = cat_level1;
    }

    public List<String> getCat_level2() {
        return cat_level2;
    }

    public void setCat_level2(List<String> cat_level2) {
        this.cat_level2 = cat_level2;
    }

}
