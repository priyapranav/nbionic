package info.com.neighbourbase.model;

import java.util.List;

public class ProductListingDto {
    private long productId;
    private long memberId;
    private String productName;
    private long categoryId;
    private String categoryName;
    private float productValue;
    private String brand;
    private double salePrice;
    private double rentalPrice;
    private int duration;
    private String model;
    private int transTypeId;
    private String transTypeName;
    private int isDeleted;
    private int isActive;
    private String postingRemarks;
    private String picture;
    private byte[] productImage;
    private int statusId;
    private String statusName;
    private String productDescription;
    private long networkId;
    private String networkName;
    private String ownerName;
    private String ownerEmailId;
    private int pincode;
    private String area;
    private String createdDateTime;
    private int isPaused;
    private String dayfrom;
    private String dayto;
    private long priceperday;
    private long pricepermonth;
    private long priceperweek;
    private int totalPages;
    private List<Long> networkids;


    private long rootCategoryId;

    private List<Category> level1CategoryList;

    public byte[] getProductImage() {
        return productImage;
    }

    public void setProductImage(byte[] productImage) {
        this.productImage = productImage;
    }

    public String getOwnerEmailId() {
        return ownerEmailId;
    }

    public void setOwnerEmailId(String ownerEmailId) {
        this.ownerEmailId = ownerEmailId;
    }

    public int getPincode() {
        return pincode;
    }

    public void setPincode(int pincode) {
        this.pincode = pincode;
    }

    public long getProductId() {
        return productId;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public long getMemberId() {
        return memberId;
    }

    public void setMemberId(long memberId) {
        this.memberId = memberId;
    }

    public long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(long categoryId) {
        this.categoryId = categoryId;
    }

    public float getProductValue() {
        return productValue;
    }

    public void setProductValue(float productValue) {
        this.productValue = productValue;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getTransTypeId() {
        return transTypeId;
    }

    public void setTransTypeId(int transTypeId) {
        this.transTypeId = transTypeId;
    }

    public int getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    public String getPostingRemarks() {
        return postingRemarks;
    }

    public void setPostingRemarks(String postingRemarks) {
        this.postingRemarks = postingRemarks;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public int getStatusId() {
        return statusId;
    }

    public void setStatusId(int statusId) {
        this.statusId = statusId;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public long getNetworkId() {
        return networkId;
    }

    public void setNetworkId(long networkId) {
        this.networkId = networkId;
    }

    public double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(double salePrice) {
        this.salePrice = salePrice;
    }

    public double getRentalPrice() {
        return rentalPrice;
    }

    public void setRentalPrice(double rentalPrice) {
        this.rentalPrice = rentalPrice;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getTransTypeName() {
        return transTypeName;
    }

    public void setTransTypeName(String transTypeName) {
        this.transTypeName = transTypeName;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public String getNetworkName() {
        return networkName;
    }

    public void setNetworkName(String networkName) {
        this.networkName = networkName;
    }

    public String getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(String createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public int getIsPaused() {
        return isPaused;
    }

    public void setIsPaused(int isPaused) {
        this.isPaused = isPaused;
    }

    public String getDayfrom() {
        return dayfrom;
    }

    public void setDayfrom(String dayfrom) {
        this.dayfrom = dayfrom;
    }

    public String getDayto() {
        return dayto;
    }

    public void setDayto(String dayto) {
        this.dayto = dayto;
    }

    public long getPriceperday() {
        return priceperday;
    }

    public void setPriceperday(long priceperday) {
        this.priceperday = priceperday;
    }

    public long getPricepermonth() {
        return pricepermonth;
    }

    public void setPricepermonth(long pricepermonth) {
        this.pricepermonth = pricepermonth;
    }

    public long getPriceperweek() {
        return priceperweek;
    }

    public void setPriceperweek(long priceperweek) {
        this.priceperweek = priceperweek;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public List<Long> getNetworkids() {
        return networkids;
    }

    public void setNetworkids(List<Long> networkids) {
        this.networkids = networkids;
    }

    public long getRootCategoryId() {
        return rootCategoryId;
    }

    public void setRootCategoryId(long rootCategoryId) {
        this.rootCategoryId = rootCategoryId;
    }

    public List<Category> getLevel1CategoryList() {
        return level1CategoryList;
    }

    public void setLevel1CategoryList(List<Category> level1CategoryList) {
        this.level1CategoryList = level1CategoryList;
    }

    public static class ProductRatingDto {

        private float avgRating ;
        private int totalReviews1;
        private info.com.neighbourbase.model.ReceiverFeedbackDto receiverFeedbackDtos;
        private ProductListingDto productListingDto;
        public float getAvgRating() {
            return avgRating;
        }
        public void setAvgRating(float avgRating) {
            this.avgRating = avgRating;
        }
        public int getTotalReviews1() {
            return totalReviews1;
        }
        public void setTotalReviews1(int totalReviews1) {
            this.totalReviews1 = totalReviews1;
        }
        public info.com.neighbourbase.model.ReceiverFeedbackDto getReceiverFeedbackDtos() {
            return receiverFeedbackDtos;
        }
        public void setReceiverFeedbackDtos(info.com.neighbourbase.model.ReceiverFeedbackDto receiverFeedbackDtos) {
            this.receiverFeedbackDtos = receiverFeedbackDtos;
        }
        public ProductListingDto getProductListingDto() {
            return productListingDto;
        }
        public void setProductListingDto(ProductListingDto productListingDto) {
            this.productListingDto = productListingDto;
        }



    }
}

