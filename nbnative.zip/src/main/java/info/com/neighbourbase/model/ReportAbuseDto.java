package info.com.neighbourbase.model;

import java.util.Date;

public class ReportAbuseDto {

	private long abuseId;
	private long productId;
	private long reportingMemberId;
	private int status;
	private Date updatedDateTime;
	private String remarks;
	private String userRemarks;
	private String productName;
	private String reportingMemberName;
	private long networkId;
	private String updatedDateStr;
	private String productOwnerName;
	private String networkName;
	private Integer adminFlag;
	private long productOwnerId;
	private int transTypeId;

	public long getAbuseId() {
		return abuseId;
	}

	public void setAbuseId(long abuseId) {
		this.abuseId = abuseId;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public long getReportingMemberId() {
		return reportingMemberId;
	}

	public void setReportingMemberId(long reportingMemberId) {
		this.reportingMemberId = reportingMemberId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Date getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Date updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getReportingMemberName() {
		return reportingMemberName;
	}

	public void setReportingMemberName(String reportingMemberName) {
		this.reportingMemberName = reportingMemberName;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getUserRemarks() {
		return userRemarks;
	}

	public void setUserRemarks(String userRemarks) {
		this.userRemarks = userRemarks;
	}

	public long getNetworkId() {
		return networkId;
	}

	public void setNetworkId(long networkId) {
		this.networkId = networkId;
	}

	public String getUpdatedDateStr() {
		return updatedDateStr;
	}

	public void setUpdatedDateStr(String updatedDateStr) {
		this.updatedDateStr = updatedDateStr;
	}

	public String getProductOwnerName() {
		return productOwnerName;
	}

	public void setProductOwnerName(String productOwnerName) {
		this.productOwnerName = productOwnerName;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public Integer getAdminFlag() {
		return adminFlag;
	}

	public void setAdminFlag(Integer adminFlag) {
		this.adminFlag = adminFlag;
	}

	public int getTransTypeId() {
		return transTypeId;
	}

	public void setTransTypeId(int transTypeId) {
		this.transTypeId = transTypeId;
	}

	public long getProductOwnerId() {
		return productOwnerId;
	}

	public void setProductOwnerId(long productOwnerId) {
		this.productOwnerId = productOwnerId;
	}

}
