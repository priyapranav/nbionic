package info.com.neighbourbase.model;



public class InvitationDto {
	private long invitationId;
	private long memberId;
	private int statusId;
	private long networkId;
	private String emailId;
	private String location;
	private Long closedOn;
	private Long dateTime;
	private int inviteFlag;
	private String description;
	private Member member;
	private Status status;
	//	@JsonBackReference
//	private Network network;
	private String dateStr;

	private NetworkDto networkDto;

	public long getInvitationId() {
		return invitationId;
	}

	public void setInvitationId(long invitationId) {
		this.invitationId = invitationId;
	}

	public long getMemberId() {
		return memberId;
	}

	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}

	public int getStatusId() {
		return statusId;
	}

	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}

	public long getNetworkId() {
		return networkId;
	}

	public void setNetworkId(long networkId) {
		this.networkId = networkId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Long getClosedOn() {
		return closedOn;
	}

	public void setClosedOn(Long closedOn) {
		this.closedOn = closedOn;
	}

	public Long getDateTime() {
		return dateTime;
	}

	public void setDateTime(Long dateTime) {
		this.dateTime = dateTime;
	}

	public int getInviteFlag() {
		return inviteFlag;
	}

	public void setInviteFlag(int inviteFlag) {
		this.inviteFlag = inviteFlag;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

//	public Network getNetwork() {
//		return network;
//	}
//
//	public void setNetwork(Network network) {
//		this.network = network;
//	}

	public String getDateStr() {
		return dateStr;
	}

	public void setDateStr(String dateStr) {
		this.dateStr = dateStr;
	}

	public NetworkDto getNetworkDto() {
		return networkDto;
	}

	public void setNetworkDto(NetworkDto networkDto) {
		this.networkDto = networkDto;
	}
}
