package info.com.neighbourbase.model;




public class ProductDuration {

	private long durationId;

	private ProductListing productListing;

	private String dayFrom;

	private String dayTo;

	private long pricePreDay;

	private long pricePerMonth;

	private long pricePerWeek;

	public long getDurationId() {
		return durationId;
	}

	public void setDurationId(long durationId) {
		this.durationId = durationId;
	}

	public ProductListing getProductListing() {
		return productListing;
	}

	public void setProductListing(ProductListing productListing) {
		this.productListing = productListing;
	}

	public String getDayFrom() {
		return dayFrom;
	}

	public void setDayFrom(String dayFrom) {
		this.dayFrom = dayFrom;
	}

	public String getDayTo() {
		return dayTo;
	}

	public void setDayTo(String dayTo) {
		this.dayTo = dayTo;
	}

	public long getPricePreDay() {
		return pricePreDay;
	}

	public void setPricePreDay(long pricePreDay) {
		this.pricePreDay = pricePreDay;
	}

	public long getPricePerMonth() {
		return pricePerMonth;
	}

	public void setPricePerMonth(long pricePerMonth) {
		this.pricePerMonth = pricePerMonth;
	}

	public long getPricePerWeek() {
		return pricePerWeek;
	}

	public void setPricePerWeek(long pricePerWeek) {
		this.pricePerWeek = pricePerWeek;
	}

	

}
