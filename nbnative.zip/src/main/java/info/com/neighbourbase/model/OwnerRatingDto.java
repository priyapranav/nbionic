package info.com.neighbourbase.model;



public class OwnerRatingDto {

	private int totalReviews1;
	private float avgRating;
	private MemberDto memberDto;
	private ProductListingDto productListingDto;
	private ReceiverFeedbackDto receiverFeedBackDto;
	public int getTotalReviews1() {
		return totalReviews1;
	}
	public void setTotalReviews1(int totalReviews1) {
		this.totalReviews1 = totalReviews1;
	}
	public float getAvgRating() {
		return avgRating;
	}
	public void setAvgRating(float avgRating) {
		this.avgRating = avgRating;
	}
	public MemberDto getMemberDto() {
		return memberDto;
	}
	public void setMemberDto(MemberDto memberDto) {
		this.memberDto = memberDto;
	}
	public ProductListingDto getProductListingDto() {
		return productListingDto;
	}
	public void setProductListingDto(ProductListingDto productListingDto) {
		this.productListingDto = productListingDto;
	}
	public ReceiverFeedbackDto getReceiverFeedBackDto() {
		return receiverFeedBackDto;
	}
	public void setReceiverFeedBackDto(ReceiverFeedbackDto receiverFeedBackDto) {
		this.receiverFeedBackDto = receiverFeedBackDto;
	}
	
}
