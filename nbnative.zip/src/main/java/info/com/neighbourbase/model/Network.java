package info.com.neighbourbase.model;

import java.util.Date;
import java.util.List;


public class Network {

    private long networkId;
    private String name;
    private Date dateTime;
    private Member member;


    private String addressline1;


    private String addressline2;


    private String city;


    private long contactNumber;


    private long landlineNumber;

    private String contactEmail;

    private License license;

    private int approvalFlag;

    private String acceptDescription;

    private String rejectDescription;

    private String pendingDescription;

    private Date lastUpdatedDateTime;

    private String updatedBy;

    private String updateReason;

    private int isDeleted;

    private int isActive;

    private String status;

    private int pincode;

    private String networkDetails;

    private String allowSecondaryMember;

    private int secondaryMemberCount;

    private String area;

    private String location;

    private NetworkType networkType;

    private List<NetworkModerator> networkModerators;

    private List<NetworkMember> networkMembers;

    private List<ProductListing> productListings;

    private List<BulletinBoard> bulletinBoards;

    private String picture;

    private double latitude;

    private double longitude;

    public int getPincode() {
        return pincode;
    }

    public void setPincode(int pincode) {
        this.pincode = pincode;
    }

    public String getNetworkDetails() {
        return networkDetails;
    }

    public String getAddressline1() {
        return addressline1;
    }

    public void setAddressline1(String addressline1) {
        this.addressline1 = addressline1;
    }

    public String getAddressline2() {
        return addressline2;
    }

    public void setAddressline2(String addressline2) {
        this.addressline2 = addressline2;
    }

    public void setNetworkDetails(String networkDetails) {
        this.networkDetails = networkDetails;
    }

    public String getAllowSecondaryMember() {
        return allowSecondaryMember;
    }

    public void setAllowSecondaryMember(String allowSecondaryMember) {
        this.allowSecondaryMember = allowSecondaryMember;
    }

    public int getSecondaryMemberCount() {
        return secondaryMemberCount;
    }

    public void setSecondaryMemberCount(int secondaryMemberCount) {
        this.secondaryMemberCount = secondaryMemberCount;
    }

    public long getNetworkId() {
        return networkId;
    }

    public void setNetworkId(long networkId) {
        this.networkId = networkId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDateTime() {
        return dateTime;
    }

    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }

    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public long getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(long contactNumber) {
        this.contactNumber = contactNumber;
    }

    public long getLandlineNumber() {
        return landlineNumber;
    }

    public void setLandlineNumber(long landlineNumber) {
        this.landlineNumber = landlineNumber;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public License getLicense() {
        return license;
    }

    public void setLicense(License license) {
        this.license = license;
    }

    public int getApprovalFlag() {
        return approvalFlag;
    }

    public void setApprovalFlag(int approvalFlag) {
        this.approvalFlag = approvalFlag;
    }

    public String getAcceptDescription() {
        return acceptDescription;
    }

    public void setAcceptDescription(String acceptDescription) {
        this.acceptDescription = acceptDescription;
    }

    public String getRejectDescription() {
        return rejectDescription;
    }

    public void setRejectDescription(String rejectDescription) {
        this.rejectDescription = rejectDescription;
    }

    public String getPendingDescription() {
        return pendingDescription;
    }

    public void setPendingDescription(String pendingDescription) {
        this.pendingDescription = pendingDescription;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdateReason() {
        return updateReason;
    }

    public void setUpdateReason(String updateReason) {
        this.updateReason = updateReason;
    }

    public int getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<NetworkModerator> getNetworkModerators() {
        return networkModerators;
    }

    public void setNetworkModerators(List<NetworkModerator> networkModerators) {
        this.networkModerators = networkModerators;
    }

    public List<NetworkMember> getNetworkMembers() {
        return networkMembers;
    }

    public void setNetworkMembers(List<NetworkMember> networkMembers) {
        this.networkMembers = networkMembers;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public List<ProductListing> getProductListings() {
        return productListings;
    }

    public void setProductListings(List<ProductListing> productListings) {
        this.productListings = productListings;
    }

    public List<BulletinBoard> getBulletinBoards() {
        return bulletinBoards;
    }

    public void setBulletinBoards(List<BulletinBoard> bulletinBoards) {
        this.bulletinBoards = bulletinBoards;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public NetworkType getNetworkType() {
        return networkType;
    }

    public void setNetworkType(NetworkType networkType) {
        this.networkType = networkType;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

}
