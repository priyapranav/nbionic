package info.com.neighbourbase.model;

import java.util.Date;



public class NetworkContactListDto {

	private long listId;
	private String name;
	private long categoryId;
	private String categoryName;
	private long mobile;
	private String landline;
	private String address1;
	private String address2;
	private String city;
	private int pincode;
	private long createdMemberId;
	private String createdMemberName;
	private int createdMemberIsActive;
	private Long createdDate;
	private long updatedMemberId;
	private Long updatedDate;
	private long networkId;
	private String networkName;
	private String email;
	private int isActive;
	private int isDelete;
	private String feedback;
	private int moderator_flag;


	public long getListId() {
		return listId;
	}

	public void setListId(long listId) {
		this.listId = listId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getLandline() {
		return landline;
	}

	public void setLandline(String landline) {
		this.landline = landline;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public long getCreatedMemberId() {
		return createdMemberId;
	}

	public void setCreatedMemberId(long createdMemberId) {
		this.createdMemberId = createdMemberId;
	}

	public Long getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Long createdDate) {
		this.createdDate = createdDate;
	}

	public long getUpdatedMemberId() {
		return updatedMemberId;
	}

	public void setUpdatedMemberId(long updatedMemberId) {
		this.updatedMemberId = updatedMemberId;
	}

	public Long getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Long updatedDate) {
		this.updatedDate = updatedDate;
	}

	public long getNetworkId() {
		return networkId;
	}

	public void setNetworkId(long networkId) {
		this.networkId = networkId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public int getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(int isDelete) {
		this.isDelete = isDelete;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public int getModerator_flag() {
		return moderator_flag;
	}

	public void setModerator_flag(int moderator_flag) {
		this.moderator_flag = moderator_flag;
	}

	public String getCreatedMemberName() {
		return createdMemberName;
	}

	public void setCreatedMemberName(String createdMemberName) {
		this.createdMemberName = createdMemberName;
	}

	public int getCreatedMemberIsActive() {
		return createdMemberIsActive;
	}

	public void setCreatedMemberIsActive(int createdMemberIsActive) {
		this.createdMemberIsActive = createdMemberIsActive;
	}

}