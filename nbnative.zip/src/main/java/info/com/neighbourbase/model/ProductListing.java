package info.com.neighbourbase.model;

import java.util.Date;




public class ProductListing {

	private long productId;

	private Member member;


	private String productName;

	private Category category;

	private float productValue;


	private double salePrice;


	private double rentalPrice;


	private int duration;


	private String brand;


	private String model;

	private TransactionType transType;


	private Date createdDateTime;


	private Date lastUpdatedDateTime;


	private String updatedBy;

	private String updateReason;

	private int isDeleted;

	private int isActive;

	private String postingRemarks;


	private String picture;

	private Network network;


	private Status status;


	private String productDescription;


	private int isPaused;

	private ProductDuration productduration;

	/*
	 * @OneToMany(mappedBy = "productListing", cascade = CascadeType.ALL)
	 * private List<Request> requests;
	 */

	public ProductDuration getProductDuration() {
		return productduration;
	}

	public void setProductDuration(ProductDuration productDuration) {
		this.productduration = productDuration;
	}

	public Member getMember() {
		return member;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public float getProductValue() {
		return productValue;
	}

	public void setProductValue(float productValue) {
		this.productValue = productValue;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public TransactionType getTransType() {
		return transType;
	}

	public void setTransType(TransactionType transType) {
		this.transType = transType;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Date getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}

	public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdateReason() {
		return updateReason;
	}

	public void setUpdateReason(String updateReason) {
		this.updateReason = updateReason;
	}

	public int getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(int isDeleted) {
		this.isDeleted = isDeleted;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public String getPostingRemarks() {
		return postingRemarks;
	}

	public void setPostingRemarks(String postingRemarks) {
		this.postingRemarks = postingRemarks;
	}

	public String getPicture() {
		return picture;
	}

	public String setPicture(String picture) {
		return this.picture = picture;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public Network getNetwork() {
		return network;
	}

	public void setNetwork(Network network) {
		this.network = network;
	}

	public double getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(double salePrice) {
		this.salePrice = salePrice;
	}

	public double getRentalPrice() {
		return rentalPrice;
	}

	public void setRentalPrice(double rentalPrice) {
		this.rentalPrice = rentalPrice;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getIsPaused() {
		return isPaused;
	}

	public void setIsPaused(int isPaused) {
		this.isPaused = isPaused;
	}

	/*
	 * public List<Request> getRequests() { return requests; }
	 * 
	 * public void setRequests(List<Request> requests) { this.requests =
	 * requests; }
	 */

}
