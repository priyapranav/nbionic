package info.com.neighbourbase.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Nila on 13-06-2017.
 */

public class CommonResponseDto {

    private String status;
    private MemberDto memberDto;
    private Map<Long, List<CategoryDto>> categoryDtoMap;
    private List<ProductListingDto> productListingSearchDto;
    //private Map<Long, String> searchProductMap;

    private List<String> productSearchName;
    private List<ProductListingDto> productListingDto;
    private long unreadCount;
    private float avgRating;
    private int totalReviews;
    private List<RequestDto> requestDto;
    private List<IssuerFeedbackDto> issuerFeedbackDto;
    private List<ReceiverFeedbackDto> receiverFeedbackDto;
    private List<NotificationThreadDto> notificationThreadDto;
    private ReceiverNoteDto receiverNoteDto;
    private IssuerNoteDto issuerNoteDto;
    private Map<String, String> invitationResponseMap;
    private List<FeedbackRemainderDto> feedbackRemainderDto;
    private PrivateNetworkDto privateNetworkDto;
    private NetworkDto networkDto;
    private List<CategoryDto> categoryDto;
    private String deviceToken;
    private RequestDto requestDtos;
    private List<BlockListDto>blockListDto;
    private NetworkContactListDto networkContactListDto;
    private List<NetworkContactListFeedbackDto> networkContactListFeedbackDtos;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public MemberDto getMemberDto() {
        return memberDto;
    }

    public void setMemberDto(MemberDto memberDto) {
        this.memberDto = memberDto;
    }

    public Map<Long, List<CategoryDto>> getCategoryDtoMap() {
        return categoryDtoMap;
    }

    public void setCategoryDtoMap(Map<Long, List<CategoryDto>> categoryDtoMap) {
        this.categoryDtoMap = categoryDtoMap;
    }

//	public Map<Long, String> getSearchProductMap() {
//		return searchProductMap;
//	}
//
//	public void setSearchProductMap(Map<Long, String> searchProductMap) {
//		this.searchProductMap = searchProductMap;
//	}

    public List<ProductListingDto> getProductListingSearchDto() {
        return productListingSearchDto;
    }

    public void setProductListingSearchDto(List<ProductListingDto> productListingSearchDto) {
        this.productListingSearchDto = productListingSearchDto;
    }

    public List<String> getProductSearchName() {
        return productSearchName;
    }

    public void setProductSearchName(List<String> productSearchName) {
        this.productSearchName = productSearchName;
    }

    public List<ProductListingDto> getProductListingDto() {
        return productListingDto;
    }

    public void setProductListingDto(List<ProductListingDto> productListingDto) {
        this.productListingDto = productListingDto;
    }

    public long getUnreadCount() {
        return unreadCount;
    }

    public void setUnreadCount(long unreadCount) {
        this.unreadCount = unreadCount;
    }

    public float getAvgRating() {
        return avgRating;
    }

    public void setAvgRating(float avgRating) {
        this.avgRating = avgRating;
    }

    public int getTotalReviews() {
        return totalReviews;
    }

    public void setTotalReviews(int totalReviews) {
        this.totalReviews = totalReviews;
    }

    public List<RequestDto> getRequestDto() {
        return requestDto;
    }

    public void setRequestDto(List<RequestDto> requestDto) {
        this.requestDto = requestDto;
    }

    public List<IssuerFeedbackDto> getIssuerFeedbackDto() {
        return issuerFeedbackDto;
    }

    public void setIssuerFeedbackDto(List<IssuerFeedbackDto> issuerFeedbackDto) {
        this.issuerFeedbackDto = issuerFeedbackDto;
    }

    public List<ReceiverFeedbackDto> getReceiverFeedbackDto() {
        return receiverFeedbackDto;
    }

    public void setReceiverFeedbackDto(List<ReceiverFeedbackDto> receiverFeedbackDto) {
        this.receiverFeedbackDto = receiverFeedbackDto;
    }

    public List<NotificationThreadDto> getNotificationThreadDto() {
        return notificationThreadDto;
    }

    public void setNotificationThreadDto(List<NotificationThreadDto> notificationThreadDto) {
        this.notificationThreadDto = notificationThreadDto;
    }

    public ReceiverNoteDto getReceiverNoteDto() {
        return receiverNoteDto;
    }

    public void setReceiverNoteDto(ReceiverNoteDto receiverNoteDto) {
        this.receiverNoteDto = receiverNoteDto;
    }

    public IssuerNoteDto getIssuerNoteDto() {
        return issuerNoteDto;
    }

    public void setIssuerNoteDto(IssuerNoteDto issuerNoteDto) {
        this.issuerNoteDto = issuerNoteDto;
    }

    public Map<String, String> getInvitationResponseMap() {
        return invitationResponseMap;
    }

    public void setInvitationResponseMap(Map<String, String> invitationResponseMap) {
        this.invitationResponseMap = invitationResponseMap;
    }

    public List<FeedbackRemainderDto> getFeedbackRemainderDto() {
        return feedbackRemainderDto;
    }

    public void setFeedbackRemainderDto(List<FeedbackRemainderDto> feedbackRemainderDto) {
        this.feedbackRemainderDto = feedbackRemainderDto;
    }

    public PrivateNetworkDto getPrivateNetworkDto() {
        return privateNetworkDto;
    }

    public void setPrivateNetworkDto(PrivateNetworkDto privateNetworkDto) {
        this.privateNetworkDto = privateNetworkDto;
    }

    public NetworkDto getNetworkDto() {
        return networkDto;
    }

    public void setNetworkDto(NetworkDto networkDto) {
        this.networkDto = networkDto;
    }

    public List<CategoryDto> getCategoryDto() {
        return categoryDto;
    }

    public void setCategoryDto(List<CategoryDto> categoryDto) {
        this.categoryDto = categoryDto;
    }

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }

    public RequestDto getRequestDtos() {
        return requestDtos;
    }

    public void setRequestDtos(RequestDto requestDtos) {
        this.requestDtos = requestDtos;
    }

    public List<BlockListDto> getBlockListDto() {
        return blockListDto;
    }

    public void setBlockListDto(List<BlockListDto> blockListDto) {
        this.blockListDto = blockListDto;
    }

    public NetworkContactListDto getNetworkContactListDto() {
        return networkContactListDto;
    }

    public void setNetworkContactListDto(NetworkContactListDto networkContactListDto) {
        this.networkContactListDto = networkContactListDto;
    }

    public List<NetworkContactListFeedbackDto> getNetworkContactListFeedbackDtos() {
        return networkContactListFeedbackDtos;
    }

    public void setNetworkContactListFeedbackDtos(List<NetworkContactListFeedbackDto> networkContactListFeedbackDtos) {
        this.networkContactListFeedbackDtos = networkContactListFeedbackDtos;
    }

}