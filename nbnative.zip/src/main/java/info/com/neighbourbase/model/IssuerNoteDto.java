package info.com.neighbourbase.model;

import java.util.Date;

public class IssuerNoteDto {
	private long issuerNoteId;
	private long sharedOn;
	private long returnBy;
	private long returnOn;
	private long requestId;
	private String returnByStr;
	private String returnOnStr;
	private String sharedOnStr;
	private String productName;
	private String requesterName;

	public String getReturnByStr() {
		return returnByStr;
	}

	public void setReturnByStr(String returnByStr) {
		this.returnByStr = returnByStr;
	}

	public String getReturnOnStr() {
		return returnOnStr;
	}

	public void setReturnOnStr(String returnOnStr) {
		this.returnOnStr = returnOnStr;
	}

	public long getIssuerNoteId() {
		return issuerNoteId;
	}

	public void setIssuerNoteId(long issuerNoteId) {
		this.issuerNoteId = issuerNoteId;
	}

	public long getSharedOn() {
		return sharedOn;
	}

	public void setSharedOn(long sharedOn) {
		this.sharedOn = sharedOn;
	}

	public long getReturnBy() {
		return returnBy;
	}

	public void setReturnBy(long returnBy) {
		this.returnBy = returnBy;
	}

	public long getReturnOn() {
		return returnOn;
	}

	public void setReturnOn(long returnOn) {
		this.returnOn = returnOn;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getSharedOnStr() {
		return sharedOnStr;
	}

	public void setSharedOnStr(String sharedOnStr) {
		this.sharedOnStr = sharedOnStr;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getRequesterName() {
		return requesterName;
	}

	public void setRequesterName(String requesterName) {
		this.requesterName = requesterName;
	}

}
