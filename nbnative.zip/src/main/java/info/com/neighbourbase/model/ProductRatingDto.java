package info.com.neighbourbase.model;



public class ProductRatingDto {

	private float avgRating ;
	private int totalReviews1;
	private ReceiverFeedbackDto receiverFeedbackDtos;
	private ProductListingDto productListingDto;
	public float getAvgRating() {
		return avgRating;
	}
	public void setAvgRating(float avgRating) {
		this.avgRating = avgRating;
	}
	public int getTotalReviews1() {
		return totalReviews1;
	}
	public void setTotalReviews1(int totalReviews1) {
		this.totalReviews1 = totalReviews1;
	}
	public ReceiverFeedbackDto getReceiverFeedbackDtos() {
		return receiverFeedbackDtos;
	}
	public void setReceiverFeedbackDtos(ReceiverFeedbackDto receiverFeedbackDtos) {
		this.receiverFeedbackDtos = receiverFeedbackDtos;
	}
	public ProductListingDto getProductListingDto() {
		return productListingDto;
	}
	public void setProductListingDto(ProductListingDto productListingDto) {
		this.productListingDto = productListingDto;
	}
	
	
	
}
