package info.com.neighbourbase.model;

import java.util.Date;



public class BulletinBoard {

	private long postingId;


	private Date dateTime;


	private String content;

	private String picture;

	private Date lastUpdatedDateTime;

	private String updatedBy;

	private String updateReason;

	private int isDeleted;

	private int isActive;

	private String status;

	private Member member;

	private Network network;

	private Date postingFrom;

	private Date postingTo;

	public long getPostingId() {
		return postingId;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdateReason() {
		return updateReason;
	}

	public void setUpdateReason(String updateReason) {
		this.updateReason = updateReason;
	}

	public int getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(int isDeleted) {
		this.isDeleted = isDeleted;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public Network getNetwork() {
		return network;
	}

	public void setNetwork(Network network) {
		this.network = network;
	}

	public void setPostingId(int postingId) {
		this.postingId = postingId;
	}

	public Date getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}

	public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}

	public Date getPostingFrom() {
		return postingFrom;
	}

	public void setPostingFrom(Date postingFrom) {
		this.postingFrom = postingFrom;
	}

	public Date getPostingTo() {
		return postingTo;
	}

	public void setPostingTo(Date postingTo) {
		this.postingTo = postingTo;
	}

}
