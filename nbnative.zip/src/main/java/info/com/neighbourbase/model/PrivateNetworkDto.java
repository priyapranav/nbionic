package info.com.neighbourbase.model;

import java.util.List;

public class PrivateNetworkDto {
	private List<NetworkMemberDto> networkMemberDtos;
	private List<ProductListingDto> productListingDtos;
	/*private List<BulletinBoardDto> bulletinBoardDtos;
	private NetworkModeratorDto primaryModerator;*/
	private NetworkDto networkDto;
	private int memberFlag;
	private long networkId;
	private long loggedInMemberId;
	private int totalPages;
	private String location;

	public List<NetworkMemberDto> getNetworkMemberDtos() {
		return networkMemberDtos;
	}

	public void setNetworkMemberDtos(List<NetworkMemberDto> networkMemberDtos) {
		this.networkMemberDtos = networkMemberDtos;
	}

	public List<ProductListingDto> getProductListingDtos() {
		return productListingDtos;
	}

	public void setProductListingDtos(List<ProductListingDto> productListingDtos) {
		this.productListingDtos = productListingDtos;
	}


	public NetworkDto getNetworkDto() {
		return networkDto;
	}

	public void setNetworkDto(NetworkDto networkDto) {
		this.networkDto = networkDto;
	}

	public int getMemberFlag() {
		return memberFlag;
	}

	public void setMemberFlag(int memberFlag) {
		this.memberFlag = memberFlag;
	}

	public long getNetworkId() {
		return networkId;
	}

	public void setNetworkId(long networkId) {
		this.networkId = networkId;
	}

	public long getLoggedInMemberId() {
		return loggedInMemberId;
	}

	public void setLoggedInMemberId(long loggedInMemberId) {
		this.loggedInMemberId = loggedInMemberId;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}
