package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.Adapter.GroupInvitationAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.InvitationDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class GroupInvitationPage extends CommonHeader {
    ListView invitationList;
    LinearLayout noInvitationLayout;
    Button createGroupBtn;
    SharedPreferences sharedPreferences;
    String memberEmailId;
    InvitationDto invitationDto;
    List<InvitationDto> invitationDtoList;
    GroupInvitationAdapter groupInvitationAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_group_invitation_page, frameLayout);
        sharedPreferences= PreferenceManager.getDefaultSharedPreferences(this);
        memberEmailId=sharedPreferences.getString("email","");
        initialize();

        if(Connectivity.isConnected(GroupInvitationPage.this)) {
            new GetInvitationList().execute();
        }else{
            callAlertDialog("Please Check Internet Connection");
        }

    }

    private void initialize() {
        invitationList=(ListView)findViewById(R.id.invitation_list);
        noInvitationLayout=(LinearLayout)findViewById(R.id.no_invitation_layout);
        createGroupBtn=(Button)findViewById(R.id.create_group_button);
        createGroupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GroupInvitationPage.this,AddGroupActivity.class));
                finish();
            }
        });
    }


    private void callAlertDialog(String message) {

        customDialog = new Dialog(GroupInvitationPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

    private class GetInvitationList extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(GroupInvitationPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... strings) {
            HttpConfig httpConfig=new HttpConfig();
            String result;
            result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getAllGroupInvites.json?emailId="+memberEmailId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            if(s!=null){
                try {
                    JSONArray invitationArray=new JSONArray(s);
                    if (invitationArray.length()>0){
                        invitationDtoList=new ArrayList<>();
                        noInvitationLayout.setVisibility(View.GONE);
                        invitationList.setVisibility(View.VISIBLE);
                        invitationDto=new InvitationDto();
                        for (int i=0;i<invitationArray.length();i++){
                            JSONObject inviteObj=invitationArray.getJSONObject(i);
                            invitationDto=new Gson().fromJson(inviteObj.toString().trim(),InvitationDto.class);
                            invitationDtoList.add(invitationDto);
                        }
                        groupInvitationAdapter=new GroupInvitationAdapter(GroupInvitationPage.this,invitationDtoList);
                        invitationList.setAdapter(groupInvitationAdapter);


                    }else if(invitationArray.length()==0){
                        noInvitationLayout.setVisibility(View.VISIBLE);
                        invitationList.setVisibility(View.GONE);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }else{
                callAlertDialog("Please Check Internet Connection");
            }
        }
    }
}
