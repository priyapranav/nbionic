package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import info.com.neighbourbase.Adapter.UsefulContactListAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.NetworkContactListCategoryDto;
import info.com.neighbourbase.model.NetworkContactListDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class UsefulContactsPage extends AppCompatActivity implements AdapterView.OnItemClickListener, View.OnClickListener {
    ListView drawerList;
    ListView contactList;
    Toolbar toolbar;
    DrawerLayout drawerLayout;
    private ActionBarDrawerToggle mDrawerToggle;
    protected FrameLayout frameLayout;
    SharedPreferences sharedPreferences;
    String groupId;
    String memberId; 
    String reqData;
    Long categoryId;
    ArrayList<String> categoryNameList=new ArrayList<>();
    NetworkContactListCategoryDto networkContactListCategoryDto=new NetworkContactListCategoryDto();
    NetworkContactListDto networkContactListDto=new NetworkContactListDto();
    ArrayList<NetworkContactListDto> networkContactListDtos=new ArrayList<>();
    ArrayList<NetworkContactListCategoryDto> networkContactListCategoryDtos=new ArrayList<>();
    HashMap<String,Long> categoryMap=new HashMap<>();
    ArrayAdapter<String> drawerListAdapter;
    Dialog customDialog;
    Dialog addCategoryDialog;
    TextView alertMessageText;
    TextView noContactListText;
    Button alertMsgOkBtn;
    ArrayAdapter usefulContactListAdapter;
    int memberFlag;
    EditText categoryName;
    Button saveCategoryBtn;
    ImageView backIcon;
    String result;
    LinearLayout addListLayout;
    LinearLayout addCategoryLayout;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_useful_contacts_page);
        sharedPreferences= PreferenceManager.getDefaultSharedPreferences(this);
        groupId=sharedPreferences.getString("groupId","");
        memberId=sharedPreferences.getString("memberId","");
        mInit();
        if(Connectivity.isConnected(UsefulContactsPage.this)) {
            new networkDetails().execute();
            new GetCategoryList().execute();
            categoryId=0L;
            new GetContactList().execute();
        }else{
            callAlertDialog("Please Check Internet Connection");
        }



    }

    private void mInit() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        drawerList = (ListView) findViewById(R.id.list);
        addCategoryLayout=(LinearLayout)findViewById(R.id.add_category_layout);
        addListLayout=(LinearLayout)findViewById(R.id.add_list_layout);
        contactList=(ListView)findViewById(R.id.list_contact);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        noContactListText=(TextView)findViewById(R.id.no_contact_list_text);
        backIcon=(ImageView)findViewById(R.id.back_icon);
        noContactListText.setVisibility(View.GONE);
        drawerLayout.setScrimColor(Color.TRANSPARENT);
        drawerList.setOnItemClickListener(this);
        backIcon.setOnClickListener(this);
        addCategoryLayout.setOnClickListener(this);
        addListLayout.setOnClickListener(this);
        

        setupDrawer();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mDrawerToggle.getDrawerArrowDrawable().setColor(getColor(R.color.White));
        } else {
            mDrawerToggle.getDrawerArrowDrawable().setColor(getResources().getColor(R.color.White));
        }
    }

    private void setupDrawer() {
        mDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
                R.string.drawer_open, R.string.drawer_close) {

            /** Called when a drawer has settled in a completely open state. */
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                invalidateOptionsMenu();
            }

            /** Called when a drawer has settled in a completely closed state. */
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                invalidateOptionsMenu();
            }

        };
        mDrawerToggle.setDrawerIndicatorEnabled(true);
        drawerLayout.setDrawerListener(mDrawerToggle);
    }
    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
       
        // Activate the navigation drawer toggle
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }


        return super.onOptionsItemSelected(item);
    }
   // ************** drawer item click listener ***************
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        drawerLayout.closeDrawers();
        String selectedFromList =(String) (drawerList.getItemAtPosition(i));
        categoryId=categoryMap.get(selectedFromList);
        new GetContactList().execute();

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back_icon:
                finish();
                break;
            case R.id.add_category_layout:
                showAddCategoryDialog();
                break;
            case R.id.add_list_layout:
                startActivity(new Intent(UsefulContactsPage.this,AddContactListPage.class));
                break;
        }

    }

    private void showAddCategoryDialog() {
        addCategoryDialog = new Dialog(UsefulContactsPage.this);
        addCategoryDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        addCategoryDialog.setContentView(R.layout.add_category);
        addCategoryDialog.setCancelable(true);

        saveCategoryBtn=(Button)addCategoryDialog.findViewById(R.id.save_category);
        categoryName=(EditText)addCategoryDialog.findViewById(R.id.category_name);
        saveCategoryBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if(categoryName.getText().toString().length()>0)
                {
                    networkContactListCategoryDto.setCategoryName(categoryName.getText().toString());
                    networkContactListCategoryDto.setNetworkId(Long.parseLong(groupId));
                    reqData=new Gson().toJson(networkContactListCategoryDto);
                    new addCategoryResponse().execute();
                    addCategoryDialog.dismiss();
                }else{
                    categoryName.setError("give a category");
                }
            }
        });


        addCategoryDialog.show();
    }

    private class GetCategoryList extends AsyncTask<String,String,String>{
        @Override
        protected String doInBackground(String... strings) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httpget(Webconfig.CONTEXT_PATH+"getallnetworkcategorylist.json?networkid="+groupId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            networkContactListCategoryDto=new NetworkContactListCategoryDto();
            super.onPostExecute(s);
            if(s!=null){
                categoryNameList.add("All");
                categoryMap.put("All",0L);

                try {

                    JSONArray jsonArray=new JSONArray(s);
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject categoryListArray=jsonArray.getJSONObject(i);
                        networkContactListCategoryDto=new Gson().fromJson(categoryListArray.toString().trim(),NetworkContactListCategoryDto.class);
                        categoryNameList.add(networkContactListCategoryDto.getCategoryName().trim());
                        categoryMap.put(networkContactListCategoryDto.getCategoryName().trim(),networkContactListCategoryDto.getContactsCategoryId());
                        networkContactListCategoryDtos.add(networkContactListCategoryDto);
                    }
                    drawerListAdapter= new ArrayAdapter<String>(UsefulContactsPage.this, android.R.layout.simple_list_item_1, categoryNameList);
                    drawerList.setAdapter(drawerListAdapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }else{
                callAlertDialog("server down");
            }
        }
    }

    private class networkDetails extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getnetworkdetails.json?networkid="+groupId+"&memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                JSONObject jsonObject=null;
                JSONArray jsonArray=null;
                try {
                    jsonObject=new JSONObject(s);
                    JSONObject privateNetworkDtojsonObj=jsonObject.getJSONObject("privateNetworkDto");
                    Long loggedMemberId= Long.valueOf(privateNetworkDtojsonObj.optString("loggedInMemberId"));
                    jsonArray=privateNetworkDtojsonObj.getJSONArray("networkMemberDtos");
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject networkMemberDtoJsonObj=jsonArray.getJSONObject(i);
                        if(memberId.equals(networkMemberDtoJsonObj.optString("memberId")))
                            memberFlag = networkMemberDtoJsonObj.optInt("flag");
                    }
                    if(memberFlag==3){
                        addCategoryLayout.setVisibility(View.VISIBLE);
                    }else{
                        addCategoryLayout.setVisibility(View.GONE);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                callAlertDialog("Server Down... Please try again");
            }
        }
    }


    private class GetContactList extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(UsefulContactsPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... strings) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getcontactlistbycategory.json?categoryid="+categoryId+"&networkid="+groupId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            if(s!=null){
                try {
                    networkContactListDtos.clear();
                    JSONArray jsonArray=new JSONArray(s);
                    if(jsonArray.length()>0){
                        contactList.setVisibility(View.VISIBLE);
                        noContactListText.setVisibility(View.GONE);
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject jsonObject=jsonArray.getJSONObject(i);
                            networkContactListDto=new Gson().fromJson(jsonObject.toString().trim(),NetworkContactListDto.class);
                            networkContactListDtos.add(networkContactListDto);
                        }
                        usefulContactListAdapter=new UsefulContactListAdapter(UsefulContactsPage.this,networkContactListDtos,memberId);
                        contactList.setAdapter(usefulContactListAdapter);

                    }else{
                        contactList.setVisibility(View.GONE);
                        noContactListText.setVisibility(View.VISIBLE);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }else{
                callAlertDialog("Check Your Internet Connection");
            }
        }
    }

    private void callAlertDialog(String message) {

        customDialog = new Dialog(UsefulContactsPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

    private class addCategoryResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(UsefulContactsPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result=httpConfig.doPost(reqData,Webconfig.CONTEXT_PATH+"createnetworkcontactlistcategory.json");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            if(s!=null){
                if(s.trim().equals("success")){
                    customDialog = new Dialog(UsefulContactsPage.this);
                    customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    customDialog.setContentView(R.layout.custom_messbox);
                    alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                    alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                    alertMsgOkBtn.setVisibility(View.GONE);
                    alertMessageText.setText(getResources().getString(R.string.cat_add_success_msg));
                    customDialog.setCancelable(true);
                    customDialog.setCanceledOnTouchOutside(true);
                    customDialog.setOnCancelListener(
                            new DialogInterface.OnCancelListener() {
                                @Override
                                public void onCancel(DialogInterface dialog) {
                                    customDialog.dismiss();
                                    startActivity(new Intent(getIntent()));
                                    finish();

                                }
                            }
                    );

                    customDialog.show();
                    customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                }else if(s.trim().equals("fail")){
                    callAlertDialog("Category added failed, try again..");
                }

            }else{
                callAlertDialog("check your internet connection");
            }

        }
    }
}
