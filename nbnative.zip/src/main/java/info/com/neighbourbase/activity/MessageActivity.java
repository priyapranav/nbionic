package info.com.neighbourbase.activity;

import android.content.Intent;
import android.graphics.Color;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.R;
import info.com.neighbourbase.utility.Constant;

public class MessageActivity extends CommonHeader {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    public static MessageActivity instance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_message);

        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_message, FrameLayout);

        init();

    }

    private void init() {
        if(!Constant.currentActivity.equalsIgnoreCase("MessageActivity")) {
            Constant.previousActivity = Constant.currentActivity;
            Constant.currentActivity = "MessageActivity";
        }
        viewPager = (ViewPager) findViewById(R.id.viewpager);
        setupViewPager(viewPager);

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
        //tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#FFFFFF"));
        tabLayout.setSelectedTabIndicatorHeight((int) (3 * getResources().getDisplayMetrics().density));
        //tabLayout.setTabTextColors(Color.parseColor("#727272"), Color.parseColor("#ffffff"));


        if (Constant.requestType.equalsIgnoreCase("received")) {
            Constant.tabPosition = 0;
        } else if(Constant.requestType.equalsIgnoreCase("sent")){
            Constant.tabPosition = 1;
        }

        selectPage(Constant.tabPosition);
    }

    void selectPage(int pageIndex){
        tabLayout.setScrollPosition(pageIndex,0f,true);
        viewPager.setCurrentItem(pageIndex);
    }

    public static MessageActivity getInstance() {
        return instance;
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new MessageFragment(), "Request Received");
        adapter.addFragment(new MessageSentFragment(), "Request Sent");
        viewPager.setAdapter(adapter);
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }
    @Override
    public void onResume(){
        super.onResume();
        init();
        instance=MessageActivity.this;

    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(MessageActivity.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(MessageActivity.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(MessageActivity.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(MessageActivity.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(MessageActivity.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(MessageActivity.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(MessageActivity.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(MessageActivity.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(MessageActivity.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(MessageActivity.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(MessageActivity.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(MessageActivity.this, AddGroupActivity.class));
//            finish();
//        }
//
//       /* else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(MessageActivity.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(MessageActivity.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(MessageActivity.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(MessageActivity.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(MessageActivity.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(MessageActivity.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(MessageActivity.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(MessageActivity.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(MessageActivity.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
