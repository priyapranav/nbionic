package info.com.neighbourbase.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import info.com.neighbourbase.R;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class MorePage extends CommonHeader implements View.OnClickListener {
    LinearLayout profileLayout,mylistingLayout,feedbackLayout,logoutLayout,addGroupLayout,termsAndConditionLayout;
    public static Typeface font_awesome;
    String userName;
    SharedPreferences preferences;
    ProgressBar selectGroupProgress;
    TextView profileIcon, myListingIcon, newGroupIcon, feedbackIcon, logoutIcon,profileText, termsConditionsIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_more_page, FrameLayout);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        userName=preferences.getString("firstName","");
        mInit();

    }

    private void mInit() {
        font_awesome = Typeface.createFromAsset(getAssets(), "fonts/fontawesome-webfont.ttf");
        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "MorePage";
        profileIcon = (TextView) findViewById(R.id.profile_icon_text);
        profileText = (TextView) findViewById(R.id.profile);
        myListingIcon = (TextView) findViewById(R.id.my_listing_icon);
        newGroupIcon = (TextView) findViewById(R.id.new_group_icon);
        feedbackIcon  = (TextView) findViewById(R.id.feedback_icon);
        logoutIcon = (TextView) findViewById(R.id.logout_icon);
        profileLayout=(LinearLayout)findViewById(R.id.profile_layout);
        mylistingLayout=(LinearLayout)findViewById(R.id.myListing_layout);
        feedbackLayout=(LinearLayout)findViewById(R.id.feedback_layout);
        logoutLayout=(LinearLayout)findViewById(R.id.logout_layout);
        addGroupLayout=(LinearLayout)findViewById(R.id.add_group_layout);
        termsConditionsIcon = (TextView) findViewById(R.id.terms_condition_icon);
        termsAndConditionLayout=(LinearLayout)findViewById(R.id.terms_condition_layout);
        addGroupLayout.setOnClickListener(this);
        profileLayout.setOnClickListener(this);
        mylistingLayout.setOnClickListener(this);
        feedbackLayout.setOnClickListener(this);
        logoutLayout.setOnClickListener(this);
        termsAndConditionLayout.setOnClickListener(this);
        profileText.setText(getResources().getString(R.string.profile)+" - "+userName);

        profileIcon.setTypeface(font_awesome);
        myListingIcon.setTypeface(font_awesome);
        newGroupIcon.setTypeface(font_awesome);
        feedbackIcon.setTypeface(font_awesome);
        termsConditionsIcon.setTypeface(font_awesome);
        logoutIcon.setTypeface(font_awesome);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.profile_layout:
                startActivity(new Intent(MorePage.this, ProfilePage.class));
                break;
            case R.id.myListing_layout:
                showGroupNamePopup();
                break;
            case R.id.feedback_layout:
                startActivity(new Intent(MorePage.this, FeedbackActivity.class));
                break;
            case R.id.add_group_layout:
                startActivity(new Intent(MorePage.this, AddGroupActivity.class));
                break;
            case R.id.logout_layout:
                logout();
                HttpConfig.username = null;
                HttpConfig.password = null;
                startActivity(new Intent(MorePage.this, LoginActivity.class));
                break;
            case R.id.terms_condition_layout:
                startActivity(new Intent(MorePage.this,TermsAndConditionsScreen.class));
                break;
        }
    }

    private void logout() {
        SharedPreferences.Editor e = preferences.edit();

        e.putString("memberId","");
        e.putString("latitude", "");
        e.putString("longitude", "");
        e.putString("pincode", "");
        e.putString("address","");
        e.putString("radius", "");
        e.commit();
    }


    private void showGroupNamePopup() {

        mylistingGroup = new Dialog(MorePage.this);
        mylistingGroup.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mylistingGroup.setContentView(R.layout.activity_my_listing_group_page);
        mylistingGroup.setCancelable(true);

        groupList=(ListView)mylistingGroup.findViewById(R.id.group_name_list);
        selectGroupProgress=(ProgressBar)mylistingGroup.findViewById(R.id.group_progress_bar);
        new getGroupName().execute();
        groupList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String groupIdStr= String.valueOf(groupId.get(position));
                String groupNameStr=groupName.get(position);
                Constant.myListGroupId=groupIdStr;
                Constant.myListGroupName=groupNameStr;
                startActivity(new Intent(MorePage.this,MyListingPage.class));
//                finish();
                mylistingGroup.dismiss();
            }
        });
        mylistingGroup.show();
    }

    private class getGroupName extends AsyncTask<String,String,String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            selectGroupProgress.setIndeterminate(true);
            selectGroupProgress.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getnetwork.json?memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            selectGroupProgress.setVisibility(View.GONE);
            if (s != null) {
                JSONObject jsonObject = null;
                JSONArray jsonArray = null;
                groupId = new ArrayList<Long>();
                groupName = new ArrayList<String>();
                groupName.add("All");
                groupId.add(0L);

                try {
                    jsonArray = new JSONArray(s);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        String networkname = jsonObject.getString("networkName");
                        Long networkid = jsonObject.getLong("networkId");
                        groupName.add(networkname);
                        groupId.add(networkid);

                    }
                    groupNameAdapter=new ArrayAdapter<String>(MorePage.this,android.R.layout.simple_spinner_dropdown_item,groupName);
                    groupList.setAdapter(groupNameAdapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                callAlertDialog("Check Your Internet Connection");
            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(MorePage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(MorePage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(MorePage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(MorePage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(MorePage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(MorePage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(MorePage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(MorePage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(MorePage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(MorePage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(MorePage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(MorePage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(MorePage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(AddGroupActivity.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(MorePage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(MorePage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(MorePage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(MorePage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(MorePage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(MorePage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(MorePage.this, ViewPage.class));
//            finish();
//        } else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(MorePage.this, AddGroupActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ReminderPage")){
//                startActivity(new Intent(MorePage.this, ReminderPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("DashBoardPage")){
//            startActivity(new Intent(MorePage.this, DashBoardPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePage")){
//            startActivity(new Intent(MorePage.this, ProfilePage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(MorePage.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
