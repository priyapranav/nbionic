package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.MemberDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class ProfileInformationPage extends CommonHeader implements View.OnClickListener {
    TextView profileAddressTxt,profilePincodeTxt,profileAreaTxt;
    Button profileResetBtn,profileChangeBtn;
    EditText profileFirstName,profileLastName,profileMobileNumber,profileDefaultSearchRadius;
    SharedPreferences preferences;
    String firstName,lastName,pincode,area,address,searchRadius,contactNumber,reqData,memberId;
    MemberDto memberDto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_profile_information_page);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_profile_information_page, FrameLayout);

        mInit();

    }

    private void mInit() {

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "ProfileInformationPage";
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        firstName=preferences.getString("firstName","");
        lastName=preferences.getString("lastName","");
        pincode=preferences.getString("pincode","");
        address=preferences.getString("address","");
        area=preferences.getString("area","");
        memberId=preferences.getString("memberId","");
        searchRadius=preferences.getString("radius","");
        contactNumber=preferences.getString("contactNumber","");

        profileAddressTxt=(TextView)findViewById(R.id.profile_address);
        profileAreaTxt=(TextView)findViewById(R.id.profile_area);
        profilePincodeTxt=(TextView)findViewById(R.id.profile_pincode);
        profileResetBtn=(Button)findViewById(R.id.profile_reset);
        profileChangeBtn=(Button)findViewById(R.id.profile_change);
        profileFirstName=(EditText) findViewById(R.id.profile_first_name);
        profileLastName=(EditText) findViewById(R.id.profile_last_name);
        profileMobileNumber=(EditText) findViewById(R.id.profile_mobile_number);
        profileDefaultSearchRadius=(EditText) findViewById(R.id.profile_default_search_radius);

        profileChangeBtn.setOnClickListener(this);
        profileResetBtn.setOnClickListener(this);
        setValues();

    }

    private void setValues() {
        profileFirstName.setText(firstName);
        profileAddressTxt.setText(address);
        profilePincodeTxt.setText(pincode);
        profileAreaTxt.setText(area);
        profileMobileNumber.setText(contactNumber);
        profileDefaultSearchRadius.setText(searchRadius);
        profileLastName.setText(lastName);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.profile_change:
                memberDto=new MemberDto();
                if(checkValidation()) {
                    memberDto.setMemberId(Long.parseLong(memberId));
                    memberDto.setFirstName(profileFirstName.getText().toString());
                    memberDto.setLastName(profileLastName.getText().toString());
                    memberDto.setPincode(Integer.parseInt(profilePincodeTxt.getText().toString()));
                    memberDto.setAddress(profileAddressTxt.getText().toString());
                    memberDto.setArea(profileAreaTxt.getText().toString());
                    if(profileMobileNumber.getText().toString().equals(""))
                        profileMobileNumber.setText("0");
                    memberDto.setContactNumber(Long.parseLong(profileMobileNumber.getText().toString()));
                    memberDto.setSearchRadius(Double.parseDouble(profileDefaultSearchRadius.getText().toString()));
                    reqData=new Gson().toJson(memberDto);
                    new getProfileChangeResponse().execute();
                }
                break;
            case R.id.profile_reset:
                setValues();
                break;

        }
    }

    private boolean checkValidation() {
        boolean valueReturn = true;
        if (!Validation.hasText(profileFirstName))
            valueReturn = false;
        if (!Validation.hasText(profileDefaultSearchRadius))
            valueReturn = false;
        return valueReturn;
    }

    private class getProfileChangeResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ProfileInformationPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData, Webconfig.CONTEXT_PATH+"updatemember.json");
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            progressDialog.dismiss();
            if(result!=null&&result.length()!=0)
            {
                result.trim();

                try {
                    JSONObject jsonObject=new JSONObject(result);
                    String status=jsonObject.optString("status", "");
                    status.trim();
                    System.out.println(status);
                    if(status.equals("success")){
                        JSONObject memberDtoObj=jsonObject.getJSONObject("memberDto");
                        Gson gson=new Gson();
                        MemberDto memberDto=gson.fromJson(memberDtoObj.toString().trim(),MemberDto.class);
                        System.out.println(memberDto.getMemberId());
                        updateMemberId(memberDto.getFirstName(),memberDto.getLastName(),memberDto.getSearchRadius(),memberDto.getContactNumber());
                        customDialog = new Dialog(ProfileInformationPage.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setVisibility(View.GONE);
                        alertMessageText.setText(getResources().getString(R.string.profile_change_msg));
                        customDialog.setCancelable(true);
                        customDialog.setCanceledOnTouchOutside(true);
                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        customDialog.dismiss();
                                        startActivity(new Intent(ProfileInformationPage.this,HomeScreen.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
//                                                finish();
                                    }
                                }
                        );

                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                    }else if(status.equals("fail")){
                        callAlertDialog("Profile change failed please try again");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }else {
                callAlertDialog("Server Down... Please try again");
            }



        }
    }

    private void updateMemberId(String firstName, String lastName, double searchRadius, long contactNumber) {
        SharedPreferences.Editor e = preferences.edit();
        e.putString("firstName",firstName);
        e.putString("lastName",lastName);
        e.putString("radius", String.valueOf(searchRadius));
        e.putString("contactNumber", String.valueOf(contactNumber));
        e.commit();

    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(ProfileInformationPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(ProfileInformationPage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(ProfileInformationPage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(ProfileInformationPage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(ProfileInformationPage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(ProfileInformationPage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(ProfileInformationPage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(ProfileInformationPage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(ProfileInformationPage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(ProfileInformationPage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(ProfileInformationPage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(ProfileInformationPage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(ProfileInformationPage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(ProfileInformationPage.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(ProfileInformationPage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(ProfileInformationPage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(ProfileInformationPage.this, AddGroupActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(ProfileInformationPage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(ProfileInformationPage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(ProfileInformationPage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(ProfileInformationPage.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(ProfileInformationPage.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
