package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import info.com.neighbourbase.Adapter.MyListProductAdapter;
import info.com.neighbourbase.Adapter.ProductViewAllAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

import static info.com.neighbourbase.activity.Header.messageCount;

/**
 * Created by Priya on 29-06-2017.
 */

public class MyListingFragment extends Fragment implements View.OnClickListener, AdapterView.OnItemClickListener {
    String transTypeId,networkId,productName,memberId;
    Long productId;
    ListView listView;
    Map<String,Long> productMap;
    List<ProductListingDto> productListingDtosBorrow;
    ArrayAdapter listProduct;
    public static TextView noProductText;
    TextView alertMessageText;
    Button alertMsgOkBtn;
    Dialog customDialog;
    boolean isScroll = true;
    int scrollCurrentPosition;
    SharedPreferences preferences;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
// Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.mylisting_fragment_page, null);
        getAllWidgets(rootView);
        setAdapter();
        preferences = PreferenceManager.getDefaultSharedPreferences(MyListingPage.getInstance());
        transTypeId=preferences.getString("myListTransType","");
        networkId=preferences.getString("myListNetworkId","");
        memberId=preferences.getString("memberId","");
        new getBorrowList().execute();
        noProductText.setOnClickListener(this);
        listView.setOnItemClickListener(this);
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == SCROLL_STATE_IDLE) {
                    if (listView.getLastVisiblePosition() >= listView.getCount() - 1) {
                        Constant.myListCurrentPage++;

                        if (isScroll) {
                            if (Connectivity.isConnected(HomeScreen.getInstance())) {
                                new GetBorrowListScroll().execute();
                            } else {
                                Toast.makeText(HomeScreen.getInstance(),
                                        "Please check your network connection",
                                        Toast.LENGTH_SHORT).show();

                            }
                        }
                        scrollCurrentPosition = listView.getFirstVisiblePosition();

                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });

        return rootView;
    }

    private void getAllWidgets(View rootView) {
        listView = (ListView) rootView.findViewById(R.id.myListing_listView);
        noProductText=(TextView)rootView.findViewById(R.id.no_product_text);
        noProductText.setVisibility(View.GONE);

    }

    private void setAdapter() {
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.no_product_text:
                getActivity().startActivity(new Intent(getActivity(),AddProductPage.class));
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        TextView product=(TextView)view.findViewById(R.id.productName);
        productName=product.getText().toString().trim();
        String[] productNameSplit=productName.replace("'s ",",").split(",");
        System.out.println(productNameSplit[1]);
        productId  = (Long) productMap.get(productNameSplit[1]);
        updateProductId(productId);
    }

    private void updateProductId(Long productId) {
        SharedPreferences.Editor e=preferences.edit();
        e.putString("myListProductId", String.valueOf(productId));
        e.commit();
    }

    public  class getBorrowList extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(MyListingPage.getInstance());
            progressDialog.setMessage("Search in progress...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "getownerproductlistng.json?transtypeid="+transTypeId+"&categoryid=0&pageNumber=0&networkid="+networkId+"&memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            progressDialog.dismiss();
            productListingDtosBorrow = new ArrayList<ProductListingDto>();
            productMap=new HashMap<String, Long>();
            ProductListingDto productDto;
            JSONObject jsonObject=null;
            if(res!=null) {
                try {
                    jsonObject=new JSONObject(res);
                    String status = jsonObject.getString("status");
                    Constant.messageUnreadCount = jsonObject.getLong("unreadCount");
                    CommonHeader.messageCount.setText(String.valueOf(Constant.messageUnreadCount));

                    if(status.equalsIgnoreCase("success")){
                    JSONArray jsonArray =jsonObject.getJSONArray("productListingDto");
                    if (jsonArray.length() == 0) {
                        listView.setVisibility(View.GONE);
                        noProductText.setVisibility(View.VISIBLE);

                    } else {
                        listView.setVisibility(View.VISIBLE);
                        noProductText.setVisibility(View.GONE);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObj = jsonArray.getJSONObject(i);
                            Gson gson = new Gson();
                            productDto = gson.fromJson(jsonObj.toString().trim(), ProductListingDto.class);
                            productMap.put(productDto.getProductName(), productDto.getProductId());
                            productListingDtosBorrow.add(productDto);
                        }
                        if (!productListingDtosBorrow.isEmpty()) {
                            Constant.myListingProductListingDtos.addAll(productListingDtosBorrow);
                        } else {
                            isScroll = false;
                        }

                        listProduct = new MyListProductAdapter(MyListingPage.getInstance(),  Constant.myListingProductListingDtos);
                        listView.setAdapter(listProduct);
                        int currentPosition = listView.getFirstVisiblePosition();
                        listView.setSelection(currentPosition);
                    }

//                for ( Map.Entry<String, Long> entry : productMap.entrySet()) {
//                    String key = entry.getKey();
//                   Long id = entry.getValue();
//                    System.out.println(key+" "+id);
//                    // do something with key and/or tab
//                }

                    }else if(status.equals("fail")){
                        listView.setVisibility(View.GONE);
                        noProductText.setVisibility(View.VISIBLE);
                    }
                    else{
                        noProductText.setVisibility(View.VISIBLE);
                        if (!productListingDtosBorrow.isEmpty()) {
                            Constant.myListingProductListingDtos.addAll(productListingDtosBorrow);
                        } else {
                            isScroll = false;
                        }

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else {
               callAlertDialog("Check Your Internet Connection");
            }
        }
    }
    private class GetBorrowListScroll extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "getownerproductlistng.json?transtypeid="+transTypeId+"&categoryid=0&pageNumber="+Constant.myListCurrentPage+"&networkid="+networkId+"&memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            productListingDtosBorrow = new ArrayList<>();
            ProductListingDto productDto;
            JSONObject jsonObj;
            Gson gson;
            productMap=new HashMap<>();
            if(res!=null) {
                try {
                    jsonObj = new JSONObject(res);
                    String status = jsonObj.getString("status");
                    if(status.equalsIgnoreCase("success")) {
                        gson = new Gson();
                        CommonResponseDto commonResponseDto = gson.fromJson(res, CommonResponseDto.class);
                        if(commonResponseDto.getProductListingDto()!=null && !commonResponseDto.getProductListingDto().isEmpty()) {

                            productListingDtosBorrow = commonResponseDto.getProductListingDto();
                            for (int j = 0; j < productListingDtosBorrow.size(); j++) {
                                productDto = productListingDtosBorrow.get(j);
                                productMap.put(productDto.getProductName(), productDto.getProductId());
                            }
                            if (!productListingDtosBorrow.isEmpty()) {
                                Constant.myListingProductListingDtos.addAll(productListingDtosBorrow);
                            } else {
                                isScroll = false;
                            }
                            listProduct = new MyListProductAdapter(MyListingPage.getInstance(),  Constant.myListingProductListingDtos);
                            listView.setAdapter(listProduct);
                            listView.setSelection(scrollCurrentPosition);
                        }


                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                if (!productListingDtosBorrow.isEmpty()) {
                    Constant.myListingProductListingDtos.addAll(productListingDtosBorrow);
                } else {
                    isScroll = false;
                }
            }

        }
    }

    private void callAlertDialog(String message) {

        customDialog = new Dialog(MyListingPage.getInstance());
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

}
