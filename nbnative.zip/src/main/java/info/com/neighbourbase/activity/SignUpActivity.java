package info.com.neighbourbase.activity;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.MemberDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener, View.OnFocusChangeListener, GoogleMap.OnMarkerDragListener, OnMapReadyCallback {
    private static final String TAG_RESULT = "predictions";
    GoogleMap googleMap;
    MarkerOptions markerOptions;
    ScrollView mapScrollView;
    LatLng latLng;
    private WorkaroundMapFragment supportMapFragment;
    ArrayList<String> area;
    ArrayAdapter<String> arrayAdapter;
    EditText inputFirstName,inputEmail,inputPassword,inputConformPassword,inputPhoneNo;
    TextInputLayout layoutFirstName,layoutEmail,layoutPassword,layoutConformPassword,layoutArea,layoutPhoneNo;
    AutoCompleteTextView inputArea;
    TextView textTermsConditions,alertMessageText,inputCity,inputCityHint;
    Button btnSignUp,btnLogIn,alertMsgOkBtn;
    CheckBox termsConditions;
    String strFirstName,strEmail,strPassword,strPhoneNo,strCity,registrationData,url,zip,strAddress,city,draggedAddress;
    double latitude,longitude,draggedLat,draggedLng;
    int pinCode;
    Dialog customDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        mInit();
        if(inputCity.getText().toString().length()==0||inputCity.getText().toString().isEmpty())
            inputCityHint.setVisibility(View.GONE);
        else
            inputCityHint.setVisibility(View.VISIBLE);


    }
    private void mInit(){
       inputArea=(AutoCompleteTextView) findViewById(R.id.input_area);
        inputCity=(TextView) findViewById(R.id.input_city);
        inputConformPassword=(EditText)findViewById(R.id.input_conformPassword);
        inputEmail=(EditText)findViewById(R.id.input_email);
        inputPhoneNo=(EditText)findViewById(R.id.input_PhoneNo) ;
        inputFirstName=(EditText)findViewById(R.id.input_firstName);
        inputPassword=(EditText)findViewById(R.id.input_password);
        layoutArea=(TextInputLayout)findViewById(R.id.input_layout_area);
        inputCityHint=(TextView) findViewById(R.id.city_hint_text);
        layoutConformPassword=(TextInputLayout)findViewById(R.id.input_layout_conformPassword);
        layoutEmail=(TextInputLayout)findViewById(R.id.input_layout_email);
        layoutFirstName=(TextInputLayout)findViewById(R.id.input_layout_firstName);
        layoutPassword=(TextInputLayout)findViewById(R.id.input_layout_password);
        layoutPhoneNo=(TextInputLayout)findViewById(R.id.input_layout_phoneNo);
        textTermsConditions=(TextView)findViewById(R.id.text_Terms_Conditions);
        btnLogIn=(Button)findViewById(R.id.btn_login);
        btnSignUp=(Button)findViewById(R.id.btn_signUp);
        termsConditions=(CheckBox)findViewById(R.id.terms_condition);
        supportMapFragment = ((WorkaroundMapFragment) getSupportFragmentManager().findFragmentById(R.id.map));
        supportMapFragment.getMapAsync(this);
        mapScrollView=(ScrollView)findViewById(R.id.mapScrollView);
        supportMapFragment.getView().setVisibility(View.GONE);

        inputEmail.setOnFocusChangeListener(this);
        inputArea.setOnFocusChangeListener(this);
        inputArea.setOnClickListener(this);
        btnLogIn.setOnClickListener(this);
        btnSignUp.setOnClickListener(this);
        textTermsConditions.setOnClickListener(this);
        inputEmail.addTextChangedListener(textWatcher);
        inputArea.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            private Timer timer=new Timer();
            private final long DELAY = 0; // milliseconds
            private Timer timer1=new Timer();
            private final long DELAY1 = 100; // milliseconds

            @Override
            public void afterTextChanged(Editable s) {
                strAddress=inputArea.getText().toString();
                // ********** map delay ***********
                timer1.cancel();
                timer1= new Timer();
                timer1.schedule(
                        new TimerTask() {
                            @Override
                            public void run() {
                                new GetLatLongDetails().execute();

                            }
                        },
                        DELAY1
                );
                //******* map delay ******************
                timer.cancel();
                timer = new Timer();
                timer.schedule(
                        new TimerTask() {
                            @Override
                            public void run() {
                                StringBuilder sb=new StringBuilder(Webconfig.GOOGLE_PLACE);
                                try {
                                    sb.append("&input=" + URLEncoder.encode(inputArea.getText().toString(), "utf8"));
                                } catch (UnsupportedEncodingException e) {
                                    e.printStackTrace();
                                }

                                url=sb.toString();
                                area=new ArrayList<String>();
                                new  googleAutoComplete().execute();
                            }
                        },
                        DELAY
                );

            }
        });
    }


    @Override
    public void onMarkerDragStart(Marker marker) {

    }

    @Override
    public void onMarkerDrag(Marker marker) {

    }

    @Override
    public void onMarkerDragEnd(Marker marker) {
        draggedLat=marker.getPosition().latitude;
        draggedLng=marker.getPosition().longitude;
        new getMarkerDraggedPosition().execute();


    }
    private void createMarker() {
        markerOptions = new MarkerOptions();
        markerOptions.position(latLng).draggable(true);
        googleMap.addMarker(markerOptions);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_login:
                startActivity(new Intent(SignUpActivity.this,LoginActivity.class));
                finish();
                break;
            case R.id.btn_signUp:
                if(checkSignUpValidation()){
                    strAddress=inputArea.getText().toString().trim();
                    strEmail=inputEmail.getText().toString().trim();
                    strFirstName=inputFirstName.getText().toString().trim();
                    strPassword=inputPassword.getText().toString().trim();
                    if(strCity.length()==0)
                        strCity=inputCity.getText().toString().trim();
                    strPhoneNo=inputPhoneNo.getText().toString().trim();

                    Long phoneNo=Long.parseLong(strPhoneNo);

                    MemberDto memberDto=new MemberDto();
                    memberDto.setEmail(strEmail);
                    memberDto.setArea(strCity);
                    memberDto.setAddress(strAddress);
                    memberDto.setFirstName(strFirstName);
                    memberDto.setPassword(strPassword);
                    memberDto.setContactNumber(phoneNo);
                    memberDto.setLatitude(latitude);
                    memberDto.setLongitude(longitude);
                    if(zip==null)
                        zip="0";
                    pinCode= Integer.parseInt(zip);
                    memberDto.setPincode(pinCode);
                    registrationData=new Gson().toJson(memberDto);
                    new registrationTask().execute();

                }
                break;
            case R.id.text_Terms_Conditions:
                startActivity(new Intent(SignUpActivity.this,TermsAndConditionsScreen.class));
                break;


        }


    }

    private boolean checkSignUpValidation() {
        boolean valueReturn = true;
        if (!Validation.hasText(inputEmail, layoutEmail))
            valueReturn = false;
        if (!Validation.hasText(inputPassword, layoutPassword))
            valueReturn = false;
        if(!Validation.hasText(inputFirstName,layoutFirstName))
            valueReturn=false;
        if(!Validation.hasText(inputArea,layoutArea))
            valueReturn=false;
        if(inputCity.getText().toString().length()==0||inputCity.getText().toString().isEmpty()){
            callAlertDialog("city should not be empty set correct area in Area ");
            valueReturn=false;
        }
        if(!Validation.hasText(inputConformPassword,layoutConformPassword))
            valueReturn=false;
        if(!Validation.hasText(inputEmail,layoutEmail))
            valueReturn=false;
        if(!Validation.hasValidPhoneNumber(inputPhoneNo,layoutPhoneNo))
            valueReturn=false;
        if(!Validation.isEmailAddress(inputEmail,layoutEmail,true))
            valueReturn=false;
        if(!(inputPassword.getText().toString().trim()).equals(inputConformPassword.getText().toString().trim())){
            inputConformPassword.setError("Password and Confirm Password Should be Same");
        valueReturn=false;}
        if(!termsConditions.isChecked()){
            callAlertDialog("accept the Terms and Conditions");
            valueReturn=false;
        }

        return valueReturn;
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        switch (v.getId()){
            case R.id.input_email:
                if(!hasFocus)
                {
                    new getCheckEmailResponse().execute();
                }
                break;
            case R.id.input_area:
                if(hasFocus) {
                    supportMapFragment.getView().setVisibility(View.VISIBLE);
                }else {
                    supportMapFragment.getView().setVisibility(View.GONE);
                }
                break;
        }

    }

    TextWatcher textWatcher =new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            inputEmail.setError(null);

        }
    };

    @Override
    public void onMapReady(GoogleMap map) {
        googleMap = map;
        // Enabling MyLocation Layer of Google Map
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        map.setMyLocationEnabled(true);
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(20.5937,78.9629), 3.7f));
        googleMap.setOnMarkerDragListener(this);
        ((WorkaroundMapFragment) getSupportFragmentManager().findFragmentById(R.id.map)).setListener(new WorkaroundMapFragment.OnTouchListener() {
            @Override
            public void onTouch() {
                mapScrollView.requestDisallowInterceptTouchEvent(true);
            }
        });
    }


    private class registrationTask extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        HttpConfig httpConfig=new HttpConfig();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(SignUpActivity.this);
            progressDialog.setMessage("Registering...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... params) {
            String result=httpConfig.doPost(registrationData, Webconfig.CONTEXT_PATH+"createmember.json");
            System.out.println(result);
            result.trim();
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            super.onPostExecute(res);
            progressDialog.dismiss();
            if(res!=null){
                    /*JSONObject jsonObject=new JSONObject(res);
                    String success=jsonObject.optString("success", "");
                    String fail=jsonObject.optString("fail","");
                    String exists=jsonObject.optString("exists","");*/

                    if(res.trim().equalsIgnoreCase("success")){

                        customDialog = new Dialog(SignUpActivity.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setVisibility(View.GONE);
                        customDialog.setCancelable(true);
                        customDialog.setCanceledOnTouchOutside(true);
                        alertMessageText.setText(getResources().getString(R.string.register_success_msg));
                        customDialog.setCanceledOnTouchOutside(true);
                        /*alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                                finish();
                                customDialog.cancel();
                            }
                        });*/
                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        //When you touch outside of dialog bounds,
                                        //the dialog gets canceled and this method executes.
                                        startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                                        finish();
                                        customDialog.cancel();
                                    }
                                }
                        );

                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        //When you touch outside of dialog bounds,
                                        //the dialog gets canceled and this method executes.
                                        startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                                        finish();
                                    }
                                }
                        );

                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                    }else if(res.trim().equalsIgnoreCase("exists")){
                       callAlertDialog("Email Already Exits");
                    }else if(res.trim().equalsIgnoreCase("fail")){
                        callAlertDialog("Sorry Registration Failed Try again");
                    }

            }else{
                callAlertDialog("server down... please try again");
            }

        }
    }
    // ******** Google place auto complete *******


    private class googleAutoComplete extends AsyncTask<Void,Integer,Void> {
        @Override
        protected Void doInBackground(Void... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(url);

            if(result !=null)
            {
                try {
                    // Getting Array of Contacts

                 JSONObject json=new JSONObject(result);
                    JSONArray googlePlace=json.getJSONArray(TAG_RESULT);

                    for(int i = 0; i < googlePlace.length(); i++){
                        JSONObject c = googlePlace.getJSONObject(i);
                        String description = c.getString("description");
                        Log.d("description", description);
                        area.add(description);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                    android.R.layout.simple_list_item_1, area) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    View view = super.getView(position, convertView, parent);
                    TextView text = (TextView) view.findViewById(android.R.id.text1);
                    text.setTextColor(Color.BLACK);
                    return view;
                }
            };


            inputArea.setAdapter(arrayAdapter);
            String strAddress=inputArea.getText().toString();
            Geocoder coder = new Geocoder(SignUpActivity.this);
            try {
                ArrayList<Address> adresses = (ArrayList<Address>) coder.getFromLocationName(strAddress, 50);
                for(Address add : adresses){
                    //Controls to ensure it is right address such as country etc.
                     longitude = add.getLongitude();
                     latitude = add.getLatitude();
                     zip=add.getPostalCode();

                    //latLng.setText("("+String.valueOf(longitude)+" ,  "+String.valueOf(latitude)+")"+zip);

                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    private class getCheckEmailResponse extends AsyncTask<String,String,String> {
        String email=inputEmail.getText().toString();
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"emailavailablecheck.json?email="+email);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject jsonObject=null;
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status","");
                    if(status.equals("Email already exists")){
                        inputEmail.setError("Email already exists");
                        inputEmail.requestFocus();
                    }else if(status.equals("success")){
                        inputEmail.setError(null);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                callAlertDialog("server down...");
            }

        }
    }

    private class GetLatLongDetails extends AsyncTask<String,String,String>{
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String locationAddress = strAddress.replaceAll(" ", "%20");
            String result=httpConfig.httppost("http://maps.googleapis.com/maps/api/geocode/json?address="+locationAddress+"&sensor=true_or_false");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String status = jsonObject.optString("status");
                    if (status.equals("OK")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("results");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObjResult = jsonArray.getJSONObject(i);
                            JSONArray addCompoArray = jsonObjResult.getJSONArray("address_components");
                            for (int j = 0; j < addCompoArray.length(); j++) {
                                JSONObject jsonObjAddCompo = addCompoArray.getJSONObject(j);
                                JSONArray jsonArrayType = jsonObjAddCompo.getJSONArray("types");
                                for (int k = 0; k < jsonArrayType.length(); k++) {
                                    String type = jsonArrayType.getString(k);
                                    if (type.equals("postal_code")) {
                                        try{
                                            pinCode = Integer.parseInt(jsonObjAddCompo.optString("long_name"));
                                        }catch (NumberFormatException ex) {
                                            pinCode=0;
                                        }

                                    } else {
                                        pinCode = 0;
                                    }
                                    if (type.equals("sublocality_level_1")){
                                        strCity=jsonObjAddCompo.optString("long_name");
                                    }
                                    if (type.equals("locality")) {
                                        city = jsonObjAddCompo.optString("long_name");
                                    }
                                    inputCity.setText(city);
                                    inputCityHint.setVisibility(View.VISIBLE);

                                }
                            }
                            JSONObject jsonObjGeometry = jsonObjResult.getJSONObject("geometry");
                            JSONObject jsonObjLocation = jsonObjGeometry.getJSONObject("location");
                            latitude = Double.valueOf(jsonObjLocation.optString("lat"));
                            longitude = Double.valueOf(jsonObjLocation.optString("lng"));

                        }
                        latLng = new LatLng(latitude,longitude);

                        markerOptions = new MarkerOptions();
                        markerOptions.position(latLng).draggable(true);
                        googleMap.clear();
                        googleMap.addMarker(markerOptions);

                        // Locate the first location
                        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12.5f));
                    }else if(status.equals("INVALID_REQUEST")){
                       callAlertDialog("Please Give Correct Address Detail");
                    }

                }catch(JSONException e){
                    e.printStackTrace();
                }


            }



        }
    }
    private class getMarkerDraggedPosition extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httpget("http://maps.googleapis.com/maps/api/geocode/json?latlng="+draggedLat+","+draggedLng+"&sensor=true_or_false");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONObject jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status");
                    if(status.equals("OK")){
                        JSONArray jsonArray=jsonObject.getJSONArray("results");
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject jObj=jsonArray.getJSONObject(0);
                            draggedAddress=jObj.optString("formatted_address");
                        }
                        inputArea.setText(draggedAddress);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(SignUpActivity.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

}
