package info.com.neighbourbase.activity;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.Adapter.ProductViewAllAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class BuyProductScreen extends Header {
    ListView listView;
    String memberId,latitude,longitude,pincode;
    List<ProductListingDto> productListingDtosBuy;
    ArrayAdapter buy;
    TextView listings,transType;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.product_list, FrameLayout);

        mInit();
        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        memberId = preferences.getString("memberId", "");
        latitude=preferences.getString("latitude","");
        longitude=preferences.getString("longitude","");
        pincode=preferences.getString("pincode","");
        new getBuyList().execute();


    }

    private void mInit() {
        listView=(ListView)findViewById(R.id.listView);
     //   listings=(TextView)findViewById(R.id.listing);

      //  listings.setBackgroundColor(0xFF47866F);
        transType.setText(getResources().getString(R.string.buy));
    }

    private  class getBuyList extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getallproductlistng.json?transtypeid=3&categoryid=0&pageNumber=0&radius=1500&pincode="+pincode+"&lat="+latitude+"&lng="+longitude+"&memberId="+memberId);
            System.out.println(result);
            return result;
        }
        @Override
        protected void onPostExecute(String res) {
            productListingDtosBuy=new ArrayList<ProductListingDto>();
            ProductListingDto productDto;
            try {
                JSONArray jsonArray=new JSONArray(res);
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObj=jsonArray.getJSONObject(i);
                    Gson gson=new Gson();
                    productDto=gson.fromJson(jsonObj.toString().trim(),ProductListingDto.class);

                    productListingDtosBuy.add(productDto);
                }

                buy = new ProductViewAllAdapter(BuyProductScreen.this, productListingDtosBuy);
                listView.setAdapter(buy);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}
