package info.com.neighbourbase.activity;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.FeedbackRemainderDto;
import info.com.neighbourbase.model.IssuerFeedbackDto;
import info.com.neighbourbase.model.ReceiverFeedbackDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;


public class HomeScreen extends Header {
    String transType, mapRadius, latitude, longitude, pincode, changeLocation, searchProductName, searchProductType, issuerFeedbackData, receiverData, ownerRatingStr, issuerReviewStr, productRatingStr, productReviewStr;
    SharedPreferences pref;
    TextView changeLocationText, borrowerName, productName, transTypeText, transTypeTextRecv, productNameRecv, ownerNameRecv, issuerRatingCouting, productRatingCountRecv, buyerRatingText;
    public static HomeScreen instance;
    private ProductList fragmentOne, fragmentTwo, fragmentThree, fragmentFour;
    private TabLayout allTabs;
    TabLayout.Tab tab = null;
    boolean doubleBackToExitPressedOnce = false;
    List<FeedbackRemainderDto> feedbackRemainderDtoList;
    FeedbackRemainderDto feedbackRemainderDto;
    Dialog iFeedbackDialog, rFeedbackDialog;
    RatingBar buyerRating, ownerRating, productRating;
    EditText reviewText, issuerReview, productReview;
    Button saveIFeedback, saveRFeedback;
    long feedbackRequestId = 0;
    LinearLayout feedbackProductDtlLay, feedbackProductDtlLayRecv;
    ImageView borrowerImage, productImage, ownerImage, productImageRecv;
    int permissionFineLocation, permissionCoarseLocation, permissionCheck2, permissionCheck3;

    /*protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        //getLayoutInflater().inflate(R.layout.activity_home_screen, FrameLayout);
        getLayoutInflater().inflate(R.layout.home_screen, FrameLayout);

        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        System.out.println("refreshed token " + refreshedToken);
        changeLocationText = (TextView) findViewById(R.id.current_location);
        pref = PreferenceManager.getDefaultSharedPreferences(this);
        Bundle intent = this.getIntent().getExtras();
        if (intent == null) {
            mapRadius = pref.getString("radius", "");
            latitude = pref.getString("latitude", "");
            longitude = pref.getString("longitude", "");
            pincode = pref.getString("pincode", "");
        } else {
            mapRadius = intent.getString("editSearchRadius");
            longitude = intent.getString("longitude");
            latitude = intent.getString("latitude");
            pincode = intent.getString("pincode");
            changeLocation = intent.getString("changeLocation");
            changeLocationText.setText(changeLocation);
            if (mapRadius == null)
                mapRadius = "1.5";
        }
        instance = HomeScreen.this;
        getAllWidgets();
        bindWidgetsWithAnEvent();
        setupTabLayout();
        if (Connectivity.isConnected(HomeScreen.this)) {
            new feedbackReminder().execute();
        } else {

        }

        Constant.currentActivity = "HomeScreen";
        Constant.previousActivity = "HomeScreen";

        int width = getWindowManager().getDefaultDisplay().getWidth();
        int height = getWindowManager().getDefaultDisplay().getHeight();
        System.out.println(width+", "+height);

        /************ This Permission is for, above lollipop version have to ask Self Permission programmatically *****************/
        permissionFineLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        permissionCoarseLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        permissionCheck3 = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE);
        permissionCheck2 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permissionFineLocation != PackageManager.PERMISSION_GRANTED && permissionCoarseLocation != PackageManager.PERMISSION_GRANTED && permissionCheck2 != PackageManager.PERMISSION_GRANTED && permissionCheck3 != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE}, 0);
        }else if(permissionFineLocation != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 0);
        }
        else if(permissionCoarseLocation != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 0);
        }
        else if(permissionCheck2 != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        }
        else if(permissionCheck3 != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, 0);
        }
    }

    public static HomeScreen getInstance() {
        return instance;
    }

    private void getAllWidgets() {
        allTabs = (TabLayout) findViewById(R.id.tabs);

        /*allTabs.setSelectedTabIndicatorColor(Color.parseColor("#FFFFFF"));
        allTabs.setSelectedTabIndicatorHeight((int) (3 * getResources().getDisplayMetrics().density));*/

    }

    private void setupTabLayout() {
        searchProductName = pref.getString("SearchProductName", "");

        if (searchProductName != null && !searchProductName.isEmpty()) {
            String[] splitsearchProductName = searchProductName.split("for");
            searchProductType = splitsearchProductName[1].trim();
        }
        fragmentOne = new ProductList();
        fragmentTwo = new ProductList();
        fragmentThree = new ProductList();
        fragmentFour = new ProductList();

        if (searchProductName == null || searchProductName.isEmpty()) {
            allTabs.addTab(allTabs.newTab().setText("Borrow"), true);
            allTabs.addTab(allTabs.newTab().setText("Rent"), false);
            allTabs.addTab(allTabs.newTab().setText("Buy"), false);
            allTabs.addTab(allTabs.newTab().setText("Giveaway"), false);

            tab = allTabs.getTabAt(0);
            tab.select();
            setCurrentTabFragment(0);
        } else if (searchProductType != null && searchProductType.equalsIgnoreCase("Lend")) {
            allTabs.addTab(allTabs.newTab().setText("Borrow"), true);
            allTabs.addTab(allTabs.newTab().setText("Rent"), false);
            allTabs.addTab(allTabs.newTab().setText("Buy"), false);
            allTabs.addTab(allTabs.newTab().setText("Giveaway"), false);
            tab = allTabs.getTabAt(0);
            tab.select();
            setCurrentTabFragment(0);
        } else if (searchProductType != null && searchProductType.equalsIgnoreCase("Rent")) {
            allTabs.addTab(allTabs.newTab().setText("Borrow"), false);
            allTabs.addTab(allTabs.newTab().setText("Rent"), true);
            allTabs.addTab(allTabs.newTab().setText("Buy"), false);
            allTabs.addTab(allTabs.newTab().setText("Giveaway"), false);
            tab = allTabs.getTabAt(1);
            tab.select();
            setCurrentTabFragment(1);
        } else if (searchProductType != null && searchProductType.equalsIgnoreCase("Sell")) {
            allTabs.addTab(allTabs.newTab().setText("Borrow"), false);
            allTabs.addTab(allTabs.newTab().setText("Rent"), false);
            allTabs.addTab(allTabs.newTab().setText("Buy"), true);
            allTabs.addTab(allTabs.newTab().setText("Giveaway"), false);
            tab = allTabs.getTabAt(2);
            tab.select();
            setCurrentTabFragment(2);
        } else if (searchProductType != null && searchProductType.equalsIgnoreCase("Gift")) {
            allTabs.addTab(allTabs.newTab().setText("Borrow"), false);
            allTabs.addTab(allTabs.newTab().setText("Rent"), false);
            allTabs.addTab(allTabs.newTab().setText("Buy"), false);
            allTabs.addTab(allTabs.newTab().setText("Giveaway"), true);
            tab = allTabs.getTabAt(3);
            tab.select();
            setCurrentTabFragment(3);
        }

    }

    private void bindWidgetsWithAnEvent() {
        allTabs.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                setCurrentTabFragment(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {


            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
    }

    private void setCurrentTabFragment(int tabPosition) {
        switch (tabPosition) {
            case 0:
                transType = "1";
                updateTransType(transType, mapRadius, latitude, longitude, pincode);
                replaceFragment(fragmentOne);
                Constant.productListingDtos.clear();
                Constant.currentPage = 0;
                break;
            case 1:
                transType = "2";
                updateTransType(transType, mapRadius, latitude, longitude, pincode);
                replaceFragment(fragmentTwo);
                Constant.productListingDtos.clear();
                Constant.currentPage = 0;
                break;
            case 2:
                transType = "3";
                updateTransType(transType, mapRadius, latitude, longitude, pincode);
                replaceFragment(fragmentThree);
                Constant.productListingDtos.clear();
                Constant.currentPage = 0;
                break;
            case 3:
                transType = "4";
                updateTransType(transType, mapRadius, latitude, longitude, pincode);
                replaceFragment(fragmentFour);
                Constant.productListingDtos.clear();
                Constant.currentPage = 0;
                break;
        }
    }

    private void updateTransType(String transType, String mapRadius, String latitude, String longitude, String pincode) {
        SharedPreferences.Editor e = pref.edit();
        e.putString("transType", transType);
        e.putString("editSearchRadius", mapRadius);
        e.putString("latitudeHome", latitude);
        e.putString("longitudeHome", longitude);
        e.putString("pincodeHome", pincode);
        e.commit();
    }

    public void replaceFragment(Fragment fragment) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.frame_container, fragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.commit();
    }

    public class feedbackReminder extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(HomeScreen.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "feedbackRemainder.json?&memberId=" + memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null && res.length() > 0) {

                try {

                    jsonObj = new JSONObject(res);
                    String status = jsonObj.getString("status");
                    Constant.messageUnreadCount = jsonObj.getLong("unreadCount");
                    Header.messageCount.setText(String.valueOf(Constant.messageUnreadCount));
                    if (status.equalsIgnoreCase("success")) {
                        feedbackRemainderDtoList = new ArrayList<FeedbackRemainderDto>();
                        feedbackRemainderDto = new FeedbackRemainderDto();
                        CommonResponseDto commonResponseDto = gson.fromJson(res, CommonResponseDto.class);
                        feedbackRemainderDtoList = commonResponseDto.getFeedbackRemainderDto();
                        if (feedbackRemainderDtoList.size() > 0) {
                            feedbackRemainderDto = feedbackRemainderDtoList.get(0);
                            if (feedbackRemainderDto.getMemberId() != 0) {
                                receiverPopupWindow();
                            } else {
                                issuerPopupWindow();
                            }
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
            }

        }
    }

    private void issuerPopupWindow() {

        iFeedbackDialog = new Dialog(HomeScreen.this);
        iFeedbackDialog.setContentView(R.layout.screen_popup);
        iFeedbackDialog.setTitle(R.string.feedback);
        iFeedbackDialog.setCancelable(false);

        feedbackProductDtlLay = (LinearLayout) iFeedbackDialog.findViewById(R.id.product_detail_layout);
        borrowerImage = (ImageView) iFeedbackDialog.findViewById(R.id.borrower_image);
        borrowerName = (TextView) iFeedbackDialog.findViewById(R.id.borrower_name);
        productImage = (ImageView) iFeedbackDialog.findViewById(R.id.product_image);
        productName = (TextView) iFeedbackDialog.findViewById(R.id.product_name);
        transTypeText = (TextView) iFeedbackDialog.findViewById(R.id.trans_type);

        buyerRating = (RatingBar) iFeedbackDialog.findViewById(R.id.buyerRating);
        buyerRatingText = (TextView) iFeedbackDialog.findViewById(R.id.buyer_rating_count);
        reviewText = (EditText) iFeedbackDialog.findViewById(R.id.review_text);
        saveIFeedback = (Button) iFeedbackDialog.findViewById(R.id.submit);
        feedbackProductDtlLay.setVisibility(View.VISIBLE);

        borrowerName.setText(feedbackRemainderDto.getReceiverName());
        productName.setText(feedbackRemainderDto.getProductName());
        if (feedbackRemainderDto.getTransTypeName().equalsIgnoreCase("lend")) {
            transTypeText.setText("Borrowed");
        } else if (feedbackRemainderDto.getTransTypeName().equalsIgnoreCase("rent")) {
            transTypeText.setText("Rented");
        } else if (feedbackRemainderDto.getTransTypeName().equalsIgnoreCase("sell")) {
            transTypeText.setText("Bought");
        } else if (feedbackRemainderDto.getTransTypeName().equalsIgnoreCase("gift")) {
            transTypeText.setText("got");
        }

        if (feedbackRemainderDto.getReceiverPicture() == null || feedbackRemainderDto.getReceiverPicture().equalsIgnoreCase("No Image") || feedbackRemainderDto.getReceiverPicture().isEmpty()) {
            Glide.clear(borrowerImage);
            borrowerImage.setImageResource(R.drawable.no_image);
        } else {
            Glide.with(HomeScreen.this)
                    .load(Webconfig.CONTEXT_PATH1 + "images/" + feedbackRemainderDto.getReceiverPicture()).thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(borrowerImage);
        }

        if (feedbackRemainderDto.getPicture() == null || feedbackRemainderDto.getPicture().equalsIgnoreCase("No Image") || feedbackRemainderDto.getPicture().isEmpty()) {
           Glide.clear(productImage);
            productImage.setImageResource(R.drawable.no_image);
        } else {
            Glide.with(HomeScreen.this)
                    .load(Webconfig.CONTEXT_PATH1 + "images/" + feedbackRemainderDto.getPicture()).thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(productImage);
        }

        buyerRating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                buyerRatingText.setText(String.valueOf(Math.round(rating)) + "/5");
            }
        });

        saveIFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (buyerRating.getRating() != 0) {
                    String buyerRatingStr = String.valueOf(buyerRating.getRating());
                    String reviewTxtStr = reviewText.getText().toString();
                    if (!(buyerRatingStr.equalsIgnoreCase("0.0"))) {
                        IssuerFeedbackDto issuerFeedbackDto = new IssuerFeedbackDto();
                        issuerFeedbackDto.setReceiverRating((int) Math.round(buyerRating.getRating()));
                        issuerFeedbackDto.setRemarks(reviewTxtStr);
                        issuerFeedbackDto.setRequestId(feedbackRemainderDto.getRequestId());

                        issuerFeedbackData = new Gson().toJson(issuerFeedbackDto);
                        new sendIssuerFeedbak().execute();
                    } else {
                        callAlertDialog("Please give rating");
                    }
                } else {
                    callAlertDialog("Please give rating");
                }

            }
        });

        iFeedbackDialog.show();
    }

    private void receiverPopupWindow() {

        rFeedbackDialog = new Dialog(HomeScreen.this);
        rFeedbackDialog.setContentView(R.layout.receiver_feedback);
        rFeedbackDialog.setTitle(R.string.feedback);
        rFeedbackDialog.setCancelable(false);

        feedbackProductDtlLayRecv = (LinearLayout) rFeedbackDialog.findViewById(R.id.product_detail_layout_recv);
        transTypeTextRecv = (TextView) rFeedbackDialog.findViewById(R.id.trans_type_recv);
        productImageRecv = (ImageView) rFeedbackDialog.findViewById(R.id.product_image_recv);
        productNameRecv = (TextView) rFeedbackDialog.findViewById(R.id.product_name_recv);
        ownerImage = (ImageView) rFeedbackDialog.findViewById(R.id.owner_image);
        ownerNameRecv = (TextView) rFeedbackDialog.findViewById(R.id.owner_name);
        ownerRating = (RatingBar) rFeedbackDialog.findViewById(R.id.issuer_rating);
        productRating = (RatingBar) rFeedbackDialog.findViewById(R.id.product_rating);
        issuerRatingCouting = (TextView) rFeedbackDialog.findViewById(R.id.issuer_rating_count);
        productRatingCountRecv = (TextView) rFeedbackDialog.findViewById(R.id.product_rating_count_recv);
        issuerReview = (EditText) rFeedbackDialog.findViewById(R.id.issuer_review);
        productReview = (EditText) rFeedbackDialog.findViewById(R.id.product_review);
        saveRFeedback = (Button) rFeedbackDialog.findViewById(R.id.submit_feedback);
        feedbackProductDtlLayRecv.setVisibility(View.VISIBLE);

        ownerNameRecv.setText(feedbackRemainderDto.getOwnerName());
        productNameRecv.setText(feedbackRemainderDto.getProductName());
        if (feedbackRemainderDto.getTransTypeName().equalsIgnoreCase("lend")) {
            transTypeTextRecv.setText("Borrowed");
        } else if (feedbackRemainderDto.getTransTypeName().equalsIgnoreCase("rent")) {
            transTypeTextRecv.setText("Rented");
        } else if (feedbackRemainderDto.getTransTypeName().equalsIgnoreCase("sell")) {
            transTypeTextRecv.setText("Bought");
        } else if (feedbackRemainderDto.getTransTypeName().equalsIgnoreCase("gift")) {
            transTypeTextRecv.setText("Giveaway");
        }

        if (feedbackRemainderDto.getOwnerPicture() == null || feedbackRemainderDto.getOwnerPicture().equalsIgnoreCase("No Image") || feedbackRemainderDto.getOwnerPicture().isEmpty()) {
            Glide.clear(ownerImage);
            ownerImage.setImageResource(R.drawable.no_image);
        } else {
            Glide.with(HomeScreen.this)
                    .load(Webconfig.CONTEXT_PATH1 + "images/" + feedbackRemainderDto.getOwnerPicture()).thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(ownerImage);
        }

        if (feedbackRemainderDto.getPicture() == null || feedbackRemainderDto.getPicture().equalsIgnoreCase("No Image") || feedbackRemainderDto.getPicture().isEmpty()) {
           Glide.clear(productImageRecv);
            productImageRecv.setImageResource(R.drawable.no_image);
        } else {
            Glide.with(HomeScreen.this)
                    .load(Webconfig.CONTEXT_PATH1 + "images/" + feedbackRemainderDto.getPicture()).thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(productImageRecv);
        }

        ownerRating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                String ratingValue = String.valueOf(Math.round(rating));
                issuerRatingCouting.setText(ratingValue + "/5");
            }
        });

        productRating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                String ratingValue = String.valueOf(Math.round(rating));
                productRatingCountRecv.setText(ratingValue + "/5");
            }
        });

        saveRFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ownerRating.getRating() != 0 && productRating.getRating() != 0) {
                    ownerRatingStr = String.valueOf(ownerRating.getRating());
                    productRatingStr = String.valueOf(productRating.getRating());
                    issuerReviewStr = issuerReview.getText().toString();
                    productReviewStr = productReview.getText().toString();

                    if (!(ownerRatingStr.equalsIgnoreCase("0.0")&& productRatingStr.equalsIgnoreCase("0.0"))) {
                        ReceiverFeedbackDto receiverFeedbackDto = new ReceiverFeedbackDto();
                        receiverFeedbackDto.setIssuerRating((int) Math.round(ownerRating.getRating()));
                        receiverFeedbackDto.setProductRating((int) Math.round(productRating.getRating()));
                        receiverFeedbackDto.setIssuerRemarks(issuerReviewStr);
                        receiverFeedbackDto.setProductRemarks(productReviewStr);
                        receiverFeedbackDto.setRequestId(feedbackRemainderDto.getRequestId());

                        receiverData = new Gson().toJson(receiverFeedbackDto);
                        new sendReceiverFeedback().execute();
                    } else {
                        callAlertDialog("Please give rating");
                    }
                } else {
                    callAlertDialog("Please give rating");
                }
            }
        });
        rFeedbackDialog.show();
    }

    public class sendIssuerFeedbak extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(HomeScreen.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.doPost(issuerFeedbackData, Webconfig.CONTEXT_PATH + "createissuerfeedback.json?&memberId=" + memberId);
            System.out.println("issuer feedback " + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null) {

                try {
                    jsonObj = new JSONObject(res);
                    IssuerFeedbackDto issuerFeedbackDto = gson.fromJson(res, IssuerFeedbackDto.class);
                    iFeedbackDialog.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(HomeScreen.this, "Server Down", Toast.LENGTH_LONG).show();
            }

        }
    }

    public class sendReceiverFeedback extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(HomeScreen.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.doPost(receiverData, Webconfig.CONTEXT_PATH + "createreceiverfeedback.json");
            System.out.println("receiver feedback " + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null && res.length() > 2) {

                try {
                    jsonObj = new JSONObject(res);
                    ReceiverFeedbackDto receiverFeedbackDto = gson.fromJson(res, ReceiverFeedbackDto.class);
                    rFeedbackDialog.dismiss();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(HomeScreen.this, "Server Down", Toast.LENGTH_LONG).show();
            }

        }
    }

    @Override
    public void onBackPressed() {

        if (doubleBackToExitPressedOnce) {

            Intent startMain = new Intent(Intent.ACTION_MAIN);
            startMain.addCategory(Intent.CATEGORY_HOME);
            startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(startMain);
            return;
        }

        this.doubleBackToExitPressedOnce = true;

        Toast.makeText(this, "click again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;

            }
        }, 2000);

    }

    private void callAlertDialog(String message) {

        customDialog = new Dialog(HomeScreen.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText = (TextView) customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn = (Button) customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

    @Override
    public void onResume(){
        super.onResume();
        instance=HomeScreen.this;
        Header.messageCount.setText(String.valueOf(Constant.messageUnreadCount));
    }
}
