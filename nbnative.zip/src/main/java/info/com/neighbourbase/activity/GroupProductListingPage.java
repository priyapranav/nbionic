package info.com.neighbourbase.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import info.com.neighbourbase.R;
import info.com.neighbourbase.utility.Constant;

public class GroupProductListingPage extends CommonHeader implements View.OnClickListener {
    String transType,groupId,searchProductName,searchProductType;
    SharedPreferences preferences;
    TextView changeLocationText,groupNameHeading;
    ImageView backIcon;
    LinearLayout commonFooter,groupFooter;
    public static GroupProductListingPage instance;
    private GroupProductListFragment fragmentOne,fragmentTwo,fragmentThree,fragmentFour;
    private TabLayout allTabs;
    TabLayout.Tab tab = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_group_product_listing_page, FrameLayout);

//        setContentView(R.layout.activity_group_product_listing_page);
        mInit();
        preferences=PreferenceManager.getDefaultSharedPreferences(this);
        groupId=preferences.getString("groupId","");
        instance=GroupProductListingPage.this;
        getAllWidgets();
        bindWidgetsWithAnEvent();
        setupTabLayout();
    }
    private void mInit() {

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "GroupProductListingPage";


        changeLocationText=(TextView)findViewById(R.id.current_location);
        commonFooter=(LinearLayout)findViewById(R.id.footer);
        groupFooter=(LinearLayout)findViewById(R.id.group_footer);
        groupNameHeading=(TextView)findViewById(R.id.group_name);
        backIcon=(ImageView)findViewById(R.id.back_icon);
        groupFooter.setVisibility(View.VISIBLE);
        commonFooter.setVisibility(View.INVISIBLE);
        groupNameHeading.setText(Constant.groupName);
        backIcon.setOnClickListener(this);

    }

    public static GroupProductListingPage getInstance() {
        return instance;
    }
    private void getAllWidgets() {
        allTabs = (TabLayout) findViewById(R.id.tabs);

    }
    private void setupTabLayout() {
        searchProductName=preferences.getString("SearchProductName","");

        if(searchProductName!=null && !searchProductName.isEmpty()) {
            String[] splitsearchProductName = searchProductName.split("for");
            searchProductType = splitsearchProductName[1].trim();
        }
        fragmentOne = new GroupProductListFragment();
        fragmentTwo=new GroupProductListFragment();
        fragmentThree=new GroupProductListFragment();
        fragmentFour=new GroupProductListFragment();

        if(searchProductName==null || searchProductName.isEmpty()) {
            allTabs.addTab(allTabs.newTab().setText("Borrow"), true);
            allTabs.addTab(allTabs.newTab().setText("Rent"), false);
            allTabs.addTab(allTabs.newTab().setText("Buy"), false);
            allTabs.addTab(allTabs.newTab().setText("Giveaway"), false);

            tab =allTabs.getTabAt(0);
            tab.select();
            setCurrentTabFragment(0);
        }else if(searchProductType!=null && searchProductType.equalsIgnoreCase("Lend")){
            allTabs.addTab(allTabs.newTab().setText("Borrow"), true);
            allTabs.addTab(allTabs.newTab().setText("Rent"), false);
            allTabs.addTab(allTabs.newTab().setText("Buy"), false);
            allTabs.addTab(allTabs.newTab().setText("Giveaway"), false);
            tab =allTabs.getTabAt(0);
            tab.select();
            setCurrentTabFragment(0);
        }else if(searchProductType!=null && searchProductType.equalsIgnoreCase("Rent")){
            allTabs.addTab(allTabs.newTab().setText("Borrow"), false);
            allTabs.addTab(allTabs.newTab().setText("Rent"), true);
            allTabs.addTab(allTabs.newTab().setText("Buy"), false);
            allTabs.addTab(allTabs.newTab().setText("Giveaway"), false);
            tab =allTabs.getTabAt(1);
            tab.select();
            setCurrentTabFragment(1);
        }else if(searchProductType!=null && searchProductType.equalsIgnoreCase("Sell")){
            allTabs.addTab(allTabs.newTab().setText("Borrow"), false);
            allTabs.addTab(allTabs.newTab().setText("Rent"), false);
            allTabs.addTab(allTabs.newTab().setText("Buy"), true);
            allTabs.addTab(allTabs.newTab().setText("Giveaway"), false);
            tab =allTabs.getTabAt(2);
            tab.select();
            setCurrentTabFragment(2);
        }else if(searchProductType!=null && searchProductType.equalsIgnoreCase("Gift")){
            allTabs.addTab(allTabs.newTab().setText("Borrow"), false);
            allTabs.addTab(allTabs.newTab().setText("Rent"), false);
            allTabs.addTab(allTabs.newTab().setText("Buy"), false);
            allTabs.addTab(allTabs.newTab().setText("Giveaway"), true);
            tab =allTabs.getTabAt(3);
            tab.select();
            setCurrentTabFragment(3);
        }


    }
    private void bindWidgetsWithAnEvent()
    {
        allTabs.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                setCurrentTabFragment(tab.getPosition());
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {


            }
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
    }
    private void setCurrentTabFragment(int tabPosition)
    {
        switch (tabPosition)
        {
            case 0 :
                transType="1";
                updateTransType(transType,groupId);
                replaceFragment(fragmentOne);
                Constant.groupProductListingDtos.clear();
                Constant.groupListCurrentPage = 0;
                break;
            case 1 :
                transType="2";
                updateTransType(transType,groupId);
                replaceFragment(fragmentTwo);
                Constant.groupProductListingDtos.clear();
                Constant.groupListCurrentPage = 0;
                break;
            case 2 :
                transType="3";
                updateTransType(transType,groupId);
                replaceFragment(fragmentThree);
                Constant.groupProductListingDtos.clear();
                Constant.groupListCurrentPage = 0;
                break;
            case 3 :
                transType="4";
                updateTransType(transType,groupId);
                replaceFragment(fragmentFour);
                Constant.groupProductListingDtos.clear();
                Constant.groupListCurrentPage = 0;
                break;
        }
    }

    private void updateTransType(String transType,String groupId) {
        SharedPreferences.Editor e = preferences.edit();
        e.putString("transType", transType);
        e.putString("groupId",groupId);
        e.commit();
    }

    public void replaceFragment(Fragment fragment) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.frame_container, fragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.commit();
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
        Constant.currentActivity="HomeScreen";
    }

    @Override
    public void onClick(View v) {
        Constant.currentActivity="HomeScreen";
        finish();
    }
    @Override
    public void onResume(){
        super.onResume();
        instance=GroupProductListingPage.this;

    }
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(GroupProductListingPage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(GroupProductListingPage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(GroupProductListingPage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(GroupProductListingPage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(GroupProductListingPage.this, ChangeLocationPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChatMessageActivity")){
//            startActivity(new Intent(GroupProductListingPage.this, ChatMessageActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(GroupProductListingPage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(GroupProductListingPage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(GroupProductListingPage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(GroupProductListingPage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(GroupProductListingPage.this, AddGroupActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(GroupProductListingPage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(GroupProductListingPage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(GroupProductListingPage.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(GroupProductListingPage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(GroupProductListingPage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(GroupProductListingPage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(GroupProductListingPage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(GroupProductListingPage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(GroupProductListingPage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(GroupProductListingPage.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(GroupProductListingPage.this, HomeScreen.class));
//            finish();
//        }
//
//    }

}
