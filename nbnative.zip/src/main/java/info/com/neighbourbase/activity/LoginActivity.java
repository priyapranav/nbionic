package info.com.neighbourbase.activity;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.MemberDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.DBHelper;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{
    TextInputLayout layoutEmail, layoutPassword;
    EditText inputEmail, inputPassword;
    Button btnLogin,alertMsgOkBtn;
    String strInputPassword, strInputEmail;
    TextView signUpText, forgotPwdText,alertMessageText;
    SharedPreferences preferences;
    Dialog customDialog;
    int permissionCheck, permissionCheck1, permissionCheck2, permissionCheck3;
    boolean doubleBackToExitPressedOnce = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        loginCheck();
        setContentView(R.layout.activity_login);
        mInit();

        /************ This Permission is for, above lollipop version have to ask Self Permission programmatically *****************/
        permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        permissionCheck1 = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        permissionCheck2 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        permissionCheck3 = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE);

        if (permissionCheck != PackageManager.PERMISSION_GRANTED && permissionCheck1 != PackageManager.PERMISSION_GRANTED && permissionCheck2 != PackageManager.PERMISSION_GRANTED && permissionCheck3 != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE}, 0);
        }else if(permissionCheck != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 0);
        }
        else if(permissionCheck1 != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 0);
        }
        else if(permissionCheck2 != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        }
        else if(permissionCheck3 != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, 0);
        }
    }


    private void loginCheck() {
        String memberId = preferences.getString("memberId","");
        if(memberId!=null && (!memberId.isEmpty())){
            if (getIntent().getExtras() != null && getIntent().getExtras().getInt("memberId")!=0) {
                System.out.println("Back Ground Msg "+ getIntent().getExtras().getString("time"));
                Integer memberId1 = getIntent().getExtras().getInt("memberId");
                    String timestamp = getIntent().getExtras().getString("time");
                    if(getIntent().getExtras().getInt("inviteFlag")==0) {
                        String message = "You have received a new message, check your message box, if you have not seen.";
                        DBHelper dbHelper = new DBHelper(getApplicationContext());
                        boolean insert = dbHelper.insertMessage(memberId1, message, timestamp);
                        System.out.println("Insert " + insert);
                        startActivity(new Intent(LoginActivity.this, NotificationMessage.class));
                        finish();
                    }else if(getIntent().getExtras().getInt("inviteFlag")==1) {
                        startActivity(new Intent(LoginActivity.this, DashBoardPage.class));
                        finish();
                    }
            }else {
                startActivity(new Intent(LoginActivity.this, HomeScreen.class));
                finish();
            }
        }
    }

    private void mInit() {
        layoutEmail = (TextInputLayout) findViewById(R.id.input_layout_email);
        inputEmail = (EditText) findViewById(R.id.input_email);
        layoutPassword = (TextInputLayout) findViewById(R.id.input_layout_password);
        inputPassword = (EditText) findViewById(R.id.input_password);
        btnLogin = (Button)findViewById(R.id.btn_login);
        signUpText = (TextView) findViewById(R.id.sign_up);
        forgotPwdText = (TextView) findViewById(R.id.forgot_password);

        btnLogin.setOnClickListener(this);
        signUpText.setOnClickListener(this);
        forgotPwdText.setOnClickListener(this);

        /*inputEmail.setText("pri@gmail.com");
        inputPassword.setText("s");*/

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_login:
                if(checkLoginValidation()){
                    if(Connectivity.isConnected(LoginActivity.this)){
                        strInputPassword=inputPassword.getText().toString().trim();
                        strInputEmail=inputEmail.getText().toString().trim();
                       //startActivity(new Intent(LoginActivity.this,HomeScreen.class));
                     new getLoginResult().execute();
                    }else{
                        Toast.makeText(LoginActivity.this, "Please Check Internet Connection", Toast.LENGTH_LONG).show();
                    }
                }
               // startActivity(new Intent(LoginActivity.this,HomeScreen.class));

                break;

            case R.id.sign_up:
                startActivity(new Intent(LoginActivity.this,SignUpActivity.class));
                break;

            case R.id.forgot_password:
                if(checkEmailValidation()){
                    strInputEmail=inputEmail.getText().toString().trim();

                   new forgotPassword().execute();

                }
                break;
        }
    }



    public class getLoginResult extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(LoginActivity.this);
            progressDialog.setMessage("Logging in...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"loginValidate.json?email="+strInputEmail+"&password="+strInputPassword);
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            progressDialog.dismiss();

            if(result!=null&&result.length()!=0)
            {
                result.trim();

                try {
                    JSONObject jsonObject=new JSONObject(result);
                    String status=jsonObject.optString("status", "");
                    status.trim();
                    System.out.println(status);
                    if(status.equals("success")){
                        Constant.categoryId = 0;
                        JSONObject memberDtoObj=jsonObject.getJSONObject("memberDto");
                        Gson gson=new Gson();

                        MemberDto memberDto=gson.fromJson(memberDtoObj.toString().trim(),MemberDto.class);
                        System.out.println(memberDto.getMemberId());
                        updateMemberId(memberDto.getMemberId(),memberDto.getLatitude(),memberDto.getLongitude(),memberDto.getPincode(),memberDto.getAddress(),memberDto.getSearchRadius(),memberDto.getArea(),memberDto.getFirstName(),memberDto.getLastName(),memberDto.getContactNumber(),memberDto.getEmail(),memberDto.getPicture(),memberDto.getPassword(),memberDto.getAboutMe());

                        if (getIntent().getExtras() != null && getIntent().getExtras().getInt("memberId")!=0) {
                            Integer memberId1 = getIntent().getExtras().getInt("memberId");
                            String timestamp = getIntent().getExtras().getString("time");
                            String message = "You have received a new message, check your message box, if you have not seen.";
                            DBHelper dbHelper = new DBHelper(getApplicationContext());
                            boolean insert = dbHelper.insertMessage(memberId1, message, timestamp);
                            System.out.println("Insert " + insert);
                            startActivity(new Intent(LoginActivity.this, NotificationMessage.class));
                            finish();
                        }else {
                            startActivity(new Intent(LoginActivity.this, HomeScreen.class));
                            finish();
                        }

                    }else if(status.equals("USERNAME")){
                        callAlertDialog("Incorrect UserEmail, Give Valid UserEmail");
                    }else if(status.equals("PASSWORD")){
                        callAlertDialog("Incorrect Password, Give Valid Password");
                    }else {
                        callAlertDialog("Invalid Login");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }else {
                callAlertDialog("Server Down... Please try again");
            }


        }
    }
    public class forgotPassword extends AsyncTask<String,String,String>{
    ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(LoginActivity.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"forgotpassword.json?email="+strInputEmail);
            System.out.println(result);
            return result.trim();
        }
        protected void onPostExecute(String res){
            super.onPostExecute(res);
            progressDialog.dismiss();
            if(res!=null){

                try {
                    JSONObject jsonObject=new JSONObject(res);
                    String status=jsonObject.optString("status");
                    if(status.equals("success")){
                        callAlertDialog("Will Send Password To Your Email");
                    }else {
                        callAlertDialog("Give Valid UserEmail");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //  System.out.println(jsonObject);
//                    String result=jsonObject.optString("result", "");
//                    result.trim();
//                    System.out.println(result);
//                if(res.equals("true")){
//
////                    final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
////                            LoginActivity.this);
////
////                    alertDialogBuilder.setTitle("Neighbourbase");
////                    alertDialogBuilder.setCancelable(true);
////                    alertDialogBuilder
////                            .setMessage(
////                                    "Will Send Password To Your Email")
////                            .setCancelable(false)
////                            .setPositiveButton("OK",
////                                    new DialogInterface.OnClickListener() {
////                                        public void onClick(DialogInterface dialog,
////                                                            int id) {
////                                            dialog.cancel();
////
////                                        }
////
////                                    });
////
////                    AlertDialog alertDialog = alertDialogBuilder.create();
////
////                    alertDialog.show();
//                }else if(res.equals("false")){
//                    final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
//                            LoginActivity.this);
//
//                    alertDialogBuilder.setTitle("Neighbourbase");
//                    alertDialogBuilder.setCancelable(true);
//                    alertDialogBuilder
//                            .setMessage(
//                                    "Give Valid UserEmail")
//                            .setCancelable(false)
//                            .setPositiveButton("OK",
//                                    new DialogInterface.OnClickListener() {
//                                        public void onClick(DialogInterface dialog,
//                                                            int id) {
//                                            dialog.cancel();
//
//                                        }
//
//                                    });
//
//                    AlertDialog alertDialog = alertDialogBuilder.create();
//                    alertDialog.show();
//                }
//
            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(LoginActivity.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }
    private boolean checkLoginValidation() {
        boolean valueReturn = true;
        if (!Validation.hasText(inputEmail, layoutEmail))
            valueReturn = false;
        if(!Validation.isEmailAddress(inputEmail,layoutEmail,true))
            valueReturn=false;
        if (!Validation.hasText(inputPassword, layoutPassword))
            valueReturn = false;

        return valueReturn;
    }

    private boolean checkEmailValidation() {
        boolean valueReturn = true;
        if (!Validation.hasText(inputEmail, layoutEmail))
            valueReturn = false;

        if(!Validation.isEmailAddress(inputEmail,layoutEmail,true))
            valueReturn=false;
        return valueReturn;
    }
    public void updateMemberId(long memberId, double latitude, double longitude, int pincode, String address, double searchRadius,String area, String firstName, String lastName, long contactNumber, String email, String picture, String password, String aboutMe){

        SharedPreferences.Editor e = preferences.edit();

        e.putString("memberId",String.valueOf( memberId));
        e.putString("latitude", String.valueOf(latitude));
        e.putString("longitude", String.valueOf(longitude));
        e.putString("pincode", String.valueOf(pincode));
        e.putString("address",address);
        e.putString("radius", String.valueOf(searchRadius));
        e.putString("area",area);
        e.putString("firstName",firstName);
        e.putString("lastName",lastName);
        e.putString("contactNumber", String.valueOf(contactNumber));
        e.putString("email",email);
        e.putString("picture",picture);
        e.putString("password",password);
        e.putString("aboutMe",aboutMe);

        e.commit();
    }

    @Override
    public void onBackPressed() {

        if (doubleBackToExitPressedOnce) {

            Intent startMain = new Intent(Intent.ACTION_MAIN);
            startMain.addCategory(Intent.CATEGORY_HOME);
            startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(startMain);
            return;
        }

        this.doubleBackToExitPressedOnce = true;

        Toast.makeText(this, "click again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;

            }
        }, 2000);

    }
}
