package info.com.neighbourbase.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.MemberDto;
import info.com.neighbourbase.model.NetworkDto;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

import static info.com.neighbourbase.activity.Header.messageCount;

public class AddGroupActivity extends CommonHeader implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    private static final String TAG_RESULT = "predictions";
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    EditText groupName, groupDetails, apartNameOrganizationName;
    AutoCompleteTextView groupAddress;
    String[] spinnerText={"Apartment/Residential","Others"};
    Button  groupSubmitBtn, groupCancelBtn,alertMsgOkBtn;
    Spinner groupTypeSpinner;
    TextView alertMessageText;
    ImageView groupImage,addImageIcon;
    SharedPreferences preferences;
    byte[] groupImgByteArray;
    String url,groupTyprStr,latitude,longitude,pincode,zip,reqData,memberId,memberArea,address,strAddress,city;
    ArrayAdapter<String> arrayAdapter,spinnerAdapter;
    ArrayList<String> area;
    NetworkDto networkDto=new NetworkDto();
    Dialog customDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.add_group_page);

        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.add_group_page, FrameLayout);
        mInit();

        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        address=preferences.getString("address","");
        latitude=preferences.getString("latitude","");
        longitude=preferences.getString("longitude","");
        pincode=preferences.getString("pincode","");
        memberId=preferences.getString("memberId","");
        memberArea=preferences.getString("area","");
        groupAddress.setText(address);
        spinnerAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,spinnerText);
        groupTypeSpinner.setAdapter(spinnerAdapter);
        groupAddress.addTextChangedListener(textWatcher);
        addImageIcon.setOnClickListener(this);
        groupCancelBtn.setOnClickListener(this);
        groupSubmitBtn.setOnClickListener(this);
        groupTypeSpinner.setOnItemSelectedListener(this);
    }

    private void mInit() {

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "AddGroupActivity";

        groupName = (EditText) findViewById(R.id.group_name);
        groupDetails = (EditText) findViewById(R.id.group_details);
        apartNameOrganizationName = (EditText) findViewById(R.id.apartName_organName);
        addImageIcon = (ImageView) findViewById(R.id.add_image_icon);
        groupSubmitBtn = (Button) findViewById(R.id.add_group_submit);
        groupCancelBtn = (Button) findViewById(R.id.add_group_cancel);
        groupTypeSpinner = (Spinner) findViewById(R.id.group_type_spinner);
        groupAddress = (AutoCompleteTextView) findViewById(R.id.group_address);
        groupImage=(ImageView)findViewById(R.id.group_image);


    }

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            StringBuilder sb=new StringBuilder(Webconfig.GOOGLE_PLACE);
            try {
                sb.append("&input=" + URLEncoder.encode(groupAddress.getText().toString(), "utf8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            url=sb.toString();
            area=new ArrayList<String>();
            new googleAutoComplete().execute();
            strAddress=groupAddress.getText().toString();
            new getLatLongDetails().execute();

        }
    };
    private class getLatLongDetails extends AsyncTask<String,String,String>{
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String locationAddress = strAddress.replaceAll(" ", "%20");
            String result=httpConfig.httppost("http://maps.googleapis.com/maps/api/geocode/json?address="+locationAddress+"&sensor=true_or_false");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String status = jsonObject.optString("status");
                    if (status.equals("OK")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("results");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObjResult = jsonArray.getJSONObject(i);
                            JSONArray addCompoArray = jsonObjResult.getJSONArray("address_components");
                            for (int j = 0; j < addCompoArray.length(); j++) {
                                JSONObject jsonObjAddCompo = addCompoArray.getJSONObject(j);
                                JSONArray jsonArrayType = jsonObjAddCompo.getJSONArray("types");
                                for (int k = 0; k < jsonArrayType.length(); k++) {
                                    String type = jsonArrayType.getString(k);
                                    if (type.equals("postal_code")) {
                                        try{
                                            pincode = jsonObjAddCompo.optString("long_name");
                                        }catch (NumberFormatException ex) {
                                            pincode="0";
                                        }

                                    } else {
                                        pincode ="0";
                                    }
                                    if (type.equals("sublocality_level_1")){
                                        memberArea=jsonObjAddCompo.optString("long_name");
                                    }
                                    if (type.equals("locality")){
                                        city=jsonObjAddCompo.optString("long_name");
                                    }

                                }
                            }
                            JSONObject jsonObjGeometry = jsonObjResult.getJSONObject("geometry");
                            JSONObject jsonObjLocation = jsonObjGeometry.getJSONObject("location");
                            latitude = jsonObjLocation.optString("lat");
                            longitude =jsonObjLocation.optString("lng");

                        }

                    }else if(status.equals("INVALID_REQUEST")){
                        callAlertDialog("Please Give Correct Address Detail");
                    }

                }catch(JSONException e){
                    e.printStackTrace();
                }


            }



        }
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.add_image_icon:
                selectImage();
                break;
            case R.id.add_group_cancel:
                startActivity(new Intent(AddGroupActivity.this,HomeScreen.class));
                break;
            case R.id.add_group_submit:
                if(checkAddListingValidation()){
                    if (groupImage.getVisibility()==View.GONE||groupImage.getDrawable().getConstantState()==getResources().getDrawable(R.drawable.no_image).getConstantState()) {
                        customDialog = new Dialog(AddGroupActivity.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setText(getResources().getString(R.string.alert_msg_yes));
                        alertMessageText.setText(getResources().getString(R.string.add_group_not_attach_photo_alert));
                        customDialog.setCancelable(true);
                        alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                customDialog.dismiss();
                                if(groupTyprStr.equals("Others")){
                                    networkDto.setNetworkTypeId(4);
                                }else{
                                    networkDto.setNetworkTypeId(1);
                                }
                                if (memberArea.length()==0)
                                    memberArea=city;
                                networkDto.setName(groupName.getText().toString().trim());
                                networkDto.setNetworkDetails(groupDetails.getText().toString().trim());
                                networkDto.setAddressline1(groupAddress.getText().toString().trim());
                                networkDto.setArea(memberArea);
                                networkDto.setAddressline2(apartNameOrganizationName.getText().toString().trim());
                                networkDto.setLatitude(Double.parseDouble(latitude));
                                networkDto.setLongitude(Double.parseDouble(longitude));
                                networkDto.setPincode(Integer.parseInt(pincode));
                                networkDto.setMemberId(Long.parseLong(memberId));
                                networkDto.setNetworkImage(groupImgByteArray);
                                reqData=new Gson().toJson(networkDto);
                                new getSubmitResponse().execute();
                            }
                        });
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

//                        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
//                                AddGroupActivity.this);
//
//                        alertDialogBuilder.setTitle("Neighbourbase");
//                        alertDialogBuilder.setCancelable(true);
//                        alertDialogBuilder
//                                .setMessage(
//                                        "You haven't attached a photo. Do you want to proceed anyway?")
//                                .setCancelable(false)
//                                .setPositiveButton("NO",
//                                        new DialogInterface.OnClickListener() {
//                                            public void onClick(DialogInterface dialog,
//                                                                int id) {
//                                                dialog.cancel();
//                                            }
//                                        }).setNegativeButton("YES",
//                                new DialogInterface.OnClickListener() {
//                                    public void onClick(DialogInterface dialog,
//                                                        int id) {
//                                        if(groupTyprStr.equals("Others")){
//                                            networkDto.setNetworkTypeId(4);
//                                        }else{
//                                            networkDto.setNetworkTypeId(1);
//                                        }
//                                        networkDto.setName(groupName.getText().toString());
//                                        networkDto.setNetworkDetails(groupDetails.getText().toString());
//                                        networkDto.setAddressline1(groupAddress.getText().toString());
//                                        networkDto.setArea(memberArea);
//                                        networkDto.setAddressline2(apartNameOrganizationName.getText().toString());
//                                        networkDto.setLatitude(Double.parseDouble(latitude));
//                                        networkDto.setLongitude(Double.parseDouble(longitude));
//                                        networkDto.setPincode(Integer.parseInt(pincode));
//                                        networkDto.setMemberId(Long.parseLong(memberId));
//                                        networkDto.setNetworkImage(groupImgByteArray);
//                                        reqData=new Gson().toJson(networkDto);
//                                        new getSubmitResponse().execute();
//                                    }
//                                });
//
//                        AlertDialog alertDialog = alertDialogBuilder.create();
//
//                        alertDialog.show();
                    }else{
                        if(groupTyprStr.equals("Others")){
                            networkDto.setNetworkTypeId(4);
                        }else{
                            networkDto.setNetworkTypeId(1);
                        }
                        if (memberArea.length()==0)
                            memberArea=city;
                        networkDto.setName(groupName.getText().toString().trim());
                        networkDto.setNetworkDetails(groupDetails.getText().toString().trim());
                        networkDto.setAddressline1(groupAddress.getText().toString().trim());
                        networkDto.setArea(memberArea);
                        networkDto.setAddressline2(apartNameOrganizationName.getText().toString().trim());
                        networkDto.setLatitude(Double.parseDouble(latitude));
                        networkDto.setLongitude(Double.parseDouble(longitude));
                        networkDto.setPincode(Integer.parseInt(pincode));
                        networkDto.setMemberId(Long.parseLong(memberId));
                        networkDto.setNetworkImage(groupImgByteArray);
                        reqData=new Gson().toJson(networkDto);
                        new getSubmitResponse().execute();
                    }
                }
                break;
        }
    }



    private boolean checkAddListingValidation() {
        boolean valueReturn = true;
        if (!Validation.hasText(groupName))
            valueReturn = false;
        if (!Validation.hasText(groupDetails))
            valueReturn = false;
        if (!Validation.hasText(groupAddress))
            valueReturn = false;
        return valueReturn;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        groupTyprStr=groupTypeSpinner.getSelectedItem().toString().trim();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    // ******** Google place auto complete *******


    private class googleAutoComplete extends AsyncTask<Void,Integer,Void> {
        @Override
        protected Void doInBackground(Void... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(url);

            if(result !=null)
            {
                try {
                    // Getting Array of Contacts

                    JSONObject json=new JSONObject(result);
                    JSONArray googlePlace=json.getJSONArray(TAG_RESULT);

                    for(int i = 0; i < googlePlace.length(); i++){
                        JSONObject c = googlePlace.getJSONObject(i);
                        String description = c.getString("description");
                        Log.d("description", description);
                        area.add(description);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                    android.R.layout.simple_list_item_1, area) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    View view = super.getView(position, convertView, parent);
                    TextView text = (TextView) view.findViewById(android.R.id.text1);
                    text.setTextColor(Color.BLACK);
                    return view;
                }
            };


            groupAddress.setAdapter(arrayAdapter);
            String strAddress=groupAddress.getText().toString();
            /*Geocoder coder = new Geocoder(AddGroupActivity.this);
            try {
                ArrayList<Address> adresses = (ArrayList<Address>) coder.getFromLocationName(strAddress, 50);
                for(Address add : adresses){
                    //Controls to ensure it is right address such as country etc.
                    longitude = String.valueOf(add.getLongitude());
                    latitude = String.valueOf(add.getLatitude());
                    zip=add.getPostalCode();
                    zip=pincode;
                    memberArea=add.getSubLocality();

                    //latLng.setText("("+String.valueOf(longitude)+" ,  "+String.valueOf(latitude)+")"+zip);

                }
            } catch (IOException e) {
                e.printStackTrace();
            }*/

        }
    }

    // **************** Capture Product Image ***************************
    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Library","No Image","Cancel"};

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(AddGroupActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {


                if (items[item].equals("Take Photo")) {
                    cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    galleryIntent();

                }  else if (items[item].equals("No Image")) {
                    groupImage.setVisibility(View.VISIBLE);
                    groupImage.setImageResource(R.drawable.no_image);
                    groupImgByteArray=null;


                } else if (items[item].equals("Cancel")) {
                    groupImage.setVisibility(View.GONE);
                    groupImgByteArray=null;
                    dialog.dismiss();

                }
            }
        });
        builder.show();
    }

    private void galleryIntent()
    {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }

    private void cameraIntent()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        String picturePath=destination.getPath();
        thumbnail=changeOrientation(picturePath,thumbnail);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        groupImgByteArray= bytes.toByteArray();
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        groupImage.setVisibility(View.VISIBLE);
        groupImage.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Uri selectedImageUri = data.getData();
        String picturePath= getRealPathFromURI(selectedImageUri);
        Bitmap bm=null;
        if (data!= null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        try {

            InputStream imageStream = getContentResolver().openInputStream(selectedImageUri);
            Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);

            selectedImage = getResizedBitmap(selectedImage, 400);// 400 is for example, replace with desired size

            selectedImage= changeOrientation(picturePath,selectedImage);
            groupImage.setVisibility(View.VISIBLE);
            groupImage.setImageBitmap(selectedImage);
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            selectedImage.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
            groupImgByteArray= bytes.toByteArray();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    public String getRealPathFromURI(Uri contentUri) {
        String [] proj={MediaStore.Images.Media.DATA};
        Cursor cursor = managedQuery( contentUri, proj, null, null, null); // Order-by clause (ascending by name)
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String path= cursor.getString(column_index);
        return path;

    }
    private Bitmap changeOrientation(String picturePath, Bitmap loadedBitmap) {
        if(picturePath!=null) {
            ExifInterface exif = null;
            try {
                File pictureFile = new File(picturePath);
                exif = new ExifInterface(pictureFile.getAbsolutePath());
            } catch (IOException e) {
                e.printStackTrace();
            }

            int orientation = ExifInterface.ORIENTATION_NORMAL;

            if (exif != null)
                orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    loadedBitmap = rotateBitmap(loadedBitmap, 90);
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    loadedBitmap = rotateBitmap(loadedBitmap, 180);
                    break;

                case ExifInterface.ORIENTATION_ROTATE_270:
                    loadedBitmap = rotateBitmap(loadedBitmap, 270);
                    break;
            }
        }
        return loadedBitmap;
    }


    public static Bitmap rotateBitmap(Bitmap bitmap, int degrees) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    // **************** Capture Product Image method finished ***************************
    private class getSubmitResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(AddGroupActivity.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData,Webconfig.CONTEXT_PATH+"createnetwork.json");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            JSONObject jsonObject=null;
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status","");
                    Constant.messageUnreadCount = jsonObject.getLong("unreadCount");
                    CommonHeader.messageCount.setText(String.valueOf(Constant.messageUnreadCount));
                    if(status.equals("success")){
                        customDialog = new Dialog(AddGroupActivity.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setVisibility(View.GONE);
                        alertMessageText.setText(getResources().getString(R.string.group_create_success_msg));
                        customDialog.setCancelable(true);
                        customDialog.setCanceledOnTouchOutside(true);
                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        customDialog.dismiss();
                                        finish();
                                    }
                                }
                        );
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                    }else if(status.equals("exists")){
                        callAlertDialog("Group with this name already exists");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
            else
            {
                callAlertDialog("Server Down... Please try again");
            }
        }
    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(AddGroupActivity.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(AddGroupActivity.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(AddGroupActivity.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(AddGroupActivity.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(AddGroupActivity.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(AddGroupActivity.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(AddGroupActivity.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(AddGroupActivity.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(AddGroupActivity.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(AddGroupActivity.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(AddGroupActivity.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(AddGroupActivity.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(AddGroupActivity.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(AddGroupActivity.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(AddGroupActivity.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(AddGroupActivity.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(AddGroupActivity.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(AddGroupActivity.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(AddGroupActivity.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(AddGroupActivity.this, ViewPage.class));
//            finish();
//        } else if(Constant.previousActivity.equalsIgnoreCase("MorePage")){
//            startActivity(new Intent(AddGroupActivity.this, MorePage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ReminderPage")){
//            startActivity(new Intent(AddGroupActivity.this, ReminderPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("DashBoardPage")){
//            startActivity(new Intent(AddGroupActivity.this, DashBoardPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePage")){
//            startActivity(new Intent(AddGroupActivity.this, ProfilePage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(AddGroupActivity.this, HomeScreen.class));
//            finish();
//        }
//
//    }


    private void callAlertDialog(String message) {

        customDialog = new Dialog(AddGroupActivity.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }
}