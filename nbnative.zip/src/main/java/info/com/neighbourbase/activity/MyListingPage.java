package info.com.neighbourbase.activity;

import android.app.ActivityManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import info.com.neighbourbase.R;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class MyListingPage extends CommonHeader {
    String transType,memberId,groupName;
    ArrayList<Long> networkId=new ArrayList<>();
    public static MyListingPage instance;
    private MyListingFragment fragmentOne,fragmentTwo,fragmentThree,fragmentFour;
    TextView heading;
    TabLayout tabLayout;
    TabLayout.Tab tab = null;
    int check = 0;
    String userSelectedGroupId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_my_listing_page);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_my_listing_page, FrameLayout);

        mInit();

        instance=MyListingPage.this;
        bindWidgetsWithAnEvent();
        setupTabLayout();
    }

    private void mInit() {

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "MyListingPage";
        heading=(TextView)findViewById(R.id.heading);

        memberId = CommonHeader.memberId;
        tabLayout=(TabLayout)findViewById(R.id.tabs);
        if(Constant.myListGroupId!=null){
            userSelectedGroupId = Constant.myListGroupId;
        }
        if(Constant.myListGroupName!=null){
            groupName=Constant.myListGroupName;
        }
        heading.setText(getResources().getString(R.string.my_listing)+" - "+groupName);

    }

    public static MyListingPage getInstance() {
        return instance;
    }


    private void setupTabLayout() {

        fragmentOne = new MyListingFragment();
        fragmentTwo=new MyListingFragment();
        fragmentThree=new MyListingFragment();
        fragmentFour=new MyListingFragment();

        tabLayout.addTab(tabLayout.newTab().setText("LEND"),true);
        tabLayout.addTab(tabLayout.newTab().setText("RENT"),false);
        tabLayout.addTab(tabLayout.newTab().setText("SELL"),false);
        tabLayout.addTab(tabLayout.newTab().setText("GIVEAWAY"),false);

        TabLayout.Tab tab = tabLayout.getTabAt(0);
        tab.select();
        setCurrentTabFragment(0);

    }
    private void bindWidgetsWithAnEvent()
    {
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                setCurrentTabFragment(tab.getPosition());
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {


            }
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
    }
    private void setCurrentTabFragment(int tabPosition)
    {
        switch (tabPosition)
        {
            case 0 :
                transType="1";
                updateTransType(transType,userSelectedGroupId);
                replaceFragment(fragmentOne);
                Constant.myListingProductListingDtos.clear();
                Constant.myListCurrentPage = 0;
                break;
            case 1 :
                transType="2";
                updateTransType(transType,userSelectedGroupId);
                replaceFragment(fragmentTwo);
                Constant.myListingProductListingDtos.clear();
                Constant.myListCurrentPage = 0;
                break;
            case 2 :
                transType="3";
                updateTransType(transType,userSelectedGroupId);
                replaceFragment(fragmentThree);
                Constant.myListingProductListingDtos.clear();
                Constant.myListCurrentPage = 0;
                break;
            case 3 :
                transType="4";
                updateTransType(transType,userSelectedGroupId);
                replaceFragment(fragmentFour);
                Constant.myListingProductListingDtos.clear();
                Constant.myListCurrentPage = 0;
                break;
        }
    }

    private void updateTransType(String transType, String userSelectedGroupId) {
        SharedPreferences.Editor e = preferences.edit();
        e.putString("myListTransType", transType);
        e.putString("myListNetworkId", userSelectedGroupId);
        e.commit();
    }

    public void replaceFragment(Fragment fragment) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.frame_container, fragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.commit();
    }


    @Override
    public void onResume(){
        super.onResume();
       instance=MyListingPage.this;

    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(MyListingPage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(MyListingPage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(MyListingPage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(MyListingPage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(MyListingPage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(MyListingPage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(MyListingPage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(MyListingPage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(MyListingPage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(MyListingPage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(MyListingPage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(MyListingPage.this, MessageActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(MyListingPage.this, AddGroupActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(MyListingPage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(MyListingPage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(MyListingPage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(MyListingPage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(MyListingPage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(MyListingPage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(MyListingPage.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(MyListingPage.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
