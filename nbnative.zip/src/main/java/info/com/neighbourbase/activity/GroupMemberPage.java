package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Network;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.Adapter.GroupMemberAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.NetworkMemberDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class GroupMemberPage extends CommonHeader {
    ListView groupMemberList;
    TextView totalMember;
    int primaryFlag;
    String memberId,groupId;
    SharedPreferences preferences;
    LinearLayout commonFooter,groupFooter;
    NetworkMemberDto networkMemberDto=new NetworkMemberDto();
    List<NetworkMemberDto> networkMemberDtoList=new ArrayList<>();
    ArrayAdapter groupMemberAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_group_member_page, FrameLayout);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        memberId=preferences.getString("memberId","");
        groupId=preferences.getString("groupId","");
        mInit();
        new getMemberDetails().execute();
    }

    private void mInit() {

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "GroupMemberPage";

        groupMemberList=(ListView)findViewById(R.id.member_list);
        totalMember=(TextView)findViewById(R.id.total_member);
        commonFooter=(LinearLayout)findViewById(R.id.footer);
        groupFooter=(LinearLayout)findViewById(R.id.group_footer);
        groupFooter.setVisibility(View.VISIBLE);
        commonFooter.setVisibility(View.INVISIBLE);
    }

    private class getMemberDetails extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getnetworkdetails.json?networkid="+groupId+"&memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                JSONObject jsonObject=null;
                JSONArray jsonArray=null;
                try {
                    jsonObject=new JSONObject(s);
                    JSONObject privateNetworkDtojsonObj=jsonObject.getJSONObject("privateNetworkDto");
                    Long loggedMemberId= Long.valueOf(privateNetworkDtojsonObj.optString("loggedInMemberId"));
                    jsonArray=privateNetworkDtojsonObj.getJSONArray("networkMemberDtos");
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject networkMemberDtoJsonObj=jsonArray.getJSONObject(i);
                        if(memberId.equals(networkMemberDtoJsonObj.optString("memberId")))
                          primaryFlag = networkMemberDtoJsonObj.optInt("primaryFlag");
                        networkMemberDto=new Gson().fromJson(networkMemberDtoJsonObj.toString().trim(), NetworkMemberDto.class);
                        networkMemberDtoList.add(networkMemberDto);

                    }
                    totalMember.setText(getResources().getString(R.string.total_member)+" :"+networkMemberDtoList.size());
                    groupMemberAdapter=new GroupMemberAdapter(GroupMemberPage.this,networkMemberDtoList,loggedMemberId,primaryFlag);
                    groupMemberList.setAdapter(groupMemberAdapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
               callAlertDialog("Server Down... Please try again");
            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(GroupMemberPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(GroupMemberPage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(GroupMemberPage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(GroupMemberPage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(GroupMemberPage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(GroupMemberPage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(GroupMemberPage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(GroupMemberPage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(GroupMemberPage.this, AddGroupActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(GroupMemberPage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(GroupMemberPage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(GroupMemberPage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(GroupMemberPage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(GroupMemberPage.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(GroupMemberPage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(GroupMemberPage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(GroupMemberPage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(GroupMemberPage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(GroupMemberPage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(GroupMemberPage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(GroupMemberPage.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(GroupMemberPage.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
