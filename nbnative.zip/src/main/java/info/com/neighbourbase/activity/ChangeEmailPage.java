package info.com.neighbourbase.activity;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputLayout;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.MemberDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class ChangeEmailPage extends CommonHeader implements View.OnClickListener {
    EditText changeEmailTxt;
    Button emailReset;
    Button emailVerify;
    TextInputLayout emailLayout;
    MemberDto memberDto=new MemberDto();
    SharedPreferences preferences;
    String emailId;
    String changeEmailTxtStr;
    String reqData;
    String memberId;
    String response;
            

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_change_email_page, frameLayout);

        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        emailId=preferences.getString("email","");
        memberId=preferences.getString("memberId","");
        setCurrentPreviousActivity();

        mInitialize();

    }

    private static void setCurrentPreviousActivity() {
        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "ChangeEmailPage";
    }

    private void mInitialize() {

        backIcon=(ImageView)findViewById(R.id.back_icon);
        changeEmailTxt=(EditText)findViewById(R.id.email_textBox);
        emailReset=(Button)findViewById(R.id.email_reset);
        emailVerify=(Button)findViewById(R.id.verify_mailId);
        emailLayout=(TextInputLayout)findViewById(R.id.input_layout_email);
        changeEmailTxt.setText(emailId);

        emailReset.setOnClickListener(this);
        emailVerify.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.email_reset:
                if (checkValidation()){
                    changeEmailTxtStr=changeEmailTxt.getText().toString();
                    memberDto.setEmail(changeEmailTxtStr);
                    memberDto.setMemberId(Long.parseLong(memberId));
                    reqData=new Gson().toJson(memberDto);
                    new GetResetResponse().execute();
                }

                break;
            case R.id.verify_mailId:
                new GetVerifyEmailResponse().execute();
                break;
        }
    }

    private boolean checkValidation() {
        boolean valueReturn=true;
//        if(!Validation.hasText(changeEmailTxt))
//            valueReturn=false;
        if(!Validation.isEmailAddress(changeEmailTxt,emailLayout,true))
            valueReturn=false;
        return valueReturn;
    }

    private class GetResetResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ChangeEmailPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData, Webconfig.CONTEXT_PATH+"updateemail.json");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            JSONObject jsonObject=null;
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status");
                    if(status.trim().equals("success")){
                        customDialog = new Dialog(ChangeEmailPage.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setVisibility(View.GONE);
                        alertMessageText.setText(getResources().getString(R.string.change_email_success_msg));
                        customDialog.setCancelable(true);
                        customDialog.setCanceledOnTouchOutside(true);
                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        customDialog.dismiss();
                                        logout();
                                        HttpConfig.username = null;
                                        HttpConfig.password = null;
                                        startActivity(new Intent(ChangeEmailPage.this, LoginActivity.class));
                                    }
                                }
                        );
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                    }else if(status.equals("exists")){
                        callAlertDialog("We have the same id in our records");
                    } else if(status.trim().equals("fail")){
                        callAlertDialog("Email can't be changed. please try again..");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
               callAlertDialog("Check your internet connection");
            }
        }
    }

    private void logout() {
        SharedPreferences.Editor e = preferences.edit();

        e.putString("memberId","");
        e.putString("latitude", "");
        e.putString("longitude", "");
        e.putString("pincode", "");
        e.putString("address","");
        e.putString("radius", "");
        e.commit();
    }


    private class GetVerifyEmailResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ChangeEmailPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"sendemailverificationmail.json?memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            if(s!=null){
                if(s.trim().equals("success")){
                   callAlertDialog("verification mail sent, check your Email");
                }else if(s.trim().equals("fail")){
                    callAlertDialog("verification mail sent failed. please try again..");
                }
            }else{
               callAlertDialog("Check your internet connection");
            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(ChangeEmailPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }
}
