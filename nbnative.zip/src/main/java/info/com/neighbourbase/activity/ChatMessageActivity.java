package info.com.neighbourbase.activity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RatingBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import info.com.neighbourbase.Adapter.ChatMessageAdapter;
import info.com.neighbourbase.Adapter.MessageAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.IssuerFeedbackDto;
import info.com.neighbourbase.model.IssuerNoteDto;
import info.com.neighbourbase.model.NotificationThreadDto;
import info.com.neighbourbase.model.ReceiverFeedbackDto;
import info.com.neighbourbase.model.ReceiverNoteDto;
import info.com.neighbourbase.model.RequestDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.RoundedImageView;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

import static info.com.neighbourbase.activity.Header.messageCount;


public class ChatMessageActivity extends AppCompatActivity implements View.OnClickListener {

    LinearLayout backLayout, sendMessage, chatLayout;
    ImageView requesterImageChat, reminderIcon;
    TextView requesterNameChat, alertMessageText, issuerRatingCouting, productRatingCountRecv, buyerRatingText, blockedTextview;
    ListView chatMessageListView;
    List<NotificationThreadDto> notificationThreadDtoList;
    EditText typedMessage, reviewText, issuerReview, productReview, borrowedOn, toBeReturnedOn, returnedOn;
    Button unableToServiceBtn, alertMsgOkBtn, sharedBtn, closedBtn, submit_btn, receiver_feedback_btn, saveReminderBtn;
    SharedPreferences pref;
    String memberId, msgString, buyerRatingStr, reviewTxtStr, issuerData, ownerRatingStr, issuerReviewStr, productRatingStr, productReviewStr, receiverData, ownerReminderData,
            receiverReminderData, sharedOnStr, toBeReturnedOnStr, returnedOnStr;
    long requestStatusId;
    RatingBar buyerRating, ownerRating, productRating;
    IssuerFeedbackDto issuerFeedbackDto;
    ReceiverFeedbackDto receiverFeedbackDto;
    private Calendar calendar;
    private int year, month, day, blockedFlag;
    private PopupWindow pwindo, receiverPwindo;
    IssuerNoteDto issuerNoteDto;
    ReceiverNoteDto receiverNoteDto;
    Dialog remindialog, iFeedbackDialog, rFeedbackDialog, customDialog;
    ToggleButton blockUnblockToggle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_message);

        init();
        if (Connectivity.isConnected(ChatMessageActivity.this)) {
            new getChatMessage().execute();
        } else {
            Toast.makeText(ChatMessageActivity.this, "Please Check Network Connection", Toast.LENGTH_LONG).show();
        }

    }

    private void init() {

        System.out.println("Current tab " + Constant.requestType);
        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "ChatMessageActivity";

        pref = PreferenceManager.getDefaultSharedPreferences(this);
        memberId = pref.getString("memberId", "");
        backLayout = (LinearLayout) findViewById(R.id.back_layout);
        blockUnblockToggle = (ToggleButton) findViewById(R.id.block_unblock_toggle);

        requesterImageChat = (ImageView) findViewById(R.id.requester_image_chat);
        requesterNameChat = (TextView) findViewById(R.id.requester_name_chat);
        chatLayout = (LinearLayout) findViewById(R.id.bottom_layout);
        chatMessageListView = (ListView) findViewById(R.id.chat_message_listview);
        blockedTextview = (TextView) findViewById(R.id.blocked_message);
        reminderIcon = (ImageView) findViewById(R.id.reminder_icon);
        typedMessage = (EditText) findViewById(R.id.type_message);
        sendMessage = (LinearLayout) findViewById(R.id.send_message);
        unableToServiceBtn = (Button) findViewById(R.id.unable_to_service_btn);
        sharedBtn = (Button) findViewById(R.id.shared_btn);
        closedBtn = (Button) findViewById(R.id.closed_btn);
        issuerFeedbackDto = new IssuerFeedbackDto();
        receiverFeedbackDto = new ReceiverFeedbackDto();

        backLayout.setOnClickListener(this);
        sendMessage.setOnClickListener(this);
        unableToServiceBtn.setOnClickListener(this);
        sharedBtn.setOnClickListener(this);
        closedBtn.setOnClickListener(this);
        reminderIcon.setOnClickListener(this);

        issuerNoteDto = new IssuerNoteDto();
        receiverNoteDto = new ReceiverNoteDto();

        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);

        if (Constant.requestType.equalsIgnoreCase("received")) {
            unableToServiceBtn.setText("Unable to service");
            blockUnblockToggle.setVisibility(View.VISIBLE);
        } else if (Constant.requestType.equalsIgnoreCase("sent")) {
            unableToServiceBtn.setText("Cancel My request");
            sharedBtn.setVisibility(View.INVISIBLE);
            closedBtn.setVisibility(View.INVISIBLE);
            blockUnblockToggle.setVisibility(View.GONE);
        }

        blockUnblockToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {

                    if (Connectivity.isConnected(ChatMessageActivity.this)) {
                        new blockMember().execute();
                    } else {
                        Toast.makeText(ChatMessageActivity.this, "Please Check Network Connection", Toast.LENGTH_LONG).show();
                    }
                    /*final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            ChatMessageActivity.this);

                    alertDialogBuilder.setTitle("Neighbourbase");
                    alertDialogBuilder.setCancelable(true);
                    alertDialogBuilder
                            .setMessage(
                                    "Blocking a member will disable all interaction with the member. Do you want to block this member?")
                            .setCancelable(false)
                            .setPositiveButton("Yes",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,
                                                            int id) {
                                            dialog.cancel();
                                            if(Connectivity.isConnected(ChatMessageActivity.this)) {
                                                new blockMember().execute();
                                            }else{
                                                Toast.makeText(ChatMessageActivity.this, "Please Check Network Connection", Toast.LENGTH_LONG).show();
                                            }
                                        }

                                    })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();*/
                } else {
                    new unBlockMember().execute();
                }
            }
        });

        /*blockUnblockToggle.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // Is the toggle on?
                boolean on = ((Switch) v).isChecked();

                if (!on) {
                    // Enable here
                    final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            ChatMessageActivity.this);

                    alertDialogBuilder.setTitle("Neighbourbase");
                    alertDialogBuilder.setCancelable(true);
                    alertDialogBuilder
                            .setMessage(
                                    "Blocking a member will disable all interaction with the member. Do you want to block this member?")
                            .setCancelable(false)
                            .setPositiveButton("Yes",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,
                                                            int id) {
                                            dialog.cancel();
                                            if(Connectivity.isConnected(ChatMessageActivity.this)) {
                                                new blockMember().execute();
                                            }else{
                                                Toast.makeText(ChatMessageActivity.this, "Please Check Network Connection", Toast.LENGTH_LONG).show();
                                            }
                                        }

                                    })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                } else {
                    // Disable here
                    new unBlockMember().execute();
                }

            }
        });*/

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_layout:
                onBackPressed();
                break;

            case R.id.reminder_icon:
                if (Constant.requestType.equalsIgnoreCase("received")) {
                    new getIssuerNote().execute();
                } else if (Constant.requestType.equalsIgnoreCase("sent")) {
                    new getReceiverNote().execute();
                }
                break;

            case R.id.send_message:
                if (checkValidation()) {
                    if (Connectivity.isConnected(ChatMessageActivity.this)) {
                        msgString = typedMessage.getText().toString();
                        new sendMessage().execute();
                    } else {
                        Toast.makeText(ChatMessageActivity.this, "Please Check Network Connection", Toast.LENGTH_LONG).show();
                    }
                }
                break;

            case R.id.unable_to_service_btn:
                customDialog = new Dialog(ChatMessageActivity.this);
                customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customDialog.setContentView(R.layout.custom_messbox);
                alertMessageText = (TextView) customDialog.findViewById(R.id.message_text);
                alertMsgOkBtn = (Button) customDialog.findViewById(R.id.ok_btn);
                alertMsgOkBtn.setText(getResources().getString(R.string.alert_msg_yes));
                alertMessageText.setText(getResources().getString(R.string.do_not_want_service));
                customDialog.setCancelable(true);
                alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customDialog.dismiss();
                        if (Connectivity.isConnected(ChatMessageActivity.this)) {
                            new unableToService().execute();
                        } else {
                            Toast.makeText(ChatMessageActivity.this, "Please Check Network Connection", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                customDialog.show();
                customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                break;

            case R.id.shared_btn:
                if (Connectivity.isConnected(ChatMessageActivity.this)) {
                    requestStatusId = 5;
                    new updateRequestStatus().execute();
                } else {
                    Toast.makeText(ChatMessageActivity.this, "Please Check Network Connection", Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.closed_btn:
                if (Connectivity.isConnected(ChatMessageActivity.this)) {
                    requestStatusId = 7;
                    new updateRequestStatus().execute();
                } else {
                    Toast.makeText(ChatMessageActivity.this, "Please Check Network Connection", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    public class getChatMessage extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;
            if (Constant.requestType.equalsIgnoreCase("received")) {
                result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "getnotificationthreadbyrequestid.json?requestId=" + Constant.requestId + "&isOwner=0");
            } else if (Constant.requestType.equalsIgnoreCase("sent")) {
                result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "getnotificationthreadbyrequestid.json?requestId=" + Constant.requestId + "&isOwner=1");
            }
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            RequestDto requestDto = new RequestDto();
            notificationThreadDtoList = new ArrayList<NotificationThreadDto>();
            List<RequestDto> requestDtoList;
            JSONObject jsonObj, jsonObj1;
            JSONArray jsonArray;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null) {

                try {
                    jsonObj = new JSONObject(res);
                    String status = jsonObj.getString("status");
                    if (status.equalsIgnoreCase("success")) {
                        requestDtoList = new ArrayList<RequestDto>();
                        CommonResponseDto commonResponseDto = gson.fromJson(res, CommonResponseDto.class);
                        requestDtoList = commonResponseDto.getRequestDto();
                        notificationThreadDtoList = commonResponseDto.getNotificationThreadDto();
                        requestStatusId = requestDtoList.get(0).getRequestStatusId();

                        blockedFlag = requestDtoList.get(0).getBlockedFlag();

                        if (Constant.requestType.equalsIgnoreCase("received")) {

                            if (blockedFlag == 0) {
                                blockedTextview.setVisibility(View.GONE);
                                chatMessageListView.setVisibility(View.VISIBLE);
                                chatLayout.setVisibility(View.VISIBLE);
                                blockUnblockToggle.setChecked(false);

                                if (requestStatusId == 5) {
                                    unableToServiceBtn.setVisibility(View.INVISIBLE);
                                    sharedBtn.setVisibility(View.INVISIBLE);
                                    closedBtn.setVisibility(View.VISIBLE);

                                } else if (requestStatusId == 7) {
                                    unableToServiceBtn.setVisibility(View.INVISIBLE);
                                    sharedBtn.setVisibility(View.INVISIBLE);
                                    closedBtn.setVisibility(View.INVISIBLE);
                                    initiatePopupWindow();
                                } else {
                                    reminderIcon.setVisibility(View.GONE);
                                    closedBtn.setVisibility(View.INVISIBLE);
                                    sharedBtn.setVisibility(View.VISIBLE);
                                }

                                if (Constant.transType.equalsIgnoreCase("giveaway")) {
                                    reminderIcon.setVisibility(View.GONE);
                                    sharedBtn.setVisibility(View.INVISIBLE);
                                    closedBtn.setVisibility(View.VISIBLE);
                                }
                                /*else {
                                    reminderIcon.setVisibility(View.VISIBLE);
                                }*/

                                unableToServiceBtn.setText("Unable to service");
                                if (requestDtoList.get(0).getRequesterImage()==null||requestDtoList.get(0).getRequesterImage().equals("No Image")||requestDtoList.get(0).getRequesterImage().equals("")) {
                                    Glide.clear(requesterImageChat);
                                    requesterImageChat.setImageResource(R.drawable.no_image);
                                } else {
                                    Glide.with(ChatMessageActivity.this)
                                            .load(Webconfig.CONTEXT_PATH1 + "images/" + requestDtoList.get(0).getRequesterImage()).thumbnail(0.5f)
                                            .crossFade()
                                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                                            .into(requesterImageChat);

                                    //requesterImageChat.setImageResource(R.drawable.no_image);
                                }
                                requesterNameChat.setText(requestDtoList.get(0).getRequesterName().toString());
                            } else {
                                blockedTextview.setVisibility(View.VISIBLE);
                                chatMessageListView.setVisibility(View.GONE);
                                chatLayout.setVisibility(View.GONE);
                                blockUnblockToggle.setChecked(true);
                            }

                        } else if (Constant.requestType.equalsIgnoreCase("sent")) {
                            blockedTextview.setVisibility(View.GONE);
                            chatMessageListView.setVisibility(View.VISIBLE);
                            chatLayout.setVisibility(View.VISIBLE);
                            if (requestStatusId == 5) {
                                if (Constant.transType.equalsIgnoreCase("giveaway"))
                                    reminderIcon.setVisibility(View.GONE);
                                else
                                    reminderIcon.setVisibility(View.VISIBLE);

                                unableToServiceBtn.setVisibility(View.INVISIBLE);
                                closedBtn.setVisibility(View.VISIBLE);
                            } else if (requestStatusId == 7) {
                                if (Constant.transType.equalsIgnoreCase("giveaway"))
                                    reminderIcon.setVisibility(View.GONE);
                                else
                                    reminderIcon.setVisibility(View.VISIBLE);

                                unableToServiceBtn.setVisibility(View.INVISIBLE);
                                sharedBtn.setVisibility(View.INVISIBLE);
                                closedBtn.setVisibility(View.INVISIBLE);
                                receiverPopupWindow();
                            } else {
                                closedBtn.setVisibility(View.INVISIBLE);
                                reminderIcon.setVisibility(View.GONE);
                            }
                            if (requestDtoList.get(0).getOwnerImage()==null||requestDtoList.get(0).getOwnerImage().equals("No Image")||requestDtoList.get(0).getOwnerImage().equals("")) {
                                Glide.clear(requesterImageChat);
                                requesterImageChat.setImageResource(R.drawable.no_image);
                            } else {
                                Glide.with(ChatMessageActivity.this)
                                        .load(Webconfig.CONTEXT_PATH1 + "images/" + requestDtoList.get(0).getOwnerImage()).thumbnail(0.5f)
                                        .crossFade()
                                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                                        .into(requesterImageChat);

                                //requesterImageChat.setImageResource(R.drawable.no_image);
                            }
                            requesterNameChat.setText(requestDtoList.get(0).getOwnerName().toString());
                        }


                        if (notificationThreadDtoList != null && notificationThreadDtoList.size() > 0) {
                            ArrayAdapter<NotificationThreadDto> notificationAdapter = new ChatMessageAdapter(ChatMessageActivity.this, notificationThreadDtoList);
                            chatMessageListView.setAdapter(notificationAdapter);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {

            }

        }
    }

    public class sendMessage extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;
            if (msgString.contains(" ")) {
                msgString = msgString.replace(" ", "%20");
            }
            if (Constant.requestType.equalsIgnoreCase("received")) {
                result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "updateownermessage.json?ownermsg=" + msgString + "&requestid=" + Constant.requestId + "&ownerflg=1&requestStatusId=" + requestStatusId + "&memberId=" + memberId);
            } else if (Constant.requestType.equalsIgnoreCase("sent")) {
                result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "updateownermessage.json?ownermsg=" + msgString + "&requestid=" + Constant.requestId + "&ownerflg=0&requestStatusId=" + requestStatusId + "&memberId=" + memberId);
            }
            System.out.println("sent msg " + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            notificationThreadDtoList = new ArrayList<NotificationThreadDto>();
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null) {

                try {
                    jsonObj = new JSONObject(res);
                    String status = jsonObj.getString("status");
                    Constant.messageUnreadCount = jsonObj.getLong("unreadCount");
                    CommonHeader.messageCount.setText(String.valueOf(Constant.messageUnreadCount));

                    if (status.equalsIgnoreCase("success")) {
                        CommonResponseDto commonResponseDto = gson.fromJson(res, CommonResponseDto.class);
                        notificationThreadDtoList = commonResponseDto.getNotificationThreadDto();

                        if (notificationThreadDtoList != null && notificationThreadDtoList.size() > 0) {
                            ArrayAdapter<NotificationThreadDto> notificationAdapter = new ChatMessageAdapter(ChatMessageActivity.this, notificationThreadDtoList);
                            chatMessageListView.setAdapter(notificationAdapter);
                            typedMessage.setText("");
                            msgString = "";
                        }

                    }
                    InputMethodManager imm = (InputMethodManager) getSystemService(
                            Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(sendMessage.getWindowToken(), 0);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(ChatMessageActivity.this, "Server Down", Toast.LENGTH_LONG).show();
            }

        }
    }

    public class unableToService extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            if (Constant.requestType.equalsIgnoreCase("received")) {
                result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "closerequest.json?requestid=" + Constant.requestId + "&memberId=" + memberId + "&isOwner=1");
            } else if (Constant.requestType.equalsIgnoreCase("sent")) {
                result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "closerequest.json?requestid=" + Constant.requestId + "&memberId=" + memberId + "&isOwner=0");
            }
            System.out.println("close request " + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            notificationThreadDtoList = new ArrayList<NotificationThreadDto>();
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null) {

                try {
                    jsonObj = new JSONObject(res);
                    String status = jsonObj.getString("status");
                    if (status.equalsIgnoreCase("success")) {
                        if (Constant.requestType.equalsIgnoreCase("received")) {
                            Constant.tabPosition = 0;
                        } else {
                            Constant.tabPosition = 1;
                        }
                        startActivity(new Intent(ChatMessageActivity.this, MessageActivity.class));
                        finish();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(ChatMessageActivity.this, "Server Down", Toast.LENGTH_LONG).show();
            }

        }
    }

    public class updateRequestStatus extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "updaterequeststatus.json?requestid=" + Constant.requestId + "&requeststatusid=" + requestStatusId + "&memberId=" + memberId);
            System.out.println("close request " + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            notificationThreadDtoList = new ArrayList<NotificationThreadDto>();
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null) {

                try {
                    jsonObj = new JSONObject(res);
                    String status = jsonObj.getString("status");
                    if (status.equalsIgnoreCase("success")) {
                        CommonResponseDto commonResponseDto = gson.fromJson(res, CommonResponseDto.class);
                        notificationThreadDtoList = commonResponseDto.getNotificationThreadDto();

                        if (notificationThreadDtoList != null && notificationThreadDtoList.size() > 0) {
                            ArrayAdapter<NotificationThreadDto> notificationAdapter = new ChatMessageAdapter(ChatMessageActivity.this, notificationThreadDtoList);
                            chatMessageListView.setAdapter(notificationAdapter);
                            typedMessage.setText("");
                            msgString = "";
                        }

                        if (requestStatusId == 7) {

                            if (Constant.requestType.equalsIgnoreCase("received")) {
                                if (requestStatusId == 7) {
                                    initiatePopupWindow();

                                }
                            } else if (Constant.requestType.equalsIgnoreCase("sent")) {
                                if (requestStatusId == 7) {
                                    receiverPopupWindow();
                                }
                            }
                        } else if (requestStatusId == 5) {
                            if (Constant.transType.equalsIgnoreCase("giveaway")) {
                                startActivity(new Intent(ChatMessageActivity.this, MessageActivity.class));
                                finish();
                            } else {
                                reminderPopupWindow();
                            }
                        }

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(ChatMessageActivity.this, "Server Down", Toast.LENGTH_LONG).show();
            }

        }
    }

    private void receiverPopupWindow() {

        rFeedbackDialog = new Dialog(ChatMessageActivity.this);
        rFeedbackDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        rFeedbackDialog.setContentView(R.layout.receiver_feedback);
        rFeedbackDialog.setTitle(R.string.feedback);
        rFeedbackDialog.setCancelable(false);

            /*LayoutInflater inflater = (LayoutInflater) ChatMessageActivity.this
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View layout = inflater.inflate(R.layout.receiver_feedback,
                    (ViewGroup) findViewById(R.id.popup_element_recv));
            receiverPwindo = new PopupWindow(layout, 300, 370, true);
            receiverPwindo.showAtLocation(layout, Gravity.CENTER, 0, 0);
            receiverPwindo.setOutsideTouchable(false);*/
        ownerRating = (RatingBar) rFeedbackDialog.findViewById(R.id.issuer_rating);
        productRating = (RatingBar) rFeedbackDialog.findViewById(R.id.product_rating);
        issuerRatingCouting = (TextView) rFeedbackDialog.findViewById(R.id.issuer_rating_count);
        productRatingCountRecv = (TextView) rFeedbackDialog.findViewById(R.id.product_rating_count_recv);
        issuerReview = (EditText) rFeedbackDialog.findViewById(R.id.issuer_review);
        productReview = (EditText) rFeedbackDialog.findViewById(R.id.product_review);
        receiver_feedback_btn = (Button) rFeedbackDialog.findViewById(R.id.submit_feedback);

        ownerRating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                String ratingValue = String.valueOf(Math.round(rating));
                issuerRatingCouting.setText(ratingValue + "/5");
            }
        });

        productRating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                String ratingValue = String.valueOf(Math.round(rating));
                productRatingCountRecv.setText(ratingValue + "/5");
            }
        });
        receiver_feedback_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ownerRating.getRating() != 0 && productRating.getRating() != 0) {
                    ownerRatingStr = String.valueOf(ownerRating.getRating());
                    productRatingStr = String.valueOf(productRating.getRating());
                    issuerReviewStr = issuerReview.getText().toString();
                    productReviewStr = productReview.getText().toString();

                    System.out.println("pop up " + ownerRatingStr + "," + issuerReviewStr);
                    if (!(ownerRatingStr.equalsIgnoreCase("0.0") && productRatingStr.equalsIgnoreCase("0.0"))) {
                        receiverFeedbackDto.setIssuerRating((int) Math.round(ownerRating.getRating()));
                        receiverFeedbackDto.setProductRating((int) Math.round(productRating.getRating()));
                        receiverFeedbackDto.setIssuerRemarks(issuerReviewStr);
                        receiverFeedbackDto.setProductRemarks(productReviewStr);
                        receiverFeedbackDto.setRequestId(Constant.requestId);

                        receiverData = new Gson().toJson(receiverFeedbackDto);
                        new sendReceiverFeedback().execute();
                    } else {
                        callAlertDialog("Please give rating");
                    }
                } else {
                    callAlertDialog("Please give rating");
                }
            }
        });
        rFeedbackDialog.show();
    }

    private void initiatePopupWindow() {

        iFeedbackDialog = new Dialog(ChatMessageActivity.this);
        iFeedbackDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        iFeedbackDialog.setContentView(R.layout.screen_popup);
        iFeedbackDialog.setTitle(R.string.feedback);
        iFeedbackDialog.setCancelable(false);
            /*LayoutInflater inflater = (LayoutInflater) ChatMessageActivity.this
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View layout = inflater.inflate(R.layout.screen_popup,
                    (ViewGroup) findViewById(R.id.popup_element));
            pwindo = new PopupWindow(layout, 300, 370, true);
            pwindo.showAtLocation(layout, Gravity.CENTER, 0, 0);
            pwindo.setOutsideTouchable(false);*/
        buyerRating = (RatingBar) iFeedbackDialog.findViewById(R.id.buyerRating);
        buyerRatingText = (TextView) iFeedbackDialog.findViewById(R.id.buyer_rating_count);
        reviewText = (EditText) iFeedbackDialog.findViewById(R.id.review_text);
        submit_btn = (Button) iFeedbackDialog.findViewById(R.id.submit);

        buyerRating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                buyerRatingText.setText(String.valueOf(Math.round(rating)) + "/5");
            }
        });


        submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (buyerRating.getRating() != 0) {
                    buyerRatingStr = String.valueOf(buyerRating.getRating());
                    reviewTxtStr = reviewText.getText().toString();
                    if (!(buyerRatingStr.equalsIgnoreCase("0.0"))) {
                        issuerFeedbackDto.setReceiverRating((int) Math.round(buyerRating.getRating()));
                        issuerFeedbackDto.setRemarks(reviewTxtStr);
                        issuerFeedbackDto.setRequestId(Constant.requestId);

                        issuerData = new Gson().toJson(issuerFeedbackDto);
                        new sendIssuerFeedbak().execute();
                    } else {
                        callAlertDialog("Please give rating");
                    }
                } else {
                    callAlertDialog("Please give rating");
                }
            }
        });

        iFeedbackDialog.show();
    }

    private void reminderPopupWindow() {
        remindialog = new Dialog(ChatMessageActivity.this);
        remindialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        remindialog.setContentView(R.layout.reminder_popup);
        remindialog.setTitle(R.string.set_reminder);

        borrowedOn = (EditText) remindialog.findViewById(R.id.input_borrowed);
        toBeReturnedOn = (EditText) remindialog.findViewById(R.id.input_tobe_returned);
        returnedOn = (EditText) remindialog.findViewById(R.id.input_returned);
        saveReminderBtn = (Button) remindialog.findViewById(R.id.save_reminder);
        if (Constant.requestType.equalsIgnoreCase("received")) {
            //borrowedOn.setHint("Shared On");
            if (requestStatusId == 5 && issuerNoteDto != null && issuerNoteDto.getSharedOnStr() != null && !issuerNoteDto.getSharedOnStr().isEmpty()) {
                borrowedOn.setTextColor(getApplicationContext().getResources().getColor(R.color.light_gray));
                borrowedOn.setClickable(false);
                //toBeReturnedOn.setTextColor(getApplicationContext().getResources().getColor(R.color.light_gray));
                toBeReturnedOn.setClickable(true);
                toBeReturnedOn.setOnClickListener(showDatePicker);
                returnedOn.setClickable(false);
            } else if (requestStatusId == 7) {
                borrowedOn.setTextColor(getApplicationContext().getResources().getColor(R.color.light_gray));
                borrowedOn.setClickable(false);
                //borrowedOn.setBackgroundColor(getApplicationContext().getResources().getColor(R.color.gray));
                toBeReturnedOn.setTextColor(getApplicationContext().getResources().getColor(R.color.light_gray));
                toBeReturnedOn.setClickable(false);
                //toBeReturnedOn.setBackgroundColor(getApplicationContext().getResources().getColor(R.color.gray));
                returnedOn.setClickable(true);
                returnedOn.setOnClickListener(showDatePicker);
                saveReminderBtn.setVisibility(View.VISIBLE);
            } else {
                borrowedOn.setClickable(true);
                toBeReturnedOn.setClickable(true);
                borrowedOn.setOnClickListener(showDatePicker);
                toBeReturnedOn.setOnClickListener(showDatePicker);
                returnedOn.setClickable(false);
                //returnedOn.setBackgroundColor(getApplicationContext().getResources().getColor(R.color.gray));
                returnedOn.setTextColor(getApplicationContext().getResources().getColor(R.color.light_gray));
            }

            if (issuerNoteDto != null && issuerNoteDto.getSharedOnStr() != null && !issuerNoteDto.getSharedOnStr().isEmpty()) {
                borrowedOn.setText(issuerNoteDto.getSharedOnStr());
            }
            if (issuerNoteDto != null && issuerNoteDto.getReturnByStr() != null && !issuerNoteDto.getReturnByStr().isEmpty()) {
                toBeReturnedOn.setText(issuerNoteDto.getReturnByStr());
            }

        } else if (Constant.requestType.equalsIgnoreCase("sent")) {

            //borrowedOn.setHint("Borrowed On");
            borrowedOn.setClickable(false);
            borrowedOn.setTextColor(getApplicationContext().getResources().getColor(R.color.light_gray));
            //borrowedOn.setBackgroundColor(getApplicationContext().getResources().getColor(R.color.gray));
            toBeReturnedOn.setClickable(false);
            toBeReturnedOn.setTextColor(getApplicationContext().getResources().getColor(R.color.light_gray));
            //toBeReturnedOn.setBackgroundColor(getApplicationContext().getResources().getColor(R.color.gray));
            returnedOn.setOnClickListener(showDatePicker);

            if (receiverNoteDto != null && receiverNoteDto.getSharedOnStr() != null && !receiverNoteDto.getSharedOnStr().isEmpty()) {
                borrowedOn.setText(receiverNoteDto.getSharedOnStr());
            }
            if (receiverNoteDto != null && receiverNoteDto.getReturnByStr() != null && !receiverNoteDto.getReturnByStr().isEmpty()) {
                toBeReturnedOn.setText(receiverNoteDto.getReturnByStr());
            }

            if (receiverNoteDto != null && receiverNoteDto.getReturnOnStr() != null && !receiverNoteDto.getReturnOnStr().isEmpty()) {
                returnedOn.setText(receiverNoteDto.getReturnOnStr());
            }
        }


        saveReminderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedOnStr = borrowedOn.getText().toString();
                toBeReturnedOnStr = toBeReturnedOn.getText().toString();
                if (Constant.requestType.equalsIgnoreCase("received")) {
                    if (ownerReminderValidation()) {
                        //receiverNoteDto = new ReceiverNoteDto();
                        //issuerNoteDto = new IssuerNoteDto();
                        issuerNoteDto.setRequestId(Constant.requestId);
                        issuerNoteDto.setSharedOnStr(sharedOnStr);
                        issuerNoteDto.setReturnByStr(toBeReturnedOnStr);
                        issuerNoteDto.setReturnOnStr("");
                        ownerReminderData = new Gson().toJson(issuerNoteDto);

                        if (receiverNoteDto != null) {
                            receiverNoteDto.setReceiverNoteId(receiverNoteDto.getReceiverNoteId());
                        } else {
                            receiverNoteDto.setReceiverNoteId(0);
                        }
                        receiverNoteDto.setRequestId(Constant.requestId);
                        receiverNoteDto.setReturnByStr(toBeReturnedOnStr);
                        receiverNoteDto.setSharedOnStr(sharedOnStr);
                        receiverNoteDto.setReturnOnStr("");
                        receiverReminderData = new Gson().toJson(receiverNoteDto);

                        //new updateIssuerNote().execute();
                        new createReceiverNote().execute();
                    }
                } else if (Constant.requestType.equalsIgnoreCase("sent")) {
                    returnedOnStr = returnedOn.getText().toString();
                    //receiverNoteDto = new ReceiverNoteDto();
                    if (receiverNoteDto != null) {
                        receiverNoteDto.setReceiverNoteId(receiverNoteDto.getReceiverNoteId());
                    } else {
                        receiverNoteDto.setReceiverNoteId(0);
                    }
                    receiverNoteDto.setRequestId(Constant.requestId);
                    receiverNoteDto.setReturnByStr(toBeReturnedOnStr);
                    receiverNoteDto.setSharedOnStr(sharedOnStr);
                    receiverNoteDto.setReturnOnStr(returnedOnStr);
                    receiverReminderData = new Gson().toJson(receiverNoteDto);

                    new createReceiverNote().execute();
                }
            }
        });
        remindialog.show();

    }

    View.OnClickListener showDatePicker = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            final View vv = v;

            DatePickerDialog datePickerDialog = new DatePickerDialog(ChatMessageActivity.this, new DatePickerDialog.OnDateSetListener() {

                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                    if (vv.getId() == R.id.input_borrowed) {
                        borrowedOn.setText(new StringBuilder().append(dayOfMonth).append("/")
                                .append(monthOfYear + 1).append("/").append(year));
                    } else if (vv.getId() == R.id.input_tobe_returned) {
                        toBeReturnedOn.setText(new StringBuilder().append(dayOfMonth).append("/")
                                .append(monthOfYear + 1).append("/").append(year));
                    } else if (vv.getId() == R.id.input_returned) {
                        returnedOn.setText(new StringBuilder().append(dayOfMonth).append("/")
                                .append(monthOfYear + 1).append("/").append(year));
                    }
                }
            }, year, month, day);
            //datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
            datePickerDialog.show();
        }
    };


    public class sendIssuerFeedbak extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.doPost(issuerData, Webconfig.CONTEXT_PATH + "createissuerfeedback.json?&memberId=" + memberId);
            System.out.println("issuer feedback " + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null) {

                try {
                    jsonObj = new JSONObject(res);
                    IssuerFeedbackDto issuerFeedbackDto = gson.fromJson(res, IssuerFeedbackDto.class);
                    iFeedbackDialog.dismiss();
                    onBackPressed();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(ChatMessageActivity.this, "Server Down", Toast.LENGTH_LONG).show();
            }

        }
    }

    public class sendReceiverFeedback extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.doPost(receiverData, Webconfig.CONTEXT_PATH + "createreceiverfeedback.json");
            System.out.println("receiver feedback " + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null) {

                try {
                    jsonObj = new JSONObject(res);
                    ReceiverFeedbackDto receiverFeedbackDto = gson.fromJson(res, ReceiverFeedbackDto.class);
                    rFeedbackDialog.dismiss();
                    onBackPressed();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(ChatMessageActivity.this, "Server Down", Toast.LENGTH_LONG).show();
            }

        }
    }

    public class createReceiverNote extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.doPost(receiverReminderData, Webconfig.CONTEXT_PATH + "createreceivernote.json");
            System.out.println("receiver note " + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null) {

                if (res.equalsIgnoreCase("success")) {
                    if (Constant.requestType.equalsIgnoreCase("received")) {
                        new updateIssuerNote().execute();
                    } else {
                        remindialog.dismiss();
                    }
                } else {
                    remindialog.dismiss();
                    Toast.makeText(ChatMessageActivity.this, "Reminder not saved, Please try after sometime", Toast.LENGTH_LONG).show();
                }

            } else {
                Toast.makeText(ChatMessageActivity.this, "Server Down", Toast.LENGTH_LONG).show();
            }

        }
    }

    public class updateIssuerNote extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.doPost(ownerReminderData, Webconfig.CONTEXT_PATH + "updateissuernote.json");
            System.out.println("owner note " + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null) {
                if (res.equalsIgnoreCase("success")) {
                    remindialog.dismiss();
                    startActivity(new Intent(ChatMessageActivity.this, MessageActivity.class));
                    finish();
                } else {
                    remindialog.dismiss();
                    Toast.makeText(ChatMessageActivity.this, "Reminder not saved, Please try after sometime", Toast.LENGTH_LONG).show();
                }

            } else {
                Toast.makeText(ChatMessageActivity.this, "Server Down", Toast.LENGTH_LONG).show();
            }

        }
    }

    public class getIssuerNote extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "getissuernote.json?requestid=" + Constant.requestId);
            System.out.println("get issuer note " + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null && res.length() > 2) {

                try {
                    jsonObj = new JSONObject(res);
                    String issuerData = jsonObj.toString().trim();
                    issuerNoteDto = new IssuerNoteDto();
                    issuerNoteDto = gson.fromJson(issuerData, IssuerNoteDto.class);
                    reminderPopupWindow();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                reminderPopupWindow();
            }

        }
    }

    public class getReceiverNote extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "getreceivernote.json?requestid=" + Constant.requestId);
            System.out.println("get receiver note " + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null) {
                receiverNoteDto = new ReceiverNoteDto();
                try {
                    jsonObj = new JSONObject(res);
                    String receiverData = jsonObj.toString().trim();
                    receiverNoteDto = gson.fromJson(receiverData, ReceiverNoteDto.class);
                    reminderPopupWindow();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Toast.makeText(ChatMessageActivity.this, "Server Down", Toast.LENGTH_LONG).show();
            }

        }
    }

    public class blockMember extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "blockrequestbymemberid.json?requestid=" + Constant.requestId + "&memberId=" + memberId);
            System.out.println("block Member" + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null && res.length() > 2) {
                if (res.equalsIgnoreCase("Success")) {
                    if (Connectivity.isConnected(ChatMessageActivity.this)) {
                        new getChatMessage().execute();
                    } else {
                        Toast.makeText(ChatMessageActivity.this, "Please Check Network Connection", Toast.LENGTH_LONG).show();
                    }
                }
            } else {
            }

        }
    }

    public class unBlockMember extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ChatMessageActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = null;

            result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "unblockrequest.json?requestid=" + Constant.requestId + "&memberId=" + memberId);
            System.out.println("unblock Member" + result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            JSONObject jsonObj;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if (res != null && res.length() > 2) {
                if (res.equalsIgnoreCase("Success")) {
                    if (Connectivity.isConnected(ChatMessageActivity.this)) {
                        new getChatMessage().execute();
                    } else {
                        Toast.makeText(ChatMessageActivity.this, "Please Check Network Connection", Toast.LENGTH_LONG).show();
                    }
                }
            } else {
            }

        }
    }

    private void callAlertDialog(String message) {

        customDialog = new Dialog(ChatMessageActivity.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText = (TextView) customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn = (Button) customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

    private boolean checkValidation() {
        boolean valueReturn = true;
        if (!Validation.hasText(typedMessage))
            valueReturn = false;

        return valueReturn;
    }

    private boolean checkReceiverValidation() {
        boolean valueReturn = true;
        if (!Validation.hasText(issuerReview))
            valueReturn = false;

        if (!Validation.hasText(productReview))
            valueReturn = false;

        return valueReturn;
    }

    private boolean ownerReminderValidation() {
        boolean valueReturn = true;
        if (!Validation.hasText(borrowedOn))
            valueReturn = false;

        if (!Validation.hasText(toBeReturnedOn))
            valueReturn = false;

        return valueReturn;
    }

    public void onBackPressed() {
        super.onBackPressed();
        if (Constant.requestType.equalsIgnoreCase("received")) {
            Constant.tabPosition = 0;
        } else {
            Constant.tabPosition = 1;
        }
        startActivity(new Intent(ChatMessageActivity.this, MessageActivity.class));
        finish();
    }
}
