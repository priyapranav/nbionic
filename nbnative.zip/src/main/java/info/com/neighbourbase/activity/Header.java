package info.com.neighbourbase.activity;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;

import android.content.pm.PackageManager;
import android.content.res.Configuration;

import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Circle;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CategoryDto;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.RequestDto;
import info.com.neighbourbase.service.MyFirebaseMessagingService;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.MessageCountListener;
import info.com.neighbourbase.utility.PushMessageListener;
import info.com.neighbourbase.utility.Webconfig;

public class Header extends AppCompatActivity implements AdapterView.OnItemClickListener{
    PopupWindow pw;
    FloatingActionButton floatingActionButton;
    ActionBarDrawerToggle actionBarDrawerToggle;
    DrawerLayout drawerLayout;
    ListView groupList, expListView, categoryListView;
    HashMap<String, List<String>> listDataChild = new HashMap<String, List<String>>();
    // SearchView searchView;
    SharedPreferences preferences;
    String memberId, address, token, mNotifyCount ="0", mMessageCount;
    List<String> categoryName = new ArrayList<String>();
    List<String> availableCategoryName = new ArrayList<String>();
    List<Long> categoryId = new ArrayList<Long>();
    Long parentId;
    ImageView mapIcon, searchIcon, messageIcon, profileIcon;
    LinearLayout searchLayout,addProductLayout,logoutLayout,dashBoardLayout, homeLayout, moreLayout, groupLayout;
    PopupWindow groupNameSelectPopup;
    ArrayList<String> groupName=new ArrayList<>();
    ArrayList<Long> groupId=new ArrayList<>();
    ArrayAdapter groupNameAdapter;
    public static TextView currentLocation, messageCount;
    Toolbar toolbar;

    GoogleMap googleMap;
    MarkerOptions markerOptions;
    LatLng latLng;
    EditText etLocation, radius;
    Circle circle;
    TextView alertMessageText;
    Button alertMsgOkBtn;
    List<CategoryDto> categoryDtoList;
    RelativeLayout messageLayout, notificationLayout;
    Dialog mylistingGroup,customDialog;
    PopupMenu popup;
    static TextView mPushMessageCount;
    int notiCount;
    int permissionCheck, permissionCheck1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_action);

       /*ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.mipmap.ic_home_white);
        actionBar.setDisplayShowHomeEnabled(true);*/

        mInit();

        new getRootCategory().execute();
    }

    private void mInit() {
        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        memberId = preferences.getString("memberId", "");
        address = preferences.getString("address", "");
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        // searchView=(SearchView)findViewById(R.id.search_view);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        notificationLayout = (RelativeLayout) findViewById(R.id.notification_layout);
        searchLayout = (LinearLayout) findViewById(R.id.search_layout);
        messageLayout = (RelativeLayout) findViewById(R.id.message_layout);
        mapIcon = (ImageView) findViewById(R.id.map_icon);
        searchIcon = (ImageView) findViewById(R.id.search_icon);
        messageIcon = (ImageView) findViewById(R.id.message_icon);
        mPushMessageCount = (TextView) findViewById(R.id.push_message_count);
        messageCount = (TextView) findViewById(R.id.message_count);
        currentLocation = (TextView) findViewById(R.id.current_location);

        addProductLayout=(LinearLayout)findViewById(R.id.add_product_layout);
        dashBoardLayout = (LinearLayout) findViewById(R.id.dash_board_layout);
        groupLayout=(LinearLayout) findViewById(R.id.group_layout);
        homeLayout = (LinearLayout) findViewById(R.id.home_layout);
        profileIcon= (ImageView) findViewById(R.id.profile_icon);
        moreLayout = (LinearLayout) findViewById(R.id.more_layout);

        expListView = (ListView) findViewById(R.id.list);
        floatingActionButton=(FloatingActionButton)findViewById(R.id.fab);

        setSupportActionBar(toolbar);
        toolbar.setTitle("");
        categoryListView = (ListView) findViewById(R.id.list);
        mapIcon.setOnClickListener(clickListener);

        notiCount = preferences.getInt("pushCount", 0);

        if (notiCount != 0) {
            mPushMessageCount.setText(String.valueOf(notiCount));
            mPushMessageCount.setVisibility(View.VISIBLE);

        } else {
            mPushMessageCount.setVisibility(View.GONE);
        }

        /*if (Constant.messageUnreadCount != 0) {
            messageCount.setVisibility(View.VISIBLE);
            messageCount.setText(String.valueOf(Constant.messageUnreadCount));
        } else {
            messageCount.setVisibility(View.INVISIBLE);
        }*/

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
                R.string.drawer_open, R.string.drawer_close);
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

//        searchView.setQueryHint("Search Products and More");
//        searchView.onActionViewExpanded();
//        searchView.clearFocus();
        setupDrawer();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            actionBarDrawerToggle.getDrawerArrowDrawable().setColor(getColor(R.color.White));
        } else {
            actionBarDrawerToggle.getDrawerArrowDrawable().setColor(getResources().getColor(R.color.White));
        }

        searchLayout.setOnClickListener(clickListener);
        messageLayout.setOnClickListener(clickListener);
        dashBoardLayout.setOnClickListener(clickListener);
        addProductLayout.setOnClickListener(clickListener);
        groupLayout.setOnClickListener(clickListener);
        moreLayout.setOnClickListener(clickListener);
        homeLayout.setOnClickListener(clickListener);
        floatingActionButton.setOnClickListener(clickListener);
        notificationLayout.setOnClickListener(clickListener);
        Bundle intent=this.getIntent().getExtras();
        if(intent==null){
            currentLocation.setText(address);
        }else{
            address=intent.getString("changeLocation");
            currentLocation.setText(address);
        }


        MyFirebaseMessagingService.bindListener(new PushMessageListener() {
            @Override
            public void pushMessageReceived(Integer pushMessageCount) {
                if(pushMessageCount!=null) {
                    mNotifyCount = pushMessageCount.toString();
                    new mPushMsgCount().execute();
                }
            }

        });

        MessageFragment.bindListener(new MessageCountListener() {
            @Override
            public void messageReceived(Integer pushMessageCount) {
                if(pushMessageCount!=null) {
                    mMessageCount = pushMessageCount.toString();
                    new MsgCount().execute();
                }
            }

        });

    }


    private void setupDrawer() {
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
                R.string.drawer_open, R.string.drawer_close) {

            /** Called when a drawer has settled in a completely open state. */
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

                invalidateOptionsMenu();
            }

            /** Called when a drawer has settled in a completely closed state. */
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);

                invalidateOptionsMenu();
            }

        };
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        drawerLayout.setDrawerListener(actionBarDrawerToggle);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        actionBarDrawerToggle.syncState();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        actionBarDrawerToggle.onConfigurationChanged(newConfig);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {

        }
        // Activate the navigation drawer toggle
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private View.OnClickListener clickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            switch (v.getId()) {

                case R.id.map_icon:
                    permissionCheck = ContextCompat.checkSelfPermission(Header.this, Manifest.permission.ACCESS_FINE_LOCATION);
                    permissionCheck1 = ContextCompat.checkSelfPermission(Header.this, Manifest.permission.ACCESS_COARSE_LOCATION);
                    if (permissionCheck != PackageManager.PERMISSION_GRANTED && permissionCheck1 != PackageManager.PERMISSION_GRANTED ) {
                        ActivityCompat.requestPermissions(Header.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 0);
                        Toast.makeText(Header.this, "Need to on location Permission in neighbourbase app, otherwise not able to access map", Toast.LENGTH_LONG).show();
                    }else {
                        startActivity(new Intent(Header.this, GoogleMapPopup.class));
                    }
//                    finish();
                    // googleMapPopup(Header.this);
                    break;
                case R.id.search_layout:
                    startActivity(new Intent(Header.this, SearchActivity.class));
//                    finish();
                    break;

                case R.id.message_layout:
                    startActivity(new Intent(Header.this, MessageActivity.class));
                    break;

                case R.id.add_product_layout:
                    startActivity(new Intent(Header.this, AddProductPage.class));
                    break;

                case R.id.dash_board_layout:
                    startActivity(new Intent(Header.this, DashBoardPage.class));
                    break;

                case R.id.group_layout:
                    startActivity(new Intent(Header.this, GroupPage.class));
                    break;

                case R.id.home_layout:
                    Constant.categoryId = 0;
                    startActivity(new Intent(Header.this, HomeScreen.class));
                    break;

                case R.id.more_layout:
                    startActivity(new Intent(Header.this, MorePage.class));
//                    final PopupMenu popup = new PopupMenu(Header.this, profileLayout);
//                    popup.getMenuInflater().inflate(R.menu.profile_popup_menu, popup.getMenu());
//                    popup.setGravity(Gravity.END);
//                    popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//                        public boolean onMenuItemClick(MenuItem item) {
//                            switch (item.getItemId()){
//                                case R.id.profile_info:
//                                    if(!Constant.currentActivity.equalsIgnoreCase("ProfileInformationPage")) {
//                                    startActivity(new Intent(Header.this,ProfileInformationPage.class));
//                                        finish();
//                                    }
//                                    break;
//                                case R.id.profile_feedback:
//                                    if(!Constant.currentActivity.equalsIgnoreCase("FeedbackActivity")) {
//                                    startActivity(new Intent(Header.this,FeedbackActivity.class));
//                                    finish();
//                                    }
//                                    break;
//                                case R.id.profile_change_email:
//                                    if(!Constant.currentActivity.equalsIgnoreCase("ChangeEmailPage")) {
//                                    startActivity(new Intent(Header.this,ChangeEmailPage.class));
//                                    finish();
//                                    }
//                                    break;
//                                case R.id.profile_picture:
//                                    if(!Constant.currentActivity.equalsIgnoreCase("ProfilePicturePage")) {
//                                        startActivity(new Intent(Header.this, ProfilePicturePage.class));
//                                        finish();
//                                    }
//                                    break;
//                                case R.id.profile_reset_password:
//                                    if(!Constant.currentActivity.equalsIgnoreCase("ResetPassword")) {
//                                        startActivity(new Intent(Header.this, ResetPassword.class));
//                                        finish();
//                                    }
//                                    break;
//                                case R.id.profile_change_location:
//                                    if(!Constant.currentActivity.equalsIgnoreCase("ChangeLocationPage")) {
//                                        startActivity(new Intent(Header.this, ChangeLocationPage.class));
//                                        finish();
//                                    }
//                                    break;
//                                case R.id.profile_mylisting:
//                                    showGroupNamePopup();
//                                    break;
//                                case R.id.profile_logout:
//                                    logout();
//                                    HttpConfig.username = null;
//                                    HttpConfig.password = null;
//                                    startActivity(new Intent(Header.this,LoginActivity.class));
//                                    finish();
//                                    break;
//                            }
//                            return true;
//                        }
//                    });
//                    popup.show();
                    break;

                case R.id.fab:
                    startActivity(new Intent(Header.this, InviteFriendsActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    break;

                case R.id.notification_layout:
                    startActivity(new Intent(Header.this, NotificationMessage.class));
                    break;
            }
        }
    };

    private void showPopup() {
    }

    private void showGroupNamePopup(final Activity context) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.activity_my_listing_group_page,
                (ViewGroup)context. findViewById(R.id.group_name_popup));
        groupNameSelectPopup = new PopupWindow(layout, 950, 1000, true);
        groupNameSelectPopup.showAtLocation(layout, Gravity.CENTER, 0, 0);
        groupList=(ListView)layout.findViewById(R.id.group_name_list);
        new getGroupName().execute();
        groupList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String groupIdStr= String.valueOf(groupId.get(position));
                startActivity(new Intent(Header.this,MyListingPage.class).putExtra("groupId",groupIdStr).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                groupNameSelectPopup.dismiss();

            }
        });

    }

    private void showGroupNamePopup() {

        mylistingGroup = new Dialog(Header.this);
        mylistingGroup.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mylistingGroup.setContentView(R.layout.activity_my_listing_group_page);
        mylistingGroup.setCancelable(true);

        groupList=(ListView)mylistingGroup.findViewById(R.id.group_name_list);
        new getGroupName().execute();
        groupList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String groupIdStr= String.valueOf(groupId.get(position));
                startActivity(new Intent(Header.this,MyListingPage.class).putExtra("groupId",groupIdStr));
                finish();
                mylistingGroup.dismiss();
            }
        });
        mylistingGroup.show();
    }


    TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            new GeocoderTask().execute(address);
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            // Getting user input location
            String location = etLocation.getText().toString();

            if (location != null && !location.equals("")) {
                new GeocoderTask().execute(location);

            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };


    // An AsyncTask class for accessing the GeoCoding Web Service
    private class GeocoderTask extends AsyncTask<Object, Object, List<android.location.Address>> {

        @Override
        protected List<android.location.Address> doInBackground(Object... locationName) {
            // Creating an instance of Geocoder class
            Geocoder geocoder = new Geocoder(getBaseContext());
            List<android.location.Address> addresses = null;

            try {
                // Getting a maximum of 3 Address that matches the input text
                addresses = geocoder.getFromLocationName((String) locationName[0], 3);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return addresses;
        }

        @Override
        protected void onPostExecute(List<android.location.Address> addresses) {

            if(addresses==null || addresses.size()==0){
                Toast.makeText(getBaseContext(), "No Location found", Toast.LENGTH_SHORT).show();
            }

            // Clears all the existing markers on the map
            googleMap.clear();

            // Adding Markers on Google Map for each matching address
            for(int i=0;i<addresses.size();i++){

                // Address address = (Address)addresses.get(i);
                android.location.Address address= new android.location.Address(Locale.ENGLISH);
                address=addresses.get(i);

                // Creating an instance of GeoPoint, to display in Google Map
                latLng = new LatLng(address.getLatitude(), address.getLongitude());

                String addressText = String.format("%s, %s",
                        address.getMaxAddressLineIndex() > 0 ? address.getAddressLine(0) : "",
                        address.getCountryName());

                markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                markerOptions.title(addressText);

                googleMap.addMarker(markerOptions);


                // Locate the first location
                if(i==0)

                    googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,10.5f));
            }
        }


    }

    private class getGroupName extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getnetwork.json?memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s != null) {
                JSONObject jsonObject = null;
                JSONArray jsonArray = null;
                groupId = new ArrayList<Long>();
                groupName = new ArrayList<String>();
                groupName.add("All");
                groupId.add(0L);

                try {
                    jsonArray = new JSONArray(s);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        String networkname = jsonObject.getString("networkName");
                        Long networkid = jsonObject.getLong("networkId");
                        groupName.add(networkname);
                        groupId.add(networkid);

                    }
                    groupNameAdapter=new ArrayAdapter<String>(Header.this,android.R.layout.simple_spinner_dropdown_item,groupName);
                    groupList.setAdapter(groupNameAdapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                callAlertDialog("Check Your Internet Connection");
            }
        }
        private void callAlertDialog(String message) {

            customDialog = new Dialog(Header.this);
            customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            customDialog.setContentView(R.layout.custom_messbox);
            customDialog.setCancelable(true);
            alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
            alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
            alertMessageText.setText(message);
            alertMsgOkBtn.setVisibility(View.GONE);
            customDialog.show();
            customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


        }
    }


    private class getRootCategory extends AsyncTask<String,String,String> {

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getrootcategories.json?memberId="+memberId);
            System.out.println("Category "+result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            CategoryDto categoryDto;
            categoryDtoList = new ArrayList<CategoryDto>();
            JSONObject jsonObject= null;
            Gson gson = new Gson();
            if(res!=null) {
                try {
                    jsonObject = new JSONObject(res);
                    String status = jsonObject.getString("status");
                    token = jsonObject.getString("deviceToken");
                    if(token == null || token.isEmpty() || !token.equalsIgnoreCase(FirebaseInstanceId.getInstance().getToken())){
                        new sentDeviceToken().execute();
                    }
                    if(status.equalsIgnoreCase("success")) {
                        CommonResponseDto commonResponseDto = gson.fromJson(res, CommonResponseDto.class);
                        categoryDtoList = commonResponseDto.getCategoryDto();
                    }
                    for (int i = 0; i < categoryDtoList.size(); i++) {
                        categoryName.add(categoryDtoList.get(i).getCategoryName());
                        categoryId.add(categoryDtoList.get(i).getCategoryId());
                    }

                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(Header.this, android.R.layout.simple_list_item_1, categoryName);
                    categoryListView.setAdapter(adapter);
                    categoryListView.setOnItemClickListener(Header.this);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    private class sentDeviceToken extends AsyncTask<String,String,String> {

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            token = FirebaseInstanceId.getInstance().getToken();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"deviceToken.json?memberid="+memberId+"&deviceToken="+token);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            CategoryDto categoryDto;
            JSONObject jsonObject= null;
            if(res!=null) {

            }

        }
    }

    private class mPushMsgCount extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {

            String result = null;
            result = mNotifyCount;
            return result;
        }

        @Override
        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            mPushMessageCount.setVisibility(View.VISIBLE);
            mPushMessageCount.setText(result);

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

    }

    private class MsgCount extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {

            String result = null;
            result = mMessageCount;
            return result;
        }

        @Override
        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            messageCount.setVisibility(View.VISIBLE);
            messageCount.setText(result);

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String category = categoryListView.getItemAtPosition(position).toString();
        parentId = categoryDtoList.get(position).getCategoryId();
        Intent intent = new Intent(Header.this, CategoryActivity.class);
        intent.putExtra("rootId", parentId.toString());
        startActivity(intent);
    }

    private void logout() {
        SharedPreferences.Editor e = preferences.edit();

        e.putString("memberId","");
        e.putString("latitude", "");
        e.putString("longitude", "");
        e.putString("pincode", "");
        e.putString("address","");
        e.putString("radius", "");
        e.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mInit();
    }

}
