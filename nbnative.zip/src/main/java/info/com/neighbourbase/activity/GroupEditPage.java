package info.com.neighbourbase.activity;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.NetworkDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class GroupEditPage extends CommonHeader implements View.OnClickListener, AdapterView.OnItemSelectedListener{
    private static final String TAG_RESULT = "predictions";
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    EditText groupName, groupDetails, apartNameOrganizationName;
    AutoCompleteTextView groupAddress;
    String[] spinnerText={"Apartment/Residential","Others"};
    Button groupSubmitBtn, groupCancelBtn;
    Spinner groupTypeSpinner;
    ImageView groupImage,addImageIcon;
    SharedPreferences preferences;
    byte[] groupImgByteArray;
    String url,groupTyprStr,reqData,memberId,groupIdStr,picture,zip,strAddress;
    Double latitude,longitude;
    int  pincode;
    ArrayAdapter<String> arrayAdapter,spinnerAdapter;
    ArrayList<String> area;
    Bitmap bitmap;
    NetworkDto networkDto=new NetworkDto();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_group_edit_page, FrameLayout);
        mInit();
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        memberId=preferences.getString("memberId","");
        groupIdStr=getIntent().getStringExtra("groupId");
        new getGroupDetail().execute();
        spinnerAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,spinnerText);
        groupTypeSpinner.setAdapter(spinnerAdapter);
        groupAddress.addTextChangedListener(textWatcher);
        addImageIcon.setOnClickListener(this);
        groupCancelBtn.setOnClickListener(this);
        groupSubmitBtn.setOnClickListener(this);
        groupTypeSpinner.setOnItemSelectedListener(this);
    }
    private void mInit() {
        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "GroupEditPage";

        groupName = (EditText) findViewById(R.id.group_name);
        groupDetails = (EditText) findViewById(R.id.group_details);
        apartNameOrganizationName = (EditText) findViewById(R.id.apartName_organName);
        addImageIcon = (ImageView) findViewById(R.id.add_image_icon);
        groupSubmitBtn = (Button) findViewById(R.id.change_group_submit);
        groupCancelBtn = (Button) findViewById(R.id.change_group_cancel);
        groupTypeSpinner = (Spinner) findViewById(R.id.group_type_spinner);
        groupAddress = (AutoCompleteTextView) findViewById(R.id.group_address);
        groupImage=(ImageView)findViewById(R.id.group_image);


    }
    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {


        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            StringBuilder sb=new StringBuilder(Webconfig.GOOGLE_PLACE);
            try {
                sb.append("&input=" + URLEncoder.encode(groupAddress.getText().toString(), "utf8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            url=sb.toString();
            area=new ArrayList<String>();
            new googleAutoComplete().execute();
            strAddress=groupAddress.getText().toString();
            new getLatLongDetails().execute();

        }
    };

    private class getLatLongDetails extends AsyncTask<String,String,String>{
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String locationAddress = strAddress.replaceAll(" ", "%20");
            String result=httpConfig.httppost("http://maps.googleapis.com/maps/api/geocode/json?address="+locationAddress+"&sensor=true_or_false");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    String status = jsonObject.optString("status");
                    if (status.equals("OK")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("results");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObjResult = jsonArray.getJSONObject(i);
                            JSONArray addCompoArray = jsonObjResult.getJSONArray("address_components");
                            for (int j = 0; j < addCompoArray.length(); j++) {
                                JSONObject jsonObjAddCompo = addCompoArray.getJSONObject(j);
                                JSONArray jsonArrayType = jsonObjAddCompo.getJSONArray("types");
                                for (int k = 0; k < jsonArrayType.length(); k++) {
                                    String type = jsonArrayType.getString(k);
                                    if (type.equals("postal_code")) {
                                        try{
                                            pincode = Integer.valueOf(jsonObjAddCompo.optString("long_name"));
                                        }catch (NumberFormatException ex) {
                                            pincode=0;
                                        }

                                    } else {
                                        pincode =0;
                                    }

                                }
                            }
                            JSONObject jsonObjGeometry = jsonObjResult.getJSONObject("geometry");
                            JSONObject jsonObjLocation = jsonObjGeometry.getJSONObject("location");
                            latitude =Double.valueOf(jsonObjLocation.optString("lat"));
                            longitude =Double.valueOf(jsonObjLocation.optString("lng"));

                        }

                    }else if(status.equals("INVALID_REQUEST")){
                        callAlertDialog("Please Give Correct Address Detail");
                    }

                }catch(JSONException e){
                    e.printStackTrace();
                }


            }



        }
    }

    public void onClick(View v) {
        switch(v.getId()){
            case R.id.add_image_icon:
                selectImage();
                break;
            case R.id.back_icon:
                finish();
                break;
            case R.id.change_group_cancel:
                startActivity(new Intent(GroupEditPage.this,GroupPage.class));
                break;
            case R.id.change_group_submit:
                if(checkAddListingValidation()){
                    if (groupImage.getDrawable().getConstantState()==getResources().getDrawable(R.drawable.no_image).getConstantState()) {
                        customDialog = new Dialog(GroupEditPage.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText = (TextView) customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn = (Button) customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setText(getResources().getString(R.string.alert_msg_yes));
                        alertMessageText.setText(getResources().getString(R.string.add_group_not_attach_photo_alert));
                        customDialog.setCancelable(true);
                        alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                customDialog.dismiss();
                                setNetworkDto();
                            }
                        });
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                    } else {
                        if(groupImgByteArray==null){
                            new loadImage().execute();
                        }else{
                            setNetworkDto();
                        }

                    }



                }
                break;
        }
    }

    private void setNetworkDto() {
        if(groupTyprStr.equals("Others")){
            networkDto.setNetworkTypeId(4);
        }else{
            networkDto.setNetworkTypeId(1);
        }
        networkDto.setName(groupName.getText().toString().trim());
        networkDto.setNetworkDetails(groupDetails.getText().toString().trim());
        networkDto.setAddressline1(groupAddress.getText().toString().trim());
        networkDto.setAddressline2(apartNameOrganizationName.getText().toString().trim());
        networkDto.setLatitude(latitude);
        networkDto.setLongitude(longitude);
        networkDto.setPincode(pincode);
        networkDto.setMemberId(Long.parseLong(memberId));
        networkDto.setNetworkImage(groupImgByteArray);
        networkDto.setPicture(picture);
        reqData=new Gson().toJson(networkDto);
        new getChangeResponse().execute();
    }

    private boolean checkAddListingValidation() {
        boolean valueReturn = true;
        if (!Validation.hasText(groupName))
            valueReturn = false;
        if (!Validation.hasText(groupDetails))
            valueReturn = false;
        if (!Validation.hasText(groupAddress))
            valueReturn = false;
        return valueReturn;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        groupTyprStr=groupTypeSpinner.getSelectedItem().toString().trim();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    // ******** Google place auto complete *******


    private class googleAutoComplete extends AsyncTask<Void,Integer,Void> {
        @Override
        protected Void doInBackground(Void... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(url);

            if(result !=null)
            {
                try {
                    // Getting Array of Contacts

                    JSONObject json=new JSONObject(result);
                    JSONArray googlePlace=json.getJSONArray(TAG_RESULT);

                    for(int i = 0; i < googlePlace.length(); i++){
                        JSONObject c = googlePlace.getJSONObject(i);
                        String description = c.getString("description");
                        Log.d("description", description);
                        area.add(description);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                    android.R.layout.simple_list_item_1, area) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    View view = super.getView(position, convertView, parent);
                    TextView text = (TextView) view.findViewById(android.R.id.text1);
                    text.setTextColor(Color.BLACK);
                    return view;
                }
            };


            groupAddress.setAdapter(arrayAdapter);
            String strAddress=groupAddress.getText().toString();
            /*Geocoder coder = new Geocoder(GroupEditPage.this);
            try {
                ArrayList<Address> adresses = (ArrayList<Address>) coder.getFromLocationName(strAddress, 50);
                for(Address add : adresses){
                    //Controls to ensure it is right address such as country etc.
                    longitude =add.getLongitude();
                    latitude = add.getLatitude();
                    zip=add.getPostalCode();
                    if(zip!=null)
                    pincode= Integer.parseInt(zip);


                    //latLng.setText("("+String.valueOf(longitude)+" ,  "+String.valueOf(latitude)+")"+zip);

                }
            } catch (IOException e) {
                e.printStackTrace();
            }*/

        }
    }

    // **************** Capture Product Image ***************************
    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Library","No Image","Cancel"};

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(GroupEditPage.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Take Photo")) {
                    cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    galleryIntent();

                }else if (items[item].equals("No Image")) {
                    groupImage.setImageResource(R.drawable.no_image);
                    groupImgByteArray=null;

                }
                else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent()
    {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }

    private void cameraIntent()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        String picturePath=destination.getPath();
        thumbnail=changeOrientation(picturePath,thumbnail);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        groupImgByteArray= bytes.toByteArray();
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        groupImage.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Uri selectedImageUri = data.getData();
        String picturePath= getRealPathFromURI(selectedImageUri);
        Bitmap bm=null;
        if (data!= null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {

            InputStream imageStream = getContentResolver().openInputStream(selectedImageUri);
            Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);

            selectedImage = getResizedBitmap(selectedImage, 400);// 400 is for example, replace with desired size
            selectedImage=changeOrientation(picturePath,selectedImage);
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            selectedImage.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
            groupImgByteArray= bytes.toByteArray();
            groupImage.setImageBitmap(selectedImage);


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
    private Bitmap changeOrientation(String picturePath, Bitmap loadedBitmap) {
        if(picturePath!=null) {
            ExifInterface exif = null;
            try {
                File pictureFile = new File(picturePath);
                exif = new ExifInterface(pictureFile.getAbsolutePath());
            } catch (IOException e) {
                e.printStackTrace();
            }

            int orientation = ExifInterface.ORIENTATION_NORMAL;

            if (exif != null)
                orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    loadedBitmap = rotateBitmap(loadedBitmap, 90);
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    loadedBitmap = rotateBitmap(loadedBitmap, 180);
                    break;

                case ExifInterface.ORIENTATION_ROTATE_270:
                    loadedBitmap = rotateBitmap(loadedBitmap, 270);
                    break;
            }
        }
        return loadedBitmap;
    }


    public static Bitmap rotateBitmap(Bitmap bitmap, int degrees) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }
    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    public String getRealPathFromURI(Uri contentUri) {
        String [] proj={MediaStore.Images.Media.DATA};
        Cursor cursor = managedQuery( contentUri, proj, null, null, null); // Order-by clause (ascending by name)
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String path= cursor.getString(column_index);
        return path;

    }
    // **************** Capture Product Image method finished ***************************

    private class getGroupDetail extends AsyncTask<String,String,String>{
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getnetworkbynetworkid.json?networkid="+groupIdStr);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONObject jsonObject=new JSONObject(s);
                    networkDto=new Gson().fromJson(jsonObject.toString().trim(),NetworkDto.class);
                    setGroupDetails();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
               callAlertDialog("Server Down... Please try again");
            }
        }
    }

    private void setGroupDetails() {
        picture=networkDto.getPicture();
        latitude=networkDto.getLatitude();
        longitude=networkDto.getLongitude();
        pincode=networkDto.getPincode();
        groupName.setText(networkDto.getName());
        groupDetails.setText(networkDto.getNetworkDetails());
        groupAddress.setText(networkDto.getAddressline1());
        apartNameOrganizationName.setText(networkDto.getAddressline2());
        if(networkDto.getNetworkTypeName().equals("Apartment/Residential")){
            groupTypeSpinner.setSelection(0);
        }else if(networkDto.getNetworkTypeName().equals("Others")){
            groupTypeSpinner.setSelection(1);
        }
        if (picture==null||picture.equals("No Image")||picture.equals("")) {
            /*changePicBtn.setText(getResources().getString(R.string.add_image));*/
            Glide.clear(groupImage);
            groupImage.setImageResource(R.drawable.no_image);
        } else {
           /* changePicBtn.setText(getResources().getString(R.string.change_pic));*/
            Glide.with(GroupEditPage.this)
                    .load(Webconfig.CONTEXT_PATH1 + "images/" +picture).thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(groupImage);
        }



    }


    private class getChangeResponse extends AsyncTask<String,String,String>{
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(GroupEditPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData,Webconfig.CONTEXT_PATH+"editnetwork.json");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject jsonObject=null;
            progressDialog.dismiss();
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status","");
                    System.out.println(status);
                    if(status.equals("success")){
                        customDialog = new Dialog(GroupEditPage.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setVisibility(View.GONE);
                        alertMessageText.setText(getResources().getString(R.string.group_edit_success_msg));
                        customDialog.setCancelable(true);
                        customDialog.setCanceledOnTouchOutside(true);
                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        customDialog.dismiss();
                                        startActivity(new Intent(GroupEditPage.this,GroupPage.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));

                                    }
                                }
                        );
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            else{
                callAlertDialog("Server down...");
            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(GroupEditPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }
    private class loadImage extends AsyncTask<String,String,Bitmap> {
        @Override
        protected Bitmap doInBackground(String... params) {
            try {
                bitmap = Glide.with(GroupEditPage.this).load(Webconfig.CONTEXT_PATH1 + "images/" + picture).asBitmap().into(100, 100).get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            groupImgByteArray= stream.toByteArray();
            setNetworkDto();
        }
    }


//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(GroupEditPage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(GroupEditPage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(GroupEditPage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(GroupEditPage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(GroupEditPage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(GroupEditPage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(GroupEditPage.this, AddGroupActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(GroupEditPage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(GroupEditPage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(GroupEditPage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(GroupEditPage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(GroupEditPage.this, MessageActivity.class));
//            finish();
//        }
//
//       /* else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(GroupEditPage.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(GroupEditPage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(GroupEditPage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(GroupEditPage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(GroupEditPage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(GroupEditPage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(GroupEditPage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(GroupEditPage.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(GroupEditPage.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
