package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import info.com.neighbourbase.Adapter.ContactListFeedbackAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class UsefulContactDetailPage extends AppCompatActivity implements View.OnClickListener {
    String contactListId,categoryName,memberId;
    ImageView backIcon;
    TextView categoryType,name,contact_no,contactAddress,email,postedBy,alertMessageText;
    LinearLayout detailsEditLayout;
    Button removeListBtn,changeListBtn,alertMsgOkBtn;
    SharedPreferences sharedPreferences;
    ListView feedbackList;
    Dialog customDialog;
    CommonResponseDto commonResponseDto=new CommonResponseDto();
    ArrayAdapter contactListFeedbackAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_useful_contact_detail_page);
        sharedPreferences= PreferenceManager.getDefaultSharedPreferences(this);
        memberId=sharedPreferences.getString("memberId","");
        Bundle intent=getIntent().getExtras();
        contactListId=intent.getString("contactListId");
        categoryName=intent.getString("categoryName");
        mInit();
        if(Connectivity.isConnected(UsefulContactDetailPage.this)) {
            new getContactPersonDetails().execute();
        }else{
            callAlertDialog("Please Check Internet Connection");
        }



    }

    private void fillDetails() {
        categoryType.setText(commonResponseDto.getNetworkContactListDto().getCategoryName());
        name.setText("Name :"+" "+commonResponseDto.getNetworkContactListDto().getName());
        contact_no.setText("Contact :"+" "+commonResponseDto.getNetworkContactListDto().getMobile());
        postedBy.setText("Posting Done by :"+" "+commonResponseDto.getNetworkContactListDto().getCreatedMemberName());
        if(commonResponseDto.getNetworkContactListDto().getEmail()!=null&&commonResponseDto.getNetworkContactListDto().getEmail().length()>0){
            email.setVisibility(View.VISIBLE);
            email.setText("E-mail :"+" "+commonResponseDto.getNetworkContactListDto().getEmail());

        }else{
            email.setVisibility(View.GONE);
        }

        if(commonResponseDto.getNetworkContactListDto().getAddress1()!=null&&commonResponseDto.getNetworkContactListDto().getAddress1().length()>0){
            if(commonResponseDto.getNetworkContactListDto().getAddress2()!=null&&commonResponseDto.getNetworkContactListDto().getAddress2().length()>0){
                contactAddress.setVisibility(View.VISIBLE);
                contactAddress.setText("Address :"+" "+commonResponseDto.getNetworkContactListDto().getAddress1()+", "+commonResponseDto.getNetworkContactListDto().getAddress2());
            }else{
                contactAddress.setVisibility(View.VISIBLE);
                contactAddress.setText("Address :"+" "+commonResponseDto.getNetworkContactListDto().getAddress1());
            }

        }else if(commonResponseDto.getNetworkContactListDto().getAddress2()!=null&&commonResponseDto.getNetworkContactListDto().getAddress2().length()>0){
            contactAddress.setVisibility(View.VISIBLE);
            contactAddress.setText("Address :"+" "+commonResponseDto.getNetworkContactListDto().getAddress2());
        }else{
            contactAddress.setVisibility(View.GONE);
        }
        String createMemberId= String.valueOf(commonResponseDto.getNetworkContactListDto().getCreatedMemberId());
        int flag=commonResponseDto.getNetworkContactListDto().getModerator_flag();

        if(createMemberId.equals(memberId)||flag==1){
            removeListBtn.setVisibility(View.VISIBLE);
            changeListBtn.setVisibility(View.VISIBLE);

        }else{
            removeListBtn.setVisibility(View.GONE);
            changeListBtn.setVisibility(View.GONE);
        }


        contactListFeedbackAdapter=new ContactListFeedbackAdapter(UsefulContactDetailPage.this,commonResponseDto.getNetworkContactListFeedbackDtos());
        feedbackList.setAdapter(contactListFeedbackAdapter);



    }

    private void mInit() {
        backIcon=(ImageView)findViewById(R.id.back_icon);
        categoryType=(TextView)findViewById(R.id.category_type);
        name=(TextView)findViewById(R.id.name);
        contact_no=(TextView)findViewById(R.id.contact_no);
        contactAddress=(TextView)findViewById(R.id.address);
        email=(TextView)findViewById(R.id.email);
        postedBy=(TextView)findViewById(R.id.posting_by);
        detailsEditLayout=(LinearLayout)findViewById(R.id.detailsEditLayout);
        removeListBtn=(Button)findViewById(R.id.contact_remove_btn);
        changeListBtn=(Button)findViewById(R.id.contact_change_btn);
        feedbackList=(ListView)findViewById(R.id.feedback_list);
        removeListBtn.setOnClickListener(this);
        changeListBtn.setOnClickListener(this);

        backIcon.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.back_icon:
                finish();
                break;
            case R.id.contact_remove_btn:
                customDialog = new Dialog(UsefulContactDetailPage.this);
                customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customDialog.setContentView(R.layout.custom_messbox);
                alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                alertMsgOkBtn.setVisibility(View.VISIBLE);
                alertMsgOkBtn.setText(getResources().getString(R.string.alert_msg_yes));
                alertMessageText.setText(getResources().getString(R.string.contact_remove_msg));
                customDialog.setCancelable(true);
                customDialog.setCanceledOnTouchOutside(true);
                alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customDialog.dismiss();
                        new contactRemoveResponse().execute();
                    }
                });
                customDialog.setOnCancelListener(
                        new DialogInterface.OnCancelListener() {
                            @Override
                            public void onCancel(DialogInterface dialog) {
                                customDialog.dismiss();

                            }
                        }

                );
                customDialog.show();
                customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                break;
            case R.id.contact_change_btn:
                startActivity(new Intent(UsefulContactDetailPage.this,ContactListEditPage.class).putExtra("contactListId",contactListId));
                break;
        }

    }

    private class getContactPersonDetails extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(UsefulContactDetailPage.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
        }
        @Override
        protected String doInBackground(String... strings) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getdetailsaboutcontactbylistid.json?listid="+contactListId+"&memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            if(s!=null){
                try {
                    JSONObject detailJsonObj=new JSONObject(s);
                    commonResponseDto=new Gson().fromJson(detailJsonObj.toString(),CommonResponseDto.class);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                fillDetails();

            }else{
                callAlertDialog("server down");


            }
        }
    }

    private class contactRemoveResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(UsefulContactDetailPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"removecontactlist.json?listid="+commonResponseDto.getNetworkContactListDto().getListId());
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            if(s!=null){
                if(s.trim().equalsIgnoreCase("success")){
                    customDialog = new Dialog(UsefulContactDetailPage.this);
                    customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    customDialog.setContentView(R.layout.custom_messbox);
                    alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                    alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                    alertMsgOkBtn.setVisibility(View.GONE);
                    alertMessageText.setText(getResources().getString(R.string.contact_remove_success_msg));
                    customDialog.setCancelable(true);
                    customDialog.setCanceledOnTouchOutside(true);
                    customDialog.setOnCancelListener(
                            new DialogInterface.OnCancelListener() {
                                @Override
                                public void onCancel(DialogInterface dialog) {
                                    customDialog.dismiss();
                                    startActivity(new Intent(UsefulContactDetailPage.this,UsefulContactsPage.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                                    finish();

                                }
                            }

                    );
                    customDialog.show();
                    customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                }else if(s.trim().equalsIgnoreCase("fail")){
                    callAlertDialog("contact list deleted failed try again..");
                }
            }else{
                callAlertDialog("server down");
            }
        }
    }

    private void callAlertDialog(String message) {

        customDialog = new Dialog(UsefulContactDetailPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }
}
