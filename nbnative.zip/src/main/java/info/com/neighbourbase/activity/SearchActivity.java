package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import info.com.neighbourbase.R;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

import static info.com.neighbourbase.activity.Header.messageCount;

public class SearchActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener  {
    AutoCompleteTextView productName;
    String memberId, proNameStr, radius,latitude,longitude,groupId;
    ArrayList<String> productList=new ArrayList<>();
    ArrayAdapter<String> productAdapter;
    ImageView backIcon;
    TextView alertMessageText;
    Dialog customDialog;
    Button proNameOk,alertMsgOkBtn;

    SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        mInit();
        productName.addTextChangedListener(textWatcher);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        memberId=preferences.getString("memberId","");
        radius=preferences.getString("radius","");
        latitude=preferences.getString("latitude","");
        longitude=preferences.getString("longitude","");
        backIcon.setOnClickListener(this);
        productName.setOnItemClickListener(this);
        if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")||Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
            groupId=preferences.getString("groupId","");
        }else{
            groupId="2";
        }


    }

    private void mInit() {
        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "SearchActivity";
        backIcon=(ImageView)findViewById(R.id.back_icon);
        productName=(AutoCompleteTextView)findViewById(R.id.product_name);
    }

    TextWatcher textWatcher=new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            productList.clear();
            proNameStr=productName.getText().toString();
            new getProductName().execute();

        }
    };

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_icon:
                onBackPressed();
                break;

        }
    }

    private void updateProductName(String productNameStr) {
        SharedPreferences.Editor e = preferences.edit();
        e.putString("SearchProductName", productNameStr);
        e.commit();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String productNameStr=productName.getText().toString();
        updateProductName(productNameStr);
        if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")||Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
            startActivity(new Intent(SearchActivity.this,GroupProductListingPage.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            finish();
        }else{
            startActivity(new Intent(SearchActivity.this,HomeScreen.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            finish();
        }
        /*startActivity(new Intent(SearchActivity.this,HomeScreen.class));*/
    }

    private class getProductName extends AsyncTask<String,String,String>{
       /* ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(SearchActivity.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }*/
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httpget(Webconfig.CONTEXT_PATH+"productnamesearch.json?productName="+proNameStr+"&networkId="+groupId+"&memberId="+memberId+"&radius="+radius+"&latitude="+latitude+"&longitude="+longitude);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject jsonObject=null;
            JSONArray jsonArray=null;
           /* progressDialog.dismiss();*/
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status = jsonObject.getString("status");
                    productList.clear();
                 /*   Constant.messageUnreadCount = jsonObject.getLong("unreadCount");
                    CommonHeader.messageCount.setText(String.valueOf(Constant.messageUnreadCount));*/

                    if(status.equalsIgnoreCase("success")) {
                        jsonArray = jsonObject.getJSONArray("productSearchName");
                        if(jsonArray.length()>0) {
                            for (int i = 0; i < jsonArray.length(); i++) {
                                productList.add(jsonArray.getString(i));
                            }
                            productAdapter = new ArrayAdapter<String>(SearchActivity.this, android.R.layout.simple_dropdown_item_1line, productList);
                            productName.setThreshold(1);
                            productName.setAdapter(productAdapter);
                            productName.showDropDown();
                            productAdapter.setNotifyOnChange(true);
                        }
                    }else{
                       callAlertDialog("No such product available for your need");

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
             /* else{
            callAlertDialog("Server down, please try after sometime");

        }*/
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(SearchActivity.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(SearchActivity.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(SearchActivity.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(SearchActivity.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(SearchActivity.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(SearchActivity.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(SearchActivity.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(SearchActivity.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(SearchActivity.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(SearchActivity.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(SearchActivity.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(SearchActivity.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(SearchActivity.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(SearchActivity.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(SearchActivity.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(SearchActivity.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(SearchActivity.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(SearchActivity.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(SearchActivity.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(SearchActivity.this, AddGroupActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(SearchActivity.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(SearchActivity.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
