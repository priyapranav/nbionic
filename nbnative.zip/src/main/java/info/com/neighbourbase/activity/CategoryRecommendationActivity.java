package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import info.com.neighbourbase.Adapter.CategoryDisplayAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CategoryDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class CategoryRecommendationActivity extends AppCompatActivity implements View.OnClickListener {
    ListView categoryList;
    ImageView backIcon;
    Button categorySelectButton;
    Button alertMsgOkBtn;
    ArrayList<String> rootCategory;
    ArrayList<String> availableCategory;
    CategoryDto categoryDto;
    CategoryDisplayAdapter categoryDisplay;
    SharedPreferences preferences;
    int catPosition;
    int userCatPos=-1;
    ArrayList<Long> categoryIds;
    TextView alertMessageText;
    Long categoryId;
    Long userCategoryId;
    String productNameStr;
    String catPositionStr;
    Dialog customDialog;
    String categoryIdStr="categoryId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.category_select_for_listing_page);
        productNameStr=getIntent().getStringExtra("productName");
        userCategoryId=getIntent().getLongExtra(categoryIdStr,1L);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        mInit();
        new GetCategory().execute();
        categorySelectButton.setOnClickListener(this);
        backIcon.setOnClickListener(this);


    }

    private void goToIntent() {
        Intent intent=new Intent();
        intent.putExtra(categoryIdStr,categoryId);
        setResult(2,intent);
        finish();
    }

    private void mInit() {
        backIcon=(ImageView)findViewById(R.id.back_icon);
        categoryList=(ListView)findViewById(R.id.category_select_list);
        categorySelectButton=(Button)findViewById(R.id.category_select_button);
        categoryList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.category_select_button:
                catPositionStr = preferences.getString(categoryIdStr, "");
                catPosition = Integer.parseInt(catPositionStr);
                if(catPosition==-1) {
                    categoryId = 9L;
                }else {categoryId = categoryIds.get(catPosition);}
                goToIntent();
                break;
            case R.id.back_icon:
                finish();
                break;
        }
    }

    private class GetCategory extends AsyncTask<String,String,String> {
        String productNameStrChange=productNameStr.replaceAll(" ","%20");
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"categoryrecommendation.json?catname="+productNameStrChange);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            if(s!=null){
                JSONObject jsonObject;
                JSONArray jsonArray;
                categoryDto=new CategoryDto();
                rootCategory=new ArrayList<>();
                availableCategory=new ArrayList<>();
                categoryIds=new ArrayList<>();
                try {
                    jsonObject=new JSONObject(s);
                    jsonArray=jsonObject.getJSONArray("categoryLevel1");
                    for(int i=0;i<jsonArray.length();i++){
                        rootCategory.add(jsonArray.get(i).toString());
                    }
                    jsonArray=jsonObject.getJSONArray("categoryLevel2");
                    for(int i=0;i<jsonArray.length();i++){
                        availableCategory.add(jsonArray.get(i).toString());
                    }
                    rootCategory.add("others");
                    availableCategory.add("others");
                    jsonArray=jsonObject.getJSONArray("categoryDtos");
                    for(int i=0;i<jsonArray.length();i++){
                        jsonObject=jsonArray.getJSONObject(i);
                        Gson gson=new Gson();
                        categoryDto=gson.fromJson(jsonObject.toString(),CategoryDto.class);
                        categoryIds.add(categoryDto.getCategoryId());
                    }
                    userCatPos=categoryIds.indexOf(userCategoryId);
                    categoryDisplay=new CategoryDisplayAdapter(CategoryRecommendationActivity.this,rootCategory,availableCategory,userCatPos);
                    categoryList.setAdapter(categoryDisplay);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }else{
               callAlertDialog("Check Your Internet Connection");
            }
        }
        private void callAlertDialog(String message) {

            customDialog = new Dialog(CategoryRecommendationActivity.this);
            customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            customDialog.setContentView(R.layout.custom_messbox);
            customDialog.setCancelable(true);
            alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
            alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
            alertMessageText.setText(message);
            alertMsgOkBtn.setVisibility(View.GONE);
            customDialog.show();
            customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


        }
    }


}
