package info.com.neighbourbase.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import info.com.neighbourbase.Adapter.CategoryDisplayAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CategoryDto;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

import static android.R.attr.breadCrumbShortTitle;
import static android.R.attr.data;
import static info.com.neighbourbase.R.id.imageView;
import static info.com.neighbourbase.activity.Header.messageCount;

public class AddProductPage extends CommonHeader implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    EditText productName,productDescription,salePrice,rentPerDay,rentPerWeek,rentPerMonth;
    Spinner selectListingType,productAvailableFrom,productAvailableTo;
    TextView thru,listProductIn,alertMessageText;
    ImageView productImage,addImageIcon;
    Button addListingBtn,categorySelectButton,alertMsgOkBtn;
    RadioButton availableFrom,availableOnlyOn;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private String userChoosenTask;
    byte[] productImgByteArray;
    SharedPreferences preferences;
    String[] listingType={"Lend","Rent","Sell","GiveAway"};
    String[] days={"Select","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
    String[] network={"public","info","career"};
    String rentPerDayStr,rentPerWeekStr,rentPerMonthStr,selectListingTypeStr,productAvailableFromSpinnerStr,productAvailableToSpinnerStr,reqData,memberId,productNameStr,productDescriptionStr,catPositionStr;
    LinearLayout salePriceLayout,rentalPriceLayout,productAvailableLayout;
    ArrayAdapter<String> listTypeAdapter,daysAdapter;
    ArrayList<String> dayList,dayList1,networkList,networkName,rootCategory,availableCategory;
    ArrayList<Long> networkId,userSelectNetworkId,categoryIds;
    ProductListingDto productListingDto;
    int transTypeId,catPosition,check=0;
    ListView categoryList;
    Map<String,Long> productNetwork;
    PopupWindow categoryNameSelect;
    CategoryDto categoryDto;
    CategoryDisplayAdapter categoryDisplay;
    Long addProductCatId;
    Dialog customDialog;
    Spinner rootCategorySpinner;
    Spinner subCategorySpinner;
    List<CategoryDto> categoryDtoLists;
    List<String> categoryNameList;
    List<Long> categoryIdList;
    Map<String,Long> categoryMap;

    List<String> catList;
    Map<String,Long> categoryIdName=new HashMap<>();
    Long rootId;
    Long subCatId;
    ArrayAdapter catAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.add_product_page);

        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.add_product_page, FrameLayout);

        mInit();
        if(Connectivity.isConnected(AddProductPage.this)) {
            new getNetworkName().execute();
        }else{
            callAlertDialog("Please Check Internet Connection");
        }

    }

    private void mInit() {

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "AddProductPage";
        memberId = CommonHeader.memberId;
        productName=(EditText)findViewById(R.id.product_name);
        productDescription=(EditText)findViewById(R.id.product_description);
        salePrice=(EditText)findViewById(R.id.sale_price);
        rentPerDay=(EditText)findViewById(R.id.rent_per_day);
        rentPerMonth=(EditText)findViewById(R.id.rent_per_month);
        rentPerWeek=(EditText)findViewById(R.id.rent_per_week);
        selectListingType=(Spinner)findViewById(R.id.select_listing_type);
        productAvailableFrom=(Spinner)findViewById(R.id.spinner_from);
        productAvailableTo=(Spinner)findViewById(R.id.spinner_to);
        listProductIn=(TextView)findViewById(R.id.list_product_in);
        thru=(TextView)findViewById(R.id.thru);
        productImage=(ImageView)findViewById(R.id.product_image);
        addImageIcon=(ImageView)findViewById(R.id.add_image_icon);
        addListingBtn=(Button)findViewById(R.id.add_listing_btn);
        availableFrom=(RadioButton)findViewById(R.id.radioBtnFrom);
        availableOnlyOn=(RadioButton)findViewById(R.id.radioBtnOnlyOn);
        rentalPriceLayout=(LinearLayout)findViewById(R.id.rental_price_layout);
        salePriceLayout=(LinearLayout)findViewById(R.id.sale_price_layout);
        productAvailableLayout=(LinearLayout)findViewById(R.id.product_available_layout);
        rootCategorySpinner=(Spinner)findViewById(R.id.root_category_spinner);
        subCategorySpinner=(Spinner)findViewById(R.id.sub_category_spinner);


        listTypeAdapter =new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,listingType);
        selectListingType.setAdapter(listTypeAdapter);
        dayList = new ArrayList<String>(Arrays.asList(days));
        dayList1=new ArrayList<String>();
        networkList=new ArrayList<String>(Arrays.asList(network));
        daysAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,dayList);
        productAvailableFrom.setAdapter(daysAdapter);
        productAvailableTo.setAdapter(daysAdapter);
        availableFrom.setChecked(true);
        productAvailableFrom.setSelection(1);
        productAvailableTo.setSelection(7);
        listProductIn.setText("Public");

        addListingBtn.setOnClickListener(this);
        availableOnlyOn.setOnClickListener(this);
        availableFrom.setOnClickListener(this);
        selectListingType.setOnItemSelectedListener(this);
        productAvailableFrom.setOnItemSelectedListener(this);
        productAvailableTo.setOnItemSelectedListener(this);
        addImageIcon.setOnClickListener(this);
        listProductIn.setOnClickListener(this);
        new LoadRootCategory().execute();
        rootCategorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String catName=categoryNameList.get(position).trim();
                if (catName.equals("Select Category")){
                subCategorySpinner.setVisibility(View.GONE);
                }else{
                    rootId = categoryMap.get(categoryNameList.get(position).trim());
                    addProductCatId=rootId;
                    new GetSubCategory().execute();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

       
    }

    private boolean checkAddListingValidation() {
        rentPerWeekStr=rentPerWeek.getText().toString().trim();
        rentPerMonthStr=rentPerMonth.getText().toString().trim();
        rentPerDayStr=rentPerDay.getText().toString().trim();
        boolean valueReturn = true;
        if (!Validation.hasText(productName))
            valueReturn = false;
        if(listProductIn.getText().toString().equals(getResources().getString(R.string.click_here)))
        { callAlertDialog("Select NetWork");
            valueReturn=false;}
        if(!Validation.hasText(productDescription))
            valueReturn=false;
        if(selectListingTypeStr.equals("Sell")) {
            if (!Validation.hasText(salePrice))
                valueReturn = false;
            if(salePrice.getText().toString().equals("0.0")){
                salePrice.setError("sale price required");
                valueReturn=false;
            }
        }
        if(selectListingTypeStr.equals("Rent")){
            if(rentPerDayStr.length()==0||rentPerDayStr.equals("0")){
                if(rentPerWeekStr.length()==0||rentPerWeekStr.equals("0")){
                    if(rentPerMonthStr.length()==0||rentPerMonthStr.equals("0")){
                        callAlertDialog("Enter at least any one the Rental price field");
                        valueReturn=false;
                    }
                }
            }
        }
        if(transTypeId==1){
            if(availableFrom.isChecked()){
                if(productAvailableFromSpinnerStr.equals("Select")){
                    callAlertDialog("Select Duration");
                    valueReturn=false;
                }else if(productAvailableToSpinnerStr.equals("Select")){
                    callAlertDialog("Select Duration");
                    valueReturn=false;
                }
            }
            if(availableOnlyOn.isChecked()){
                if(productAvailableFromSpinnerStr.equals("Select")){
                    callAlertDialog("Select Duration");
                    valueReturn=false;
                }

            }

        }
        String selectRootCatString=rootCategorySpinner.getSelectedItem().toString();
        if(selectRootCatString.trim().equals("Select Category")){
            callAlertDialog("Select Valid Category");
            valueReturn=false;
        }else{
            addProductCatId=rootId;
        }
        if(subCategorySpinner.getVisibility()==View.VISIBLE){
            String selectSubCatString=subCategorySpinner.getSelectedItem().toString();
            if(selectSubCatString.trim().equals("Select Sub-Category")){
                callAlertDialog("Select Valid Sub-Category");
                valueReturn=false;
            }else
                {
                    subCatId = categoryIdName.get(selectSubCatString.trim());
                    addProductCatId=subCatId;

                }

        }


        return valueReturn;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.add_listing_btn:
                if(checkAddListingValidation()) {
                    if (productImage.getVisibility()==View.GONE||productImage.getDrawable().getConstantState()==getResources().getDrawable(R.drawable.no_image).getConstantState()) {
                        customDialog = new Dialog(AddProductPage.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setText(getResources().getString(R.string.alert_msg_yes));
                        alertMessageText.setText(getResources().getString(R.string.add_product_no_img_msg));
                        customDialog.setCancelable(true);
                        alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                customDialog.dismiss();
                                setProductListingDto();
//                                productNameStr = productName.getText().toString().trim();
//                                Intent i=new Intent(AddProductPage.this,CategoryRecommendationActivity.class);
//                                i.putExtra("productName",productNameStr);
//                                startActivityForResult(i,2);
                            }
                        });
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                    }else{
                        setProductListingDto();
//                        productNameStr = productName.getText().toString().trim();
//                        Intent i=new Intent(AddProductPage.this,CategoryRecommendationActivity.class);
//                        i.putExtra("productName",productNameStr);
//                        startActivityForResult(i,2);

                    }

                }
                break;
            case R.id.radioBtnOnlyOn:
                thru.setVisibility(View.GONE);
                productAvailableTo.setVisibility(View.GONE);
                break;
            case R.id.radioBtnFrom:
                thru.setVisibility(View.VISIBLE);
                productAvailableTo.setVisibility(View.VISIBLE);
                break;
            case R.id.add_image_icon:
                selectImage();
                break;
            case R.id.list_product_in:
                loadNetwork();
                break;

        }
    }


    private void setProductListingDto() {
        productNameStr = productName.getText().toString().trim();
        productDescriptionStr = productDescription.getText().toString().trim();
        productListingDto = new ProductListingDto();
        productListingDto.setProductName(productNameStr);
        productListingDto.setProductDescription(productDescriptionStr);
        productListingDto.setNetworkId(2);
        productListingDto.setTransTypeId(transTypeId);
        productListingDto.setProductImage(productImgByteArray);
        productListingDto.setMemberId(Long.parseLong(memberId));
        if(selectListingTypeStr.equals("Sell"))
            productListingDto.setSalePrice(Double.parseDouble(salePrice.getText().toString()));
        if(selectListingTypeStr.equals("Rent")) {
            if(rentPerDayStr.equals(""))
                rentPerDayStr="0";
            if(rentPerWeekStr.equals(""))
                rentPerWeekStr="0";
            if(rentPerMonthStr.equals(""))
                rentPerMonthStr="0";
            productListingDto.setPriceperday(Long.parseLong(rentPerDayStr));
            productListingDto.setPriceperweek(Long.parseLong(rentPerWeekStr));
            productListingDto.setPricepermonth(Long.parseLong(rentPerMonthStr));
        }
        getDayfromDayto();
        getUserSelectNetworkId();
        if(availableOnlyOn.isChecked())
            productAvailableToSpinnerStr="0";
        productListingDto.setNetworkids(userSelectNetworkId);
        productListingDto.setDayfrom(productAvailableFromSpinnerStr);
        productListingDto.setDayto(productAvailableToSpinnerStr);
        productListingDto.setCategoryId(addProductCatId);
        reqData=new Gson().toJson(productListingDto);
        new getAddListingResponse().execute();
//        new getCategory().execute();
    }

    private void showCategorySelectPopup(final Activity context) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.category_select_for_listing_page,
                (ViewGroup)context. findViewById(R.id.popup));
        categoryNameSelect = new PopupWindow(layout, 950, 1000, true);
        categoryNameSelect.showAtLocation(layout, Gravity.CENTER, 0, 0);
        categoryList=(ListView)layout.findViewById(R.id.category_select_list);
        categorySelectButton=(Button)layout.findViewById(R.id.category_select_button);
        categoryList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        categoryList.setAdapter(categoryDisplay);
        categorySelectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoryNameSelect.dismiss();
                catPositionStr=preferences.getString("categoryId","");
                catPosition= Integer.parseInt(catPositionStr);
                Long addProductCatId=categoryIds.get(catPosition);
                productListingDto.setCategoryId(addProductCatId);
                reqData=new Gson().toJson(productListingDto);
                new getAddListingResponse().execute();
            }
        });

    }

    private void getUserSelectNetworkId() {
        userSelectNetworkId=new ArrayList<Long>();
        String network= listProductIn.getText().toString().trim();
        String[] networkStr=network.split(",");
        for (String aNetworkStr : networkStr) {
            userSelectNetworkId.add((Long) productNetwork.get(aNetworkStr));
        }

    }

    private void getDayfromDayto() {
        if (productAvailableFromSpinnerStr.equals("Select"))
            productAvailableFromSpinnerStr="0";
        if (productAvailableFromSpinnerStr.equals("Sunday"))
            productAvailableFromSpinnerStr = "1";
        if (productAvailableFromSpinnerStr.equals("Monday"))
            productAvailableFromSpinnerStr = "2";
        if (productAvailableFromSpinnerStr.equals("Tuesday"))
            productAvailableFromSpinnerStr = "3";
        if (productAvailableFromSpinnerStr.equals("Wednesday"))
            productAvailableFromSpinnerStr = "4";
        if (productAvailableFromSpinnerStr.equals("Thursday"))
            productAvailableFromSpinnerStr = "5";
        if (productAvailableFromSpinnerStr.equals("Friday"))
            productAvailableFromSpinnerStr = "6";
        if (productAvailableFromSpinnerStr.equals("Saturday"))
            productAvailableFromSpinnerStr = "7";
        if (productAvailableToSpinnerStr.equals("Select"))
            productAvailableToSpinnerStr="0";
        if (productAvailableToSpinnerStr.equals("Sunday"))
            productAvailableToSpinnerStr = "1";
        if (productAvailableToSpinnerStr.equals("Monday"))
            productAvailableToSpinnerStr = "2";
        if (productAvailableToSpinnerStr.equals("Tuesday"))
            productAvailableToSpinnerStr = "3";
        if (productAvailableToSpinnerStr.equals("Wednesday"))
            productAvailableToSpinnerStr = "4";
        if (productAvailableToSpinnerStr.equals("Thursday"))
            productAvailableToSpinnerStr = "5";
        if (productAvailableToSpinnerStr.equals("Friday"))
            productAvailableToSpinnerStr = "6";
        if (productAvailableToSpinnerStr.equals("Saturday"))
            productAvailableToSpinnerStr = "7";
    }

    private void loadNetwork() {
        final CharSequence[] dialogList=  networkName.toArray(new CharSequence[networkName.size()]);
        final android.app.AlertDialog.Builder builderDialog = new android.app.AlertDialog.Builder(AddProductPage.this);
        builderDialog.setTitle("Select Network");
        int count = dialogList.length;
        final boolean[] is_checked = new boolean[count];
        if(listProductIn.getText().toString().length()!=0){
            String network= listProductIn.getText().toString().trim();
            String[] networkStr=network.split(",");
            for(String networkList:networkStr){
             for(int j=0;j<networkName.size();j++){
                 if(networkName.get(j).equals(networkList))
                     is_checked[j]=true;
             }
            }
        }


        // Creating multiple selection by using setMutliChoiceItem method
        builderDialog.setMultiChoiceItems(dialogList, is_checked,
                new DialogInterface.OnMultiChoiceClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int whichButton, boolean isChecked) {
                    }
                });

        builderDialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        ListView list = ((android.app.AlertDialog) dialog).getListView();

                        // make selected item in the comma seprated string
                        StringBuilder stringBuilder = new StringBuilder();
                        for (int i = 0; i < list.getCount(); i++) {
                            boolean checked = list.isItemChecked(i);

                            if (checked) {
                                if (stringBuilder.length() > 0) stringBuilder.append(",");
                                stringBuilder.append(list.getItemAtPosition(i));


                            }
                        }

                        /*Check string builder is empty or not. If string builder is not empty.
                          It will display on the screen.
                         */
                        if (stringBuilder.toString().trim().equals("")) {

                            listProductIn.setText("Public");
                            stringBuilder.setLength(0);

                        } else {

                            listProductIn.setText(stringBuilder);
                        }
                    }
                });

        builderDialog.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                       // listProductIn.setText(getResources().getString(R.string.click_here));
                    }
                });
        android.app.AlertDialog alert = builderDialog.create();
        alert.show();

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.select_listing_type:
            selectListingTypeStr = selectListingType.getSelectedItem().toString().trim();
            if (selectListingTypeStr.equals("Lend")) {
                transTypeId=1;
                salePriceLayout.setVisibility(View.GONE);
                rentalPriceLayout.setVisibility(View.GONE);
                productAvailableLayout.setVisibility(View.VISIBLE);

            } else if (selectListingTypeStr.equals("Rent")) {
                transTypeId=2;
                salePriceLayout.setVisibility(View.GONE);
                rentalPriceLayout.setVisibility(View.VISIBLE);
                productAvailableLayout.setVisibility(View.GONE);

            } else if (selectListingTypeStr.equals("Sell")) {
                transTypeId=3;
                rentalPriceLayout.setVisibility(View.GONE);
                productAvailableLayout.setVisibility(View.GONE);
                salePriceLayout.setVisibility(View.VISIBLE);

            } else if (selectListingTypeStr.equals("GiveAway")) {
                transTypeId=4;
                salePriceLayout.setVisibility(View.GONE);
                rentalPriceLayout.setVisibility(View.GONE);
                productAvailableLayout.setVisibility(View.GONE);

            }
                break;
            case R.id.spinner_from:
                productAvailableFromSpinnerStr = productAvailableFrom.getSelectedItem().toString().trim();
                if(++check>1) {
                    if (position > 0) {
                        dayList1.clear();
                        int i = productAvailableFrom.getSelectedItemPosition();
                        dayList.remove(productAvailableFromSpinnerStr);
                        dayList1.addAll(dayList);
                        daysAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, dayList1);
                        productAvailableTo.setAdapter(daysAdapter);
                        dayList.add(i, productAvailableFromSpinnerStr);

                    }
                }
                break;
            case R.id.spinner_to:
                productAvailableToSpinnerStr=productAvailableTo.getSelectedItem().toString().trim();
                break;

        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private class getAddListingResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(AddProductPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData, Webconfig.CONTEXT_PATH+"createproductlisting.json");
            System.out.println(result);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject jsonObject=null;
            progressDialog.dismiss();
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status","");
                    Constant.messageUnreadCount = jsonObject.getLong("unreadCount");
                    CommonHeader.messageCount.setText(String.valueOf(Constant.messageUnreadCount));

                    System.out.println(status);
                    if(status.equals("success")){
                        customDialog = new Dialog(AddProductPage.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setVisibility(View.GONE);
                        alertMessageText.setText(getResources().getString(R.string.add_product_success_msg));
                        customDialog.setCancelable(true);
                        customDialog.setCanceledOnTouchOutside(true);
                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        customDialog.dismiss();
                                        startActivity(new Intent(AddProductPage.this,AddProductPage.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));

                                    }
                                }
                        );
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            else{
                callAlertDialog("Server down");
            }
        }
    }

  // **************** Capture Product Image ***************************
  private void selectImage() {
      final CharSequence[] items = { "Take Photo", "Choose from Library","No Image","Cancel"};

      android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(AddProductPage.this);
      builder.setTitle("Add Photo!");
      builder.setItems(items, new DialogInterface.OnClickListener() {
          @Override
          public void onClick(DialogInterface dialog, int item) {


              if (items[item].equals("Take Photo")) {
                  userChoosenTask ="Take Photo";
                  cameraIntent();
              }
              else if (items[item].equals("Choose from Library")) {
                  userChoosenTask ="Choose from Library";
                  galleryIntent();
              }
              else if (items[item].equals("No Image")) {
                  productImage.setVisibility(View.VISIBLE);
                  productImage.setImageResource(R.drawable.no_image);
                  productImgByteArray=null;
              }
              else if (items[item].equals("Cancel")) {
                  productImage.setVisibility(View.GONE);
                  productImgByteArray=null;
                  dialog.dismiss();
              }
          }
      });
      builder.show();
  }

    private void galleryIntent()
    {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }

    private void cameraIntent()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent,0);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 0:
                if (resultCode == Activity.RESULT_OK) {
                    if (requestCode == 0)
                        onCaptureImageResult(data);
                }
                break;
            case 1:
                if (resultCode == Activity.RESULT_OK) {
                    if (requestCode == SELECT_FILE)
                        onSelectFromGalleryResult(data);}
                    break;
//            case 2:
//                if (resultCode == 2) {
//                    addProductCatId = data.getLongExtra("categoryId", 0L);
//                    setProductListingDto();
//                }
//

        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        productImgByteArray= bytes.toByteArray();

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        String path=destination.getPath();
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        productImage.setVisibility(View.VISIBLE);
        productImage.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Uri selectedImageUri = data.getData();
        String picturePath= getRealPathFromURI(selectedImageUri);
        Bitmap bm=null;
        if (data!= null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {
           
            InputStream imageStream = getContentResolver().openInputStream(selectedImageUri);
            Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);

            selectedImage = getResizedBitmap(selectedImage, 400);// 400 is for example, replace with desired size
            selectedImage= changeOrientation(picturePath,selectedImage);
            productImage.setVisibility(View.VISIBLE);
            productImage.setImageBitmap(selectedImage);
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            selectedImage.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
            productImgByteArray= bytes.toByteArray();



        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
    private Bitmap changeOrientation(String picturePath, Bitmap loadedBitmap) {
        if(picturePath!=null) {
            ExifInterface exif = null;
            try {
                File pictureFile = new File(picturePath);
                exif = new ExifInterface(pictureFile.getAbsolutePath());
            } catch (IOException e) {
                e.printStackTrace();
            }

            int orientation = ExifInterface.ORIENTATION_NORMAL;

            if (exif != null)
                orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    loadedBitmap = rotateBitmap(loadedBitmap, 90);
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    loadedBitmap = rotateBitmap(loadedBitmap, 180);
                    break;

                case ExifInterface.ORIENTATION_ROTATE_270:
                    loadedBitmap = rotateBitmap(loadedBitmap, 270);
                    break;
            }
        }
        return loadedBitmap;
    }


    public static Bitmap rotateBitmap(Bitmap bitmap, int degrees) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    public String getRealPathFromURI(Uri contentUri) {
        String [] proj={MediaStore.Images.Media.DATA};
        Cursor cursor = managedQuery( contentUri, proj, null, null, null); // Order-by clause (ascending by name)
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String path= cursor.getString(column_index);
        return path;

    }
    // **************** Capture Product Image method finished ***************************


    private class getNetworkName extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getnetwork.json?memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s != null) {
                JSONObject jsonObject = null;
                JSONArray jsonArray = null;
                networkId = new ArrayList<Long>();
                networkName = new ArrayList<String>();
                productNetwork = new HashMap<String, Long>();
                try {
                    jsonArray = new JSONArray(s);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        String networkname = jsonObject.getString("networkName");
                        Long networkid = jsonObject.getLong("networkId");
                        productNetwork.put(networkname.trim(), networkid);
                        networkName.add(networkname.trim());
                        networkId.add(networkid);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                callAlertDialog("Server down");
            }
        }
    }


    private void callAlertDialog(String message) {

        customDialog = new Dialog(AddProductPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

    private class LoadRootCategory extends AsyncTask<String,String,String>{
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(AddProductPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... strings) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getrootcategories.json?memberId="+memberId);
            System.out.println("Category "+result);
            return result;
        }
        @Override
        protected void onPostExecute(String res) {
            CategoryDto categoryDto;
            progressDialog.dismiss();
            categoryDtoLists = new ArrayList<CategoryDto>();
            categoryIdList=new ArrayList<>();
            categoryMap=new HashMap<>();
            categoryNameList=new ArrayList();
            JSONObject jsonObject= null;
            Gson gson = new Gson();
            if(res!=null) {
                try {
                    categoryNameList.add("Select Category");
                    jsonObject = new JSONObject(res);
                    String status = jsonObject.getString("status");

                    if(status.equalsIgnoreCase("success")) {
                        CommonResponseDto commonResponseDto = gson.fromJson(res, CommonResponseDto.class);
                        categoryDtoLists = commonResponseDto.getCategoryDto();
                    }
                    for (int i = 0; i < categoryDtoList.size(); i++) {
                        categoryNameList.add(categoryDtoList.get(i).getCategoryName().trim());
                        categoryMap.put(categoryDtoList.get(i).getCategoryName().trim(),categoryDtoList.get(i).getCategoryId());
                        categoryIdList.add(categoryDtoList.get(i).getCategoryId());
                    }

                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(AddProductPage.this, android.R.layout.simple_spinner_dropdown_item, categoryNameList);
                    rootCategorySpinner.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                callAlertDialog("check your network connection");
            }

        }
    }

    private class GetSubCategory extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(AddProductPage.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result;
            result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getchildcategories.json?parentid="+rootId);
            return result;
        }
        @Override
        protected void onPostExecute(String res) {
            CategoryDto categoryDto;
            catList=new ArrayList<>();
            progressDialog.dismiss();
            if(res!=null && res.length()>3) {
                catList.add("Select Sub-Category");
                subCategorySpinner.setVisibility(View.VISIBLE);
                try {
                    JSONArray jsonArray = new JSONArray(res.trim());
                    /*if(Connectivity.isConnected(CategoryActivity.this)) {
                        new GetAvailableCategory().execute();
                    }else{
                        Toast.makeText(CategoryActivity.this,"Please Check Internet Connection", Toast.LENGTH_LONG).show();
                    }*/
                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject category = jsonArray.getJSONObject(i);
                        Gson gson = new Gson();
                        categoryDto = gson.fromJson(category.toString().trim(), CategoryDto.class);
                        catList.add(categoryDto.getCategoryName().trim());
                        categoryIdName.put(categoryDto.getCategoryName().trim(), categoryDto.getCategoryId());

                    }
                    catAdapter=new ArrayAdapter(AddProductPage.this,android.R.layout.simple_spinner_dropdown_item,catList);
                    subCategorySpinner.setAdapter(catAdapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else {
                if (res == null) {
                    callAlertDialog("check your internet connection");
                }
                subCategorySpinner.setVisibility(View.GONE);

            }
        }
    }
//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")) {
//
//            startActivity(new Intent(AddProductPage.this, AddGroupActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(AddProductPage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(AddProductPage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(AddProductPage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(AddProductPage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(AddProductPage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(AddProductPage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(AddProductPage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(AddProductPage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(AddProductPage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(AddProductPage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(AddProductPage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(AddProductPage.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(AddProductPage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(AddProductPage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(AddProductPage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(AddProductPage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(AddProductPage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(AddProductPage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(AddProductPage.this, ViewPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePage")){
//            startActivity(new Intent(AddProductPage.this, ProfilePage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("")){
//            startActivity(new Intent(AddProductPage.this, ProfilePage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(AddProductPage.this, HomeScreen.class));
//            finish();
//        }
//
//    }

}
