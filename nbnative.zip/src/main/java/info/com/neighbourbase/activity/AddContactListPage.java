package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.appindexing.FirebaseAppIndex;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.NetworkContactListCategoryDto;
import info.com.neighbourbase.model.NetworkContactListDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class AddContactListPage extends AppCompatActivity implements View.OnClickListener {
    Spinner categorySpinner;
    ImageView backIcon;
    Button addListBtn,cancelAddListBtn;
    EditText name,contactMobile,landLine,city,addressLine1,addressLine2,emailId,addListPincode,feedback;
    TextInputLayout nameLayout,contactMobileLayout,landLineLayout,cityLayout,addressLine1Layout,addressLine2Layout,emailIdLayout,addListPincodeLayout,feedbackLayout;
    ArrayAdapter<String> categoryAdapter;
    NetworkContactListCategoryDto networkContactListCategoryDto;
    ArrayList<String> categoryNameList=new ArrayList<>();
    HashMap<String,Long> categoryMap=new HashMap<>();
    String groupId;
    TextView alertMessageText;
    Button alertMsgOkBtn;
    SharedPreferences sharedPreferences;
    Dialog customDialog;
    String reqData,memeberId;
    NetworkContactListDto networkContactListDto=new NetworkContactListDto();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact_list_page);
        sharedPreferences= PreferenceManager.getDefaultSharedPreferences(this);
        groupId=sharedPreferences.getString("groupId","");
        memeberId=sharedPreferences.getString("memberId","");
        mInit();
        if(Connectivity.isConnected(AddContactListPage.this)) {
            new getCategoryList().execute();
        }else{
            callAlertDialog("Please Check Internet Connection");
        }


    }

    private void mInit() {
        categorySpinner=(Spinner)findViewById(R.id.category_spinner);
        backIcon=(ImageView)findViewById(R.id.back_icon);
        name=(EditText)findViewById(R.id.name);
        contactMobile=(EditText)findViewById(R.id.contact_mobile);
        landLine=(EditText) findViewById(R.id.land_line);
        city=(EditText)findViewById(R.id.city);
        addressLine1=(EditText)findViewById(R.id.address_line_one);
        addressLine2=(EditText)findViewById(R.id.address_line_two);
        emailId=(EditText)findViewById(R.id.email_id);
        addListPincode=(EditText)findViewById(R.id.pincode);
        feedback=(EditText)findViewById(R.id.feedback);
        nameLayout=(TextInputLayout)findViewById(R.id.name_input_layout);
        contactMobileLayout=(TextInputLayout)findViewById(R.id.input_layout_contact_mobile);
        landLineLayout=(TextInputLayout)findViewById(R.id.input_layout_land_line);
        cityLayout=(TextInputLayout)findViewById(R.id.input_layout_city);
        addressLine1Layout=(TextInputLayout)findViewById(R.id.input_layout_address_line_one);
        addressLine2Layout=(TextInputLayout)findViewById(R.id.input_layout_address_line_two);
        emailIdLayout=(TextInputLayout)findViewById(R.id.input_layout_email_id);
        addListPincodeLayout=(TextInputLayout)findViewById(R.id.input_layout_pincode);
        feedbackLayout=(TextInputLayout)findViewById(R.id.input_layout_feedback);
        addListBtn=(Button)findViewById(R.id.add_list_button);
        cancelAddListBtn=(Button)findViewById(R.id.add_list_cancel_btn);
        cancelAddListBtn.setOnClickListener(this);
        addListBtn.setOnClickListener(this);
        backIcon.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.add_list_cancel_btn:
                finish();
                break;
            case R.id.add_list_button:
                if(checkValitation()){
                    fillDetails();
                }
                break;
            case R.id.back_icon:
                finish();
                break;
        }

    }

    private void fillDetails() {
        networkContactListDto.setName(name.getText().toString());
        networkContactListDto.setMobile(Long.parseLong(contactMobile.getText().toString()));
        networkContactListDto.setFeedback(feedback.getText().toString());
        if(landLine.getText().toString().length()>0)
            networkContactListDto.setLandline(landLine.getText().toString());
        if(addressLine1.getText().toString().length()>0)
            networkContactListDto.setAddress1(addressLine1.getText().toString());
        if(addressLine2.getText().toString().length()>0)
            networkContactListDto.setAddress2(addressLine2.getText().toString());
        if(city.getText().toString().length()>0)
            networkContactListDto.setCity(city.getText().toString());
        if(addListPincode.getText().toString().length()>0)
            networkContactListDto.setPincode(Integer.parseInt(addListPincode.getText().toString()));
        if(emailId.getText().toString().length()>0)
            networkContactListDto.setEmail(emailId.getText().toString());
        String spinnerSelection=categorySpinner.getSelectedItem().toString();
        Long spinnerSelectCatId=categoryMap.get(spinnerSelection);
        networkContactListDto.setCategoryId(spinnerSelectCatId);
        networkContactListDto.setNetworkId(Long.parseLong(groupId));
        networkContactListDto.setCreatedMemberId(Long.parseLong(memeberId));
        networkContactListDto.setUpdatedMemberId(Long.parseLong(memeberId));
        reqData=new Gson().toJson(networkContactListDto);

        new addListResponse().execute();

    }

    private boolean checkValitation() {
        boolean valueReturn=true;
        if(!Validation.hasText(name))
            valueReturn=false;
        if(!Validation.hasText(feedback))
            valueReturn=false;
        if(!Validation.hasValidPhoneNumber(contactMobile,contactMobileLayout))
            valueReturn=false;
        String catSpinnerSelection=categorySpinner.getSelectedItem().toString();
        if (catSpinnerSelection.equals("Select Category")){
            callAlertDialog("select any one category");
            valueReturn=false;
        }
        if(addListPincode.getText().toString().length()>0){
            if (!Validation.isPin(addListPincode))
                valueReturn=false;
        }

        if(emailId.getText().toString().length()>0){
            if (!Validation.isEmailAddress(emailId,emailIdLayout,true))
                valueReturn=false;
        }


        return valueReturn;
    }

    private class getCategoryList extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... strings) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httpget(Webconfig.CONTEXT_PATH+"getallnetworkcategorylist.json?networkid="+groupId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            networkContactListCategoryDto=new NetworkContactListCategoryDto();
            super.onPostExecute(s);
            if(s!=null){
                categoryNameList.add("Select Category");

                try {

                    JSONArray jsonArray=new JSONArray(s);
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject categoryListArray=jsonArray.getJSONObject(i);
                        networkContactListCategoryDto=new Gson().fromJson(categoryListArray.toString().trim(),NetworkContactListCategoryDto.class);
                        categoryNameList.add(networkContactListCategoryDto.getCategoryName().trim());
                        categoryMap.put(networkContactListCategoryDto.getCategoryName().trim(),networkContactListCategoryDto.getContactsCategoryId());

                    }
                    categoryAdapter=new ArrayAdapter<String>(AddContactListPage.this, android.R.layout.simple_spinner_dropdown_item, categoryNameList);
                    categorySpinner.setAdapter(categoryAdapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }
    }

    private void callAlertDialog(String message) {

        customDialog = new Dialog(AddContactListPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

    private class addListResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(AddContactListPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData,Webconfig.CONTEXT_PATH+"createnetworkcontactlist.json");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            if(s!=null){
                if(s.trim().equals("success")){
                    customDialog = new Dialog(AddContactListPage.this);
                    customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    customDialog.setContentView(R.layout.custom_messbox);
                    alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                    alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                    alertMsgOkBtn.setVisibility(View.GONE);
                    alertMessageText.setText(getResources().getString(R.string.add_contact_success_msg));
                    customDialog.setCancelable(true);
                    customDialog.setCanceledOnTouchOutside(true);
                    customDialog.setOnCancelListener(
                            new DialogInterface.OnCancelListener() {
                                @Override
                                public void onCancel(DialogInterface dialog) {
                                    customDialog.dismiss();
                                    startActivity(new Intent(AddContactListPage.this,UsefulContactsPage.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                                    finish();

                                }
                            }
                    );

                    customDialog.show();
                    customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                }else if(s.trim().equals("fail")){
                    callAlertDialog("Contact List Created failed try again...");
                }
            }else{
                callAlertDialog("check your internet connection");
            }
        }
    }
}
