package info.com.neighbourbase.activity;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.InvitationDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class InviteFriendsActivity extends CommonHeader implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    Button inviteBtn;
    EditText emailId;
    TextInputLayout emailIdLayout;
    SharedPreferences preferences;
    TextView mailingListTxt;
    int check=0;
    Long userSelectGroupId=0L;
    Spinner groupSelectSpinner;
    String memberId,mailIdStr,mailingListStr,reqData,selectGroup;
    Map<String,Long> productgroup;
    ArrayList<String> groupName=new ArrayList<>();
    ArrayList<Long> groupId=new ArrayList<>();
    ImageView backIcon,addEmailBtn;
    ArrayAdapter<String> groupAdapter;
    InvitationDto invitationDto=new InvitationDto();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_invite_friends);

        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_invite_friends, FrameLayout);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        memberId=preferences.getString("memberId","");
        mInit();
        new getGroup().execute();
        addEmailBtn.setOnClickListener(this);
        inviteBtn.setOnClickListener(this);
        groupSelectSpinner.setOnItemSelectedListener(this);

    }


    private void mInit() {

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "InviteFriendsActivity";

        addEmailBtn=(ImageView)findViewById(R.id.add_button);
        inviteBtn=(Button)findViewById(R.id.invite_button);
        emailId=(EditText)findViewById(R.id.email_edit_text);
        mailingListTxt=(TextView)findViewById(R.id.mailing_list);
        groupSelectSpinner=(Spinner)findViewById(R.id.select_group_spinner);
        emailIdLayout=(TextInputLayout)findViewById(R.id.input_layout_emailId);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.add_button:
                if(checkValidation()) {
                    if(++check==1) {
                        mailIdStr=emailId.getText().toString();
                        emailId.setText("");
                        mailingListTxt.setText(mailIdStr);

                    }else if(++check>1){
                        mailIdStr=emailId.getText().toString();
                        emailId.setText("");
                        mailingListTxt.append(",");
                        mailingListTxt.append(mailIdStr);

                    }
                }

                break;
            case R.id.invite_button:
                if(checkMailingList()){
                    invitationDto.setMemberId(Long.parseLong(memberId));
                    invitationDto.setInviteFlag(1);
                    invitationDto.setEmailId(mailingListStr);
                    invitationDto.setNetworkId(userSelectGroupId);
                    reqData=new Gson().toJson(invitationDto);
                    if(selectGroup.equals("Public")) {
                        new getInviteResponseIndividual().execute();
                    }else{
                        new getInviteResponseGroup().execute();
                    }

                }
                break;
        }

    }

    private boolean checkMailingList() {
        boolean valueReturn = true;
        mailingListStr=mailingListTxt.getText().toString();
        if(mailingListStr.length()==0){
            callAlertDialog("The invite list is empty. Please 'Add' email to this list before you invite");
            valueReturn=false;
        }

        return valueReturn;
    }

    private boolean checkValidation() {
        boolean valueReturn = true;
        mailIdStr=emailId.getText().toString();
        mailingListStr=mailingListTxt.getText().toString();
        if(!Validation.hasText(emailId))
            valueReturn=false;
        if(!Validation.isEmailAddress(emailId,emailIdLayout,true))
            valueReturn=false;
        return valueReturn;
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        selectGroup=  groupSelectSpinner.getSelectedItem().toString().trim();
        userSelectGroupId=((Long) productgroup.get(selectGroup));
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private class getGroup extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getnetwork.json?memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s != null) {
                JSONObject jsonObject = null;
                JSONArray jsonArray = null;
                groupId = new ArrayList<Long>();
                groupName = new ArrayList<String>();
                productgroup = new HashMap<String, Long>();

                try {
                    jsonArray = new JSONArray(s);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        String groupname = jsonObject.getString("networkName");
                        Long groupid = jsonObject.getLong("networkId");
                        productgroup.put(groupname, groupid);
                        groupName.add(groupname);
                        groupId.add(groupid);

                    }
                    groupAdapter=new ArrayAdapter<String>(InviteFriendsActivity.this,android.R.layout.simple_spinner_dropdown_item,groupName);
                    groupSelectSpinner.setAdapter(groupAdapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                callAlertDialog("Check Your Internet Connection");
            }
        }
    }


    private class getInviteResponseIndividual extends AsyncTask<String,String,String>{
        ProgressDialog progressDialog;
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(InviteFriendsActivity.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"referfriends.json?memberId="+memberId+"&emailIds="+mailingListStr);
            return result;
        }
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            JSONObject jsonObject=null;
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status");
                    if(status.equals("success")){
                        customDialog = new Dialog(InviteFriendsActivity.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setVisibility(View.GONE);
                        alertMessageText.setText(getResources().getString(R.string.invite_group_success_msg));
                        customDialog.setCancelable(true);
                        customDialog.setCanceledOnTouchOutside(true);
                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        customDialog.dismiss();
                                        startActivity(getIntent());
//                                                finish();
                                    }
                                }
                        );
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                    }else if(status.equals("fail")){
                        callAlertDialog("Invitation Sent Failed");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }else {
                callAlertDialog("Server Down... Please try again");
            }
        }

    }
    private class getInviteResponseGroup extends AsyncTask<String,String,String>{
        ProgressDialog progressDialog;
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(InviteFriendsActivity.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData,Webconfig.CONTEXT_PATH+"createinvitationNew.json");
            return result;
        }

        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            JSONObject jsonObject=null;
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status");
                    if(status.equals("success")){
                        customDialog = new Dialog(InviteFriendsActivity.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setVisibility(View.GONE);
                        alertMessageText.setText(getResources().getString(R.string.invite_group_success_msg));
                        customDialog.setCancelable(true);
                        customDialog.setCanceledOnTouchOutside(true);
                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        customDialog.dismiss();
                                        startActivity(getIntent());
//                                                finish();
                                    }
                                }
                        );
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                    }else if(status.equals("fail")){
                        callAlertDialog("Invitation Sent Failed");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }else {
               callAlertDialog("Server Down... Please try again");
            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(InviteFriendsActivity.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(InviteFriendsActivity.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(InviteFriendsActivity.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(InviteFriendsActivity.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(InviteFriendsActivity.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(InviteFriendsActivity.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(InviteFriendsActivity.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(InviteFriendsActivity.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(InviteFriendsActivity.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(InviteFriendsActivity.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(InviteFriendsActivity.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(InviteFriendsActivity.this, AddGroupActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(InviteFriendsActivity.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(InviteFriendsActivity.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(InviteFriendsActivity.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(InviteFriendsActivity.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(InviteFriendsActivity.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(InviteFriendsActivity.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(InviteFriendsActivity.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(InviteFriendsActivity.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(InviteFriendsActivity.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(InviteFriendsActivity.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
