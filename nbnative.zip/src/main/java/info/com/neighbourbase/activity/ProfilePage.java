package info.com.neighbourbase.activity;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import info.com.neighbourbase.R;
import info.com.neighbourbase.utility.Constant;

public class ProfilePage extends CommonHeader implements View.OnClickListener {
    TextView profileInfoText,profilePictureText,resetPasswordText,changeEmailText,changeLocationText,pageHeadingText;
    SharedPreferences preferences;
    String userName;
    int permissionCheck, permissionCheck1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_profile_page, FrameLayout);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        userName=preferences.getString("firstName","");
        mInit();

    }

    private void mInit() {
        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "ProfilePage";
        profileInfoText=(TextView)findViewById(R.id.profile_info);
        profilePictureText=(TextView)findViewById(R.id.profile_picture);
        resetPasswordText=(TextView)findViewById(R.id.reset_password);
        changeEmailText=(TextView)findViewById(R.id.change_email);
        changeLocationText=(TextView)findViewById(R.id.change_location);
        pageHeadingText=(TextView)findViewById(R.id.page_heading);
        profileInfoText.setOnClickListener(this);
        profilePictureText.setOnClickListener(this);
        resetPasswordText.setOnClickListener(this);
        changeEmailText.setOnClickListener(this);
        changeLocationText.setOnClickListener(this);
        pageHeadingText.setText(userName+"'s  "+getResources().getString(R.string.profile));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.profile_info:
                startActivity(new Intent(ProfilePage.this,ProfileInformationPage.class));
                break;
            case R.id.profile_picture:
                startActivity(new Intent(ProfilePage.this,ProfilePicturePage.class));
                break;
            case R.id.reset_password:
                startActivity(new Intent(ProfilePage.this,ResetPassword.class));
                break;
            case R.id.change_email:
                startActivity(new Intent(ProfilePage.this,ChangeEmailPage.class));
                break;
            case R.id.change_location:
                permissionCheck = ContextCompat.checkSelfPermission(ProfilePage.this, Manifest.permission.ACCESS_FINE_LOCATION);
                permissionCheck1 = ContextCompat.checkSelfPermission(ProfilePage.this, Manifest.permission.ACCESS_COARSE_LOCATION);
                if (permissionCheck != PackageManager.PERMISSION_GRANTED && permissionCheck1 != PackageManager.PERMISSION_GRANTED ) {
                    ActivityCompat.requestPermissions(ProfilePage.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 0);
                    Toast.makeText(ProfilePage.this, "Need to on location Permission in neighbourbase app, otherwise not able to access map", Toast.LENGTH_LONG).show();
                }else {
                    startActivity(new Intent(ProfilePage.this, ChangeLocationPage.class));
                }
                break;
        }
    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(ProfilePage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(ProfilePage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(ProfilePage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(ProfilePage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(ProfilePage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(ProfilePage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(ProfilePage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(ProfilePage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(ProfilePage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(ProfilePage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(ProfilePage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(ProfilePage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(AddGroupActivity.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(ProfilePage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(ProfilePage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(ProfilePage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(ProfilePage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(ProfilePage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(ProfilePage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(ProfilePage.this, ViewPage.class));
//            finish();
//        } else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(ProfilePage.this, AddGroupActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MorePage")){
//            startActivity(new Intent(ProfilePage.this, MorePage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("DashBoardPage")){
//            startActivity(new Intent(ProfilePage.this, DashBoardPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ReminderPage")){
//            startActivity(new Intent(ProfilePage.this, ReminderPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(ProfilePage.this, HomeScreen.class));
//            finish();
//        }
//
//    }

}
