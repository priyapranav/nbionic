package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import info.com.neighbourbase.Adapter.UnblockMemberAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.BlockListDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class UnblockMemberPage extends CommonHeader {
    ListView unblockMemberList;
    SharedPreferences preferences;
    TextView noUnblockMemberText;
    String memberId;
    BlockListDto blockListDto=new BlockListDto();
    ArrayList<BlockListDto> blockListDtoList=new ArrayList<>();
    ArrayAdapter unblockMemberAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_unblock_member_page, FrameLayout);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        memberId=preferences.getString("memberId","");
        mInit();
        new unblockMemberListResponse().execute();
    }

    private void mInit() {
        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "UnblockMemberPage";
        unblockMemberList=(ListView)findViewById(R.id.unblock_members_list);
        noUnblockMemberText=(TextView)findViewById(R.id.noUnblock_member_text);
        noUnblockMemberText.setVisibility(View.GONE);
        unblockMemberList.setVisibility(View.VISIBLE);
    }

    private class unblockMemberListResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(UnblockMemberPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getblocklistbymemberid.json?memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            if(s!=null){
                try {
                    JSONArray blockListArray=new JSONArray(s);
                    if(blockListArray.length()!=0){
                        noUnblockMemberText.setVisibility(View.GONE);
                        unblockMemberList.setVisibility(View.VISIBLE);
                        for(int i=0;i<blockListArray.length();i++){
                            JSONObject blockList=blockListArray.getJSONObject(i);
                            blockListDto=new Gson().fromJson(blockList.toString(),BlockListDto.class);
                            blockListDtoList.add(blockListDto);

                        }
                        unblockMemberAdapter=new UnblockMemberAdapter(UnblockMemberPage.this,blockListDtoList);
                        unblockMemberList.setAdapter(unblockMemberAdapter);
                    }else if(blockListArray.length()==0){
                        noUnblockMemberText.setVisibility(View.VISIBLE);
                        unblockMemberList.setVisibility(View.GONE);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                callAlertDialog("Server Down... Please try again");
            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(UnblockMemberPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }
}
