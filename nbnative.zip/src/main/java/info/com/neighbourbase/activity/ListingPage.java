package info.com.neighbourbase.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class ListingPage extends CommonHeader implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    EditText productName,productDescription,salePrice,rentPerDay,rentPerWeek,rentPerMonth;
    Spinner selectListingType,productAvailableFrom,productAvailableTo;
    TextView productImageNameText,thru,listProductIn;
    ImageView productImage;
    Button browseBtn,removeBtn,addListingBtn;
    RadioButton availableFrom,availableOnlyOn;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private String userChoosenTask;
    byte[] productImgByteArray;
    SharedPreferences preferences;
    String[] listingType={"Lend","Rent","Sell","Gift"};
    String[] days={"Select","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
    String[] network={"public","info","career"};
    String rentPerDayStr,rentPerWeekStr,rentPerMonthStr,selectListingTypeStr,productAvailableFromSpinnerStr,productAvailableToSpinnerStr,reqData,memberId;
    LinearLayout salePriceLayout,rentalPriceLayout,productAvailableLayout;
    ArrayAdapter<String> listTypeAdapter,daysAdapter;
    ArrayList<String> dayList,dayList1,networkList,networkName;
    ArrayList<Long> networkId;
    ProductListingDto productListingDto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listing_page);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        memberId=preferences.getString("memberId","");

        mInit();
        new getNetworkName().execute();
        addListingBtn.setOnClickListener(this);
        availableOnlyOn.setOnClickListener(this);
        availableFrom.setOnClickListener(this);
        selectListingType.setOnItemSelectedListener(this);
        productAvailableFrom.setOnItemSelectedListener(this);
        productAvailableTo.setOnItemSelectedListener(this);
        browseBtn.setOnClickListener(this);
        removeBtn.setOnClickListener(this);
        listProductIn.setOnClickListener(this);

    }

    private void mInit() {
        productName=(EditText)findViewById(R.id.product_name);
        productDescription=(EditText)findViewById(R.id.product_description);
        salePrice=(EditText)findViewById(R.id.sale_price);
        rentPerDay=(EditText)findViewById(R.id.rent_per_day);
        rentPerMonth=(EditText)findViewById(R.id.rent_per_month);
        rentPerWeek=(EditText)findViewById(R.id.rent_per_week);
        selectListingType=(Spinner)findViewById(R.id.select_listing_type);
        productAvailableFrom=(Spinner)findViewById(R.id.spinner_from);
        productAvailableTo=(Spinner)findViewById(R.id.spinner_to);
        listProductIn=(TextView)findViewById(R.id.list_product_in);
        productImageNameText=(TextView)findViewById(R.id.img_name_txt);
        thru=(TextView)findViewById(R.id.thru);
        productImage=(ImageView)findViewById(R.id.product_image);
        browseBtn=(Button)findViewById(R.id.browse_product_img_btn);
        removeBtn=(Button)findViewById(R.id.remove_product_btn);
        addListingBtn=(Button)findViewById(R.id.add_listing_btn);
        availableFrom=(RadioButton)findViewById(R.id.radioBtnFrom);
        availableOnlyOn=(RadioButton)findViewById(R.id.radioBtnOnlyOn);
        rentalPriceLayout=(LinearLayout)findViewById(R.id.rental_price_layout);
        salePriceLayout=(LinearLayout)findViewById(R.id.sale_price_layout);
        productAvailableLayout=(LinearLayout)findViewById(R.id.product_available_layout);

        listTypeAdapter =new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,listingType);
        selectListingType.setAdapter(listTypeAdapter);
        dayList = new ArrayList<String>(Arrays.asList(days));
        dayList1=new ArrayList<String>();
        networkList=new ArrayList<String>(Arrays.asList(network));
        daysAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,dayList);
        productAvailableFrom.setAdapter(daysAdapter);
        productAvailableTo.setAdapter(daysAdapter);
        availableFrom.setChecked(true);

    }

    private boolean checkAddListingValidation() {
        rentPerWeekStr=rentPerWeek.getText().toString().trim();
        rentPerMonthStr=rentPerMonth.getText().toString().trim();
        rentPerDayStr=rentPerDay.getText().toString().trim();
        boolean valueReturn = true;
        if (!Validation.hasText(productName))
            valueReturn = false;
        if(!Validation.hasText(productDescription))
            valueReturn=false;
        if(selectListingTypeStr.equals("Sell")) {
            if (!Validation.hasText(salePrice))
                valueReturn = false;
        }
        if(selectListingTypeStr.equals("Rent")){
            if(rentPerDayStr.length()==0){
                if(rentPerWeekStr.length()==0){
                    if(rentPerMonthStr.length()==0){
                        callAlertDialog("Enter at least any one the Rental price field");
                        valueReturn=false;
                    }
                }
            }
        }
        if(availableFrom.isChecked()){
            if(productAvailableFromSpinnerStr.equals("Select")){
                callAlertDialog("Select Duration");
                valueReturn=false;
            }else  if(productAvailableToSpinnerStr.equals("Select")){
                callAlertDialog("Select Duration");
                valueReturn=false;

            }
        }
        if(availableOnlyOn.isChecked()){
            if(productAvailableFromSpinnerStr.equals("Select")){
               callAlertDialog("Select Duration");
                valueReturn=false;
            }

        }


        return valueReturn;
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(ListingPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.add_listing_btn:
                if(checkAddListingValidation()){
                    productListingDto=new ProductListingDto();
                    productListingDto.setProductName(productName.getText().toString());
                    productListingDto.setProductDescription(productDescription.getText().toString());
                    productListingDto.setNetworkId(2);
                    productListingDto.setTransTypeId(1);
                    productListingDto.setDayfrom("2");
                    productListingDto.setDayto("3");
                    productListingDto.setCategoryId(112);
                    reqData=new Gson().toJson(productListingDto);
                    new getAddListingResponse().execute();
                }
                break;
            case R.id.radioBtnOnlyOn:
                thru.setVisibility(View.GONE);
                productAvailableTo.setVisibility(View.GONE);
                break;
            case R.id.radioBtnFrom:
                thru.setVisibility(View.VISIBLE);
                productAvailableTo.setVisibility(View.VISIBLE);
                break;
            case R.id.browse_product_img_btn:
                selectImage();
                break;
            case R.id.remove_product_btn:
                productImage.setImageDrawable(null);
                productImageNameText.setText("");
                break;
            case R.id.list_product_in:
                loadNetwork();
                break;
        }
    }

    private void loadNetwork() {
        final CharSequence[] dialogList=  networkName.toArray(new CharSequence[networkName.size()]);
        final android.app.AlertDialog.Builder builderDialog = new android.app.AlertDialog.Builder(ListingPage.this);
        builderDialog.setTitle("Select Network");
        int count = dialogList.length;
        boolean[] is_checked = new boolean[count];

        // Creating multiple selection by using setMutliChoiceItem method
        builderDialog.setMultiChoiceItems(dialogList, is_checked,
                new DialogInterface.OnMultiChoiceClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int whichButton, boolean isChecked) {
                    }
                });

        builderDialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        ListView list = ((android.app.AlertDialog) dialog).getListView();
                        // make selected item in the comma seprated string
                        StringBuilder stringBuilder = new StringBuilder();
                        for (int i = 0; i < list.getCount(); i++) {
                            boolean checked = list.isItemChecked(i);

                            if (checked) {
                                if (stringBuilder.length() > 0) stringBuilder.append(",");
                                stringBuilder.append(list.getItemAtPosition(i));


                            }
                        }

                        /*Check string builder is empty or not. If string builder is not empty.
                          It will display on the screen.
                         */
                        if (stringBuilder.toString().trim().equals("")) {

                            listProductIn.setText("Click here to Select Network");
                            stringBuilder.setLength(0);

                        } else {

                            listProductIn.setText(stringBuilder);
                        }
                    }
                });

        builderDialog.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        listProductIn.setText("Click here to Select Network");
                    }
                });
        android.app.AlertDialog alert = builderDialog.create();
        alert.show();

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.select_listing_type:
                selectListingTypeStr = selectListingType.getSelectedItem().toString().trim();
                if (selectListingTypeStr.equals("Lend")) {
                    salePriceLayout.setVisibility(View.GONE);
                    rentalPriceLayout.setVisibility(View.GONE);
                    productAvailableLayout.setVisibility(View.VISIBLE);

                } else if (selectListingTypeStr.equals("Rent")) {
                    salePriceLayout.setVisibility(View.GONE);
                    rentalPriceLayout.setVisibility(View.VISIBLE);
                    productAvailableLayout.setVisibility(View.VISIBLE);

                } else if (selectListingTypeStr.equals("Sell")) {
                    rentalPriceLayout.setVisibility(View.GONE);
                    productAvailableLayout.setVisibility(View.GONE);
                    salePriceLayout.setVisibility(View.VISIBLE);
                    availableFrom.setChecked(false);

                } else if (selectListingTypeStr.equals("Gift")) {
                    salePriceLayout.setVisibility(View.GONE);
                    rentalPriceLayout.setVisibility(View.GONE);
                    productAvailableLayout.setVisibility(View.GONE);
                    availableFrom.setChecked(false);

                }
                break;
            case R.id.spinner_from:
                productAvailableFromSpinnerStr = productAvailableFrom.getSelectedItem().toString().trim();
                if(position>0) {
                    dayList1.clear();
                    int i=productAvailableFrom.getSelectedItemPosition();
                    dayList.remove(productAvailableFromSpinnerStr);
                    dayList1.addAll(dayList);
                    daysAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, dayList1);
                    productAvailableTo.setAdapter(daysAdapter);
                    dayList.add(i,productAvailableFromSpinnerStr);

                }
                break;
            case R.id.spinner_to:
                productAvailableToSpinnerStr=productAvailableTo.getSelectedItem().toString().trim();
                break;



        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private class getAddListingResponse extends AsyncTask<String,String,String> {

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData, Webconfig.CONTEXT_PATH+"createproductlisting.json?memberId="+memberId+"productimage"+ Arrays.toString(productImgByteArray) +"networkIds"+networkId);
            System.out.println(result);
            return result;
        }
    }

    // **************** Capture Product Image ***************************
    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Library","Cancel"};

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(ListingPage.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {


                if (items[item].equals("Take Photo")) {
                    userChoosenTask ="Take Photo";

                    cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    userChoosenTask ="Choose from Library";

                    galleryIntent();

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent()
    {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }

    private void cameraIntent()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        productImgByteArray= bytes.toByteArray();

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        String path=destination.getPath();
        String filename=path.substring(path.lastIndexOf("/")+1);
        productImageNameText.setText(filename);
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        productImage.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Uri selectedImageUri = data.getData();
        String s= getRealPathFromURI(selectedImageUri);
        Bitmap bm=null;
        if (data!= null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        productImgByteArray= bytes.toByteArray();

        productImage.setImageBitmap(bm);
    }

    public String getRealPathFromURI(Uri contentUri) {
        String filename;
        String [] proj={MediaStore.Images.Media.DATA};
        Cursor cursor = managedQuery( contentUri, proj, null, null, null); // Order-by clause (ascending by name)
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String path= cursor.getString(column_index);
        if(path!=null){
            filename=path.substring(path.lastIndexOf("/")+1);
            productImageNameText.setText(filename);
        }

        return null;

    }
    // **************** Capture Product Image method finished ***************************

    private class getNetworkName extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getnetwork.json?memberId=66");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject jsonObject=null;
            JSONArray jsonArray=null;
            networkId=new ArrayList<Long>();
            networkName=new ArrayList<String>();
            try {
                jsonArray=new JSONArray(s);
                for(int i=0;i<jsonArray.length();i++){
                    jsonObject=jsonArray.getJSONObject(i);
                    String networkname=jsonObject.getString("networkName");
                    Long networkid=jsonObject.getLong("networkId");
                    networkName.add(networkname);
                    networkId.add(networkid);

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
