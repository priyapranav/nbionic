package info.com.neighbourbase.activity;

import android.app.Dialog;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.support.v7.widget.Toolbar;

import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CategoryDto;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.service.MyFirebaseMessagingService;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.DBHelper;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.MessageCountListener;
import info.com.neighbourbase.utility.PushMessageListener;
import info.com.neighbourbase.utility.Webconfig;

public class CommonHeader extends AppCompatActivity implements AdapterView.OnItemClickListener {
    FloatingActionButton floatingActionButton;
    ActionBarDrawerToggle actionBarDrawerToggle;
    DrawerLayout drawerLayout;
    ListView categoryListView;
    Toolbar toolbar;
    ImageView backIcon;
    ImageView mapIcon;
    ImageView searchIcon;
    ImageView profileIcon;
    ImageView messageIcon;
    LinearLayout  addProductLayout;
    LinearLayout dashBoardLayout;
    LinearLayout homeLayout;
    LinearLayout moreLayout;
    LinearLayout groupLayout;
    LinearLayout searchLayout;
    LinearLayout groupHomeLayout;
    LinearLayout memberLayout;
    LinearLayout deleteLayout;
    LinearLayout usefulContactsLayout;
    PopupWindow groupNameSelectPopup;
    ArrayList<String> groupName = new ArrayList<>();
    ArrayList<Long> groupId = new ArrayList<>();
    List<String> categoryName = new ArrayList<>();
    List<Long> categoryId = new ArrayList<>();
    ArrayAdapter groupNameAdapter;
    ListView groupList;
    ListView expListView;
    public static SharedPreferences preferences;
    HashMap<String, List<String>> listDataChild = new HashMap<>();
    public static String memberId;
    RelativeLayout messageLayout;
    RelativeLayout notificationLayout;
    public static TextView messageCount;
    List<CategoryDto> categoryDtoList;
    Long parentId;
    Dialog mylistingGroup;
    Dialog customDialog;
    static TextView mPushMessageCount;
    int notiCount;
    String mNotifyCount = "0", mMessageCount;
    TextView alertMessageText;
    Button alertMsgOkBtn;
    String result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.common_header);
        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        memberId = preferences.getString("memberId", "");

        mInit();
        if(Connectivity.isConnected(CommonHeader.this)){
            new GetRootCategory().execute();
        }else{
            Toast.makeText(CommonHeader.this, "Please Check Internet Connection", Toast.LENGTH_LONG).show();
        }

        setSupportActionBar(toolbar);
        toolbar.setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
                R.string.drawer_open, R.string.drawer_close);
        drawerLayout.setDrawerListener(actionBarDrawerToggle);
        drawerLayout.setScrimColor(getResources().getColor(android.R.color.transparent));

        setupDrawer();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            actionBarDrawerToggle.getDrawerArrowDrawable().setColor(getColor(R.color.White));
        } else {
            actionBarDrawerToggle.getDrawerArrowDrawable().setColor(getResources().getColor(R.color.White));
        }

    }

    private void mInit() {

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        notificationLayout = (RelativeLayout) findViewById(R.id.notification_layout);
        deleteLayout = (LinearLayout) findViewById(R.id.delete_layout);
        searchLayout = (LinearLayout) findViewById(R.id.search_layout);
        messageLayout = (RelativeLayout) findViewById(R.id.message_layout);
        mapIcon = (ImageView) findViewById(R.id.map_icon);

        addProductLayout = (LinearLayout) findViewById(R.id.add_product_layout);
        dashBoardLayout = (LinearLayout) findViewById(R.id.dash_board_layout);
        groupLayout = (LinearLayout) findViewById(R.id.group_layout);
        homeLayout = (LinearLayout) findViewById(R.id.home_layout);
        profileIcon = (ImageView) findViewById(R.id.profile_icon);
        moreLayout = (LinearLayout) findViewById(R.id.more_layout);
        setSupportActionBar(toolbar);
        toolbar.setTitle("");
        expListView = (ListView) findViewById(R.id.list);
        searchIcon = (ImageView) findViewById(R.id.search_icon);
        messageIcon = (ImageView) findViewById(R.id.message_icon);
        messageCount = (TextView) findViewById(R.id.message_count);
        mPushMessageCount = (TextView) findViewById(R.id.push_message_count);
        backIcon = (ImageView) findViewById(R.id.back_icon);
        floatingActionButton = (FloatingActionButton) findViewById(R.id.fab);

        groupHomeLayout = (LinearLayout) findViewById(R.id.group_home_layout);
        usefulContactsLayout=(LinearLayout)findViewById(R.id.useful_contacts_layout);
        memberLayout = (LinearLayout) findViewById(R.id.member_layout);

        messageCount.setText(String.valueOf(Constant.messageUnreadCount));
        mPushMessageCount.setText(String.valueOf(Constant.newMessageCount));



        setSupportActionBar(toolbar);
        toolbar.setTitle("");
        categoryListView = (ListView) findViewById(R.id.list);

        notiCount = preferences.getInt("pushCount", 0);

        if (notiCount != 0) {
            mPushMessageCount.setText(String.valueOf(notiCount));
            mPushMessageCount.setVisibility(View.VISIBLE);

        } else {
            mPushMessageCount.setVisibility(View.GONE);
        }



        deleteLayout.setOnClickListener(clickListener);
        searchLayout.setOnClickListener(clickListener);
        messageLayout.setOnClickListener(clickListener);
        dashBoardLayout.setOnClickListener(clickListener);
        addProductLayout.setOnClickListener(clickListener);
        groupLayout.setOnClickListener(clickListener);
        moreLayout.setOnClickListener(clickListener);
        homeLayout.setOnClickListener(clickListener);
        backIcon.setOnClickListener(clickListener);
        floatingActionButton.setOnClickListener(clickListener);
        groupHomeLayout.setOnClickListener(clickListener);
        memberLayout.setOnClickListener(clickListener);
        notificationLayout.setOnClickListener(clickListener);
        usefulContactsLayout.setOnClickListener(clickListener);

        MyFirebaseMessagingService.bindListener(new PushMessageListener() {
            @Override
            public void pushMessageReceived(Integer pushMessageCount) {
                if (pushMessageCount != null) {
                    mNotifyCount = pushMessageCount.toString();
                    new MPushMsgCount().execute();
                }
            }

        });

        MessageFragment.bindListener(new MessageCountListener() {
            @Override
            public void messageReceived(Integer pushMessageCount) {
                if (pushMessageCount != null) {
                    mMessageCount = pushMessageCount.toString();

                }
            }

        });

    }

    private View.OnClickListener clickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {

            switch (v.getId()) {
                case R.id.back_icon:

                    finish();
                    break;
                case R.id.map_icon:
                    startActivity(new Intent(CommonHeader.this, GoogleMapPopup.class));
                    break;
                case R.id.search_layout:
                    startActivity(new Intent(CommonHeader.this, SearchActivity.class));
                    break;

                case R.id.delete_layout:
                    customDialog = new Dialog(CommonHeader.this);
                    customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    customDialog.setContentView(R.layout.custom_messbox);
                    alertMessageText = (TextView) customDialog.findViewById(R.id.message_text);
                    alertMsgOkBtn = (Button) customDialog.findViewById(R.id.ok_btn);
                    alertMsgOkBtn.setText(getResources().getString(R.string.alert_msg_yes));
                    alertMessageText.setText(getResources().getString(R.string.delete_notification));
                    customDialog.setCancelable(true);
                    alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            DBHelper dbHelper = new DBHelper(CommonHeader.this);
                            dbHelper.deleteAllPushMessages();
                            customDialog.dismiss();
                            startActivity(new Intent(CommonHeader.this, NotificationMessage.class));
                            finish();
                        }
                    });
                    customDialog.show();
                    customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                    break;

                case R.id.message_layout:
                    startActivity(new Intent(CommonHeader.this, MessageActivity.class));

                    break;

                case R.id.add_product_layout:
                    startActivity(new Intent(CommonHeader.this, AddProductPage.class));

                    break;

                case R.id.dash_board_layout:
                    startActivity(new Intent(CommonHeader.this, DashBoardPage.class));

                    break;

                case R.id.group_layout:
                    startActivity(new Intent(CommonHeader.this, GroupPage.class));

                    break;

                case R.id.home_layout:
                    Constant.categoryId = 0;
                    startActivity(new Intent(CommonHeader.this, HomeScreen.class));
                    break;

                case R.id.more_layout:
                    startActivity(new Intent(CommonHeader.this, MorePage.class));

                    break;

                case R.id.fab:
                    startActivity(new Intent(CommonHeader.this, InviteFriendsActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    break;

                case R.id.member_layout:
                    startActivity(new Intent(CommonHeader.this, GroupMemberPage.class));
                    break;
                case R.id.useful_contacts_layout:
                    startActivity(new Intent(CommonHeader.this,UsefulContactsPage.class));
                    break;
                case R.id.group_home_layout:
                    Constant.categoryId = 0;
                    startActivity(new Intent(CommonHeader.this, HomeScreen.class));

                    break;

                case R.id.notification_layout:
                    startActivity(new Intent(CommonHeader.this, NotificationMessage.class));

                    break;
            }

        }

    };

    private void setupDrawer() {

        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
                R.string.drawer_open, R.string.drawer_close) {

            /** Called when a drawer has settled in a completely open state. */
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                invalidateOptionsMenu();
            }

            /** Called when a drawer has settled in a completely closed state. */
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                invalidateOptionsMenu();
            }

        };

        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        drawerLayout.setDrawerListener(actionBarDrawerToggle);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        actionBarDrawerToggle.syncState();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        actionBarDrawerToggle.onConfigurationChanged(newConfig);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private class MPushMsgCount extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {

            result = null;
            result = mNotifyCount;
            return result;
        }

        @Override
        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            mPushMessageCount.setVisibility(View.VISIBLE);
            mPushMessageCount.setText(result);

        }


    }

    private class GetRootCategory extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "getrootcategories.json?memberId=" + memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {

            categoryDtoList = new ArrayList<>();
            JSONObject jsonObject = null;
            Gson gson = new Gson();
            if (res != null) {
                try {

                    jsonObject = new JSONObject(res);
                    String status = jsonObject.getString("status");
                    if (status.equalsIgnoreCase("success")) {
                        CommonResponseDto commonResponseDto = gson.fromJson(res, CommonResponseDto.class);
                        categoryDtoList = commonResponseDto.getCategoryDto();
                    }
                    for (int i = 0; i < categoryDtoList.size(); i++) {
                        categoryName.add(categoryDtoList.get(i).getCategoryName());
                        categoryId.add(categoryDtoList.get(i).getCategoryId());
                    }

                    ArrayAdapter<String> adapter = new ArrayAdapter<>(CommonHeader.this, android.R.layout.simple_list_item_1, categoryName);
                    categoryListView.setAdapter(adapter);
                    categoryListView.setOnItemClickListener(CommonHeader.this);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        parentId = categoryDtoList.get(position).getCategoryId();
        Intent intent = new Intent(CommonHeader.this, CategoryActivity.class);
        intent.putExtra("rootId", parentId.toString());
        startActivity(intent);

    }


    @Override
    protected void onResume() {
        super.onResume();
        mInit();
    }

}
