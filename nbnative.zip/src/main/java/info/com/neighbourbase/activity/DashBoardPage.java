package info.com.neighbourbase.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import info.com.neighbourbase.R;
import info.com.neighbourbase.utility.Constant;

public class DashBoardPage extends CommonHeader implements View.OnClickListener {
    LinearLayout unblockMemberLayout,reminderLayout,groupInvitationLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_dash_board_page, FrameLayout);
        mInit();
    }

    private void mInit() {
        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "DashBoardPage";
        unblockMemberLayout=(LinearLayout)findViewById(R.id.unblock_members_layout);
        reminderLayout=(LinearLayout)findViewById(R.id.reminder_layout);
        groupInvitationLayout=(LinearLayout)findViewById(R.id.group_invitation_layout);
        unblockMemberLayout.setOnClickListener(this);
        reminderLayout.setOnClickListener(this);
        groupInvitationLayout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.unblock_members_layout:
                startActivity(new Intent(DashBoardPage.this, UnblockMemberPage.class));
                break;
            case R.id.reminder_layout:
                startActivity(new Intent(DashBoardPage.this, ReminderPage.class));
                break;
            case R.id.group_invitation_layout:
                startActivity(new Intent(DashBoardPage.this, GroupInvitationPage.class));
                break;
        }

    }
//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(DashBoardPage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(DashBoardPage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(DashBoardPage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(DashBoardPage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(DashBoardPage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(DashBoardPage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(DashBoardPage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(DashBoardPage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(DashBoardPage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(DashBoardPage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(DashBoardPage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(DashBoardPage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(AddGroupActivity.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(DashBoardPage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(DashBoardPage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(DashBoardPage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(DashBoardPage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(DashBoardPage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(DashBoardPage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(DashBoardPage.this, ViewPage.class));
//            finish();
//        } else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(DashBoardPage.this, AddGroupActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MorePage")){
//            startActivity(new Intent(DashBoardPage.this, MorePage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePage")){
//            startActivity(new Intent(DashBoardPage.this, ProfilePage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ReminderPage")){
//            startActivity(new Intent(DashBoardPage.this, ReminderPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(DashBoardPage.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
