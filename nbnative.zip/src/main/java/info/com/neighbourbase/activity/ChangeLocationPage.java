package info.com.neighbourbase.activity;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;

import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.MemberDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class ChangeLocationPage extends CommonHeader implements View.OnClickListener, OnMapReadyCallback, GoogleMap.OnMarkerDragListener {
    private static final String TAG_RESULT = "predictions";
    GoogleMap googleMap;
    MarkerOptions markerOptions;
    ScrollView mapScrollView;
    LatLng latLng;
    AutoCompleteTextView etLocation;
    String url;
    String address;
    String location;
    String pincode;
    String memberId;
    String userArea;
    String reqData;
    String strAddress;
    String draggedAddress;
    String city;
    ArrayList<String> area;
    ArrayAdapter<String> arrayAdapter;
    double latitude;
    double longitude;
    double draggedLat;
    double draggedLng;
    Button changeLocationBtn;
    Button alertMsgOkBtn1;
    TextView alertMessageText1;
    Dialog customDialog1;
    MemberDto memberDto=new MemberDto();
    SharedPreferences preferences;
    private WorkaroundMapFragment supportMapFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_change_location_page, frameLayout);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        address=preferences.getString("address","");
        memberId=preferences.getString("memberId","");
        userArea=preferences.getString("area","");
        pincode=preferences.getString("pincode","");
        latitude= Double.parseDouble(preferences.getString("latitude",""));
        longitude= Double.parseDouble(preferences.getString("longitude",""));
        mInit();


    }


   TextWatcher textWatcher= new TextWatcher() {
       @Override
       public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        // add code before text changed
       }

       @Override
       public void onTextChanged(CharSequence s, int start, int before, int count) {
                     // add code while text changed
       }

       private Timer timer=new Timer();
       private final long delay = 500; // milliseconds
       private Timer timer1=new Timer();
       private final long delay1 = 500; // milliseconds

       @Override
       public void afterTextChanged(Editable s) {
           strAddress=etLocation.getText().toString();
           // ********** map delay ***********
           timer1.cancel();
           timer1= new Timer();
           timer1.schedule(
                   new TimerTask() {
                       @Override
                       public void run() {
                           new GetLatLongDetails().execute();

                       }
                   },
                   delay1
           );
           //******* map delay ******************
           timer.cancel();
           timer = new Timer();
           timer.schedule(
                   new TimerTask() {
                       @Override
                       public void run() {
                           StringBuilder sb=new StringBuilder(Webconfig.GOOGLE_PLACE);
                           try {
                               sb.append("&input=" + URLEncoder.encode(etLocation.getText().toString(), "utf8"));
                           } catch (UnsupportedEncodingException e) {
                               e.printStackTrace();
                           }

                           url=sb.toString();
                           area=new ArrayList<>();
                           new googleAutoComplete().execute();

                       }
                   },
                   delay
           );

       }
   };
    private void mInit() {

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "ChangeLocationPage";

        etLocation=(AutoCompleteTextView)findViewById(R.id.et_location);
        backIcon=(ImageView)findViewById(R.id.back_icon);
        changeLocationBtn=(Button)findViewById(R.id.change_location_btn);
        /*MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        // Getting a reference to the map
        googleMap = mapFragment.getMap();*/
        supportMapFragment = ((WorkaroundMapFragment) getSupportFragmentManager().findFragmentById(R.id.map));
        supportMapFragment.getMapAsync(this);
        mapScrollView=(ScrollView)findViewById(R.id.mapScrollView);
        etLocation.setText(address);

        strAddress =etLocation.getText().toString();
        location =etLocation.getText().toString();
        etLocation.addTextChangedListener(textWatcher);
        changeLocationBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.change_location_btn:
                if(checkValidation()) {
                    if(userArea.length()==0)
                        userArea=city;
                    memberDto.setLatitude(latitude);
                    memberDto.setLongitude(longitude);
                    if (pincode == null)
                        pincode = "0";
                    memberDto.setPincode(Integer.parseInt(pincode));
                    memberDto.setMemberId(Long.parseLong(memberId));
                    memberDto.setAddress(etLocation.getText().toString());
                    memberDto.setArea(userArea);
                    reqData = new Gson().toJson(memberDto);
                    new GetChangeLocationResponse().execute();

                }
                break;
        }
    }

    private boolean checkValidation() {
        boolean valueReturn = true;
        if (!Validation.hasText(etLocation))
            valueReturn = false;
        return valueReturn;
    }

    // ******** Google place auto complete *******

    private class googleAutoComplete extends AsyncTask<Void,Integer,Void> {
        @Override
        protected Void doInBackground(Void... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(url);

            if(result !=null)
            {
                try {
                    // Getting Array of Contacts

                    JSONObject json=new JSONObject(result);
                    JSONArray googlePlace=json.getJSONArray(TAG_RESULT);

                    for(int i = 0; i < googlePlace.length(); i++){
                        JSONObject c = googlePlace.getJSONObject(i);
                        String description = c.getString("description");
                        Log.d("description", description);
                        area.add(description);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                    android.R.layout.simple_list_item_1, area) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    View view = super.getView(position, convertView, parent);
                    TextView text = (TextView) view.findViewById(android.R.id.text1);
                    text.setTextColor(Color.BLACK);
                    return view;
                }
            };

            etLocation.setAdapter(arrayAdapter);

        }
    }

    // An AsyncTask class for accessing the GeoCoding Web Service
    private class GeocoderTask extends AsyncTask<Object, Object, List<Address>> {

        @Override
        protected List<Address> doInBackground(Object... locationName) {
            // Creating an instance of Geocoder class
            Geocoder geocoder = new Geocoder(getBaseContext());
            List<Address> addresses = null;

            try {
                // Getting a maximum of 3 Address that matches the input text
                addresses = geocoder.getFromLocationName((String) locationName[0], 3);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return addresses;
        }

        @Override
        protected void onPostExecute(List<Address> addresses) {

            if(addresses==null || addresses.size()==0){
                Toast.makeText(getBaseContext(), "No Location found", Toast.LENGTH_SHORT).show();
            }

            if (googleMap == null) {
                callAlertDialog("Please Update Google Play Service");
            } else {
                // Clears all the existing markers on the map
                googleMap.clear();

                // Adding Markers on Google Map for each matching address
                if(addresses!=null)
                    for(int i=0;i<addresses.size();i++){

                    // Address address = (Address)addresses.get(i);
                    android.location.Address address= new android.location.Address(Locale.ENGLISH);
                    address=addresses.get(i);


                    // Creating an instance of GeoPoint, to display in Google Map
                    latLng = new LatLng(address.getLatitude(), address.getLongitude());

                    String addressText = String.format("%s, %s",
                            address.getMaxAddressLineIndex() > 0 ? address.getAddressLine(0) : "",
                            address.getCountryName());

                    markerOptions = new MarkerOptions();
                    markerOptions.position(latLng).draggable(true);
                    markerOptions.title(addressText);

                    googleMap.addMarker(markerOptions);
                    pincode=address.getPostalCode();
                    latitude= address.getLatitude();
                    longitude= address.getLongitude();
                    userArea=address.getSubLocality();

                    // Locate the first location
                    if(i==0)

                        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,12.5f));
                }
            }

        }


    }

    private class GetChangeLocationResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;

        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ChangeLocationPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result;
            result=httpConfig.doPost(reqData,Webconfig.CONTEXT_PATH+"updatelocation.json");
            return result;
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            JSONObject jsonObject=null;
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status");
                    if(status.equals("success")){
                        Gson gson=new Gson();
                        String actualData  = jsonObject.getString("memberDto");
                        memberDto=gson.fromJson(actualData,MemberDto.class);
                        customDialog1 = new Dialog(ChangeLocationPage.this);
                        customDialog1.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog1.setContentView(R.layout.custom_messbox);
                        alertMessageText1=(TextView)customDialog1.findViewById(R.id.message_text);
                        alertMsgOkBtn1=(Button)customDialog1.findViewById(R.id.ok_btn);
                        alertMsgOkBtn1.setVisibility(View.GONE);
                        alertMessageText1.setText(getResources().getString(R.string.profile_change_msg));
                        customDialog1.setCancelable(true);
                        customDialog1.setCanceledOnTouchOutside(true);
                        customDialog1.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        customDialog1.dismiss();
                                        updateAddress(memberDto.getAddress(),memberDto.getArea(),memberDto.getPincode());
                                        startActivity(new Intent(ChangeLocationPage.this,HomeScreen.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
//                                                finish();
                                    }
                                }
                        );
                        customDialog1.show();
                        customDialog1.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                    }else{
                       callAlertDialog("Profile Updated Failed. Please try again");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }else{
                callAlertDialog("Server Down... Please try again");
            }
        }
    }

    private void updateAddress(String address, String area, int pincode) {
        SharedPreferences.Editor e=preferences.edit();
        e.putString("address",address);
        e.putString("area",area);
        e.putString("pincode", String.valueOf(pincode));
        e.putString("latitude", String.valueOf(memberDto.getLatitude()));
        e.putString("longitude", String.valueOf(memberDto.getLongitude()));
        e.apply();
    }

    private class GetLatLongDetails extends AsyncTask<String,String,String>{
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String locationAddress = strAddress.replaceAll(" ", "%20");
            String result;
            result=httpConfig.httppost("http://maps.googleapis.com/maps/api/geocode/json?address="+locationAddress+"&sensor=true_or_false");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONObject jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status");
                    if(status.equals("OK")) {
                        JSONArray jsonArray=jsonObject.getJSONArray("results");
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject jsonObjResult=jsonArray.getJSONObject(i);
                            JSONArray addCompoArray=jsonObjResult.getJSONArray("address_components");
                            for(int j=0;j<addCompoArray.length();j++){
                                JSONObject jsonObjAddCompo=addCompoArray.getJSONObject(j);
                                JSONArray jsonArrayType=jsonObjAddCompo.getJSONArray("types");
                                for(int k=0;k<jsonArrayType.length();k++){
                                    String type=jsonArrayType.getString(k);
                                    if(type.equals("postal_code")){
                                        pincode=jsonObjAddCompo.optString("long_name");
                                    }else{
                                        pincode="0";
                                    }
                                    if (type.equals("sublocality_level_1")){
                                        userArea=jsonObjAddCompo.optString("long_name");
                                    }
                                    if (type.equals("locality")){
                                        city=jsonObjAddCompo.optString("long_name");
                                    }

                                }
                            }
                            JSONObject jsonObjGeometry=jsonObjResult.getJSONObject("geometry");
                            JSONObject jsonObjLocation=jsonObjGeometry.getJSONObject("location");
                            latitude= Double.valueOf(jsonObjLocation.optString("lat"));
                            longitude=Double.valueOf(jsonObjLocation.optString("lng"));

                        }
                        // Creating an instance of GeoPoint, to display in Google Map
                        latLng = new LatLng(latitude,longitude);

                        markerOptions = new MarkerOptions();
                        markerOptions.position(latLng).draggable(true);
                        googleMap.clear();
                        googleMap.addMarker(markerOptions);

                        // Locate the first location
                        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12.5f));
                    }
                    else if(status.equals("INVALID_REQUEST")){
                        callAlertDialog("Please Give Correct Address Detail");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        }
    }

    @Override
    public void onMapReady(GoogleMap map) {
        googleMap = map;
        // Enabling MyLocation Layer of Google Map
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        map.setMyLocationEnabled(true);
        latLng=new LatLng(latitude,longitude);
        createMarker();
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12.5f));
        googleMap.setOnMarkerDragListener(this);
        new GetLatLongDetails().execute();
        ((WorkaroundMapFragment) getSupportFragmentManager().findFragmentById(R.id.map)).setListener(new WorkaroundMapFragment.OnTouchListener() {
            @Override
            public void onTouch() {
                mapScrollView.requestDisallowInterceptTouchEvent(true);
            }
        });
    }
    @Override
    public void onMarkerDragStart(Marker marker) {
      // write code when marker start to drag
    }

    @Override
    public void onMarkerDrag(Marker marker) {
        // write code when marker while to drag
    }

    @Override
    public void onMarkerDragEnd(Marker marker) {
        draggedLat=marker.getPosition().latitude;
        draggedLng=marker.getPosition().longitude;
        new GetMarkerDraggedPosition().execute();


    }
    private void createMarker() {
        markerOptions = new MarkerOptions();
        markerOptions.position(latLng).draggable(true);
        googleMap.addMarker(markerOptions);
    }

    private class GetMarkerDraggedPosition extends AsyncTask<String,String,String>
    {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result;
            result=httpConfig.httpget("http://maps.googleapis.com/maps/api/geocode/json?latlng="+draggedLat+","+draggedLng+"&sensor=true_or_false");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONObject jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status");
                    if(status.equals("OK")){
                        JSONArray jsonArray=jsonObject.getJSONArray("results");
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject jObj=jsonArray.getJSONObject(0);
                            draggedAddress=jObj.optString("formatted_address");
                        }
                        etLocation.setText(draggedAddress);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void callAlertDialog(String message) {

        customDialog1 = new Dialog(ChangeLocationPage.this);
        customDialog1.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog1.setContentView(R.layout.custom_messbox);
        customDialog1.setCancelable(true);
        alertMessageText1=(TextView)customDialog1.findViewById(R.id.message_text);
        alertMsgOkBtn1=(Button)customDialog1.findViewById(R.id.ok_btn);
        alertMessageText1.setText(message);
        alertMsgOkBtn1.setVisibility(View.GONE);
        customDialog1.show();
        customDialog1.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }
}
