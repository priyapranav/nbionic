package info.com.neighbourbase.activity;

import android.Manifest;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.roomorama.caldroid.CaldroidListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import info.com.neighbourbase.R;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class GoogleMapPopup extends AppCompatActivity implements View.OnClickListener, OnMapReadyCallback, GoogleMap.OnMarkerDragListener {
    GoogleMap googleMap;
    Marker marker;
    private static final String TAG_RESULT = "predictions";
    MarkerOptions markerOptions;
    LatLng latLng;
    AutoCompleteTextView etLocation;
    EditText radius;
    ArrayList<String> area;
    ArrayAdapter<String> arrayAdapter;
    Circle circle;
    SharedPreferences preferences;
    String address,searchRadius,editSearchRadius,latitude,longitude,pincode,location,url, strAddress, radiusStr,draggedAddress;
    Double locationRadius,draggedLat,draggedLng;
    Toolbar toolbar;
    ImageView back_icon, img_find ;
    TextView alertMessageText;
    Button alertMsgOkBtn;
    Dialog customDialog;
    private SupportMapFragment supportMapFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.google_map);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        address=preferences.getString("address","");
        searchRadius=preferences.getString("radius","");
        latitude=preferences.getString("latitude","");
        longitude=preferences.getString("longitude","");
        latLng=new LatLng(Double.valueOf(latitude),Double.valueOf(longitude));
        mInit();

        /*MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);

        // Getting a reference to the map
        googleMap = mapFragment.getMap();*/
        supportMapFragment = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map));
        supportMapFragment.getMapAsync(this);

        /*latLng=new LatLng(Double.valueOf(latitude),Double.valueOf(longitude));
        createSearchRadius();
        createMarker();
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12.5f));*/




    }

    private void mInit() {
        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "GoogleMapPopup";
        toolbar=(Toolbar)findViewById(R.id.toolbar);
        back_icon=(ImageView)findViewById(R.id.back_icon);
        etLocation = (AutoCompleteTextView) findViewById(R.id.et_location);
        etLocation.setText(address);
        etLocation.addTextChangedListener(textWatcher);
        location =etLocation.getText().toString();
        radius=(EditText)findViewById(R.id.radius);
       /* if(Constant.searchRadius==0.0){*/
            radius.setText(searchRadius);
       /* } else {
            radius.setText(String.valueOf(Constant.searchRadius));
        }*/
        etLocation.addTextChangedListener(textWatcher);
  // Getting reference to btn_find of the layout activity_main
        img_find = (ImageView) findViewById(R.id.img_find);
        img_find.setOnClickListener(this);
        back_icon.setOnClickListener(this);
        radius.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                createSearchRadius();
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });


    }


    TextWatcher textWatcher= new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        private Timer timer=new Timer();
        private final long DELAY = 500; // milliseconds
        private Timer timer1=new Timer();
        private final long DELAY1 = 500; // milliseconds

        @Override
        public void afterTextChanged(Editable s) {
            strAddress=etLocation.getText().toString();
           // ********** map delay ***********
            timer1.cancel();
            timer1= new Timer();
            timer1.schedule(
                    new TimerTask() {
                        @Override
                        public void run() {
                            new getLatLongDetails().execute();

                        }
                    },
                    DELAY1
            );
            //******* map delay ******************
            timer.cancel();
            timer = new Timer();
            timer.schedule(
                    new TimerTask() {
                        @Override
                        public void run() {
                            StringBuilder sb=new StringBuilder(Webconfig.GOOGLE_PLACE);
                            try {
                                sb.append("&input=" + URLEncoder.encode(etLocation.getText().toString(), "utf8"));
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }

                            url=sb.toString();
                            area=new ArrayList<String>();
                            new googleAutoComplete().execute();

                        }
                    },
                    DELAY
            );

        }
    };

    private void createMarker() {
        markerOptions = new MarkerOptions();
        markerOptions.position(latLng).draggable(true);
        googleMap.addMarker(markerOptions);
    }

    private boolean checkDetails() {
        boolean valueReturn = true;
        if (!Validation.hasText(etLocation))
            valueReturn=false;
        if(!Validation.hasText(radius))
            valueReturn=false;
        return  valueReturn;
    }


    @Override
    public void onMapReady(GoogleMap map) {
        googleMap = map;
        // Enabling MyLocation Layer of Google Map
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        map.setMyLocationEnabled(true);
        latLng=new LatLng(Double.valueOf(latitude),Double.valueOf(longitude));
        createSearchRadius();
        createMarker();
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12.5f));
        googleMap.setOnMarkerDragListener(this);

    }

    @Override
    public void onMarkerDragStart(Marker marker) {

    }

    @Override
    public void onMarkerDrag(Marker marker) {

    }

    @Override
    public void onMarkerDragEnd(Marker marker) {
        draggedLat=marker.getPosition().latitude;
        draggedLng=marker.getPosition().longitude;
        new getMarkerDraggedPosition().execute();


    }

    private class googleAutoComplete extends AsyncTask<Void,Integer,Void> {
        @Override
        protected Void doInBackground(Void... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(url);
            area.clear();
            if(result !=null)
            {
                try {
                    // Getting Array of Contacts

                    JSONObject json=new JSONObject(result);
                    JSONArray googlePlace=json.getJSONArray(TAG_RESULT);

                    for(int i = 0; i < googlePlace.length(); i++){
                        JSONObject c = googlePlace.getJSONObject(i);
                        String description = c.getString("description");
                        Log.d("description", description);
                        area.add(description);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                    android.R.layout.simple_list_item_1, area) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    View view = super.getView(position, convertView, parent);
                    TextView text = (TextView) view.findViewById(android.R.id.text1);
                    text.setTextColor(Color.BLACK);
                    return view;
                }
            };
            etLocation.setAdapter(arrayAdapter);
        }
    }


    private void createSearchRadius() {
        radiusStr = radius.getText().toString().trim();
        if(radiusStr.length()==0 || radiusStr.isEmpty()){
            radiusStr = "0.0";
        }
        if(circle!=null)
            circle.remove();
        circle = googleMap.addCircle(new CircleOptions()
                .center(new LatLng(latLng.latitude, latLng.longitude))
                .radius((Double.parseDouble(radiusStr) * 1000))
                .strokeColor(Color.argb(255,242,212,212))
                .fillColor(Color.argb(255,242,212,212)));
        circle.setCenter(latLng);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.img_find:
                if(checkDetails()) {
                    if (circle != null)
                        circle.remove();
                    locationRadius = Double.parseDouble(radius.getText().toString().trim());
                    editSearchRadius = String.valueOf(locationRadius);
                    if (locationRadius <= 0) {
                        callAlertDialog("Give Valid Limit");
                    } else {
                        createSearchRadius();
                        location = etLocation.getText().toString().trim();
                        Intent intent = new Intent(GoogleMapPopup.this, HomeScreen.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        /*Constant.searchRadius=locationRadius;*/
                        intent.putExtra("editSearchRadius", editSearchRadius);
                        intent.putExtra("latitude", latitude);
                        intent.putExtra("longitude", longitude);
                        intent.putExtra("pincode", pincode);
                        intent.putExtra("changeLocation", location);
                        startActivity(intent);

                    }

                }
                break;
            case R.id.back_icon:
                startActivity(new Intent(GoogleMapPopup.this, HomeScreen.class));
//                finish();
                break;
        }
    }

    private class getLatLongDetails extends AsyncTask<String,String,String>{
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String locationAddress = strAddress.replaceAll(" ", "%20");
            String result=httpConfig.httppost("http://maps.googleapis.com/maps/api/geocode/json?address="+locationAddress+"&sensor=true_or_false");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONObject jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status");
                    if(status.equals("OK")) {
                        JSONArray jsonArray=jsonObject.getJSONArray("results");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObjResult = jsonArray.getJSONObject(i);
                            JSONArray addCompoArray = jsonObjResult.getJSONArray("address_components");
                            for (int j = 0; j < addCompoArray.length(); j++) {
                                JSONObject jsonObjAddCompo = addCompoArray.getJSONObject(j);
                                JSONArray jsonArrayType = jsonObjAddCompo.getJSONArray("types");
                                for (int k = 0; k < jsonArrayType.length(); k++) {
                                    String type = jsonArrayType.getString(k);
                                    if (type.equals("postal_code")) {
                                        pincode = jsonObjAddCompo.optString("long_name");
                                    } else {
                                        pincode = "0";
                                    }

                                }
                            }
                            JSONObject jsonObjGeometry = jsonObjResult.getJSONObject("geometry");
                            JSONObject jsonObjLocation = jsonObjGeometry.getJSONObject("location");
                            latitude = jsonObjLocation.optString("lat");
                            longitude = jsonObjLocation.optString("lng");

                        }
                        // Creating an instance of GeoPoint, to display in Google Map
                        latLng = new LatLng(Double.valueOf(latitude),Double.valueOf(longitude));

                        markerOptions = new MarkerOptions();
                        markerOptions.position(latLng).draggable(true);
                        googleMap.clear();
                        googleMap.addMarker(markerOptions);

                        createSearchRadius();
                        // Locate the first location
                        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12.5f));

                    } else if(status.equals("INVALID_REQUEST")){
                        callAlertDialog("Please Give Correct Address Detail");
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        }
    }

    private class getMarkerDraggedPosition extends AsyncTask<String,String,String>
    {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httpget("http://maps.googleapis.com/maps/api/geocode/json?latlng="+draggedLat+","+draggedLng+"&sensor=true_or_false");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONObject jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status");
                    if(status.equals("OK")){
                        JSONArray jsonArray=jsonObject.getJSONArray("results");
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject jObj=jsonArray.getJSONObject(0);
                            draggedAddress=jObj.optString("formatted_address");
                        }
                        etLocation.setText(draggedAddress);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(GoogleMapPopup.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }


//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(GoogleMapPopup.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(GoogleMapPopup.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(GoogleMapPopup.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(GoogleMapPopup.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(GoogleMapPopup.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(GoogleMapPopup.this, AddGroupActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(GoogleMapPopup.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(GoogleMapPopup.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(GoogleMapPopup.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(GoogleMapPopup.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(GoogleMapPopup.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(GoogleMapPopup.this, MessageActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(GoogleMapPopup.this, MyListingPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(GoogleMapPopup.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(GoogleMapPopup.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(GoogleMapPopup.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(GoogleMapPopup.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(GoogleMapPopup.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(GoogleMapPopup.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(GoogleMapPopup.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(GoogleMapPopup.this, HomeScreen.class));
//            finish();
//        }
//
//    }

}

