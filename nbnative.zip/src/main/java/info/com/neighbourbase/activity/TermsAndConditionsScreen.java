package info.com.neighbourbase.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import info.com.neighbourbase.R;
import info.com.neighbourbase.utility.Webconfig;

public class TermsAndConditionsScreen extends AppCompatActivity {
WebView termsAndConditions;
    ImageView close_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_and_conditions_screen);
        termsAndConditions=(WebView)findViewById(R.id.terms_conditions);
        close_btn=(ImageView)findViewById(R.id.closeButton);
        termsAndConditions.getSettings().setJavaScriptEnabled(true);
        termsAndConditions.loadUrl(Webconfig.CONTEXT_PATH1+"terms_and_conditions_bfr");
        close_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
