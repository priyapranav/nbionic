package info.com.neighbourbase.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import info.com.neighbourbase.Adapter.CategoryDisplayAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CategoryDto;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class ProductEditPage extends CommonHeader implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    EditText productName,productDescription,salePrice,rentPerDay,rentPerWeek,rentPerMonth;
    Spinner selectListingType,productAvailableFrom,productAvailableTo;
    TextView thru,listProductIn;
    ImageView productImage,addImageIcon;
    Button updateListingBtn,categorySelectButton;
    RadioButton availableFrom,availableOnlyOn;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private String userChoosenTask;
    byte[] productImgByteArray;
    SharedPreferences preferences;
    String[] listingType={"Lend","Rent","Sell","GiveAway"};
    String[] days={"Select","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
    String[] network={"public","info","career"};
    String picture,dayFm,dayTo,rentPerDayStr,rentPerWeekStr,rentPerMonthStr,selectListingTypeStr,productAvailableFromSpinnerStr,productAvailableToSpinnerStr,reqData,memberId,productNameStr,productDescriptionStr,catPositionStr,productIdStr;
    LinearLayout salePriceLayout,rentalPriceLayout,productAvailableLayout;
    ArrayAdapter<String> listTypeAdapter,daysAdapter;
    ArrayList<String> dayList,dayList1,networkList,networkName,rootCategory,availableCategory;
    ArrayList<Long> networkId,userSelectNetworkId,categoryIds;
    ProductListingDto productListingDto;
    int transTypeId,catPosition,dayFmInt,dayToInt,check=0;
    ListView categoryList;
    Map<String,Long> productNetwork;
    Map<Long,String> productNetworkMap;
    PopupWindow categoryNameSelect;
    CategoryDto categoryDto;
    CategoryDisplayAdapter categoryDisplay;
    StringBuilder sb;
    Long addProductCatId;
    Bitmap bitmap;

    Spinner rootCategorySpinner;
    Spinner subCategorySpinner;
    List<CategoryDto> categoryDtoLists;
    List<String> categoryNameList;
    List<Long> categoryIdList;
    Map<String,Long> categoryMap;
    Map<Long,String> rootCatInvertMap;
    Map<Long,String> subCatInvertMap;

    List<String> catList;
    Map<String,Long> categoryIdName=new HashMap<>();
    Long rootId;
    Long subCatId;
    ArrayAdapter catAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_product_edit_page);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_product_edit_page, FrameLayout);

        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        memberId=preferences.getString("memberId","");
        productIdStr=getIntent().getStringExtra("productId");
        mInit();
        new LoadRootCategory().execute();
        new getNetworkName().execute();
        new getProductDetails().execute();
        updateListingBtn.setOnClickListener(this);
        availableOnlyOn.setOnClickListener(this);
        availableFrom.setOnClickListener(this);
        selectListingType.setOnItemSelectedListener(this);
        productAvailableFrom.setOnItemSelectedListener(this);
        productAvailableTo.setOnItemSelectedListener(this);
        addImageIcon.setOnClickListener(this);
        listProductIn.setOnClickListener(this);


    }



    private void mInit() {

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "ProductEditPage";

        productName=(EditText)findViewById(R.id.product_name);
        productDescription=(EditText)findViewById(R.id.product_description);
        salePrice=(EditText)findViewById(R.id.sale_price);
        rentPerDay=(EditText)findViewById(R.id.rent_per_day);
        rentPerMonth=(EditText)findViewById(R.id.rent_per_month);
        rentPerWeek=(EditText)findViewById(R.id.rent_per_week);
        selectListingType=(Spinner)findViewById(R.id.select_listing_type);
        productAvailableFrom=(Spinner)findViewById(R.id.spinner_from);
        productAvailableTo=(Spinner)findViewById(R.id.spinner_to);
        listProductIn=(TextView) findViewById(R.id.list_product_in);
        thru=(TextView)findViewById(R.id.thru);
        productImage=(ImageView)findViewById(R.id.product_image);
        addImageIcon=(ImageView) findViewById(R.id.add_image_icon);
        updateListingBtn=(Button)findViewById(R.id.update_listing_btn);
        availableFrom=(RadioButton)findViewById(R.id.radioBtnFrom);
        availableOnlyOn=(RadioButton)findViewById(R.id.radioBtnOnlyOn);
        rentalPriceLayout=(LinearLayout)findViewById(R.id.rental_price_layout);
        salePriceLayout=(LinearLayout)findViewById(R.id.sale_price_layout);
        productAvailableLayout=(LinearLayout)findViewById(R.id.product_available_layout);
        rootCategorySpinner=(Spinner)findViewById(R.id.root_category_spinner);
        subCategorySpinner=(Spinner)findViewById(R.id.sub_category_spinner);


        listTypeAdapter =new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,listingType);
        selectListingType.setAdapter(listTypeAdapter);
        dayList = new ArrayList<String>(Arrays.asList(days));
        dayList1=new ArrayList<String>();
        networkList=new ArrayList<String>(Arrays.asList(network));
        daysAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,dayList);
        productAvailableFrom.setAdapter(daysAdapter);
        productAvailableTo.setAdapter(daysAdapter);
        rootCategorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String catName=categoryNameList.get(position).trim();
                if (catName.equals("Select Category")){
                    subCategorySpinner.setVisibility(View.GONE);
                }else{
                    rootId = categoryMap.get(categoryNameList.get(position).trim());
                    addProductCatId=rootId;
                    new GetSubCategory().execute();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });




    }

    private boolean checkAddListingValidation() {
        rentPerWeekStr=rentPerWeek.getText().toString().trim();
        rentPerMonthStr=rentPerMonth.getText().toString().trim();
        rentPerDayStr=rentPerDay.getText().toString().trim();
        boolean valueReturn = true;
        if (!Validation.hasText(productName))
            valueReturn = false;
        if(listProductIn.getText().toString().equals(getResources().getString(R.string.click_here)))
        {  callAlertDialog("Select NetWork");
            valueReturn=false;}
        if(!Validation.hasText(productDescription))
            valueReturn=false;
        if(selectListingTypeStr.equals("Sell")) {
            if (!Validation.hasText(salePrice))
                valueReturn = false;
            if(salePrice.getText().toString().equals("0.0")){
                salePrice.setError("sale price required");
                valueReturn=false;
            }

        }
        if(selectListingTypeStr.equals("Rent")){
            if(rentPerDayStr.length()==0||rentPerDayStr.equals("0")){
                if(rentPerWeekStr.length()==0||rentPerWeekStr.equals("0")){
                    if(rentPerMonthStr.length()==0||rentPerMonthStr.equals("0")){
                        callAlertDialog("Enter at least any one the Rental price field");
                        valueReturn=false;
                        }
                    }
                }
            }
        if(transTypeId==1){
            if(availableFrom.isChecked()){
                if(productAvailableFromSpinnerStr.equals("Select")){
                    callAlertDialog("Select Duration");
                    valueReturn=false;
                }else  if(productAvailableToSpinnerStr.equals("Select")){
                    callAlertDialog("Select Duration");
                    valueReturn=false;

                }
            }

            if(availableOnlyOn.isChecked()){
                if(productAvailableFromSpinnerStr.equals("Select")){
                   callAlertDialog("Select Duration");
                    valueReturn=false;
                }

            }

        }
        String selectRootCatString=rootCategorySpinner.getSelectedItem().toString();
        if(selectRootCatString.trim().equals("Select Category")){
            callAlertDialog("Select Valid Category");
            valueReturn=false;
        }else{
            addProductCatId=rootId;
        }
        if(subCategorySpinner.getVisibility()==View.VISIBLE){
            String selectSubCatString=subCategorySpinner.getSelectedItem().toString();
            if(selectSubCatString.trim().equals("Select Sub-Category")){
                callAlertDialog("Select Valid Sub-Category");
                valueReturn=false;
            }else
            {
                subCatId = categoryIdName.get(selectSubCatString.trim());
                addProductCatId=subCatId;

            }

        }



        return valueReturn;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.update_listing_btn:
                if(checkAddListingValidation()) {
                    if(productImage.getDrawable()==null){
                        setProductListingDto();
                    }else{
                        if(productImage.getDrawable().getConstantState()==getResources().getDrawable(R.drawable.no_image).getConstantState()){
                            customDialog = new Dialog(ProductEditPage.this);
                            customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                            customDialog.setContentView(R.layout.custom_messbox);
                            alertMessageText = (TextView) customDialog.findViewById(R.id.message_text);
                            alertMsgOkBtn = (Button) customDialog.findViewById(R.id.ok_btn);
                            alertMsgOkBtn.setText(getResources().getString(R.string.alert_msg_yes));
                            alertMessageText.setText(getResources().getString(R.string.add_group_not_attach_photo_alert));
                            customDialog.setCancelable(true);
                            alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    customDialog.dismiss();
//                                    Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.no_image);
//                                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
//                                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
//                                    productImgByteArray= stream.toByteArray();
                                    setProductListingDto();
//                                productNameStr = productName.getText().toString().trim();
//                                Intent i=new Intent(ProductEditPage.this,CategoryRecommendationActivity.class);
//                                i.putExtra("productName",productNameStr);
//                                i.putExtra("categoryId",productListingDto.getCategoryId());
//                                startActivityForResult(i,2);
                                }
                            });
                            customDialog.show();
                            customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                        }else{
                            if(productImgByteArray==null){
                                new loadImage().execute();
//                            productNameStr = productName.getText().toString().trim();
//                            Intent i=new Intent(ProductEditPage.this,CategoryRecommendationActivity.class);
//                            i.putExtra("productName",productNameStr);
//                            i.putExtra("categoryId",productListingDto.getCategoryId());
//                            startActivityForResult(i,2);

                            }else{
                                setProductListingDto();
                            /*productNameStr = productName.getText().toString().trim();
                            Intent i=new Intent(ProductEditPage.this,CategoryRecommendationActivity.class);
                            i.putExtra("productName",productNameStr);
                            i.putExtra("categoryId",productListingDto.getCategoryId());
                            startActivityForResult(i,2);*/
                            }
                        }
                    }


                }
                break;
            case R.id.radioBtnOnlyOn:
                thru.setVisibility(View.GONE);
                productAvailableTo.setVisibility(View.GONE);
                break;
            case R.id.radioBtnFrom:
                thru.setVisibility(View.VISIBLE);
                productAvailableTo.setVisibility(View.VISIBLE);
                break;
            case R.id.add_image_icon:
                selectImage();
                break;
            case R.id.list_product_in:
                loadNetwork();
                break;



        }
    }

    private void setProductListingDto() {
        productNameStr = productName.getText().toString().trim();
        productDescriptionStr = productDescription.getText().toString().trim();
        productListingDto = new ProductListingDto();
        productListingDto.setProductName(productNameStr);
        productListingDto.setProductDescription(productDescriptionStr);
        productListingDto.setProductId(Long.parseLong(productIdStr));
        productListingDto.setNetworkId(2);
        productListingDto.setTransTypeId(transTypeId);
        productListingDto.setProductImage(productImgByteArray);
        productListingDto.setMemberId(Long.parseLong(memberId));
        if(selectListingTypeStr.equals("Sell"))
            productListingDto.setSalePrice(Double.parseDouble(salePrice.getText().toString()));
        if(selectListingTypeStr.equals("Rent")) {
            if(rentPerDayStr.equals(""))
                rentPerDayStr="0";
            if(rentPerWeekStr.equals(""))
                rentPerWeekStr="0";
            if(rentPerMonthStr.equals(""))
                rentPerMonthStr="0";
            productListingDto.setPriceperday(Long.parseLong(rentPerDayStr));
            productListingDto.setPriceperweek(Long.parseLong(rentPerWeekStr));
            productListingDto.setPricepermonth(Long.parseLong(rentPerMonthStr));
        }

        getDayfromDayto();
        getUserSelectNetworkId();
        if(availableOnlyOn.isChecked())
            productAvailableToSpinnerStr="0";
        productListingDto.setNetworkids(userSelectNetworkId);
        productListingDto.setDayfrom(productAvailableFromSpinnerStr);
        productListingDto.setDayto(productAvailableToSpinnerStr);
        productListingDto.setCategoryId(addProductCatId);
        reqData=new Gson().toJson(productListingDto);
        new getAddListingResponse().execute();
//        new getCategory().execute();
    }
    private class LoadRootCategory extends AsyncTask<String,String,String>{
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ProductEditPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... strings) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getrootcategories.json?memberId="+memberId);
            return result;
        }
        @Override
        protected void onPostExecute(String res) {
            CategoryDto categoryDto;
            progressDialog.dismiss();
            categoryDtoLists = new ArrayList<CategoryDto>();
            categoryIdList=new ArrayList<>();
            categoryMap=new HashMap<>();
            rootCatInvertMap=new HashMap<>();
            categoryNameList=new ArrayList();
            JSONObject jsonObject= null;
            Gson gson = new Gson();
            if(res!=null) {
                try {
                    categoryNameList.add("Select Category");
                    jsonObject = new JSONObject(res);
                    String status = jsonObject.getString("status");

                    if(status.equalsIgnoreCase("success")) {
                        CommonResponseDto commonResponseDto = gson.fromJson(res, CommonResponseDto.class);
                        categoryDtoLists = commonResponseDto.getCategoryDto();
                    }
                    for (int i = 0; i < categoryDtoList.size(); i++) {
                        categoryNameList.add(categoryDtoList.get(i).getCategoryName().trim());
                        categoryMap.put(categoryDtoList.get(i).getCategoryName().trim(),categoryDtoList.get(i).getCategoryId());
                        categoryIdList.add(categoryDtoList.get(i).getCategoryId());
                        rootCatInvertMap.put(categoryDtoList.get(i).getCategoryId(),categoryDtoList.get(i).getCategoryName().trim());
                    }

                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(ProductEditPage.this, android.R.layout.simple_spinner_dropdown_item, categoryNameList);
                    rootCategorySpinner.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                callAlertDialog("check your internet connection");
            }

        }
    }
    private class GetSubCategory extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ProductEditPage.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result;
            result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getchildcategories.json?parentid="+rootId);
            return result;
        }
        @Override
        protected void onPostExecute(String res) {
            CategoryDto categoryDto;
            catList=new ArrayList<>();
            subCatInvertMap=new HashMap<>();
            progressDialog.dismiss();
            if(res!=null && res.length()>3) {
                catList.add("Select Sub-Category");
                subCategorySpinner.setVisibility(View.VISIBLE);
                try {
                    JSONArray jsonArray = new JSONArray(res.trim());
                    /*if(Connectivity.isConnected(CategoryActivity.this)) {
                        new GetAvailableCategory().execute();
                    }else{
                        Toast.makeText(CategoryActivity.this,"Please Check Internet Connection", Toast.LENGTH_LONG).show();
                    }*/
                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject category = jsonArray.getJSONObject(i);
                        Gson gson = new Gson();
                        categoryDto = gson.fromJson(category.toString().trim(), CategoryDto.class);
                        catList.add(categoryDto.getCategoryName().trim());
                        subCatInvertMap.put( categoryDto.getCategoryId(),categoryDto.getCategoryName().trim());
                        categoryIdName.put(categoryDto.getCategoryName().trim(), categoryDto.getCategoryId());

                    }
                    catAdapter=new ArrayAdapter(ProductEditPage.this,android.R.layout.simple_spinner_dropdown_item,catList);
                    subCategorySpinner.setAdapter(catAdapter);
                    if(productListingDto.getLevel1CategoryList()!=null&&!productListingDto.getLevel1CategoryList().isEmpty()){
                        subCategorySpinner.setVisibility(View.VISIBLE);
                        subCategorySpinner.setSelection(catList.indexOf(productListingDto.getCategoryName().trim()));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else {
                if(res==null)
                    callAlertDialog("check your internet connection");
                subCategorySpinner.setVisibility(View.GONE);

            }
        }
    }
    private void showCategorySelectPopup(final Activity context) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.category_select_for_listing_page,
                (ViewGroup)context. findViewById(R.id.popup));
        categoryNameSelect = new PopupWindow(layout, 950, 1200, true);
        categoryNameSelect.showAtLocation(layout, Gravity.CENTER, 0, 0);
        categoryList=(ListView)layout.findViewById(R.id.category_select_list);
        categorySelectButton=(Button)layout.findViewById(R.id.category_select_button);
        categoryList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        categoryList.setAdapter(categoryDisplay);
        categorySelectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoryNameSelect.dismiss();
                catPositionStr=preferences.getString("categoryId","");
                catPosition= Integer.parseInt(catPositionStr);
                Long categoryId=categoryIds.get(catPosition);
                productListingDto.setCategoryId(categoryId);
                reqData=new Gson().toJson(productListingDto);
                new getAddListingResponse().execute();
            }
        });

    }

    private void getUserSelectNetworkId() {
        userSelectNetworkId=new ArrayList<Long>();
        String network= listProductIn.getText().toString().trim();
        String[] networkStr=network.split(",");
        for (String aNetworkStr : networkStr) {
            Long ID=(Long) productNetwork.get(aNetworkStr);
            System.out.println(ID);
            userSelectNetworkId.add(ID);
        }

    }

    private void getDayfromDayto() {
        if (productAvailableFromSpinnerStr.equals("Select"))
            productAvailableFromSpinnerStr="0";
        if (productAvailableFromSpinnerStr.equals("Sunday"))
            productAvailableFromSpinnerStr = "1";
        if (productAvailableFromSpinnerStr.equals("Monday"))
            productAvailableFromSpinnerStr = "2";
        if (productAvailableFromSpinnerStr.equals("Tuesday"))
            productAvailableFromSpinnerStr = "3";
        if (productAvailableFromSpinnerStr.equals("Wednesday"))
            productAvailableFromSpinnerStr = "4";
        if (productAvailableFromSpinnerStr.equals("Thursday"))
            productAvailableFromSpinnerStr = "5";
        if (productAvailableFromSpinnerStr.equals("Friday"))
            productAvailableFromSpinnerStr = "6";
        if (productAvailableFromSpinnerStr.equals("Saturday"))
            productAvailableFromSpinnerStr = "7";
        if (productAvailableToSpinnerStr.equals("Select"))
            productAvailableToSpinnerStr="0";
        if (productAvailableToSpinnerStr.equals("Sunday"))
            productAvailableToSpinnerStr = "1";
        if (productAvailableToSpinnerStr.equals("Monday"))
            productAvailableToSpinnerStr = "2";
        if (productAvailableToSpinnerStr.equals("Tuesday"))
            productAvailableToSpinnerStr = "3";
        if (productAvailableToSpinnerStr.equals("Wednesday"))
            productAvailableToSpinnerStr = "4";
        if (productAvailableToSpinnerStr.equals("Thursday"))
            productAvailableToSpinnerStr = "5";
        if (productAvailableToSpinnerStr.equals("Friday"))
            productAvailableToSpinnerStr = "6";
        if (productAvailableToSpinnerStr.equals("Saturday"))
            productAvailableToSpinnerStr = "7";
    }

    private void loadNetwork() {
        final CharSequence[] dialogList=  networkName.toArray(new CharSequence[networkName.size()]);
        final android.app.AlertDialog.Builder builderDialog = new android.app.AlertDialog.Builder(ProductEditPage.this);
        builderDialog.setTitle("Select Network");
        int count = dialogList.length;
        boolean[] is_checked = new boolean[count];
        if(listProductIn.getText().toString().length()!=0){
            String network= listProductIn.getText().toString().trim();
            String[] networkStr=network.split(",");
            for(String networkList:networkStr){
                for(int j=0;j<networkName.size();j++){
                    if(networkName.get(j).equals(networkList))
                        is_checked[j]=true;
                }
            }
        }

        // Creating multiple selection by using setMutliChoiceItem method
        builderDialog.setMultiChoiceItems(dialogList, is_checked,
                new DialogInterface.OnMultiChoiceClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int whichButton, boolean isChecked) {
                    }
                });

        builderDialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        ListView list = ((android.app.AlertDialog) dialog).getListView();
                        // make selected item in the comma seprated string
                        StringBuilder stringBuilder = new StringBuilder();
                        for (int i = 0; i < list.getCount(); i++) {
                            boolean checked = list.isItemChecked(i);

                            if (checked) {
                                if (stringBuilder.length() > 0) stringBuilder.append(",");
                                stringBuilder.append(list.getItemAtPosition(i));


                            }
                        }

                        /*Check string builder is empty or not. If string builder is not empty.
                          It will display on the screen.
                         */
                        if (stringBuilder.toString().trim().equals("")) {

//                            listProductIn.setText(getResources().getString(R.string.click_here));
                            stringBuilder.setLength(0);

                        } else {

                            listProductIn.setText(stringBuilder);
                        }
                    }
                });

        builderDialog.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
//                        listProductIn.setText(getResources().getString(R.string.click_here));
                    }
                });
        android.app.AlertDialog alert = builderDialog.create();
        alert.show();

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.select_listing_type:
                selectListingTypeStr = selectListingType.getSelectedItem().toString().trim();
                if (selectListingTypeStr.equals("Lend")) {
                    transTypeId=1;
                    salePriceLayout.setVisibility(View.GONE);
                    rentalPriceLayout.setVisibility(View.GONE);
                    productAvailableLayout.setVisibility(View.VISIBLE);

                } else if (selectListingTypeStr.equals("Rent")) {
                    transTypeId=2;
                    salePriceLayout.setVisibility(View.GONE);
                    rentalPriceLayout.setVisibility(View.VISIBLE);
                    productAvailableLayout.setVisibility(View.GONE);

                } else if (selectListingTypeStr.equals("Sell")) {
                    transTypeId=3;
                    rentalPriceLayout.setVisibility(View.GONE);
                    productAvailableLayout.setVisibility(View.GONE);
                    salePriceLayout.setVisibility(View.VISIBLE);


                } else if (selectListingTypeStr.equals("GiveAway")) {
                    transTypeId=4;
                    salePriceLayout.setVisibility(View.GONE);
                    rentalPriceLayout.setVisibility(View.GONE);
                    productAvailableLayout.setVisibility(View.GONE);


                }
                break;
            case R.id.spinner_from:
                productAvailableFromSpinnerStr = productAvailableFrom.getSelectedItem().toString().trim();
                if(++check>2){
                    if(position>0) {
                        dayList1.clear();
                        int i=productAvailableFrom.getSelectedItemPosition();
                        dayList.remove(productAvailableFromSpinnerStr);
                        dayList1.addAll(dayList);
                        daysAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, dayList1);
                        productAvailableTo.setAdapter(daysAdapter);
                        dayList.add(i,productAvailableFromSpinnerStr);

                    }
                }

                break;
            case R.id.spinner_to:
                productAvailableToSpinnerStr=productAvailableTo.getSelectedItem().toString().trim();
                break;

        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private class getAddListingResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ProductEditPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData, Webconfig.CONTEXT_PATH+"updateproductlisting.json");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject jsonObject=null;
            progressDialog.dismiss();
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status","");
                    System.out.println(status);
                    if(status.equals("success")){
                        customDialog = new Dialog(ProductEditPage.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setVisibility(View.GONE);
                        alertMessageText.setText(getResources().getString(R.string.product_edit_success_msg));
                        customDialog.setCancelable(true);
                        customDialog.setCanceledOnTouchOutside(true);
                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        customDialog.dismiss();
                                        startActivity(new Intent(ProductEditPage.this,MyListingPage.class));

                                    }
                                }
                        );
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            else{
                callAlertDialog("Server down...");
            }
        }
    }

    // **************** Capture Product Image ***************************
    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Library","No Image","Cancel"};

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(ProductEditPage.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {


                if (items[item].equals("Take Photo")) {
                    userChoosenTask ="Take Photo";
                    cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    userChoosenTask ="Choose from Library";
                    galleryIntent();

                } else if (items[item].equals("No Image")) {
                    productImage.setImageResource(R.drawable.no_image);
                    productImgByteArray=null;
                }else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent()
    {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }

    private void cameraIntent()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, 0);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode){
            case 0:
                if (resultCode == Activity.RESULT_OK) {
                    if (requestCode == 0)
                        onCaptureImageResult(data);
                }
                break;
            case 1:
                if (resultCode == Activity.RESULT_OK) {
                    if (requestCode == SELECT_FILE)
                        onSelectFromGalleryResult(data);}
                break;
//            case 2:
//                if (resultCode == 2) {
//                    addProductCatId = data.getLongExtra("categoryId", 0L);
//                    setProductListingDto();
//                }
//                break;

        }

    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        String picturePath=destination.getPath();
        thumbnail=changeOrientation(picturePath,thumbnail);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        productImgByteArray= bytes.toByteArray();

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        productImage.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Uri selectedImageUri = data.getData();
        String picturePath= getRealPathFromURI(selectedImageUri);
        Bitmap bm=null;
        if (data!= null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {

            InputStream imageStream = getContentResolver().openInputStream(selectedImageUri);
            Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
            selectedImage = getResizedBitmap(selectedImage, 400);// 400 is for example, replace with desired size
            selectedImage= changeOrientation(picturePath,selectedImage);
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            selectedImage.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
            productImgByteArray= bytes.toByteArray();
            productImage.setImageBitmap(selectedImage);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }
    private Bitmap changeOrientation(String picturePath, Bitmap loadedBitmap) {
        if(picturePath!=null) {
            ExifInterface exif = null;
            try {
                File pictureFile = new File(picturePath);
                exif = new ExifInterface(pictureFile.getAbsolutePath());
            } catch (IOException e) {
                e.printStackTrace();
            }

            int orientation = ExifInterface.ORIENTATION_NORMAL;

            if (exif != null)
                orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    loadedBitmap = rotateBitmap(loadedBitmap, 90);
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    loadedBitmap = rotateBitmap(loadedBitmap, 180);
                    break;

                case ExifInterface.ORIENTATION_ROTATE_270:
                    loadedBitmap = rotateBitmap(loadedBitmap, 270);
                    break;
            }
        }
        return loadedBitmap;
    }


    public static Bitmap rotateBitmap(Bitmap bitmap, int degrees) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }
    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    public String getRealPathFromURI(Uri contentUri) {
        String [] proj={MediaStore.Images.Media.DATA};
        Cursor cursor = managedQuery( contentUri, proj, null, null, null); // Order-by clause (ascending by name)
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String path= cursor.getString(column_index);
        return path;

    }
    // **************** Capture Product Image method finished ***************************

    private class getNetworkName extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getnetwork.json?memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s != null) {
                JSONObject jsonObject = null;
                JSONArray jsonArray = null;
                networkId = new ArrayList<Long>();
                networkName = new ArrayList<String>();
                productNetwork = new HashMap<String, Long>();
                productNetworkMap=new HashMap<Long, String>();
                try {
                    jsonArray = new JSONArray(s);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        String networkname = jsonObject.getString("networkName");
                        Long networkid = jsonObject.getLong("networkId");
                        productNetwork.put(networkname.trim(), networkid);
                        productNetworkMap.put(networkid,networkname.trim());
                        networkName.add(networkname.trim());
                        networkId.add(networkid);

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                callAlertDialog("Check Your Internet Connection");
            }
        }
    }

//    private class getCategory extends AsyncTask<String,String,String>{
//        String productNameStrChange=productNameStr.replaceAll(" ","%20");
//        @Override
//        protected String doInBackground(String... params) {
//            HttpConfig httpConfig=new HttpConfig();
//            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"categoryrecommendation.json?catname="+productNameStrChange);
//            return result;
//        }
//
//        @Override
//        protected void onPostExecute(String s) {
//            if(s!=null){
//                JSONObject jsonObject=null;
//                JSONArray jsonArray=null;
//                categoryDto=new CategoryDto();
//                rootCategory=new ArrayList<>();
//                availableCategory=new ArrayList<>();
//                categoryIds=new ArrayList<>();
//                try {
//                    jsonObject=new JSONObject(s);
//                    jsonArray=jsonObject.getJSONArray("categoryLevel1");
//                    for(int i=0;i<jsonArray.length();i++){
//                        rootCategory.add(jsonArray.get(i).toString());
//                    }
//                    jsonArray=jsonObject.getJSONArray("categoryLevel2");
//                    for(int i=0;i<jsonArray.length();i++){
//                        availableCategory.add(jsonArray.get(i).toString());
//                    }
//                    rootCategory.add("others");
//                    availableCategory.add("others");
//                    categoryDisplay=new CategoryDisplayAdapter(ProductEditPage.this,rootCategory,availableCategory);
//                    showCategorySelectPopup(ProductEditPage.this);
//                    jsonArray=jsonObject.getJSONArray("categoryDtos");
//                    for(int i=0;i<jsonArray.length();i++){
//                        jsonObject=jsonArray.getJSONObject(i);
//                        Gson gson=new Gson();
//                        categoryDto=gson.fromJson(jsonObject.toString(),CategoryDto.class);
//                        categoryIds.add(categoryDto.getCategoryId());
//                    }
//
//
//
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//
//
//            }else{
//                final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
//                        ProductEditPage.this);
//
//                alertDialogBuilder.setTitle("Neighbourbase");
//                alertDialogBuilder.setCancelable(true);
//                alertDialogBuilder
//                        .setMessage(
//                                "Check Your Internet Connection")
//                        .setCancelable(false)
//                        .setPositiveButton("OK",
//                                new DialogInterface.OnClickListener() {
//                                    public void onClick(DialogInterface dialog,
//                                                        int id) {
//                                        dialog.cancel();
//
//                                    }
//
//                                });
//
//                AlertDialog alertDialog = alertDialogBuilder.create();
//
//                alertDialog.show();
//            }
//        }
//    }

    private class getProductDetails extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ProductEditPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getproductlistingbyproductid.json?productid="+productIdStr);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            productListingDto=new ProductListingDto();
            JSONObject jsonObject=null;
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    Gson gson=new Gson();
                    productListingDto=gson.fromJson(jsonObject.toString(),ProductListingDto.class);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                setProductDetails();
            }else{
                callAlertDialog("Server down...");
            }


        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(ProductEditPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

    private void setProductDetails() {
        userSelectNetworkId=new ArrayList<Long>();
       int transType= productListingDto.getTransTypeId();
        if(transType==1)
            selectListingType.setSelection(0);
        if(transType==2)
            selectListingType.setSelection(1);
        if(transType==3)
            selectListingType.setSelection(2);
        if(transType==4)
            selectListingType.setSelection(3);
        productName.setText(productListingDto.getProductName());
        productDescription.setText(productListingDto.getProductDescription());
        salePrice.setText(String.valueOf( productListingDto.getSalePrice()));
        rentPerDay.setText(String.valueOf( productListingDto.getPriceperday()));
        rentPerWeek.setText(String.valueOf(productListingDto.getPriceperweek()));
        rentPerMonth.setText(String.valueOf(productListingDto.getPricepermonth()));
        dayFm=productListingDto.getDayfrom();
        dayTo=productListingDto.getDayto();
        if(dayFm!=null&&dayTo!=null){

            if(dayTo.equals("0")){
                thru.setVisibility(View.GONE);
                productAvailableTo.setVisibility(View.GONE);
                availableOnlyOn.setChecked(true);
                getDays();
                productAvailableFrom.setSelection(dayFmInt);
            }else{
                thru.setVisibility(View.VISIBLE);
                productAvailableTo.setVisibility(View.VISIBLE);
                availableOnlyOn.setChecked(false);
                availableFrom.setChecked(true);
                getDays();
                productAvailableTo.setSelection(dayToInt);
                productAvailableFrom.setSelection(dayFmInt);

            }
        }

        for(Long networkId:productListingDto.getNetworkids()){
            userSelectNetworkId.add(networkId);
        }

        sb = new StringBuilder();
        for (Long aNetwork : userSelectNetworkId) {
         String network= productNetworkMap.get(aNetwork);
            sb.append(",");
            sb.append(network);
        }
        String networkNameStr= sb.toString().replaceFirst(","," ");
        listProductIn.setText(networkNameStr);
        picture=productListingDto.getPicture();
        if (picture==null||picture.equals("No Image")||picture.equals("")) {
            Glide.clear(productImage);
            productImage.setImageResource(R.drawable.no_image);
        } else {

            Glide.with(ProductEditPage.this)
                    .load(Webconfig.CONTEXT_PATH1 + "images/" + picture).thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(productImage);
        }
        String rootCat=rootCatInvertMap.get(productListingDto.getRootCategoryId());
        rootCategorySpinner.setSelection(categoryNameList.indexOf(rootCat));


    }

    private void getDays() {
        if (dayFm.equals("1")){
            dayFm = "Sunday";
            dayFmInt=1;
        }
        if (dayFm.equals("2")){
            dayFm = "Monday";
            dayFmInt=2;
        }
        if (dayFm.equals("3")){
            dayFm = "Tuesday";
            dayFmInt=3;
        }
        if (dayFm.equals("4")){
            dayFm = "Wednesday";
            dayFmInt=4;
        }
        if (dayFm.equals("5")){
            dayFm = "Thursday";
            dayFmInt=5;
        }
        if (dayFm.equals("6")){
            dayFm = "Friday";
            dayFmInt=6;
        }
        if (dayFm.equals("7")){
            dayFm = "Saturday";
            dayFmInt=7;
        }
        if (dayTo.equals("1")){
            dayTo = "Sunday";
            dayToInt=1;
        }
        if (dayTo.equals("2")){
            dayTo = "Monday";
            dayToInt=2;
        }
        if (dayTo.equals("3")){
            dayTo = "Tuesday";
            dayToInt=3;
        }
        if (dayTo.equals("4")){
            dayTo = "Wednesday";
            dayToInt=4;
        }
        if (dayTo.equals("5")){
            dayTo = "Thursday";
            dayToInt=5;
        }
        if (dayTo.equals("6")){
            dayTo = "Friday";
            dayToInt=6;
        }
        if (dayTo.equals("7")){
            dayTo = "Saturday";
            dayToInt=7;

        }
    }

    private class loadImage extends AsyncTask<String,String,Bitmap> {
        @Override
        protected Bitmap doInBackground(String... params) {
            try {
                bitmap = Glide.with(ProductEditPage.this).load(Webconfig.CONTEXT_PATH1 + "images/" + picture).asBitmap().into(100, 100).get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            productImgByteArray= stream.toByteArray();
            setProductListingDto();
        }
    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(ProductEditPage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(ProductEditPage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(ProductEditPage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(ProductEditPage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(ProductEditPage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(ProductEditPage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(ProductEditPage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(ProductEditPage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(ProductEditPage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(ProductEditPage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(ProductEditPage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(ProductEditPage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(ProductEditPage.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(ProductEditPage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(ProductEditPage.this, AddGroupActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(ProductEditPage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(ProductEditPage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(ProductEditPage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(ProductEditPage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(ProductEditPage.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(ProductEditPage.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}