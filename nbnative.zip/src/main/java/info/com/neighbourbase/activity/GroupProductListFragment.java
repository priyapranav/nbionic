package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import info.com.neighbourbase.Adapter.ProductViewAllAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

/**
 * Created by Priya on 19-07-2017.
 */

public class GroupProductListFragment extends Fragment implements AdapterView.OnItemClickListener {
    String transTypeId,groupId;
    SharedPreferences preferences;
    //    ImageView addGroupIcon,logoutIcon,profileIcon;
    ListView listView;
    //    LinearLayout feedbackIconLayout,addProductLayout,logoutLayout,profileLayout,addGroupLayout;
    String memberId, latitude, longitude, pincode,radius,productName,searchProductName;
    List<ProductListingDto> productListingDtosBorrow;
    ArrayAdapter borrow;
    Map<String,Long> productMap;
    TextView noProductText,alertMessageText;
    Button alertMsgOkBtn;
    int scrollCurrentPosition;
    boolean isScroll = true;
    Dialog customDialog;
    Long productId;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
// Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.group_product_list, null);
        getAllWidgets(rootView);
        setAdapter();
        preferences= PreferenceManager.getDefaultSharedPreferences(GroupProductListingPage.getInstance());
        transTypeId=preferences.getString("transType","");
        memberId=preferences.getString("memberId","");
        groupId=preferences.getString("groupId","");
        latitude=preferences.getString("latitude","");
        longitude=preferences.getString("longitude","");
        radius=preferences.getString("radius","");
        searchProductName=preferences.getString("SearchProductName","");
        if(!searchProductName.equals("")){
            if(searchProductName.contains(" "))
                searchProductName=searchProductName.replaceAll(" ","%20");
            new getSearchList().execute();
        }else {
            new getBorrowList().execute();
        }
       /* new getBorrowList().execute();*/
        listView.setOnItemClickListener(this);
        return rootView;
    }

    private void setAdapter() {
    }

    private void getAllWidgets(View view) {
        listView = (ListView) view.findViewById(R.id.listView);
        noProductText=(TextView)view.findViewById(R.id.no_product_text);
       /* addGroupIcon=(ImageView)view.findViewById(R.id.add_group_icon);
        logoutIcon=(ImageView)view.findViewById(R.id.logout_icon);
        profileIcon=(ImageView)view.findViewById(R.id.profile_icon);
        addProductLayout=(LinearLayout)view.findViewById(R.id.add_product_layout);
        feedbackIconLayout=(LinearLayout) view.findViewById(R.id.feedback_layout);
        logoutLayout=(LinearLayout) view.findViewById(R.id.logout_layout);
        addGroupLayout=(LinearLayout) view.findViewById(R.id.add_group_layout);
        profileLayout=(LinearLayout) view.findViewById(R.id.profile_layout);*/
        noProductText.setVisibility(View.GONE);
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == SCROLL_STATE_IDLE) {
                    if (listView.getLastVisiblePosition() >= listView.getCount() - 1) {
                        Constant.groupListCurrentPage++;

                        if (isScroll) {
                            if (Connectivity.isConnected(HomeScreen.getInstance())) {
                                new GetBorrowListScroll().execute();
                            } else {
                                Toast.makeText(HomeScreen.getInstance(),
                                        "Please check your network connection",
                                        Toast.LENGTH_SHORT).show();

                            }
                        }
                        scrollCurrentPosition = listView.getFirstVisiblePosition();

                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });


    }

    public  class getSearchList extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(GroupProductListingPage.getInstance());
            progressDialog.setMessage("Listing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = httpConfig.httpget(Webconfig.CONTEXT_PATH + "getproductbynameandtranstype.json?prodNameTransName="+searchProductName+"&networkId="+groupId+"&memberId="+memberId+"&radius="+radius+"&latitude="+latitude+"&longitude="+longitude);
            return result;
        }
        @Override
        protected void onPostExecute(String s) {
            progressDialog.dismiss();
            super.onPostExecute(s);
            ProductListingDto productDto;
            JSONArray jsonArray=null;
            JSONObject jsonObject=null;
            productListingDtosBorrow = new ArrayList<ProductListingDto>();
            productMap=new HashMap<String, Long>();
            if(s!=null){
                try {
                    listView.setVisibility(View.VISIBLE);
                    noProductText.setVisibility(View.GONE);
                    jsonObject=new JSONObject(s);
                    String status = jsonObject.getString("status");
                    Constant.messageUnreadCount = jsonObject.getLong("unreadCount");
                    Header.messageCount.setText(String.valueOf(Constant.messageUnreadCount));

                    if(status.equalsIgnoreCase("success")) {
                        jsonArray = jsonObject.getJSONArray("productListingSearchDto");
                        if(jsonArray.length()>0) {
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObj = jsonArray.getJSONObject(i);
                                Gson gson = new Gson();
                                productDto = gson.fromJson(jsonObj.toString().trim(), ProductListingDto.class);
                                productMap.put(productDto.getProductName(), productDto.getProductId());
                                productListingDtosBorrow.add(productDto);
                            }

                            borrow = new ProductViewAllAdapter(GroupProductListingPage.getInstance(), productListingDtosBorrow);
                            listView.setAdapter(borrow);
                        }
                    }else if(status.equals("fail")){
                        listView.setVisibility(View.GONE);
                        noProductText.setVisibility(View.VISIBLE);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }else {
                callAlertDialog("Check Your Internet Connection");
            }
            preferences.edit().remove("SearchProductName").commit();
        }
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if(searchProductName == null || searchProductName.isEmpty()){
            //**** changed by nila ********/
            productName = Constant.groupProductListingDtos.get(position).getProductName();
            productId = Constant.groupProductListingDtos.get(position).getProductId();
        }else {
            TextView product=(TextView)view.findViewById(R.id.productName);
            productName=product.getText().toString().trim();
            String[] productNameSplit=productName.replace("'s ",",").split(",");
            System.out.println(productNameSplit[1]);
            productId  = (Long) productMap.get(productNameSplit[1]);
        }

        updateProductId(productId);
        System.out.println(productId);
        startActivity(new Intent(GroupProductListingPage.getInstance(),ViewPage.class));

    }

    private void updateProductId(Long productId) {
        SharedPreferences.Editor e = preferences.edit();
        e.putString("productId", String.valueOf(productId));
        e.commit();
    }

//    @Override
//    public void onClick(View v) {
//        switch(v.getId()){
//            case R.id.add_group_layout:
//             getActivity().startActivity(new Intent(getActivity(),AddGroupActivity.class));
//                break;
//            case R.id.add_product_layout:
//                getActivity().startActivity(new Intent(getActivity(),AddProductPage.class));
//                break;
//            case R.id.feedback_layout:
//                getActivity().startActivity(new Intent(getActivity(),FeedbackActivity.class));
//                break;
//            case R.id.logout_layout:
//                getActivity().startActivity(new Intent(getActivity(),LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
//                getActivity().finish();
//                break;
//            case R.id.profile_layout:
//                PopupMenu popup = new PopupMenu(getActivity(), profileIcon);
//                popup.getMenuInflater().inflate(R.menu.profile_popup_menu, popup.getMenu());
//                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//                    public boolean onMenuItemClick(MenuItem item) {
//                       // Toast.makeText(getActivity(),"You Clicked : " + item.getTitle(),Toast.LENGTH_SHORT).show();
//                        switch (item.getItemId()){
//                            case R.id.profile_info:
//                                getActivity().startActivity(new Intent(getActivity(),ProfileInformationPage.class));
//                                break;
//                            case R.id.profile_change_email:
//                                getActivity().startActivity(new Intent(getActivity(),ChangeEmailPage.class));
//                                break;
//                            case R.id.profile_picture:
//                                getActivity().startActivity(new Intent(getActivity(),ProfilePicturePage.class));
//                                break;
//                            case R.id.profile_reset_password:
//                                getActivity().startActivity(new Intent(getActivity(),ResetPassword.class));
//                                break;
//                            case R.id.profile_change_location:
//                                getActivity().startActivity(new Intent(getActivity(),ChangeLocationPage.class));
//                                break;
//                            case R.id.profile_mylisting:
//                                getActivity().startActivity(new Intent(getActivity(),MyListingPage.class));
//                                break;
//                            case R.id.profile_logout:
//                                break;
//                        }
//                        return true;
//                    }
//                });
//                popup.show();//showing popup menu
//
//        break;
//
//
//        }
//    }

    public  class getBorrowList extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(GroupProductListingPage.getInstance());
            progressDialog.setMessage("Search in progress...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "getnetworkproductlisting.json?transtypeid="+transTypeId+"&categoryid="+ Constant.categoryId+"&pageNumber=0&networkid="+groupId+"&memberId="+ memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            progressDialog.dismiss();
            productListingDtosBorrow = new ArrayList<ProductListingDto>();
            productMap=new HashMap<String, Long>();
            ProductListingDto productDto;
            if(res!=null) {
                try {
                    JSONObject jsonObject=new JSONObject(res);
                    String status=jsonObject.optString("status");
                    if(status.equals("success")){
                        JSONArray jsonArray = jsonObject.getJSONArray("productListingDto");
                        if (jsonArray.length() == 0) {
                            listView.setVisibility(View.GONE);
                            noProductText.setVisibility(View.VISIBLE);

                        } else {
                            listView.setVisibility(View.VISIBLE);
                            noProductText.setVisibility(View.GONE);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObj = jsonArray.getJSONObject(i);
                                Gson gson = new Gson();
                                productDto = gson.fromJson(jsonObj.toString().trim(), ProductListingDto.class);
                                productMap.put(productDto.getProductName().trim(), productDto.getProductId());
                                productListingDtosBorrow.add(productDto);
                            }
                            if (!productListingDtosBorrow.isEmpty()) {
                                Constant.groupProductListingDtos.addAll(productListingDtosBorrow);
                            } else {
                                isScroll = false;
                            }
                            borrow = new ProductViewAllAdapter(GroupProductListingPage.getInstance(),  Constant.groupProductListingDtos);
                            listView.setAdapter(borrow);
                            int currentPosition = listView.getFirstVisiblePosition();
                            listView.setSelection(currentPosition);

                        }
                    }else if(status.equals("fail")){
                        listView.setVisibility(View.GONE);
                        noProductText.setVisibility(View.VISIBLE);
                    }
                    else{
                        noProductText.setVisibility(View.VISIBLE);
                        if (!productListingDtosBorrow.isEmpty()) {
                            Constant.productListingDtos.addAll(productListingDtosBorrow);
                        } else {
                            isScroll = false;
                        }

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else {
                callAlertDialog("Check Your Internet Connection");
            }
        }

    }
    private class GetBorrowListScroll extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "getnetworkproductlisting.json?transtypeid="+transTypeId+"&categoryid="+ Constant.categoryId+"&pageNumber="+Constant.groupListCurrentPage+"&networkid="+groupId+"&memberId="+ memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            productListingDtosBorrow = new ArrayList<>();
            ProductListingDto productDto;
            JSONObject jsonObj;
            Gson gson;
            productMap=new HashMap<>();
            if(res!=null) {
                try {
                    jsonObj = new JSONObject(res);
                    String status = jsonObj.getString("status");
                    if(status.equalsIgnoreCase("success")) {
                        gson = new Gson();
                        CommonResponseDto commonResponseDto = gson.fromJson(res, CommonResponseDto.class);
                        if(commonResponseDto.getProductListingDto()!=null && !commonResponseDto.getProductListingDto().isEmpty()) {

                            productListingDtosBorrow = commonResponseDto.getProductListingDto();
                            for (int j = 0; j < productListingDtosBorrow.size(); j++) {
                                productDto = productListingDtosBorrow.get(j);
                                productMap.put(productDto.getProductName(), productDto.getProductId());
                            }
                            if (!productListingDtosBorrow.isEmpty()) {
                                Constant.groupProductListingDtos.addAll(productListingDtosBorrow);
                            } else {
                                isScroll = false;
                            }
                            borrow = new ProductViewAllAdapter(GroupProductListingPage.getInstance(),  Constant.groupProductListingDtos);
                            listView.setAdapter(borrow);
                            listView.setSelection(scrollCurrentPosition);
                        }


                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                if (!productListingDtosBorrow.isEmpty()) {
                    Constant.groupProductListingDtos.addAll(productListingDtosBorrow);
                } else {
                    isScroll = false;
                }
            }

        }
    }

    private void callAlertDialog(String message) {

        customDialog = new Dialog(GroupProductListingPage.getInstance());
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }


}
