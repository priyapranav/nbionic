package info.com.neighbourbase.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import info.com.neighbourbase.Adapter.ExpandParentCatAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CategoryDto;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class CategoryActivity extends CommonHeader {

//    ExpandableListView subCategoryListView;
    ExpandParentCatAdapter expandParentCatAdapter;
    int rootId;
    ListView categoryList;
    CommonResponseDto commonResponseDto;
    List<String> catList;
    Map<Long, List<CategoryDto>> categoryDtoMap = new HashMap<>();
    Map<String,Long> categoryIdName=new HashMap<>();
    List<CategoryDto> categoryDtosList;
    List<Long> categoryIdsListL1;
    ArrayAdapter catAdapter;
    String groupProductListingPageStr="GroupProductListingPage";
    String groupMemberPageStr="GroupMemberPage";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_category, frameLayout);

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "CategoryActivity";
        categoryList=(ListView)findViewById(R.id.cat_list_view);
//        subCategoryListView = (ExpandableListView) findViewById(R.id.sub_category_list_view);
        String rootStr = getIntent().getStringExtra("rootId");
        rootId = Integer.parseInt(rootStr);

        if(Connectivity.isConnected(CategoryActivity.this)) {
              new GetChildCategories().execute();

        }else{
            Toast.makeText(CategoryActivity.this,"Please Check Internet Connection", Toast.LENGTH_LONG).show();
        }
        categoryList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Constant.categoryId = categoryIdName.get(catList.get(position));
                System.out.println("cat id for other:--"+Constant.categoryId);
                if(Constant.previousActivity.equalsIgnoreCase(groupProductListingPageStr)||Constant.previousActivity.equalsIgnoreCase(groupMemberPageStr)){
                    startActivity(new Intent(CategoryActivity.this, GroupProductListingPage.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    finish();
                }else{
                    startActivity(new Intent(CategoryActivity.this, HomeScreen.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    finish();
                }
            }
        });

       /* subCategoryListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {

                int index = parent.getFlatListPosition(ExpandableListView.getPackedPositionForChild(groupPosition, childPosition));
                parent.setItemChecked(index, true);
                Constant.categoryId = categoryDtoMap.get(categoryIdsListL1.get(groupPosition)).get(childPosition).getCategoryId();
                System.out.println("cat id for other:--"+Constant.categoryId);
                if(Constant.previousActivity.equalsIgnoreCase(groupProductListingPageStr)||Constant.previousActivity.equalsIgnoreCase(groupMemberPageStr)){
                    startActivity(new Intent(CategoryActivity.this, GroupProductListingPage.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    finish();
                }else{
                    startActivity(new Intent(CategoryActivity.this, HomeScreen.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    finish();
                }

                return false;
            }
        });

        // Listview Group click listener
        subCategoryListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

            @Override
            public boolean onGroupClick(ExpandableListView parent, View v,
                                        int groupPosition, long id) {
                 long catId = categoryIdsListL1.get(groupPosition);
                 List<CategoryDto> catIdValueList = categoryDtoMap.get(catId);
                if(catIdValueList.isEmpty()){
                    Constant.categoryId = catId;
                    System.out.println("cat id for other:--"+catId);

                    if(Constant.previousActivity.equalsIgnoreCase(groupProductListingPageStr)||Constant.previousActivity.equalsIgnoreCase(groupMemberPageStr)){
                        startActivity(new Intent(CategoryActivity.this, GroupProductListingPage.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        finish();
                    }else{
                        startActivity(new Intent(CategoryActivity.this, HomeScreen.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        finish();
                    }
                }
                return false;
            }
        });*/
    }

    private class GetAvailableCategory extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result;
            result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getavailablecategories.json?parentid="+rootId);
            return result;
        }
        @Override
        protected void onPostExecute(String res) {
            commonResponseDto = new CommonResponseDto();
            JSONObject jsonObject= null;
            JSONObject obj1;
            Gson g;

            if(res!=null && res.length()>3) {
                g = new Gson();
                try {
                    jsonObject = new JSONObject(res);
                    String status = jsonObject.getString("status");
                    if(status.equalsIgnoreCase("success")) {
                        categoryIdsListL1 = new ArrayList<>();
                        obj1 = new JSONObject(jsonObject.getString("categoryDtoMap"));
                         Iterator<String> itr = obj1.keys();

                        while (itr.hasNext()) {
                            String key = itr.next();
                            String value = obj1.getString(key);
                            JSONArray jsonArray = new JSONArray(value);
                            categoryIdsListL1.add(Long.parseLong(key));
                            categoryDtosList = new ArrayList<>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject j = jsonArray.getJSONObject(i);
                                CategoryDto categoryDto2 = g.fromJson(j.toString().trim(), CategoryDto.class);
                                categoryDtosList.add(categoryDto2);
                            }
                            categoryDtoMap.put(Long.parseLong(key),categoryDtosList);
                        }

                        expandParentCatAdapter = new ExpandParentCatAdapter(CategoryActivity.this, categoryIdsListL1, categoryDtoMap);
//                        subCategoryListView.setAdapter(expandParentCatAdapter);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        }
    }

    private class GetChildCategories extends AsyncTask<String,String,String> {

        ProgressDialog progressDialog;
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(CategoryActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result;
            result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getchildcategories.json?parentid="+rootId);
            return result;
        }
        @Override
        protected void onPostExecute(String res) {
            CategoryDto categoryDto;
            catList=new ArrayList<>();
            progressDialog.dismiss();
            if(res!=null && res.length()>3) {
                try {
                    JSONArray jsonArray = new JSONArray(res.trim());
                    /*if(Connectivity.isConnected(CategoryActivity.this)) {
                        new GetAvailableCategory().execute();
                    }else{
                        Toast.makeText(CategoryActivity.this,"Please Check Internet Connection", Toast.LENGTH_LONG).show();
                    }*/
                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject category = jsonArray.getJSONObject(i);
                        Gson gson = new Gson();
                        categoryDto = gson.fromJson(category.toString().trim(), CategoryDto.class);
                        catList.add(categoryDto.getCategoryName());
                        Constant.categoryDtoListLevel1.add(categoryDto);
                        categoryIdName.put(categoryDto.getCategoryName().trim(), categoryDto.getCategoryId());
                        Constant.categoryIdNameMap.put(categoryDto.getCategoryId(), categoryDto.getCategoryName().trim());
                    }
                    catAdapter=new ArrayAdapter(CategoryActivity.this,android.R.layout.simple_list_item_1,catList);
                    categoryList.setAdapter(catAdapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else {
                Constant.categoryId = rootId;
                System.out.println("cat id for other:--"+  Constant.categoryId);
                if(Constant.previousActivity.equalsIgnoreCase(groupProductListingPageStr)||Constant.previousActivity.equalsIgnoreCase(groupMemberPageStr)){
                    startActivity(new Intent(CategoryActivity.this, GroupProductListingPage.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    finish();
                }else{
                    startActivity(new Intent(CategoryActivity.this, HomeScreen.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    finish();
                }
            }
        }
    }

    private static Object fromJson(Object json) throws JSONException {
        if (json == JSONObject.NULL) {
            return null;
        } else if (json instanceof JSONObject) {
            return toMap((JSONObject) json);
        } else {
            return json;
        }
    }

    public static Map<String, Object> toMap(JSONObject object) throws JSONException {
        Map<String, Object> map = new HashMap<>();
        Iterator keys = object.keys();
        while (keys.hasNext()) {
            String key = (String) keys.next();
            map.put(key, fromJson(object.get(key)));
        }
        return map;
    }

}
