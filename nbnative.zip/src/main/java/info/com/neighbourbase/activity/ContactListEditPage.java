package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.NetworkContactListCategoryDto;
import info.com.neighbourbase.model.NetworkContactListDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class ContactListEditPage extends AppCompatActivity implements View.OnClickListener {
    CommonResponseDto commonResponseDto=new CommonResponseDto();
    String contactListId;
    Spinner categorySpinner;
    ImageView backIcon;
    Button changeListBtn,cancelChangeListBtn;
    EditText name,contactMobile,landLine,city,addressLine1,addressLine2,emailId,addListPincode;
    TextInputLayout nameLayout,contactMobileLayout,landLineLayout,cityLayout,addressLine1Layout,addressLine2Layout,emailIdLayout,addListPincodeLayout;
    ArrayAdapter<String> categoryAdapter;
    NetworkContactListCategoryDto networkContactListCategoryDto;
    ArrayList<String> categoryNameList=new ArrayList<>();
    HashMap<String,Long> categoryMap=new HashMap<>();
    String groupId;
    TextView alertMessageText;
    Button alertMsgOkBtn;
    SharedPreferences sharedPreferences;
    Dialog customDialog;
    String reqData,memberId;
    NetworkContactListDto networkContactListDto=new NetworkContactListDto();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list_edit_page); Bundle intent=getIntent().getExtras();
        contactListId=intent.getString("contactListId");
        sharedPreferences= PreferenceManager.getDefaultSharedPreferences(this);
        groupId=sharedPreferences.getString("groupId","");
        memberId=sharedPreferences.getString("memberId","");
        mInit();
        if(Connectivity.isConnected(ContactListEditPage.this)) {
            new getCategoryList().execute();
            new getContactPersonDetails().execute();
        }else{
            callAlertDialog("Please Check Internet Connection");
        }


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.change_list_cancel_btn:
                finish();
                break;
            case R.id.change_list_button:
                if(checkValitation()){
                    fillEditDetails();
                }
                break;
            case R.id.back_icon:
                finish();
                break;
        }

    }

    private void fillEditDetails() {
        networkContactListDto.setName(name.getText().toString());
        networkContactListDto.setMobile(Long.parseLong(contactMobile.getText().toString()));
        if(landLine.getText().toString().length()>0)
            networkContactListDto.setLandline(landLine.getText().toString());
        if(addressLine1.getText().toString().length()>0)
            networkContactListDto.setAddress1(addressLine1.getText().toString());
        if(addressLine2.getText().toString().length()>0)
            networkContactListDto.setAddress2(addressLine2.getText().toString());
        if(city.getText().toString().length()>0)
            networkContactListDto.setCity(city.getText().toString());
        if(addListPincode.getText().toString().length()>0)
            networkContactListDto.setPincode(Integer.parseInt(addListPincode.getText().toString()));
        if(emailId.getText().toString().length()>0)
            networkContactListDto.setEmail(emailId.getText().toString());
        String spinnerSelection=categorySpinner.getSelectedItem().toString();
        Long spinnerSelectCatId=categoryMap.get(spinnerSelection);
        networkContactListDto.setCategoryId(spinnerSelectCatId);
        networkContactListDto.setListId(Long.parseLong(contactListId));
        networkContactListDto.setNetworkId(Long.parseLong(groupId));
        networkContactListDto.setUpdatedMemberId(Long.parseLong(memberId));
        reqData=new Gson().toJson(networkContactListDto);

        new updateListResponse().execute();

    }

    private boolean checkValitation() {
        boolean valueReturn=true;
        if(!Validation.hasText(name))
            valueReturn=false;
        if(!Validation.hasValidPhoneNumber(contactMobile,contactMobileLayout))
            valueReturn=false;
        String catSpinnerSelection=categorySpinner.getSelectedItem().toString();
        if (catSpinnerSelection.equals("Select")){
            callAlertDialog("select any one category");
            valueReturn=false;
        }
        if(addListPincode.getText().toString().length()>0&&!addListPincode.getText().toString().equals("0")){
            if (!Validation.isPin(addListPincode))
                valueReturn=false;
        }

        if(emailId.getText().toString().length()>0){
            if (!Validation.isEmailAddress(emailId,emailIdLayout,true))
                valueReturn=false;
        }


        return valueReturn;
    }


    private class getContactPersonDetails extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ContactListEditPage.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
        }
        @Override
        protected String doInBackground(String... strings) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getdetailsaboutcontactbylistid.json?listid="+contactListId+"&memberId="+memberId);
            return result;
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            if(s!=null){
                try {
                    JSONObject detailJsonObj=new JSONObject(s);
                    commonResponseDto=new Gson().fromJson(detailJsonObj.toString(),CommonResponseDto.class);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                fillDetails();

            }else{
                callAlertDialog("server down");

            }
        }
    }

    private void fillDetails() {
        String catName=commonResponseDto.getNetworkContactListDto().getCategoryName();
        int catPos=categoryNameList.indexOf(catName.trim());
        categorySpinner.setSelection(catPos);
        name.setText(commonResponseDto.getNetworkContactListDto().getName());
        contactMobile.setText(String.valueOf(commonResponseDto.getNetworkContactListDto().getMobile()));
        if(commonResponseDto.getNetworkContactListDto().getLandline()!=null){
            if(commonResponseDto.getNetworkContactListDto().getLandline().length()>0)
                landLine.setText(commonResponseDto.getNetworkContactListDto().getLandline());
        }
        if(commonResponseDto.getNetworkContactListDto().getAddress1()!=null){
            if(commonResponseDto.getNetworkContactListDto().getAddress1().length()>0)
                addressLine1.setText(commonResponseDto.getNetworkContactListDto().getAddress1());
        }
        if(commonResponseDto.getNetworkContactListDto().getAddress2()!=null){
            if(commonResponseDto.getNetworkContactListDto().getAddress2().length()>0)
                addressLine2.setText(commonResponseDto.getNetworkContactListDto().getAddress2());
        }
        if(commonResponseDto.getNetworkContactListDto().getCity()!=null){
            if(commonResponseDto.getNetworkContactListDto().getCity().length()>0)
                city.setText(commonResponseDto.getNetworkContactListDto().getCity());
        }
        if(String.valueOf(commonResponseDto.getNetworkContactListDto().getPincode())!=null){
            if(String.valueOf(commonResponseDto.getNetworkContactListDto().getPincode()).length()>0)
                addListPincode.setText(String.valueOf(commonResponseDto.getNetworkContactListDto().getPincode()));
        }

        if(commonResponseDto.getNetworkContactListDto().getEmail()!=null){
            if(commonResponseDto.getNetworkContactListDto().getEmail().length()>0)
                emailId.setText(commonResponseDto.getNetworkContactListDto().getEmail());
        }





    }
    private void mInit() {
        categorySpinner=(Spinner)findViewById(R.id.category_spinner);
        backIcon=(ImageView)findViewById(R.id.back_icon);
        name=(EditText)findViewById(R.id.name);
        contactMobile=(EditText)findViewById(R.id.contact_mobile);
        landLine=(EditText) findViewById(R.id.land_line);
        city=(EditText)findViewById(R.id.city);
        addressLine1=(EditText)findViewById(R.id.address_line_one);
        addressLine2=(EditText)findViewById(R.id.address_line_two);
        emailId=(EditText)findViewById(R.id.email_id);
        addListPincode=(EditText)findViewById(R.id.pincode);
        nameLayout=(TextInputLayout)findViewById(R.id.name_input_layout);
        contactMobileLayout=(TextInputLayout)findViewById(R.id.input_layout_contact_mobile);
        landLineLayout=(TextInputLayout)findViewById(R.id.input_layout_land_line);
        cityLayout=(TextInputLayout)findViewById(R.id.input_layout_city);
        addressLine1Layout=(TextInputLayout)findViewById(R.id.input_layout_address_line_one);
        addressLine2Layout=(TextInputLayout)findViewById(R.id.input_layout_address_line_two);
        emailIdLayout=(TextInputLayout)findViewById(R.id.input_layout_email_id);
        addListPincodeLayout=(TextInputLayout)findViewById(R.id.input_layout_pincode);
        changeListBtn=(Button)findViewById(R.id.change_list_button);
        cancelChangeListBtn=(Button)findViewById(R.id.change_list_cancel_btn);
        cancelChangeListBtn.setOnClickListener(this);
        changeListBtn.setOnClickListener(this);
        backIcon.setOnClickListener(this);

    }
    private class getCategoryList extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... strings) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httpget(Webconfig.CONTEXT_PATH+"getallnetworkcategorylist.json?networkid="+groupId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            networkContactListCategoryDto=new NetworkContactListCategoryDto();
            super.onPostExecute(s);
            if(s!=null){
                categoryNameList.add("Select");

                try {

                    JSONArray jsonArray=new JSONArray(s);
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject categoryListArray=jsonArray.getJSONObject(i);
                        networkContactListCategoryDto=new Gson().fromJson(categoryListArray.toString().trim(),NetworkContactListCategoryDto.class);
                        categoryNameList.add(networkContactListCategoryDto.getCategoryName().trim());
                        categoryMap.put(networkContactListCategoryDto.getCategoryName().trim(),networkContactListCategoryDto.getContactsCategoryId());

                    }
                    categoryAdapter=new ArrayAdapter<String>(ContactListEditPage.this, android.R.layout.simple_spinner_dropdown_item, categoryNameList);
                    categorySpinner.setAdapter(categoryAdapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(ContactListEditPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

    private class updateListResponse extends AsyncTask<String,String,String>{
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(ContactListEditPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData,Webconfig.CONTEXT_PATH+"updatenetworkcontactlist.json");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            if(s!=null){
                if(s.trim().equalsIgnoreCase("success")){
                    customDialog = new Dialog(ContactListEditPage.this);
                    customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    customDialog.setContentView(R.layout.custom_messbox);
                    alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                    alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                    alertMsgOkBtn.setVisibility(View.GONE);
                    alertMessageText.setText(getResources().getString(R.string.contact_update_msg));
                    customDialog.setCancelable(true);
                    customDialog.setCanceledOnTouchOutside(true);
                    customDialog.setOnCancelListener(
                            new DialogInterface.OnCancelListener() {
                                @Override
                                public void onCancel(DialogInterface dialog) {
                                    customDialog.dismiss();
                                    startActivity(new Intent(ContactListEditPage.this,UsefulContactsPage.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                                    finish();

                                }
                            }

                    );
                    customDialog.show();
                    customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                }else if(s.trim().equalsIgnoreCase("fail")){
                    callAlertDialog("contact list deleted failed try again..");

                }

            }else {
                callAlertDialog("server down");
            }
        }
    }
}
