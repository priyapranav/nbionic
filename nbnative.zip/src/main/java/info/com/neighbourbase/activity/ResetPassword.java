package info.com.neighbourbase.activity;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.MemberDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class ResetPassword extends CommonHeader implements View.OnClickListener {

    EditText oldPassword,newPassword,conformPassword;
    Button resetBtn;
    SharedPreferences preferences;
    String password,memberId,reqData;
    MemberDto memberDto=new MemberDto();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_reset_password);

        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_reset_password, FrameLayout);

        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        password=preferences.getString("password","");
        memberId=preferences.getString("memberId","");
        mInit();

    }

    private void mInit() {
        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "ResetPassword";
        oldPassword=(EditText)findViewById(R.id.old_password);
        newPassword=(EditText)findViewById(R.id.new_password);
        conformPassword=(EditText)findViewById(R.id.conform_password);
        resetBtn=(Button)findViewById(R.id.password_reset);

        resetBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.password_reset:
                if(checkValidation()) {
                    memberDto.setMemberId(Long.parseLong(memberId));
                    memberDto.setPassword(newPassword.getText().toString());
                    reqData=new Gson().toJson(memberDto);
                    new getResetPasswordResponse().execute();

                }
                break;

        }
    }

    private boolean checkValidation() {

        boolean valueReturn = true;
        if (!Validation.hasText(oldPassword))
            valueReturn = false;
        if (!Validation.hasText(newPassword))
            valueReturn = false;
        if (!Validation.hasText(conformPassword))
            valueReturn = false;
        if(!newPassword.getText().toString().equals(conformPassword.getText().toString()))
        {
            newPassword.setError("New Password and Conform Password should be same");
            valueReturn = false;
        }
        if(!oldPassword.getText().toString().equals(password)){
            oldPassword.setError("Give Correct Old Password");
            valueReturn = false;
        }
        if(oldPassword.getText().toString().equals(newPassword.getText().toString())){
            newPassword.setError("Old Password and New Password should be different");
            valueReturn = false;
        }
        return valueReturn;
    }

    private class getResetPasswordResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ResetPassword.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData, Webconfig.CONTEXT_PATH+"updatemember.json");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            JSONObject jsonObject=null;
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status");
                    if(status.equals("success")){
                        customDialog = new Dialog(ResetPassword.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setVisibility(View.GONE);
                        alertMessageText.setText(getResources().getString(R.string.change_password_success_msg));
                        customDialog.setCancelable(true);
                        customDialog.setCanceledOnTouchOutside(true);
                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        customDialog.dismiss();
                                        logout();
                                        HttpConfig.username = null;
                                        HttpConfig.password = null;
                                        startActivity(new Intent(ResetPassword.this, LoginActivity.class));
                                    }
                                }
                        );
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                    }else if(status.equals("fail")){
                        callAlertDialog("Password update failed. please try again");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }else {
               callAlertDialog("Server Down... Please try again");
            }
        }
    }

    private void logout() {
        SharedPreferences.Editor e = preferences.edit();

        e.putString("memberId","");
        e.putString("latitude", "");
        e.putString("longitude", "");
        e.putString("pincode", "");
        e.putString("address","");
        e.putString("radius", "");
        e.commit();
    }

    private void callAlertDialog(String message) {

        customDialog = new Dialog(ResetPassword.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(ResetPassword.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(ResetPassword.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(ResetPassword.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(ResetPassword.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(ResetPassword.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(ResetPassword.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(ResetPassword.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(ResetPassword.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(ResetPassword.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(ResetPassword.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(ResetPassword.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(ResetPassword.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(ResetPassword.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(ResetPassword.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(ResetPassword.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(ResetPassword.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(ResetPassword.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(ResetPassword.this, AddGroupActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(ResetPassword.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(ResetPassword.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(ResetPassword.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
