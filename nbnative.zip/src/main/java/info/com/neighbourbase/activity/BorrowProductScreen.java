package info.com.neighbourbase.activity;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.Adapter.ProductViewAllAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class BorrowProductScreen extends Header {
   ListView listView;
    SharedPreferences preferences;
    String memberId, latitude, longitude, pincode;
    List<ProductListingDto> productListingDtosBorrow;
    ArrayAdapter borrow;
    TextView listings, transType;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.product_list, FrameLayout);
        mInit();

        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        memberId = preferences.getString("memberId", "");
        latitude = preferences.getString("latitude", "");
        longitude = preferences.getString("longitude", "");
        pincode = preferences.getString("pincode", "");
        new getBorrowList().execute();


        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    private void mInit() {
        listView = (ListView) findViewById(R.id.listView);
     //   listings = (TextView) findViewById(R.id.listing);



     //   listings.setBackgroundColor(0xFF47866F);

    }

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public Action getIndexApiAction() {
        Thing object = new Thing.Builder()
                .setName("BorrowProductScreen Page") // TODO: Define a title for the content shown.
                // TODO: Make sure this auto-generated URL is correct.
                .setUrl(Uri.parse("http://[ENTER-YOUR-URL-HERE]"))
                .build();
        return new Action.Builder(Action.TYPE_VIEW)
                .setObject(object)
                .setActionStatus(Action.STATUS_TYPE_COMPLETED)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        AppIndex.AppIndexApi.start(client, getIndexApiAction());
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        AppIndex.AppIndexApi.end(client, getIndexApiAction());
        client.disconnect();
    }

    private class getBorrowList extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "getallproductlistng.json?transtypeid=1&categoryid=0&pageNumber=0&radius=1500&pincode=" + pincode + "&lat=" + latitude + "&lng=" + longitude + "&memberId=" + memberId);
            System.out.println(result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            productListingDtosBorrow = new ArrayList<ProductListingDto>();
            ProductListingDto productDto;
            try {
                JSONArray jsonArray = new JSONArray(res);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i);
                    Gson gson = new Gson();
                    productDto = gson.fromJson(jsonObj.toString().trim(), ProductListingDto.class);

                    productListingDtosBorrow.add(productDto);
                }

                borrow = new ProductViewAllAdapter(BorrowProductScreen.this, productListingDtosBorrow);
                listView.setAdapter(borrow);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}
