package info.com.neighbourbase.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RatingBar;
import android.widget.Switch;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.BlockListDto;
import info.com.neighbourbase.model.NotificationThreadDto;
import info.com.neighbourbase.model.OwnerRatingDto;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.model.ProductRatingDto;
import info.com.neighbourbase.model.ReportAbuseDto;
import info.com.neighbourbase.model.RequestDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Validation;
import info.com.neighbourbase.utility.Webconfig;

public class  ViewPage extends CommonHeader implements View.OnClickListener {
    ImageView productImage, reportAbuseImg;
    TextView ownerRatingTxt,productRatingTxt,transTypeTxt,productName,productDescription,productAvailable,reqText,productAvailableTxt,salePrice,rentPerDay,rentPerWeek,rentPerMonth,rentPriceTxt;
    EditText reqEditText, enterDetailsTxt;
    TextInputLayout enterDetailsLayout;
    RequestDto requestDto;
    LinearLayout salePriceLayout,rentPriceLayout;
    SharedPreferences preferences;
    String productId,dayFrom,dayTo,reqData,memberId, reqDataForReportAbuse;
    ProductListingDto productDto;
    ProductRatingDto productRatingDto;
    NotificationThreadDto  notificationThreadDto;
    OwnerRatingDto ownerRatingDto;
    RatingBar owner_rating,product_rating;
    Button reqSendBtn, reportAbuseReportBtn;
    PopupWindow reportAbusePopup;
    Long networkId;
    ReportAbuseDto reportAbuseDto=new ReportAbuseDto();
    Dialog reportAbuseDialog;
    BlockListDto blockListDto=new BlockListDto();
    List<BlockListDto> blockListDtoList=new ArrayList<>();
    public static ViewPage instance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_view_page);

        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_view_page, FrameLayout);

        /*ViewGroup vg = (ViewGroup) findViewById(R.id.view_content);
        View.inflate(getApplicationContext(), R.layout.activity_view_page, vg);*/

        preferences= PreferenceManager.getDefaultSharedPreferences(ViewPage.this);
        productId=preferences.getString("productId","");
        memberId=preferences.getString("memberId","");
        mInit();
        new getViewList().execute();
        reqSendBtn.setOnClickListener(ViewPage.this);

    }

    private void getProductAvailable() {
        if((productDto.getTransTypeId())==1) {
            dayFrom = productDto.getDayfrom();
            dayTo = productDto.getDayto();
            if (dayFrom != null && dayTo != null) {

                if (dayFrom.equals("1"))
                    dayFrom = "Sunday";
                if (dayFrom.equals("2"))
                    dayFrom = "Monday";
                if (dayFrom.equals("3"))
                    dayFrom = "Tuesday";
                if (dayFrom.equals("4"))
                    dayFrom = "Wednesday";
                if (dayFrom.equals("5"))
                    dayFrom = "Thursday";
                if (dayFrom.equals("6"))
                    dayFrom = "Friday";
                if (dayFrom.equals("7"))
                    dayFrom = "Saturday";
                if (dayTo.equals("1"))
                    dayTo = "Sunday";
                if (dayTo.equals("2"))
                    dayTo = "Monday";
                if (dayTo.equals("3"))
                    dayTo = "Tuesday";
                if (dayTo.equals("4"))
                    dayTo = "Wednesday";
                if (dayTo.equals("5"))
                    dayTo = "Thursday";
                if (dayTo.equals("6"))
                    dayTo = "Friday";
                if (dayTo.equals("7"))
                    dayTo = "Saturday";
                if (dayTo.equals("0")) {
                    productAvailable.setText(dayFrom);
                } else {
                    productAvailable.setText(dayFrom + " " + (getResources().getString(R.string.through)) + " " + dayTo);
                }
            }else if(dayFrom==null&&dayTo==null){
                productAvailableTxt.setVisibility(View.GONE);
                productAvailable.setVisibility(View.GONE);
            }
        } else if((productDto.getTransTypeId())==3||(productDto.getTransTypeId())==4||(productDto.getTransTypeId()==2)){
            productAvailableTxt.setVisibility(View.GONE);
            productAvailable.setVisibility(View.GONE);
        }
    }


    private void mInit() {

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "ViewPage";

        backIcon=(ImageView)findViewById(R.id.back_icon);
        productImage=(ImageView)findViewById(R.id.productImage);
        productName=(TextView)findViewById(R.id.productName);
        reqText=(TextView)findViewById(R.id.reqText);
        productDescription=(TextView)findViewById(R.id.productDescription);
        productAvailable=(TextView)findViewById(R.id.productAvailable);
        owner_rating=(RatingBar)findViewById(R.id.rating_owner);
        product_rating=(RatingBar)findViewById(R.id.rating_product);
        productAvailableTxt=(TextView)findViewById(R.id.productAvailableTxt);
        reqEditText=(EditText)findViewById(R.id.reqEditText);
        reqSendBtn=(Button)findViewById(R.id.req_send_btn);
        salePriceLayout=(LinearLayout)findViewById(R.id.salePriceLayout);
        rentPriceLayout=(LinearLayout)findViewById(R.id.rentPriceLayout);
        salePrice=(TextView)findViewById(R.id.salePrice);
        rentPerDay=(TextView)findViewById(R.id.rentPerDay);
        rentPerWeek=(TextView)findViewById(R.id.rentPerWeek);
        rentPerMonth=(TextView)findViewById(R.id.rentPerMonth);
        rentPriceTxt=(TextView)findViewById(R.id.rent_price_txt);
        transTypeTxt=(TextView)findViewById(R.id.transTypeTxt);
        productRatingTxt=(TextView)findViewById(R.id.product_rating_txt);
        ownerRatingTxt=(TextView)findViewById(R.id.owner_rating_txt);
        reportAbuseImg=(ImageView)findViewById(R.id.report_abuse_img);
        reportAbuseImg.setOnClickListener(this);

    }

    public static ViewPage getInstance() {
        return instance;
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.req_send_btn:
                sendRequestToOwner();
                break;
            case R.id.report_abuse_img:
                networkId= productDto.getNetworkId();
                showReportAbusePopup();
                break;


        }
    }

    private void showReportAbusePopup(final Activity context) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.report_abuse_page,
                (ViewGroup)context. findViewById(R.id.popup));
        reportAbusePopup = new PopupWindow(layout, 950, 1000, true);
        reportAbusePopup.showAtLocation(layout, Gravity.CENTER, 0, 0);
        reportAbuseReportBtn=(Button)layout.findViewById(R.id.report_btn);
        enterDetailsLayout=(TextInputLayout)layout.findViewById(R.id.input_enter_details);
        enterDetailsTxt=(EditText)layout.findViewById(R.id.enter_details);

        reportAbuseReportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(checkEnterDetail()){
                    reportAbusePopup.dismiss();
                    reportAbuseDto.setReportingMemberId(Long.parseLong(memberId));
                    reportAbuseDto.setNetworkId(networkId);
                    reportAbuseDto.setProductId(Long.parseLong(productId));
                    reportAbuseDto.setRemarks(enterDetailsTxt.getText().toString());
                    reqDataForReportAbuse=new Gson().toJson(reportAbuseDto);
                    new getReportAbuseResponse().execute();

                }

            }
        });

    }

    private void showReportAbusePopup() {

        reportAbuseDialog = new Dialog(ViewPage.this);
        reportAbuseDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        reportAbuseDialog.setContentView(R.layout.report_abuse_page);
        reportAbuseDialog.setCancelable(true);

        reportAbuseReportBtn=(Button)reportAbuseDialog.findViewById(R.id.report_btn);
        enterDetailsLayout=(TextInputLayout)reportAbuseDialog.findViewById(R.id.input_enter_details);
        enterDetailsTxt=(EditText)reportAbuseDialog.findViewById(R.id.enter_details);

        reportAbuseReportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(checkEnterDetail()){
                    reportAbuseDialog.dismiss();
                    reportAbuseDto.setReportingMemberId(Long.parseLong(memberId));
                    reportAbuseDto.setNetworkId(networkId);
                    reportAbuseDto.setProductId(Long.parseLong(productId));
                    reportAbuseDto.setRemarks(enterDetailsTxt.getText().toString());
                    reqDataForReportAbuse=new Gson().toJson(reportAbuseDto);
                    new getReportAbuseResponse().execute();

                }

            }
        });
        reportAbuseDialog.show();
    }

    private void sendRequestToOwner() {

        requestDto=new RequestDto();
        requestDto.setProductId(productDto.getProductId());
        requestDto.setNetworkId(productDto.getNetworkId());
        requestDto.setRequestStatusId(2);
        requestDto.setFirstReqstMsg(reqEditText.getText().toString().trim());
        reqData=new Gson().toJson(requestDto);
        new getCheckRequestSendOrNot().execute();
//        new sendRequestResponse().execute();


    }

    private class getReportAbuseResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog( ViewPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqDataForReportAbuse,Webconfig.CONTEXT_PATH+"createreportabuse.json");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            if(s!=null){
                if(s.trim().equals("SUCCESS")){
                   callAlertDialog("Thank You for reporting this listing, neighbourbase admin will review your report and take appropriate action");
                }else if(s.trim().equals("FAIL")){
                    callAlertDialog("Abuse can't be reported.. please try again");
                }

            }else {
                callAlertDialog("Server Down... please try again");
            }
        }
    }


    private class getViewList extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ViewPage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getproductlistingbyproductid.json?productid="+productId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            progressDialog.dismiss();
            super.onPostExecute(s);
            if(s!=null) {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    Gson gson = new Gson();
                    productDto = gson.fromJson(jsonObject.toString().trim(), ProductListingDto.class);
                    productName.setText(productDto.getOwnerName()+" 's "+productDto.getProductName().trim());
                    productDescription.setText(productDto.getProductDescription().trim());
                    productAvailableTxt.setText(productDto.getProductName().trim()+" "+getResources().getString(R.string.will_available));
                    reqText.setText(Html.fromHtml((getResources().getString(R.string.sent_req_to)) + " " +"<font color=\"#15B37A\">"+ productDto.getOwnerName()+ "</font>" + " " + (getResources().getString(R.string.For)) + " " + "<font color=\"#15B37A\">"+productDto.getProductName()+"</font><br><br>"));

                    getProductAvailable();
                    sendRequest();
                    if (productDto.getPicture()==null||productDto.getPicture().equals("No Image")||productDto.getPicture().equals("")) {
                        Glide.clear(productImage);
                        productImage.setImageResource(R.drawable.no_image);
                    } else {
                        Glide.with(ViewPage.this)
                                .load(Webconfig.CONTEXT_PATH1 + "images/" + productDto.getPicture()) .thumbnail(0.5f)
                                .crossFade()
                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                .into(productImage);
                    }
                    setSaleRentPrice();
                    new getProductRating().execute();
                    new getOwnerRating().execute();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else {
                callAlertDialog("Check Your Internet Connection");
            }
        }
    }

    private void setSaleRentPrice() {
        if(productDto.getTransTypeId()==1||productDto.getTransTypeId()==4){
            salePriceLayout.setVisibility(View.GONE);
            rentPriceLayout.setVisibility(View.GONE);
        }else if(productDto.getTransTypeId()==2){
            salePriceLayout.setVisibility(View.GONE);
            rentPriceLayout.setVisibility(View.VISIBLE);
            if(productDto.getPriceperday()==0&&productDto.getPriceperweek()==0&&productDto.getPricepermonth()==0){
                rentPriceTxt.setText("");
            }else  if(productDto.getPriceperday()!=0||productDto.getPriceperweek()!=0||productDto.getPricepermonth()!=0){
                rentPriceTxt.setText(Html.fromHtml("<b>"+getResources().getString(R.string.rent_Rs)+"</b>"+" "+getResources().getString(R.string.rupees)));
            }
            if(productDto.getPriceperday()==0){
                rentPerDay.setVisibility(View.GONE);
            }else{
                rentPerDay.setText("  "+String.valueOf(productDto.getPriceperday())+getResources().getString(R.string.per_day));

            }
            if(productDto.getPriceperweek()==0){

                rentPerWeek.setVisibility(View.GONE);
            }else{

                rentPerWeek.setText("  "+String.valueOf(productDto.getPriceperweek())+getResources().getString(R.string.per_week));

            }
            if(productDto.getPricepermonth()==0){

                rentPerMonth.setVisibility(View.GONE);
            }else{

                rentPerMonth.setText("  "+String.valueOf(productDto.getPricepermonth())+getResources().getString(R.string.per_month));
            }

        }else if(productDto.getTransTypeId()==3){
            rentPriceLayout.setVisibility(View.GONE);
            salePriceLayout.setVisibility(View.VISIBLE);
            if(productDto.getSalePrice()==0.0){
                salePriceLayout.setVisibility(View.GONE);
            }else{
                salePrice.setText(" "+getResources().getString(R.string.rupees)+" "+String.valueOf(productDto.getSalePrice()));
            }
        }
    }

    private void sendRequest() {
        if(productDto.getTransTypeId()==1){
            transTypeTxt.setText(getResources().getString(R.string.borrow));
            reqEditText.setText((getResources().getString(R.string.I_would_like_to_borrow))+" "+productDto.getProductName());}
        if(productDto.getTransTypeId()==2){
            transTypeTxt.setText(getResources().getString(R.string.rent));
            reqEditText.setText((getResources().getString(R.string.I_would_like_to_rent))+" "+productDto.getProductName());
        }
        if(productDto.getTransTypeId()==3){
            transTypeTxt.setText(getResources().getString(R.string.buy));
            reqEditText.setText((getResources().getString(R.string.I_would_like_to_buy))+" "+productDto.getProductName());
        }
        if(productDto.getTransTypeId()==4){
            transTypeTxt.setText(getResources().getString(R.string.gift));
            reqEditText.setText((getResources().getString(R.string.I_would_like_to_gift))+" "+productDto.getProductName());
        }


    }

    private class getProductRating extends AsyncTask<String,String,String> {

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getproductreviews.json?productId="+productDto.getProductId());
            System.out.println(result);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {

            super.onPostExecute(s);
            if(s!=null) {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    Gson gson = new Gson();
                    productRatingDto = gson.fromJson(jsonObject.toString().trim(), ProductRatingDto.class);
                    product_rating.setRating(productRatingDto.getAvgRating());
                    if(productRatingDto.getAvgRating()==0.0F){
                        productRatingTxt.setVisibility(View.GONE);
                    }else{
                        productRatingTxt.setVisibility(View.VISIBLE);
                        BigDecimal result=round(productRatingDto.getAvgRating(),2);
                        productRatingTxt.setText(String.valueOf(result)+""+getResources().getString(R.string.per_five));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else {
                callAlertDialog("Check Your Internet Connection");
            }
        }
    }
    public static BigDecimal round(float d, int decimalPlace) {
        BigDecimal bd = new BigDecimal(Float.toString(d));
        bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
        return bd;
    }

    private class getOwnerRating extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"productownerreviews.json?memberId="+memberId);
            System.out.println(result);
            return result;
        }
        protected void onPostExecute(String s) {

            super.onPostExecute(s);
            if(s!=null) {
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    Gson gson = new Gson();
                    ownerRatingDto = gson.fromJson(jsonObject.toString().trim(), OwnerRatingDto.class);
                    owner_rating.setRating(ownerRatingDto.getAvgRating());
                    if(ownerRatingDto.getAvgRating()==0.0F){
                        ownerRatingTxt.setVisibility(View.GONE);
                    }else{
                        ownerRatingTxt.setVisibility(View.VISIBLE);
                        BigDecimal result=round(ownerRatingDto.getAvgRating(),2);
                        ownerRatingTxt.setText(String.valueOf(result)+""+getResources().getString(R.string.per_five));
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else {
                callAlertDialog("Check Your Internet Connection");
            }
        }
    }

    private class sendRequestResponse extends AsyncTask<String,String,String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ViewPage.this);
            progressDialog.setMessage("Your Request is being sent….Please wait…");
            progressDialog.setProgressDrawable(new ColorDrawable(android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData, Webconfig.CONTEXT_PATH+"createrequest.json?memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            notificationThreadDto=new NotificationThreadDto();
            super.onPostExecute(s);
            progressDialog.dismiss();
            JSONObject jsonObject=null;
            if(s!=null) {
                try {
                    JSONArray jsonArray = new JSONArray(s);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        Gson gson = new Gson();
                        notificationThreadDto = gson.fromJson(jsonObject.toString().trim(), NotificationThreadDto.class);
                    }
                    customDialog = new Dialog(ViewPage.this);
                    customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    customDialog.setContentView(R.layout.custom_messbox);
                    alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                    alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                    alertMsgOkBtn.setVisibility(View.GONE);
                    alertMessageText.setText(getResources().getString(R.string.send_request_success_msg));
                    customDialog.setCancelable(true);
                    customDialog.setCanceledOnTouchOutside(true);

                    customDialog.setOnCancelListener(
                            new DialogInterface.OnCancelListener() {
                                @Override
                                public void onCancel(DialogInterface dialog) {
                                    customDialog.dismiss();
                                    startActivity(new Intent(ViewPage.this,HomeScreen.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));

                                }
                            }
                    );

                    customDialog.show();
                    customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else {
                callAlertDialog("Check Your Internet Connection");
            }
        }
    }

    private boolean checkEnterDetail() {
        boolean valueReturn = true;
        if (!Validation.hasText(enterDetailsTxt, enterDetailsLayout))
            valueReturn = false;
        return valueReturn;
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(ViewPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

    private class getCheckRequestSendOrNot extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getallrequestmade.json?productid="+productId+"&memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONObject jsonObject=new JSONObject(s);
                    JSONArray blockListArray=jsonObject.getJSONArray("blockListDto");
                    JSONObject reqAllMadeObj=jsonObject.getJSONObject("requestDtos");
                    if(productId.equals(reqAllMadeObj.optString("productId"))){
                        callAlertDialog("There is a similar request already pending, check your message box");
                    }else
                    if(blockListArray.length()>0){
                        callAlertDialog("You blocked this member for send request unblock the member");
                    }else {
                        new sendRequestResponse().execute();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }else{
                callAlertDialog("check your internet connection");
            }
        }
    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(ViewPage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(ViewPage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(ViewPage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(ViewPage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(ViewPage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(ViewPage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(ViewPage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(ViewPage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(ViewPage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(ViewPage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(ViewPage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(ViewPage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(ViewPage.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(ViewPage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(ViewPage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(ViewPage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(ViewPage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(ViewPage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(ViewPage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(ViewPage.this, AddGroupActivity.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(ViewPage.this, HomeScreen.class));
//            finish();
//        }
//
//    }

}
