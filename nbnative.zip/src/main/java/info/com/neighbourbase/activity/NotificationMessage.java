package info.com.neighbourbase.activity;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

import info.com.neighbourbase.Adapter.PushNotificationAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.PushNotificationDto;
import info.com.neighbourbase.service.MyFirebaseMessagingService;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.DBHelper;
import info.com.neighbourbase.utility.PushMessageListener;

public class NotificationMessage extends CommonHeader {

    List<PushNotificationDto> pushMessageDtoList;
    DBHelper db;
    ListView mPushListView;
    TextView mNoPushMsg;
    PushNotificationAdapter pushNotificationAdapter;
    SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        pref = PreferenceManager.getDefaultSharedPreferences(this);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_notification_message, FrameLayout);

        if(!Constant.currentActivity.equalsIgnoreCase("NotificationMessage")) {
            Constant.previousActivity = Constant.currentActivity;
            Constant.currentActivity = "NotificationMessage";
        }

        notificationLayout = (RelativeLayout) findViewById(R.id.notification_layout);
        deleteLayout = (LinearLayout) findViewById(R.id.delete_layout);
        notificationLayout.setVisibility(View.GONE);
        deleteLayout.setVisibility(View.VISIBLE);


        SharedPreferences.Editor se = pref.edit();
        se.putInt("pushCount", 0);
        se.commit();
        Constant.newMessageCount = 0;


        MyFirebaseMessagingService.bindListener(new PushMessageListener() {
            @Override
            public void pushMessageReceived(Integer messageCount) {
                if(messageCount!=null) {
                    //mNotifyCount = messageCount.toString();
                    if(Constant.currentActivity.equalsIgnoreCase("NotificationMessage")) {
                        startActivity(new Intent(NotificationMessage.this, NotificationMessage.class));
                        finish();
                    }

                }
            }

        });

        //Header.mPushMessageCount.setVisibility(View.GONE);
        CommonHeader.mPushMessageCount.setVisibility(View.GONE);
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.cancelAll();

        mPushListView = (ListView) findViewById(R.id.listMessages);
        mNoPushMsg = (TextView) findViewById(R.id.noPushMsg);

        db = new DBHelper(this);
        String memberId = pref.getString("memberId","");
        Integer memId = Integer.parseInt(memberId);
        pushMessageDtoList = db.getAllMessages(memId);

        if(pushMessageDtoList.size()>0) {
            pushNotificationAdapter = new PushNotificationAdapter(NotificationMessage.this, pushMessageDtoList);
            mPushListView.setAdapter(pushNotificationAdapter);
            mPushListView.setVisibility(View.VISIBLE);
            mNoPushMsg.setVisibility(View.GONE);

            for (PushNotificationDto cn : pushMessageDtoList) {
                String log = "Id: "+cn.getMemberid()+" ,Message: " + cn.getMessage() + " ,Date: " + cn.getDate()+", Id:"+cn.getId();
                //Toast.makeText(StudentsList.this, log, Toast.LENGTH_LONG).show();
                Log.d("Name: ", log);
            }
        }else{
            mPushListView.setVisibility(View.GONE);
            mNoPushMsg.setVisibility(View.VISIBLE);
        }
    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(NotificationMessage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(NotificationMessage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(NotificationMessage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(NotificationMessage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(NotificationMessage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(NotificationMessage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(NotificationMessage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(NotificationMessage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(NotificationMessage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(NotificationMessage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(NotificationMessage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(NotificationMessage.this, MessageActivity.class));
//            finish();
//        }
//
//       /* else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(NotificationMessage.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(NotificationMessage.this, AddGroupActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(NotificationMessage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(NotificationMessage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(NotificationMessage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(NotificationMessage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(NotificationMessage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(NotificationMessage.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(NotificationMessage.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
