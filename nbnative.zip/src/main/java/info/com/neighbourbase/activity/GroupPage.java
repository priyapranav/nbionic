package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.Adapter.GroupAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.NetworkDto;

import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class GroupPage extends CommonHeader implements View.OnClickListener {

    String memberId, groupId,groupName;
    NetworkDto networkDto;
    List<NetworkDto> networkDtoList;
    ArrayAdapter groupAdapter;
    ListView groupList;
    TextView noGroupText;
    public static GroupPage instance;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_group_page, FrameLayout);

        memberId = CommonHeader.memberId;
        groupList=(ListView)findViewById(R.id.group_list);
        noGroupText=(TextView)findViewById(R.id.noGroupText);
        instance=this;

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "GroupPage";

        noGroupText.setOnClickListener(this);
        groupList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                System.out.println("a");
                Constant.categoryId=0;
                groupId = String.valueOf(networkDtoList.get(position).getNetworkId());
                groupName=String.valueOf(networkDtoList.get(position).getName());
                updateGroupId();
                Constant.groupName=groupName;
                startActivity(new Intent(GroupPage.this,GroupProductListingPage.class));
//        finish();
            }
        });

        if(Connectivity.isConnected(GroupPage.this)) {
            new getGroupDetails().execute();
        }else{
            callAlertDialog("Please Check Internet Connection");
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.noGroupText:
                startActivity(new Intent(GroupPage.this,AddGroupActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                break;

        }
    }

  /*  @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        System.out.println("a");
        Constant.categoryId=0;
        groupId = String.valueOf(networkDtoList.get(position).getNetworkId());
        groupName=String.valueOf(networkDtoList.get(position).getName());
        updateGroupId();
        Constant.groupName=groupName;
        startActivity(new Intent(GroupPage.this,GroupProductListingPage.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
//        finish();
    }*/

    private class getGroupDetails extends AsyncTask<String,String,String>
    {
        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(GroupPage.this);
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getallmembernetworks.json?memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            networkDto=new NetworkDto();
            networkDtoList=new ArrayList<>();
            super.onPostExecute(s);
            progressDialog.dismiss();
            if (s!= null) {
                JSONObject jsonObject = null;
                JSONArray jsonArray = null;
                try {
                    jsonArray = new JSONArray(s);
                    if (jsonArray.length() == 0) {
                        groupList.setVisibility(View.GONE);
                        noGroupText.setVisibility(View.VISIBLE);

                    } else {
                        groupList.setVisibility(View.VISIBLE);
                        noGroupText.setVisibility(View.GONE);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObject = jsonArray.getJSONObject(i);
                            networkDto = new Gson().fromJson(jsonObject.toString().trim(), NetworkDto.class);
                            networkDtoList.add(networkDto);
                        }
                        groupAdapter = new GroupAdapter(GroupPage.this, networkDtoList);
                        groupList.setAdapter(groupAdapter);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                callAlertDialog("Server Down");
//                groupList.setVisibility(View.GONE);
//                noGroupText.setVisibility(View.VISIBLE);
            }
        }
    }
    private void updateGroupId() {
        SharedPreferences.Editor e = preferences.edit();
        e.putString("groupId",groupId);
        e.commit();


    }


    private void callAlertDialog(String message) {

        customDialog = new Dialog(GroupPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(GroupPage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(GroupPage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(GroupPage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(GroupPage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(GroupPage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(GroupPage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(GroupPage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(GroupPage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(GroupPage.this, AddGroupActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(GroupPage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(GroupPage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(GroupPage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(GroupPage.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(GroupPage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(GroupPage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(GroupPage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(GroupPage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(GroupPage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(GroupPage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(GroupPage.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(GroupPage.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}
