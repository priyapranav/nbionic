package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.roomorama.caldroid.CaldroidFragment;
import com.roomorama.caldroid.CaldroidListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.IssuerNoteDto;
import info.com.neighbourbase.model.ReceiverNoteDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

public class ReminderPage extends CommonHeader {
    Date date1,date2,holidayDay;
    String inputString2,inputString1,memberId;
    ArrayList<IssuerNoteDto> issuerNoteDtoList=new ArrayList<>();
    ArrayList<String> issuerNoteDtoReturnDate=new ArrayList<>();
    ArrayList<ReceiverNoteDto> receiverNoteDtoList=new ArrayList<>();
    ArrayList<String> receiverNoteDtoReturnDate=new ArrayList<>();
    SharedPreferences preferences;
    private CaldroidFragment caldroidFragment;
    ReceiverNoteDto receiverNoteDto=new ReceiverNoteDto();
    IssuerNoteDto issuerNoteDto=new IssuerNoteDto();
    private int day;
    SimpleDateFormat myFormat = new SimpleDateFormat("dd/MM/yyyy");
    TextView reminderText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_reminder_page, FrameLayout);
        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "ReminderPage";
        reminderText=(TextView)findViewById(R.id.reminder_text);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        memberId=preferences.getString("memberId","");
        new issuerReminderResponse().execute();
        new receiverReminderResponse().execute();
        caldroidFragment = new CaldroidFragment();
        if (savedInstanceState != null) {
            caldroidFragment.restoreStatesFromKey(savedInstanceState,
                    "CALDROID_SAVED_STATE");
        }
        // If activity is created from fresh
        else {
            Bundle args = new Bundle();
            Calendar cal = Calendar.getInstance();
            args.putInt(CaldroidFragment.MONTH, cal.get(Calendar.MONTH) + 1);
            args.putInt(CaldroidFragment.YEAR, cal.get(Calendar.YEAR));
            args.putBoolean(CaldroidFragment.ENABLE_SWIPE, true);
            args.putBoolean(CaldroidFragment.SIX_WEEKS_IN_CALENDAR, true);

            caldroidFragment.setArguments(args);
        }
              // Attach to the activity
        FragmentTransaction t = getSupportFragmentManager().beginTransaction();
        t.replace(R.id.calendar1, caldroidFragment);
        t.commit();

        // Setup Caldroid
        caldroidFragment.setCaldroidListener(listener);

    }
    // Setup listener
    final CaldroidListener listener = new CaldroidListener() {

        @Override
        public void onSelectDate(Date date, View view) {
//                Toast.makeText(getApplicationContext(), formatter.format(date),
//                        Toast.LENGTH_SHORT).show();
            reminderText.setText("");
            int i=0,j=0;
            for (String issuerReturnDate : issuerNoteDtoReturnDate) {

                try {
                    if (String.valueOf(date).equals(String.valueOf(myFormat.parse(issuerReturnDate)))) {
                        reminderText.setText("Time to get"+" "+issuerNoteDtoList.get(i).getProductName()+" from "+issuerNoteDtoList.get(i).getRequesterName());
                    }
                } catch (ParseException e) {
                    e.printStackTrace();

                }

                i=i+1;

            }

            for (String receiverReturnDate : receiverNoteDtoReturnDate) {

                try {
                    if (String.valueOf(date).equals(String.valueOf(myFormat.parse(receiverReturnDate)))) {
                        reminderText.setText("Time to return"+" "+receiverNoteDtoList.get(j).getProductName()+" to "+receiverNoteDtoList.get(j).getProductOwner());
                    }

                } catch (ParseException e) {
                    e.printStackTrace();

                }
                j=j+1;
            }
        }


    };



    private void setCustomResourceForIssuerDates() {

        Calendar cal = Calendar.getInstance();
        //highlighlighting the holidays in a month taking the static dates
        ArrayList<String> dates = new ArrayList<String>();
        dates.addAll(issuerNoteDtoReturnDate);
        Date date = new Date();
        for (int i = 0; i < dates.size(); i++) {
            inputString2 = dates.get(i);
            inputString1 = myFormat.format(date);

            try {
                //Converting String format to date format
                date1 = myFormat.parse(inputString1);
                date2 = myFormat.parse(inputString2);
                //Calculating number of days from two dates
                long diff = date2.getTime() - date1.getTime();
                long datee = diff / (1000 * 60 * 60 * 24);
                //Converting long type to int type
                day = (int) datee;
            } catch (ParseException e) {
                e.printStackTrace();
            }
            cal = Calendar.getInstance();
            cal.add(Calendar.DATE, day);
            holidayDay = cal.getTime();

            if (caldroidFragment != null) {
                caldroidFragment.setBackgroundDrawableForDate(new ColorDrawable(getResources().getColor(R.color.colorPrimary)),
                        holidayDay);
                caldroidFragment.setTextColorForDate(R.color.White, holidayDay);
            }

        }
    }


    private void setCustomResourceForReceiverDates() {

        Calendar cal = Calendar.getInstance();
        //highlighlighting the holidays in a month taking the static dates
        ArrayList<String> dates = new ArrayList<String>();
        dates.addAll(receiverNoteDtoReturnDate);
        Date date = new Date();
        for (int i = 0; i < dates.size(); i++) {
            inputString2 = dates.get(i);
            inputString1 = myFormat.format(date);

            try {
                //Converting String format to date format
                date1 = myFormat.parse(inputString1);
                date2 = myFormat.parse(inputString2);
                //Calculating number of days from two dates
                long diff = date2.getTime() - date1.getTime();
                long datee = diff / (1000 * 60 * 60 * 24);
                //Converting long type to int type
                day = (int) datee;
            } catch (ParseException e) {
                e.printStackTrace();
            }
            cal = Calendar.getInstance();
            cal.add(Calendar.DATE, day);
            holidayDay = cal.getTime();

            if (caldroidFragment != null) {
                caldroidFragment.setBackgroundDrawableForDate(new ColorDrawable(getResources().getColor(R.color.colorAccent)),
                        holidayDay);
                caldroidFragment.setTextColorForDate(R.color.White, holidayDay);
            }

        }
    }


    /**
     * Save current states of the Caldroid here
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        // TODO Auto-generated method stub
        super.onSaveInstanceState(outState);
        if (caldroidFragment != null) {
            caldroidFragment.saveStatesToKey(outState, "CALDROID_SAVED_STATE");
        }

    }

    private class issuerReminderResponse extends AsyncTask<String,String,String>{

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getissuernotedateremainder.json?memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONArray jsonArray=new JSONArray(s);
                    if(jsonArray.length()!=0) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject issuerNoteReminderObj = jsonArray.getJSONObject(i);
                            issuerNoteDto = new Gson().fromJson(issuerNoteReminderObj.toString(), IssuerNoteDto.class);
                            issuerNoteDtoList.add(issuerNoteDto);
                            issuerNoteDtoReturnDate.add(issuerNoteReminderObj.optString("returnByStr"));
                        }

                        setCustomResourceForIssuerDates();
                        caldroidFragment.refreshView();   // refresh the caldroid fragment

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }else{
                callAlertDialog("Server Down... Please try again");
            }
        }
    }



    private class receiverReminderResponse extends AsyncTask<String,String,String>{

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getreceivernotedateremainder.json?memberId="+memberId);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                try {
                    JSONArray jsonArray=new JSONArray(s);
                    if(jsonArray.length()!=0) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject issuerNoteReminderObj = jsonArray.getJSONObject(i);
                            receiverNoteDto = new Gson().fromJson(issuerNoteReminderObj.toString(), ReceiverNoteDto.class);
                            receiverNoteDtoList.add(receiverNoteDto);
                            receiverNoteDtoReturnDate.add(issuerNoteReminderObj.optString("returnByStr"));
                        }

                        setCustomResourceForReceiverDates();
                        caldroidFragment.refreshView();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
            else{
                callAlertDialog("Server Down... Please try again");
            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(ReminderPage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(ReminderPage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(ReminderPage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(ReminderPage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(ReminderPage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(ReminderPage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(ReminderPage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(ReminderPage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(ReminderPage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(ReminderPage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(ReminderPage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(ReminderPage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(ReminderPage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(AddGroupActivity.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(ReminderPage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(ReminderPage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(ReminderPage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePicturePage")){
//            startActivity(new Intent(ReminderPage.this, ProfilePicturePage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(ReminderPage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(ReminderPage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(ReminderPage.this, ViewPage.class));
//            finish();
//        } else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(ReminderPage.this, AddGroupActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MorePage")){
//            startActivity(new Intent(ReminderPage.this, MorePage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("DashBoardPage")){
//            startActivity(new Intent(ReminderPage.this, DashBoardPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfilePage")){
//            startActivity(new Intent(ReminderPage.this, ProfilePage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(ReminderPage.this, HomeScreen.class));
//            finish();
//        }
//
//    }
}

