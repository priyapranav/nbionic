package info.com.neighbourbase.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.Adapter.MessageAdapter;
import info.com.neighbourbase.Adapter.MessageSentAdapter;
import info.com.neighbourbase.R;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.RequestDto;
import info.com.neighbourbase.utility.Connectivity;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

import static info.com.neighbourbase.activity.Header.messageCount;

/**
 * Created by user on 29-06-2017.
 */

public class MessageSentFragment extends Fragment {

    SharedPreferences preferences;
    String memberId;
    List<RequestDto> requestDtoList;
    ListView sentRequestListview;
    TextView noMessageSentText, alertMessageText;
    Button alertMsgOkBtn;
    Dialog customDialog;

    public MessageSentFragment(){

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.message_sent_fragment, container, false);
        sentRequestListview = (ListView) rootView.findViewById(R.id.sent_message_list_view);
        noMessageSentText = (TextView) rootView.findViewById(R.id.no_message_sent_text);

        preferences= PreferenceManager.getDefaultSharedPreferences(getContext());
        memberId=preferences.getString("memberId","");

        if(Connectivity.isConnected(getContext())) {
            new getRequestSent().execute();
        }else{
            Toast.makeText(getContext(), "Please check internet connection.", Toast.LENGTH_LONG).show();
        }
        return rootView;
    }

    public class getRequestSent extends AsyncTask<String, String, String> {
        ProgressDialog progressDialog;
        protected void onPreExecute() {

            super.onPreExecute();
            progressDialog = new ProgressDialog(getContext());
            progressDialog.setMessage("Loading...");
            progressDialog.setProgressDrawable(new ColorDrawable(
                    android.graphics.Color.BLUE));
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig = new HttpConfig();
            String result = httpConfig.httppost(Webconfig.CONTEXT_PATH +"getreqmadebynetwork.json?memberId="+memberId+"&pageNumber="+0+"&networkId=0");
            System.out.println("Request sent "+result);
            return result;
        }

        @Override
        protected void onPostExecute(String res) {
            RequestDto requestDto = new RequestDto();
            JSONObject jsonObj, jsonObj1;
            JSONArray jsonArray;
            Gson gson = new Gson();
            progressDialog.dismiss();
            if(res!=null){
                try {
                    jsonObj = new JSONObject(res);
                    String status = jsonObj.getString("status");
                    Constant.messageUnreadCount = jsonObj.getLong("unreadCount");
                    CommonHeader.messageCount.setText(String.valueOf(Constant.messageUnreadCount));

                    if(status.equalsIgnoreCase("success")){
                        requestDtoList = new ArrayList<RequestDto>();
                        CommonResponseDto commonResponseDto = gson.fromJson(res, CommonResponseDto.class);
                        requestDtoList = commonResponseDto.getRequestDto();
                        /*jsonArray = jsonObj.getJSONArray("requestDto");
                        for(int i=0; i<jsonArray.length();i++){
                            jsonObj1 = jsonArray.getJSONObject(i);
                            requestDto = gson.fromJson(jsonObj1.toString(),RequestDto.class);
                            requestDtoList.add(requestDto);
                        }*/
                        if(commonResponseDto.getRequestDto()!=null && commonResponseDto.getRequestDto().size()>0) {
                            sentRequestListview.setVisibility(View.VISIBLE);
                            noMessageSentText.setVisibility(View.GONE);
                            ArrayAdapter<RequestDto> requestDtoAdapter = new MessageSentAdapter(getActivity(), commonResponseDto.getRequestDto());
                            sentRequestListview.setAdapter(requestDtoAdapter);
                        }else{
                            sentRequestListview.setVisibility(View.GONE);
                            noMessageSentText.setVisibility(View.VISIBLE);
                        }
                        sentRequestListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                //long requestId = requestDtoList.get(position).getRequestId();
                                Constant.requestId = requestDtoList.get(position).getRequestId();
                                Constant.requestStatusId = requestDtoList.get(position).getRequestStatusId();
                                Constant.requestType = "sent";
                                if(requestDtoList.get(position).getTransName().equalsIgnoreCase("Lend")){
                                    Constant.transType = "borrow";
                                }else if(requestDtoList.get(position).getTransName().equalsIgnoreCase("Rent")){
                                    Constant.transType = "rent";
                                }
                                else if(requestDtoList.get(position).getTransName().equalsIgnoreCase("Sell")){
                                    Constant.transType = "buy";
                                }
                                else if(requestDtoList.get(position).getTransName().equalsIgnoreCase("Gift")){
                                    Constant.transType = "giveaway";
                                }
                                startActivity(new Intent(getActivity(), ChatMessageActivity.class));
                                getActivity().finish();
                            }
                        });
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                callAlertDialog("Server Down, Please try after sometime.");
            }

        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(getContext());
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText = (TextView) customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn = (Button) customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

}