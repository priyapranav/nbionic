package info.com.neighbourbase.activity;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.MemberDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

import static android.R.attr.data;

public class ProfilePicturePage extends CommonHeader implements View.OnClickListener {
    EditText aboutMeText;
    MemberDto memberDto=new MemberDto();
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    ImageView profileImage,addImageIcon;
    Button profileChangeBtn;
    SharedPreferences preferences;
    String profilePictureStr,reqData,memberId,aboutMe;
    byte[] profileImageByteArray;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_profile_picture_page);
        FrameLayout FrameLayout = (FrameLayout) findViewById(R.id.frame_layout);
        getLayoutInflater().inflate(R.layout.activity_profile_picture_page, FrameLayout);

        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        profilePictureStr=preferences.getString("picture","");
        memberId=preferences.getString("memberId","");
        aboutMe=preferences.getString("aboutMe","");
        mInit();
        setProfilePic();


        addImageIcon.setOnClickListener(this);
        profileChangeBtn.setOnClickListener(this);
    }

    private void setProfilePic() {
        if(profilePictureStr==null||profilePictureStr.equals("No Image")||profilePictureStr.equals("")) {
            Glide.clear(profileImage);
            profileImage.setImageResource(R.drawable.no_image);
        }else{
            Glide.with(this)
                    .load(Webconfig.CONTEXT_PATH1+"images/"+profilePictureStr) .thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(profileImage);
        }

    }

    private void mInit() {

        Constant.previousActivity = Constant.currentActivity;
        Constant.currentActivity = "ProfilePicturePage";

        aboutMeText=(EditText)findViewById(R.id.aboutme_text);
        profileImage=(ImageView)findViewById(R.id.profile_picture);
        addImageIcon=(ImageView) findViewById(R.id.browse_img_btn);
        profileChangeBtn=(Button)findViewById(R.id.profile_pic_change);

        aboutMeText.setText(aboutMe);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.browse_img_btn:
                selectImage();
                break;

            case R.id.profile_pic_change:
                memberDto.setMemberProfilePic(profileImageByteArray);
                memberDto.setAboutMe(aboutMeText.getText().toString());
                memberDto.setMemberId(Long.parseLong(memberId));
                memberDto.setPicture(profilePictureStr);
                reqData=new Gson().toJson(memberDto);
                new getProfilePicChangeResponse().execute();
                break;
        }
    }

    // **************** Capture Product Image ***************************
    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Library","No Image","Cancel"};

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(ProfilePicturePage.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {


                if (items[item].equals("Take Photo")) {
                    cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    galleryIntent();

                } else if (items[item].equals("No Image")) {
                    profileImage.setImageResource(R.drawable.no_image);
                    Drawable drawable = getResources().getDrawable(R.drawable.no_image);
                    Bitmap bitmap = ((BitmapDrawable)drawable).getBitmap();
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                    profileImageByteArray = stream.toByteArray();

                }else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent()
    {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }

    private void cameraIntent()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");
        String picturePath=destination.getPath();
        thumbnail=changeOrientation(picturePath,thumbnail);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        profileImageByteArray= bytes.toByteArray();
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        profileImage.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Uri selectedImageUri = data.getData();
        String picturePath= getRealPathFromURI(selectedImageUri);
        Bitmap bm=null;
        if (data!= null) {
            try {
                bm = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        InputStream imageStream = null;
        try {
            imageStream = getContentResolver().openInputStream(selectedImageUri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
        selectedImage = getResizedBitmap(selectedImage, 400);// 400 is for example, replace with desired size
        selectedImage= changeOrientation(picturePath,selectedImage);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        selectedImage.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        profileImageByteArray= bytes.toByteArray();

        profileImage.setImageBitmap(selectedImage);
    }
    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }
    private Bitmap changeOrientation(String picturePath, Bitmap loadedBitmap) {
        if(picturePath!=null) {
            ExifInterface exif = null;
            try {
                File pictureFile = new File(picturePath);
                exif = new ExifInterface(pictureFile.getAbsolutePath());
            } catch (IOException e) {
                e.printStackTrace();
            }

            int orientation = ExifInterface.ORIENTATION_NORMAL;

            if (exif != null)
                orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    loadedBitmap = rotateBitmap(loadedBitmap, 90);
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    loadedBitmap = rotateBitmap(loadedBitmap, 180);
                    break;

                case ExifInterface.ORIENTATION_ROTATE_270:
                    loadedBitmap = rotateBitmap(loadedBitmap, 270);
                    break;
            }
        }
        return loadedBitmap;
    }


    public static Bitmap rotateBitmap(Bitmap bitmap, int degrees) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public String getRealPathFromURI(Uri contentUri) {
        String [] proj={MediaStore.Images.Media.DATA};
        Cursor cursor = managedQuery( contentUri, proj, null, null, null); // Order-by clause (ascending by name)
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String path= cursor.getString(column_index);
        return path;
    }
    // **************** Capture Product Image method finished ***************************

    private class getProfilePicChangeResponse extends AsyncTask<String,String,String>{
        ProgressDialog progressDialog;

        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(ProfilePicturePage.this);
            progressDialog.setMessage("Processing...");
            progressDialog.setProgressDrawable(new ColorDrawable(android.graphics.Color.GRAY));
            progressDialog.setCancelable(true);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

        }
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.doPost(reqData,Webconfig.CONTEXT_PATH+"memberprofilepictureupload.json");
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            JSONObject jsonObject=null;
            if(s!=null){
                try {
                    jsonObject=new JSONObject(s);
                    String status=jsonObject.optString("status");
                    if(status.equals("success")){
                        Gson gson=new Gson();
                        String actualData  = jsonObject.getString("memberDto");
                        memberDto=gson.fromJson(actualData,MemberDto.class);
                        customDialog = new Dialog(ProfilePicturePage.this);
                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        customDialog.setContentView(R.layout.custom_messbox);
                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                        alertMsgOkBtn.setVisibility(View.GONE);
                        alertMessageText.setText(getResources().getString(R.string.profile_change_msg));
                        customDialog.setCancelable(true);
                        customDialog.setCanceledOnTouchOutside(true);
                        customDialog.setOnCancelListener(
                                new DialogInterface.OnCancelListener() {
                                    @Override
                                    public void onCancel(DialogInterface dialog) {
                                        customDialog.dismiss();
                                        preferences.edit().remove("picture").commit();
                                        String changeProfilePicStr=memberDto.getPicture();
                                        updateProfilePic(changeProfilePicStr,memberDto.getAboutMe());
                                        startActivity(new Intent(ProfilePicturePage.this,HomeScreen.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
//                                                finish();
                                    }
                                }
                        );
                        customDialog.show();
                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                    }else{
                       callAlertDialog("Profile Picture Updated Failed. Please try again");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }else{
                callAlertDialog("Server Down... Please try again");
            }
        }
    }



   private void updateProfilePic(String changeProfilePicStr, String aboutMe) {
        SharedPreferences.Editor e = preferences.edit();
        e.putString("picture",changeProfilePicStr);
        e.putString("aboutMe",aboutMe);
        e.commit();
    }

    private void callAlertDialog(String message) {

        customDialog = new Dialog(ProfilePicturePage.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }
//    @Override
//    public void onBackPressed() {
//
//        super.onBackPressed();
//
//        if(Constant.previousActivity.equalsIgnoreCase("AddProductPage")) {
//
//            startActivity(new Intent(ProfilePicturePage.this, AddProductPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("CategoryActivity")) {
//
//            startActivity(new Intent(ProfilePicturePage.this, CategoryActivity.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("ChangeEmailPage")) {
//
//            startActivity(new Intent(ProfilePicturePage.this, ChangeEmailPage.class));
//            finish();
//        }else if(Constant.previousActivity.equalsIgnoreCase("HomeScreen")) {
//
//            startActivity(new Intent(ProfilePicturePage.this, HomeScreen.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("ChangeLocationPage")) {
//
//            startActivity(new Intent(ProfilePicturePage.this, ChangeLocationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("FeedbackActivity")){
//            startActivity(new Intent(ProfilePicturePage.this, FeedbackActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupEditPage")){
//            startActivity(new Intent(ProfilePicturePage.this, GroupEditPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupMemberPage")){
//            startActivity(new Intent(ProfilePicturePage.this, GroupMemberPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupPage")){
//            startActivity(new Intent(ProfilePicturePage.this, GroupPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("GroupProductListingPage")){
//            startActivity(new Intent(ProfilePicturePage.this, GroupProductListingPage.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("InviteFriendsActivity")){
//            startActivity(new Intent(ProfilePicturePage.this, InviteFriendsActivity.class));
//            finish();
//        }
//        else if(Constant.previousActivity.equalsIgnoreCase("MessageActivity")){
//            startActivity(new Intent(ProfilePicturePage.this, MessageActivity.class));
//            finish();
//        }
//
//        /*else if(Constant.previousActivity.equalsIgnoreCase("MyListingPage")){
//            startActivity(new Intent(ProfilePicturePage.this, MyListingPage.class));
//            finish();
//        }*/
//
//        else if(Constant.previousActivity.equalsIgnoreCase("NotificationMessage")){
//            startActivity(new Intent(ProfilePicturePage.this, NotificationMessage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProductEditPage")){
//            startActivity(new Intent(ProfilePicturePage.this, ProductEditPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ProfileInformationPage")){
//            startActivity(new Intent(ProfilePicturePage.this, ProfileInformationPage.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("AddGroupActivity")){
//            startActivity(new Intent(ProfilePicturePage.this, AddGroupActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ResetPassword")){
//            startActivity(new Intent(ProfilePicturePage.this, ResetPassword.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("SearchActivity")){
//            startActivity(new Intent(ProfilePicturePage.this, SearchActivity.class));
//            finish();
//        }
//
//        else if(Constant.previousActivity.equalsIgnoreCase("ViewPage")){
//            startActivity(new Intent(ProfilePicturePage.this, ViewPage.class));
//            finish();
//        }
//        else{
//            startActivity(new Intent(ProfilePicturePage.this, HomeScreen.class));
//            finish();
//        }
//
//    }

}
