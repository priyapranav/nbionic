package info.com.neighbourbase.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.List;

import info.com.neighbourbase.R;
import info.com.neighbourbase.activity.GroupEditPage;
import info.com.neighbourbase.model.NetworkDto;
import info.com.neighbourbase.utility.Webconfig;

/**
 * Created by Priya on 18-07-2017.
 */

public class GroupAdapter extends ArrayAdapter<NetworkDto> {

    private Context context;
    List<NetworkDto> groupList;
    LayoutInflater inflater;


    public GroupAdapter(Context context,  List<NetworkDto> groupList) {
        super(context, 0,groupList);

        this.context = context;
        this.groupList = groupList;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        ViewHolder holder;
        holder = new ViewHolder();
        if (vi == null) {
            vi = inflater.inflate(R.layout.group_page_list_item, null);
            vi.setTag(holder);
        } else {
            vi.getTag();
        }
        vi.setFocusable(false);
        holder.groupName = (TextView) vi.findViewById(R.id.group_name);
        holder.groupDetails = (TextView) vi.findViewById(R.id.group_details);
        holder.groupImage = (ImageView) vi.findViewById(R.id.group_image);
        holder.editBtn=(Button)vi.findViewById(R.id.group_edit_btn);
        

        holder.groupName.setText(groupList.get(position).getName());
        holder.groupDetails.setText(groupList.get(position).getNetworkDetails());

        if(groupList.get(position).getPicture()==null||groupList.get(position).getPicture().equals("No Image")||groupList.get(position).getPicture().equals("")) {
            Glide.clear(holder.groupImage);
            holder.groupImage.setImageResource(R.drawable.no_image);
        }else{
            Glide.with(context)
                    .load(Webconfig.CONTEXT_PATH1+"images/"+groupList.get(position).getPicture()) .thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(holder.groupImage);
        }
        holder.editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String groupId= String.valueOf(groupList.get(position).getNetworkId());
                context.startActivity(new Intent(context,GroupEditPage.class).putExtra("groupId",groupId));
            }
        });
        if(groupList.get(position).getPrimaryFlag()==0){
            holder.editBtn.setVisibility(View.GONE);
        }else  if(groupList.get(position).getPrimaryFlag()==1){
            holder.editBtn.setVisibility(View.VISIBLE);
        }


        return vi;

    }

    public static class ViewHolder {

        public TextView groupName,groupDetails;
        public ImageView groupImage;
        public Button editBtn;

    }

}
