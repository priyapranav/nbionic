package info.com.neighbourbase.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.PushNotificationDto;

/**
 * Created by user on 01-08-2017.
 */

public class
PushNotificationAdapter extends ArrayAdapter<PushNotificationDto> {

    private Context context;
    List<PushNotificationDto> listMessages;
    LayoutInflater inflater;

    public PushNotificationAdapter(Context context, List<PushNotificationDto> lMessages) {
        super(context, 0, lMessages);

        this.listMessages = lMessages;
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        ViewHolder holder;
        holder = new ViewHolder();
        if(vi == null)
        {
            vi = inflater.inflate(R.layout.list_notification_message, null);
            vi.setTag(holder);
        }
        else{
            vi.getTag();
        }
        holder.txtPushSNo = (TextView) vi.findViewById(R.id.pushSNo);
        holder.txtPushMsg = (TextView) vi.findViewById(R.id.pushMessageName);
        holder.txtPushDate = (TextView) vi.findViewById(R.id.pushDate);

        holder.txtPushSNo.setText(String.valueOf(position+1)+".");
        holder.txtPushMsg.setText(listMessages.get(position).getMessage());
        holder.txtPushDate.setText(listMessages.get(position).getDate());

        return vi;

    }

    public static class ViewHolder {

        public TextView txtPushMsg, txtPushDate, txtPushMsgId, txtPushSNo;


    }

}