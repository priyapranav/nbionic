package info.com.neighbourbase.Adapter;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.support.design.widget.TextInputLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;

import java.util.List;

import info.com.neighbourbase.R;
import info.com.neighbourbase.activity.UsefulContactDetailPage;
import info.com.neighbourbase.model.NetworkContactListDto;
import info.com.neighbourbase.model.NetworkContactListFeedbackDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

/**
 * Created by SIVANATH on 17-Nov-17.
 */

public class ContactListFeedbackAdapter extends ArrayAdapter <NetworkContactListFeedbackDto>{
    private Context context;
    List<NetworkContactListFeedbackDto> feedbackList;
    LayoutInflater inflater;



    public ContactListFeedbackAdapter(Context context, List<NetworkContactListFeedbackDto> feedbackList) {
        super(context, 0, feedbackList);


        this.context = context;
        this.feedbackList = feedbackList;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public View getView(final int position, final View convertView, ViewGroup parent) {
        View vi = convertView;
        ContactListFeedbackAdapter.ViewHolder holder;
        holder = new ContactListFeedbackAdapter.ViewHolder();
        if (vi == null) {
            vi = inflater.inflate(R.layout.contact_list_feedback, null);
            vi.setTag(holder);
        } else {
            vi.getTag();
        }
        holder.feedback_text=(TextView)vi.findViewById(R.id.feedback_text);
        holder.detail_text=(TextView)vi.findViewById(R.id.detail_text);
        holder.feedback_text.setText(feedbackList.get(position).getFeedbackMessage());
        if(feedbackList.get(position).getMemberLocation()==null){
            holder.detail_text.setText(feedbackList.get(position).getMemberName()+"/ On: "+feedbackList.get(position).getDate());

        }else
            holder.detail_text.setText(feedbackList.get(position).getMemberName()+"/ "+feedbackList.get(position).getMemberLocation()+"/ On: "+feedbackList.get(position).getDate());

        return vi;

    }




    public static class ViewHolder {

        public TextView feedback_text,detail_text;



    }

}
