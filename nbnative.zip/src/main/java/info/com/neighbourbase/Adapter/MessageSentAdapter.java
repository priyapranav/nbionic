package info.com.neighbourbase.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.NotificationThreadDto;
import info.com.neighbourbase.model.RequestDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.Webconfig;

/**
 * Created by user on 11-07-2017.
 */

public class MessageSentAdapter extends ArrayAdapter<RequestDto> {

    private Context context;
    List<RequestDto> requestDtoList;
    LayoutInflater inflater;
    NotificationThreadDto notificationThreadDto;
    List<NotificationThreadDto> notificationThreadDtoList;
    String transType;

    public MessageSentAdapter(Context context, List<RequestDto> dtoList) {
        super(context, 0, dtoList);

        this.context = context;
        this.requestDtoList = dtoList;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        notificationThreadDto = new NotificationThreadDto();
        notificationThreadDtoList = new ArrayList<NotificationThreadDto>();
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        MessageSentAdapter.ViewHolder holder;
        holder = new MessageSentAdapter.ViewHolder();
        if (vi == null) {
            vi = inflater.inflate(R.layout.reveived_message_list, null);
            vi.setTag(holder);
        } else {
            vi.getTag();
        }
        holder.messageLayout = (LinearLayout) vi.findViewById(R.id.message_list_layout);
        holder.productName = (TextView) vi.findViewById(R.id.product_name);
        holder.requesterName = (TextView) vi.findViewById(R.id.requester_name);
        holder.requestType = (TextView) vi.findViewById(R.id.request_type);
        holder.requestDate=(TextView)vi.findViewById(R.id.date_text);
        holder.groupName=(TextView)vi.findViewById(R.id.group_name_text);
        holder.requesterImage = (ImageView) vi.findViewById(R.id.requester_image);

        notificationThreadDtoList = requestDtoList.get(position).getNotificationThreadDto();
        if(notificationThreadDtoList.size()>0){
            notificationThreadDto = notificationThreadDtoList.get(notificationThreadDtoList.size()-1);

                if (notificationThreadDto.getIsReadReceiverFlag() == 0) {
                    holder.messageLayout.setBackgroundColor(context.getResources().getColor(R.color.gray));
                } else if (notificationThreadDto.getIsReadReceiverFlag() == 1) {
                    holder.messageLayout.setBackgroundColor(context.getResources().getColor(R.color.White));
                }
                holder.requesterName.setText(requestDtoList.get(position).getOwnerName());

            /*********************for sent message display product image ******************************/
                if(requestDtoList.get(position).getProductImage()==null||requestDtoList.get(position).getProductImage().equalsIgnoreCase("No Image") || requestDtoList.get(position).getProductImage().isEmpty()) {
                    Glide.clear(holder.requesterImage);
                    holder.requesterImage.setImageResource(R.drawable.no_image);
                }else{
                    Glide.with(context)
                            .load(Webconfig.CONTEXT_PATH1+"images/"+requestDtoList.get(position).getProductImage()) .thumbnail(0.5f)
                            .crossFade()
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(holder.requesterImage);
                }
            }

        if(requestDtoList.get(position).getTransName().equalsIgnoreCase("Lend")){

            transType = "borrow";
        }else if(requestDtoList.get(position).getTransName().equalsIgnoreCase("Rent")){
            transType = "rent";
        }
        else if(requestDtoList.get(position).getTransName().equalsIgnoreCase("Sell")){
            transType = "buy";
        }
        else if(requestDtoList.get(position).getTransName().equalsIgnoreCase("Gift")){
            transType = "get";
        }

        holder.requesterName.setText("I wanted to "+transType+" "+requestDtoList.get(position).getOwnerName()+"'s "+requestDtoList.get(position).getProductName() +" from "+requestDtoList.get(position).getNetworkName()
                + " group.");

        holder.productName.setText(requestDtoList.get(position).getProductName());
        holder.requestType.setText(requestDtoList.get(position).getTransName());
        holder.requestDate.setText(new SimpleDateFormat("dd/MM/yyyy").format(new Date(requestDtoList.get(position).getCreatedDateTime())));
        holder.groupName.setText(requestDtoList.get(position).getNetworkName());

        return vi;

    }


    public static class ViewHolder {

        public TextView productName, requesterName, requestType, requestDate, groupName;
        public ImageView requesterImage;
        public LinearLayout messageLayout;

    }
}
