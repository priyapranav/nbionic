package info.com.neighbourbase.Adapter;


import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;

import android.content.Intent;

import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.gson.Gson;
import java.util.List;
import info.com.neighbourbase.R;
import info.com.neighbourbase.activity.UsefulContactDetailPage;
import info.com.neighbourbase.model.NetworkContactListDto;
import info.com.neighbourbase.model.NetworkContactListFeedbackDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

/**
 * Created by SIVANATH on 08-Nov-17.
 */

public class UsefulContactListAdapter extends ArrayAdapter<NetworkContactListDto> {
    private Context context;
    List<NetworkContactListDto> contactList;
    LayoutInflater inflater;
    private Dialog feedbackDialog;
    EditText feedbackEditText;
    String memberId;
    Button postFeedbackBtn,alertMsgOkBtn;
    String reqData;
    Dialog customDialog;
    TextView alertMessageText;
    NetworkContactListFeedbackDto networkContactListFeedbackDto=new NetworkContactListFeedbackDto();



    public UsefulContactListAdapter(Context context, List<NetworkContactListDto> contactList, String memberId) {
        super(context, 0, contactList);
        this.memberId=memberId;

        this.context = context;
        this.contactList = contactList;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public View getView(final int position, final View convertView, ViewGroup parent) {
        View vi = convertView;
        UsefulContactListAdapter.ViewHolder holder;
        holder = new UsefulContactListAdapter.ViewHolder();
        if (vi == null) {
            vi = inflater.inflate(R.layout.useful_contacts_page_list_item, null);
            vi.setTag(holder);
        } else {
            vi.getTag();
        }

        holder.contact_person_category = (TextView) vi.findViewById(R.id.contact_person_category);
        holder.contact_person_name = (TextView) vi.findViewById(R.id.contact_person_name);
        holder.useful_contacts_more = (ImageView) vi.findViewById(R.id.useful_contacts_more);
        holder.write_feedback = (ImageView) vi.findViewById(R.id.write_feedback);
        holder.contact_person_no=(TextView)vi.findViewById(R.id.contact_person_no);



        //holder.productName.setText(productList.get(position).getProductName());
        holder.contact_person_category.setText(contactList.get(position).getCategoryName());
        holder.contact_person_name.setText(contactList.get(position).getName());
        holder.contact_person_no.setText(String.valueOf(contactList.get(position).getMobile()));

        holder.useful_contacts_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,UsefulContactDetailPage.class);
                intent.putExtra("contactListId",String.valueOf(contactList.get(position).getListId()));
                intent.putExtra("categoryName",contactList.get(position).getCategoryName());
                context.startActivity(intent);


            }
        });

        holder.write_feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                feedbackDialog = new Dialog(context);
                feedbackDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                feedbackDialog.setContentView(R.layout.useful_contacts_feedback_page);
                feedbackDialog.setCancelable(true);

                postFeedbackBtn=(Button)feedbackDialog.findViewById(R.id.post_feedback);
                feedbackEditText=(EditText)feedbackDialog.findViewById(R.id.feedback);
                postFeedbackBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if(feedbackEditText.getText().toString().length()>0)
                        {
                            feedbackDialog.dismiss();
                            networkContactListFeedbackDto.setFeedbackMessage(feedbackEditText.getText().toString());
                            networkContactListFeedbackDto.setNetworkId(contactList.get(position).getNetworkId());
                            networkContactListFeedbackDto.setMemberId(Long.parseLong(memberId));
                            networkContactListFeedbackDto.setContactId(contactList.get(position).getListId());
                            reqData=new Gson().toJson(networkContactListFeedbackDto);

                            new AsyncTask<String, String, String>() {
                                ProgressDialog progressDialog;
                                @Override
                                protected void onPreExecute() {
                                    super.onPreExecute();
                                    progressDialog = new ProgressDialog( context);
                                    progressDialog.setMessage("Processing...");
                                    progressDialog.setProgressDrawable(new ColorDrawable(
                                            android.graphics.Color.GRAY));
                                    progressDialog.setCancelable(true);
                                    progressDialog.setCanceledOnTouchOutside(false);
                                    progressDialog.show();
                                }

                                @Override
                                protected String doInBackground(String... params) {
                                    HttpConfig httpConfig=new HttpConfig();
                                    String result=httpConfig.doPost(reqData,Webconfig.CONTEXT_PATH+"createfeedback.json");
                                    return result;
                                }

                                @Override
                                protected void onPostExecute(String s) {
                                    super.onPostExecute(s);
                                    progressDialog.dismiss();
                                    if(s!=null){
                                        if(s.trim().equals("success")){
                                            callAlertDialog("Thank You for your feedback");
                                        }else if(s.trim().equals("fail")){
                                            callAlertDialog("process failed try again...");
                                        }


                                    }else{
                                       callAlertDialog("please check your internet connection");
                                    }


                                }
                            }.execute();


                        }else{
                            feedbackEditText.setError("give a feedback");
                        }
                    }
                });


                feedbackDialog.show();



            }
        });


        return vi;

    }

 


    public static class ViewHolder {

        public TextView contact_person_category,contact_person_name,contact_person_no;
        public ImageView useful_contacts_more,write_feedback;


    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(context);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

}
