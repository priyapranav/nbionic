package info.com.neighbourbase.Adapter;

import android.app.Activity;
import android.app.AlarmManager;

import android.app.Dialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.R;
import info.com.neighbourbase.activity.AddGroupActivity;
import info.com.neighbourbase.activity.ChangeEmailPage;
import info.com.neighbourbase.activity.ChangeLocationPage;
import info.com.neighbourbase.activity.HomeScreen;
import info.com.neighbourbase.activity.LoginActivity;
import info.com.neighbourbase.activity.MyListingFragment;
import info.com.neighbourbase.activity.MyListingPage;
import info.com.neighbourbase.activity.ProductEditPage;
import info.com.neighbourbase.activity.ProductList;
import info.com.neighbourbase.model.MemberDto;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

/**
 * Created by Priya on 29-06-2017.
 */

public class MyListProductAdapter extends ArrayAdapter<ProductListingDto>  {

    private static Context context;
    private List<ProductListingDto> productList;
    private TextView alertMessageText;
    private Button alertMsgOkBtn;
    private Dialog customDialog;
    LayoutInflater inflater;

    ArrayList<Long> productIdList=new ArrayList<>();
    String productId;

    ViewHolder holder;


    public MyListProductAdapter(Context context, List<ProductListingDto> productList) {
        super(context, 0, productList);

        this.context = context;
        this.productList = productList;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public int getCount() {
        if (productList.isEmpty()) {
            MyListingFragment.noProductText.setVisibility(View.VISIBLE);
        }else{
            MyListingFragment.noProductText.setVisibility(View.GONE);
        }
        return productList.size();

    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;

        holder = new ViewHolder();
        if (vi == null) {
            vi = inflater.inflate(R.layout.mylisting_fragment_list_item, null);
            vi.setTag(holder);
        } else {
            vi.getTag();
        }


        holder.productName = (TextView) vi.findViewById(R.id.productName);
        holder.productDetails = (TextView) vi.findViewById(R.id.productDetail);
        holder.imgList = (ImageView) vi.findViewById(R.id.img_list);
        holder.productLayout=(LinearLayout)vi.findViewById(R.id.product_layout);
        holder.productSellPrice=(TextView)vi.findViewById(R.id.productSellPrice);
        holder.proRentPerDay=(TextView)vi.findViewById(R.id.rentPricePerDay);
        holder.proRentPerWeek=(TextView)vi.findViewById(R.id.rentPricePerWeek);
        holder.proRentPerMonth=(TextView)vi.findViewById(R.id.rentPricePerMonth);
        holder.deleteImg=(ImageView)vi.findViewById(R.id.delete_icon);
        holder.inuseImgLayout=(LinearLayout) vi.findViewById(R.id.inUse_icon_layout);
        holder.notInuseImgLayout=(LinearLayout) vi.findViewById(R.id.not_inuse_layout);
        holder.editBtn=(Button)vi.findViewById(R.id.editBtn);


        holder.productName.setText(productList.get(position).getOwnerName()+" 's "+productList.get(position).getProductName());
        holder.productDetails.setText(productList.get(position).getCategoryName()+" | "+productList.get(position).getArea()+" | "+"POSTED ON: "+productList.get(position).getCreatedDateTime());

        if(productList.get(position).getPicture()==null||productList.get(position).getPicture().equals("No Image")||productList.get(position).getPicture().equals("")) {
            Glide.clear(holder.imgList);
            holder.imgList.setImageResource(R.drawable.no_image);
        }else{
            Glide.with(context)
                    .load(Webconfig.CONTEXT_PATH1+"images/"+productList.get(position).getPicture())
                    .thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(holder.imgList);
        }
        if(productList.get(position).getTransTypeId()==1||productList.get(position).getTransTypeId()==4){
            holder.productSellPrice.setVisibility(View.GONE);
            holder.proRentPerDay.setVisibility(View.GONE);
            holder.proRentPerWeek.setVisibility(View.GONE);
            holder.proRentPerMonth.setVisibility(View.GONE);
        }else  if(productList.get(position).getTransTypeId()==2){
            holder.productSellPrice.setVisibility(View.GONE);
            if(productList.get(position).getPriceperday()==0){
                holder.proRentPerDay.setVisibility(View.GONE);
            }else{
                holder.proRentPerDay.setVisibility(View.VISIBLE);
                holder.proRentPerDay.setText(context.getResources().getString(R.string.rupees)+" "+String.valueOf(productList.get(position).getPriceperday())+" "+context.getResources().getString(R.string.per_day));

            }
            if(productList.get(position).getPriceperweek()==0){
                holder.proRentPerWeek.setVisibility(View.GONE);
            }else{
                holder.proRentPerWeek.setVisibility(View.VISIBLE);
                holder.proRentPerWeek.setText(context.getResources().getString(R.string.rupees)+" "+String.valueOf(productList.get(position).getPriceperweek())+" "+context.getResources().getString(R.string.per_week));

            }
            if(productList.get(position).getPricepermonth()==0){
                holder.proRentPerMonth.setVisibility(View.GONE);
            }else{
                holder.proRentPerMonth.setVisibility(View.VISIBLE);
                holder.proRentPerMonth.setText(context.getResources().getString(R.string.rupees)+" "+String.valueOf(productList.get(position).getPricepermonth())+" "+context.getResources().getString(R.string.per_month));
            }
        }else if(productList.get(position).getTransTypeId()==3){
            holder.proRentPerDay.setVisibility(View.GONE);
            holder.proRentPerWeek.setVisibility(View.GONE);
            holder.proRentPerMonth.setVisibility(View.GONE);
            if(productList.get(position).getSalePrice()==0.0){
                holder.productSellPrice.setVisibility(View.GONE);
            }else{
                holder.productSellPrice.setVisibility(View.VISIBLE);
                holder.productSellPrice.setText(context.getResources().getString(R.string.rupees)+" "+String.valueOf(productList.get(position).getSalePrice()));
            }
        }

        productIdList.add(productList.get(position).getProductId());
        if(productList.get(position).getIsPaused()==0)
        {
            holder.notInuseImgLayout.setVisibility(View.GONE);
            holder.inuseImgLayout.setVisibility(View.VISIBLE);

        }
        else if(productList.get(position).getIsPaused()==1)
        {
            holder.notInuseImgLayout.setVisibility(View.VISIBLE);
            holder.inuseImgLayout.setVisibility(View.GONE);

        }


        holder.editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                productId= String.valueOf(productList.get(position).getProductId());
                Intent i=new Intent(context,ProductEditPage.class);
                i.putExtra("productId",productId);
                context.startActivity(i);
            }
        });
        holder.deleteImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                customDialog = new Dialog(context);
                customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customDialog.setContentView(R.layout.custom_messbox);
                alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                alertMsgOkBtn.setText(context.getResources().getString(R.string.alert_msg_yes));
                alertMessageText.setText(context.getResources().getString(R.string.delete_listing));
                customDialog.setCancelable(true);
                alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customDialog.dismiss();
                        productId= String.valueOf(productIdList.get(position));
                        new AsyncTask<String, String, String>() {

                            @Override
                            protected String doInBackground(String... params) {
                                HttpConfig httpConfig=new HttpConfig();
                                String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"deleteproductlist.json?productid="+productId);
                                return result;
                            }

                            @Override
                            protected void onPostExecute(String s) {
                                super.onPostExecute(s);
                                JSONObject jsonObject=null;
                                if(s!=null){
                                    try {
                                        jsonObject=new JSONObject(s);
                                        String status=jsonObject.optString("status");
                                        if(status.equals("success")){
                                            customDialog = new Dialog(context);
                                            customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                            customDialog.setContentView(R.layout.custom_messbox);
                                            alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                                            alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                                            alertMsgOkBtn.setVisibility(View.GONE);
                                            alertMessageText.setText(context.getResources().getString(R.string.remove_product_from_listing));
                                            customDialog.setCancelable(true);
                                            customDialog.setCanceledOnTouchOutside(true);

                                            customDialog.setOnCancelListener(
                                                    new DialogInterface.OnCancelListener() {
                                                        @Override
                                                        public void onCancel(DialogInterface dialog) {
                                                            customDialog.dismiss();
                                                            productList.remove(position);

                                                            notifyDataSetChanged();
                                                        }
                                                    }
                                            );

                                            customDialog.show();
                                            customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                                        }else{
                                            callAlertDialog("You have not removed the product from your listing. please try again");
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }else{
                                    callAlertDialog("Server Down... Please try again");
                                }
                            }

                        }.execute();


                    }
                });
                customDialog.show();
                customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


            }
        });
        holder.inuseImgLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                customDialog = new Dialog(context);
                customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customDialog.setContentView(R.layout.custom_messbox);
                alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                alertMsgOkBtn.setText(context.getResources().getString(R.string.alert_msg_yes));
                alertMessageText.setText(context.getResources().getString(R.string.pause_listing));
                customDialog.setCancelable(true);
                alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customDialog.dismiss();
                        productId= String.valueOf(productIdList.get(position));
                        new AsyncTask<String, String, String>() {

                            @Override
                            protected String doInBackground(String... params) {
                                HttpConfig httpConfig=new HttpConfig();
                                String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"pauseproduct.json?productid="+productId);
                                return result;
                            }

                            @Override
                            protected void onPostExecute(String s) {
                                super.onPostExecute(s);
                                JSONObject jsonObject=null;
                                if(s!=null){
                                    try {
                                        jsonObject=new JSONObject(s);
                                        String status=jsonObject.optString("status");
                                        if(status.equals("success")){
                                            customDialog = new Dialog(context);
                                            customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                            customDialog.setContentView(R.layout.custom_messbox);
                                            alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                                            alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                                            alertMsgOkBtn.setVisibility(View.GONE);
                                            alertMessageText.setText(context.getResources().getString(R.string.listing_status_updated));
                                            customDialog.setCancelable(true);
                                            customDialog.setCanceledOnTouchOutside(true);
                                            customDialog.setOnCancelListener(
                                                    new DialogInterface.OnCancelListener() {
                                                        @Override
                                                        public void onCancel(DialogInterface dialog) {
                                                            customDialog.dismiss();
                                                            productList.get(position).setIsPaused(1);
                                                            LinearLayout rl = (LinearLayout) view.getParent();
                                                            holder.notInuseImgLayout=(LinearLayout) rl.findViewById(R.id.not_inuse_layout);
                                                            holder.inuseImgLayout=(LinearLayout) rl.findViewById(R.id.inUse_icon_layout);
                                                            holder.notInuseImgLayout.setVisibility(View.VISIBLE);
                                                            holder.inuseImgLayout.setVisibility(View.GONE);
                                                            notifyDataSetChanged();

                                                        }
                                                    }
                                            );
                                            customDialog.show();
                                            customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);



                                        }else{
                                            callAlertDialog("Listing status Update Failed");
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }else{
                                    callAlertDialog("Server Down... Please try again");
                                }
                            }

                        }.execute();


                    }
                });
                customDialog.show();
                customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);





            }

        });
        holder.notInuseImgLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                customDialog = new Dialog(context);
                customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customDialog.setContentView(R.layout.custom_messbox);
                alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                alertMsgOkBtn.setText(context.getResources().getString(R.string.alert_msg_yes));
                alertMessageText.setText(context.getResources().getString(R.string.resume_listing_msg));
                customDialog.setCancelable(true);
                alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customDialog.dismiss();
                        productId= String.valueOf(productIdList.get(position));
                        new AsyncTask<String, String, String>() {
                            ProgressDialog progressDialog;
                            @Override
                            protected void onPreExecute() {

                                super.onPreExecute();
                                progressDialog = new ProgressDialog(context);
                                progressDialog.setMessage("Processing...");
                                progressDialog.setProgressDrawable(new ColorDrawable(
                                        android.graphics.Color.GRAY));
                                progressDialog.setCancelable(true);
                                progressDialog.setCanceledOnTouchOutside(false);
                                progressDialog.show();

                            }
                            @Override
                            protected String doInBackground(String... params) {
                                HttpConfig httpConfig=new HttpConfig();
                                String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"resumeproduct.json?productid="+productId);
                                return result;
                            }
                            @Override
                            protected void onPostExecute(String s) {
                                super.onPostExecute(s);
                                progressDialog.dismiss();
                                JSONObject jsonObject=null;
                                if(s!=null){
                                    try {
                                        jsonObject=new JSONObject(s);
                                        String status=jsonObject.optString("status");
                                        if(status.equals("success")){
                                            customDialog = new Dialog(context);
                                            customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                            customDialog.setContentView(R.layout.custom_messbox);
                                            alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                                            alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                                            alertMsgOkBtn.setVisibility(View.GONE);
                                            alertMessageText.setText(context.getResources().getString(R.string.listing_status_updated));
                                            customDialog.setCancelable(true);
                                            customDialog.setCanceledOnTouchOutside(true);
                                            customDialog.setOnCancelListener(
                                                    new DialogInterface.OnCancelListener() {
                                                        @Override
                                                        public void onCancel(DialogInterface dialog) {
                                                            customDialog.dismiss();
                                                            productList.get(position).setIsPaused(0);
                                                            LinearLayout rl = (LinearLayout) view.getParent();
                                                            holder.notInuseImgLayout=(LinearLayout) rl.findViewById(R.id.not_inuse_layout);
                                                            holder.inuseImgLayout=(LinearLayout) rl.findViewById(R.id.inUse_icon_layout);
                                                            holder.notInuseImgLayout.setVisibility(View.GONE);
                                                            holder.inuseImgLayout.setVisibility(View.VISIBLE);
                                                            notifyDataSetChanged();
                                                        }
                                                    }
                                            );

                                            customDialog.show();
                                            customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);



                                        }else{
                                            callAlertDialog("Listing status Update Failed");
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }else{
                                    callAlertDialog("Server Down... Please try again");
                                }
                            }
                        }.execute();




                    }
                });
                customDialog.show();
                customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);





            }
        });


        return vi;

    }



    public static class ViewHolder {

        public TextView productName,productDetails,productSellPrice,proRentPerDay,proRentPerWeek,proRentPerMonth;
        public ImageView imgList;
        public LinearLayout productLayout;
        public Button editBtn;
        public ImageView deleteImg;
        LinearLayout inuseImgLayout,notInuseImgLayout;

    }

    private void callAlertDialog(String message) {

        customDialog = new Dialog(context);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

}

