package info.com.neighbourbase.Adapter;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.R;
import info.com.neighbourbase.activity.AddGroupActivity;
import info.com.neighbourbase.activity.ChangeEmailPage;
import info.com.neighbourbase.activity.LoginActivity;
import info.com.neighbourbase.activity.UnblockMemberPage;
import info.com.neighbourbase.model.BlockListDto;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

/**
 * Created by Priya on 10-08-2017.
 */

public class UnblockMemberAdapter extends ArrayAdapter <BlockListDto> {

    private Context context;
    private String requestId;
    private String memberId;
    private TextView alertMessageText;
    private Button alertMsgOkBtn;
    private Dialog customDialog;
    private List<BlockListDto> blockList;
    private LayoutInflater inflater;


    public UnblockMemberAdapter(Context context, List<BlockListDto> blockList) {
        super(context, 0, blockList);

        this.context = context;
        this.blockList = blockList;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public View getView(final int position, final View convertView, ViewGroup parent) {
        View vi = convertView;
        ViewHolder holder;
        holder = new ViewHolder();
        if (vi == null) {
            vi = inflater.inflate(R.layout.unblock_member_list_item, null);
            vi.setTag(holder);
        } else {
            vi.getTag();
        }

        holder.blockMemberName = (TextView) vi.findViewById(R.id.block_member_name);
        holder.blockDetails = (TextView) vi.findViewById(R.id.block_details);
        holder.blockMemberImg = (ImageView) vi.findViewById(R.id.member_img);
        holder.unblockMemberBtn=(Button)vi.findViewById(R.id.unblock_member_btn);

        holder.blockMemberName.setText(blockList.get(position).getRequesterName());
        holder.blockDetails.setText("Blocked On :"+" "+String.valueOf(blockList.get(position).getDate() ));

        if(blockList.get(position).getRequesterImage()==null||blockList.get(position).getRequesterImage().equals("No Image")||blockList.get(position).getRequesterImage().equals("")) {
            Glide.clear(holder.blockMemberImg);
            holder.blockMemberImg.setImageResource(R.drawable.no_image);
        }else{
            Glide.with(context)
                    .load(Webconfig.CONTEXT_PATH1+"images/"+blockList.get(position).getRequesterImage()) .thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(holder.blockMemberImg);
        }
        holder.unblockMemberBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customDialog = new Dialog(context);
                customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customDialog.setContentView(R.layout.custom_messbox);
                alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                alertMsgOkBtn.setText(context.getResources().getString(R.string.alert_msg_yes));
                alertMessageText.setText(context.getResources().getString(R.string.unblock_ok_msg));
                customDialog.setCancelable(true);
                alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customDialog.dismiss();
                        requestId= String.valueOf(blockList.get(position).getRequestId());
                        memberId= String.valueOf(blockList.get(position).getMemberId());
                        new getUnblockResponse().execute();
                    }
                });
                customDialog.show();
                customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


            }
        });


        return vi;

    }



    private static class ViewHolder {

        private TextView blockMemberName,blockDetails;
        private ImageView blockMemberImg;
        private Button unblockMemberBtn;

    }

    private class getUnblockResponse extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            HttpConfig httpConfig=new HttpConfig();
            String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"unblockrequest.json?requestid="+requestId+"&memberId="+memberId);
            return result;

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){
                 if(s.trim().equals("success")){
                     customDialog = new Dialog(context);
                     customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                     customDialog.setContentView(R.layout.custom_messbox);
                     alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                     alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                     alertMsgOkBtn.setVisibility(View.GONE);
                     alertMessageText.setText(context.getResources().getString(R.string.you_unblock_member));
                     customDialog.setCancelable(true);
                     customDialog.setCanceledOnTouchOutside(true);
                     customDialog.setOnCancelListener(
                             new DialogInterface.OnCancelListener() {
                                 @Override
                                 public void onCancel(DialogInterface dialog) {
                                     customDialog.dismiss();
                                     context.startActivity(new Intent(context, UnblockMemberPage.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));

                                 }
                             }
                     );

                     customDialog.show();
                     customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                 }else if(s.trim().equals("fail")){
                     callAlertDialog("you are unblocked the member.. please try again");
                 }

            }else{
                callAlertDialog("Server Down... Please try again");
            }
        }
    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(context);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }
}
