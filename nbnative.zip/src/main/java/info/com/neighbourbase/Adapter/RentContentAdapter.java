package info.com.neighbourbase.Adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.io.InputStream;
import java.util.List;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.Webconfig;

/**
 * Created by Priya on 22-05-2017.
 */

public class RentContentAdapter extends RecyclerView.Adapter<RentContentAdapter.ViewHolder> {

    private Context context;
    List<ProductListingDto> rentProductList;
    LayoutInflater inflater;


    public RentContentAdapter(Context context, List<ProductListingDto> rentProductList) {
        super();
        this.context = context;
        this.rentProductList = rentProductList;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public RentContentAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.horizontal_list_item, viewGroup, false);
       RentContentAdapter.ViewHolder viewHolder = new RentContentAdapter.ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RentContentAdapter.ViewHolder viewHolder, int position) {
        viewHolder.textList.setText(rentProductList.get(position).getProductName());

        if(rentProductList.get(position).getPicture().equals("No Image")) {
            viewHolder.imgList.setImageResource(R.drawable.no_image);
        }else{
          // new RentContentAdapter.loadImage().execute("http://192.168.0.124:8080/neighbourbase/images/shareligionresources/9/productListing_Mon%20Oct%2019%2018-26-38%20MST%202015.jpg");
            Picasso.with(context)
                    .load(Webconfig.CONTEXT_PATH1+"images/"+rentProductList.get(position).getPicture())
                    .into(viewHolder.imgList);
        }



    }

    @Override
    public int getItemCount() {
        return rentProductList.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder  {

        public ImageView imgList;
        public TextView textList;


        public ViewHolder(View itemView) {
            super(itemView);
            imgList = (ImageView) itemView.findViewById(R.id.img_list);
            textList = (TextView) itemView.findViewById(R.id.text_list);

        }


    }


}

