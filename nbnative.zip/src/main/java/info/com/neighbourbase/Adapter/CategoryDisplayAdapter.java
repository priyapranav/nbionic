package info.com.neighbourbase.Adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.DataSetObserver;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import java.util.ArrayList;

import info.com.neighbourbase.R;

/**
 * Created by Priya on 12-06-2017.
 */

public class CategoryDisplayAdapter extends BaseAdapter {

    private LayoutInflater inflater;
    private ArrayList<String> rootCategory;
    private ArrayList<String> availableCategory;
    SharedPreferences preferences;
    int catId;
    private boolean checkState[];
    private Context context;



    private class ViewHolder {
        TextView rootCat;
        TextView availableCat;
        CheckBox catCheck;
    }

    public CategoryDisplayAdapter(Context context,ArrayList<String> rootCategory,ArrayList<String> availableCategory,int catId) {
        inflater = LayoutInflater.from(context);
        this.rootCategory = rootCategory;
        this.availableCategory = availableCategory;
        this.context=context;
        this.catId=catId;
        checkState = new boolean[rootCategory.size()];    }

    public int getCount() {
        return rootCategory.size();
    }

    public String getItem(int position) {
        return rootCategory.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View view, ViewGroup parent) {
        ViewHolder holder = null;
        if(view == null) {
            holder = new ViewHolder();
            preferences= PreferenceManager.getDefaultSharedPreferences(context);
            view = inflater.inflate(R.layout.category_select_for_listingpage_listitem, null);
            holder.rootCat = (TextView) view.findViewById(R.id.root_category_text);
            holder.catCheck=(CheckBox)view.findViewById(R.id.category_select_checkbox) ;
            if(catId!=-1){
                holder.catCheck.setChecked(checkState[catId]=true);
                update(catId);
            }else {
                holder.catCheck.setChecked(checkState[rootCategory.size() - 1] = true);
                update(catId);
            }

            holder.availableCat = (TextView) view.findViewById(R.id.sub_category_text);
            holder.catCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    int getPosition = (Integer) buttonView.getTag();  // Here we get the position that we have set for the checkbox using setTag.
                }
            });
            view.setTag(holder);
            view.setTag(R.id.root_category_text,holder.rootCat);
            view.setTag(R.id.sub_category_text,holder.availableCat);
            view.setTag(R.id.category_select_checkbox,holder.catCheck);
        } else {
            holder = (ViewHolder) view.getTag();
        }

        holder.catCheck.setTag(position);
        holder.rootCat.setText(context.getResources().getString(R.string.root_category)+" "+rootCategory.get(position));
        holder.availableCat.setText(context.getResources().getString(R.string.sub_category)+" "+availableCategory.get(position));
//        if (position == selectedPosition) {
//            holder.catCheck.setChecked(true);
//        } else holder.catCheck.setChecked(false);

        holder.catCheck.setChecked(checkState[position]);
        holder.catCheck.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View arg0) {

            for(int i=0;i<checkState.length;i++)
            {
                if(i==position)
                {
                    checkState[i]=true;
                    update(position);

                }
                else
                {
                    checkState[i]=false;
                }
            }
            notifyDataSetChanged();

        }

            private void update(int i) {
                SharedPreferences.Editor e = preferences.edit();
                e.putString("categoryId", String.valueOf(i));
                e.commit();
            }
        });


        return view;
    }


    private void update(int position) {
        SharedPreferences.Editor e = preferences.edit();
        e.putString("categoryId", String.valueOf(position));
        e.commit();
    }
//    private View.OnClickListener onStateChangedListener(final CheckBox checkBox, final int position) {
//        return new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                if (checkBox.isChecked()) {
////                    selectedPosition = position;
////                } else {
////                    selectedPosition =-1;
////                }
//                if(checkBox.isChecked())
//                {
//                    selectedPosition =  position;
//                }
//                else{
//                    selectedPosition = -1;
//                }
//                notifyDataSetChanged();
//
//            }
//        };
//    }
}