package info.com.neighbourbase.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.List;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.utility.Webconfig;


public class ProductViewAllAdapter extends ArrayAdapter <ProductListingDto>  {

    private Context context;
    List<ProductListingDto> productList;
    LayoutInflater inflater;


    public ProductViewAllAdapter(Context context, List<ProductListingDto> productList) {
        super(context, 0, productList);

        this.context = context;
        this.productList = productList;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        ViewHolder holder;
        holder = new ViewHolder();
        if (vi == null) {
            vi = inflater.inflate(R.layout.product_list_item, null);
            vi.setTag(holder);
        } else {
            vi.getTag();
        }
        holder.productName = (TextView) vi.findViewById(R.id.productName);
        holder.productDetails = (TextView) vi.findViewById(R.id.productDetail);
        holder.imgList = (ImageView) vi.findViewById(R.id.img_list);
        holder.productLayout=(LinearLayout)vi.findViewById(R.id.product_layout);
        holder.productSellPrice=(TextView)vi.findViewById(R.id.productSellPrice);
        holder.proRentPerDay=(TextView)vi.findViewById(R.id.rentPricePerDay);
        holder.proRentPerWeek=(TextView)vi.findViewById(R.id.rentPricePerWeek);
        holder.proRentPerMonth=(TextView)vi.findViewById(R.id.rentPricePerMonth);

        //holder.productName.setText(productList.get(position).getProductName());
        holder.productName.setText(productList.get(position).getOwnerName()+" 's "+productList.get(position).getProductName());
        holder.productDetails.setText(productList.get(position).getCategoryName()+" | "+productList.get(position).getArea()+" | "+"POSTED ON: "+productList.get(position).getCreatedDateTime());

        if((productList.get(position).getPicture()==null)||productList.get(position).getPicture().equals("No Image")||productList.get(position).getPicture().equals("") ) {
            Glide.clear(holder.imgList);
            holder.imgList.setImageResource(R.drawable.no_image);
        }else{
            //Glide.with(holder.imgList.getContext()).load(Webconfig.CONTEXT_PATH1+"images/"+productList.get(position).getPicture()).into(holder.imgList);

            Glide.with(context)
                    .load(Webconfig.CONTEXT_PATH1+"images/"+productList.get(position).getPicture()).thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(holder.imgList);
        }
        if(productList.get(position).getTransTypeId()==1||productList.get(position).getTransTypeId()==4){
            holder.productSellPrice.setVisibility(View.GONE);
            holder.proRentPerDay.setVisibility(View.GONE);
            holder.proRentPerWeek.setVisibility(View.GONE);
            holder.proRentPerMonth.setVisibility(View.GONE);
        }else if(productList.get(position).getTransTypeId()==3){
            holder.proRentPerDay.setVisibility(View.GONE);
            holder.proRentPerWeek.setVisibility(View.GONE);
            holder.proRentPerMonth.setVisibility(View.GONE);
            if(productList.get(position).getSalePrice()==0.0){
                holder.productSellPrice.setVisibility(View.GONE);
            }else{
                holder.productSellPrice.setVisibility(View.VISIBLE);
                holder.productSellPrice.setText(context.getResources().getString(R.string.rupees)+" "+String.valueOf(productList.get(position).getSalePrice()));
            }
        }else if(productList.get(position).getTransTypeId()==2){
            holder.productSellPrice.setVisibility(View.GONE);
            if(productList.get(position).getPriceperday()==0){
                holder.proRentPerDay.setVisibility(View.GONE);
            }else{
                holder.proRentPerDay.setVisibility(View.VISIBLE);
                holder.proRentPerDay.setText(context.getResources().getString(R.string.rupees)+" "+String.valueOf(productList.get(position).getPriceperday())+" "+context.getResources().getString(R.string.per_day));

            }
            if(productList.get(position).getPriceperweek()==0){
                holder.proRentPerWeek.setVisibility(View.GONE);
            }else{
                holder.proRentPerWeek.setVisibility(View.VISIBLE);
                holder.proRentPerWeek.setText(context.getResources().getString(R.string.rupees)+" "+String.valueOf(productList.get(position).getPriceperweek())+" "+context.getResources().getString(R.string.per_week));

            }
            if(productList.get(position).getPricepermonth()==0){
                holder.proRentPerMonth.setVisibility(View.GONE);
            }else{
                holder.proRentPerMonth.setVisibility(View.VISIBLE);
                holder.proRentPerMonth.setText(context.getResources().getString(R.string.rupees)+" "+String.valueOf(productList.get(position).getPricepermonth())+" "+context.getResources().getString(R.string.per_month));
            }

        }



        return vi;

    }




    public static class ViewHolder {

        public TextView productName,productDetails,productSellPrice,proRentPerDay,proRentPerWeek,proRentPerMonth;
        public ImageView imgList;
        public LinearLayout productLayout;

    }

}
