package info.com.neighbourbase.Adapter;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.List;

import info.com.neighbourbase.R;

import info.com.neighbourbase.activity.GroupEditPage;
import info.com.neighbourbase.activity.GroupMemberPage;
import info.com.neighbourbase.activity.GroupPage;
import info.com.neighbourbase.activity.HomeScreen;
import info.com.neighbourbase.activity.ProfilePicturePage;
import info.com.neighbourbase.activity.ViewPage;
import info.com.neighbourbase.model.NetworkDto;
import info.com.neighbourbase.model.NetworkMemberDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

/**
 * Created by Priya on 25-07-2017.
 */
public class GroupMemberAdapter extends ArrayAdapter<NetworkMemberDto> {

    private Context context;
    private List<NetworkMemberDto> memberList;
    private Long loggedMemberId;
    private Dialog customDialog;
    private TextView alertMessageText;
    private Button alertMsgOkBtn;
    private int primaryFlag;
    LayoutInflater inflater;


    public GroupMemberAdapter(Context context, List<NetworkMemberDto> memberList, Long loggedMemberId, int primaryFlag) {
        super(context, 0,memberList);

        this.context = context;
        this.loggedMemberId=loggedMemberId;
        this.primaryFlag=primaryFlag;
        this.memberList = memberList;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public View getView(final int position, final View convertView, ViewGroup parent) {
        View vi = convertView;
        ViewHolder holder;
        holder = new ViewHolder();
        if (vi == null) {
            vi = inflater.inflate(R.layout.group_member_list_item, null);
            vi.setTag(holder);
        } else {
            vi.getTag();
        }
        vi.setFocusable(false);
        holder.memberName = (TextView) vi.findViewById(R.id.member_name);
        holder.memberDetails = (TextView) vi.findViewById(R.id.member_detail);
        holder.memberImage = (ImageView) vi.findViewById(R.id.member_image);
        holder.removeNetworkBtn=(Button)vi.findViewById(R.id.remove_btn);
        holder.exitNetworkBtn=(Button)vi.findViewById(R.id.exit_network_btn);
        holder.assignModeratorBtn=(Button)vi.findViewById(R.id.assign_moderator_btn);

        holder.memberName.setText(memberList.get(position).getName());
        if(memberList.get(position).getLocation()==null){
            holder.memberDetails.setVisibility(View.GONE);

        }else {
            holder.memberDetails.setText(memberList.get(position).getLocation());
        }

        if(memberList.get(position).getPicture()==null||memberList.get(position).getPicture().equals("No Image")||memberList.get(position).getPicture().equals("")) {
            Glide.clear(holder.memberImage);
            holder.memberImage.setImageResource(R.drawable.no_image);
        }else{
            Glide.with(context)
                    .load(Webconfig.CONTEXT_PATH1+"images/"+memberList.get(position).getPicture()) .thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(holder.memberImage);
        }

        if(memberList.get(position).getPrimaryFlag()>0&& memberList.get(position).getMemberId()==loggedMemberId){
            holder.removeNetworkBtn.setVisibility(View.GONE);
            holder.exitNetworkBtn.setVisibility(View.VISIBLE);
            holder.assignModeratorBtn.setVisibility(View.GONE);
        }else if(primaryFlag>0&&memberList.get(position).getPrimaryFlag()==0){
            holder.removeNetworkBtn.setVisibility(View.VISIBLE);
            holder.exitNetworkBtn.setVisibility(View.GONE);
            holder.assignModeratorBtn.setVisibility(View.VISIBLE);
        }else{
            holder.removeNetworkBtn.setVisibility(View.GONE);
            holder.exitNetworkBtn.setVisibility(View.GONE);
            holder.assignModeratorBtn.setVisibility(View.GONE);
        }

        holder.assignModeratorBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customDialog = new Dialog(context);
                customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customDialog.setContentView(R.layout.custom_messbox);
                alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                alertMsgOkBtn.setText(context.getResources().getString(R.string.alert_msg_yes));
                alertMessageText.setText(context.getResources().getString(R.string.add_moderator_conformation));
                customDialog.setCancelable(true);
                alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customDialog.dismiss();
                        final String memberId=String.valueOf(memberList.get(position).getMemberId());
                        final String networkId=String.valueOf(memberList.get(position).getNetworkId());
                        new AsyncTask<String, String, String>() {
                            ProgressDialog progressDialog;
                            @Override
                            protected void onPreExecute() {
                                super.onPreExecute();
                                progressDialog = new ProgressDialog( context);
                                progressDialog.setMessage("Processing...");
                                progressDialog.setProgressDrawable(new ColorDrawable(
                                        android.graphics.Color.GRAY));
                                progressDialog.setCancelable(true);
                                progressDialog.setCanceledOnTouchOutside(false);
                                progressDialog.show();
                            }

                            @Override
                            protected String doInBackground(String... params) {
                                HttpConfig httpConfig=new HttpConfig();
                                String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"assignmoderator.json?memberid="+memberId+"&networkid="+networkId);
                                return result;
                            }

                            @Override
                            protected void onPostExecute(String s) {
                                super.onPostExecute(s);
                                progressDialog.dismiss();
                                if(s!=null){
                                    if(s.trim().equals("SUCCESS")){
                                        customDialog = new Dialog(context);
                                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                        customDialog.setContentView(R.layout.custom_messbox);
                                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                                        alertMsgOkBtn.setVisibility(View.GONE);
                                        alertMessageText.setText(context.getResources().getString(R.string.moderator_add_success_msg));
                                        customDialog.setCancelable(true);
                                        customDialog.setCanceledOnTouchOutside(true);
                                        customDialog.setOnCancelListener(
                                                new DialogInterface.OnCancelListener() {
                                                    @Override
                                                    public void onCancel(DialogInterface dialog) {
                                                        customDialog.dismiss();
                                                        getContext().startActivity(new Intent(context, GroupMemberPage.class));
                                                        ((Activity)context).finish();
                                                    }
                                                }
                                        );


                                        customDialog.show();
                                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                                    }else{
                                        if(s.trim().equals("FAIL")){
                                            callAlertDialog("Moderator Add Failed");
                                        }

                                    }

                                }else{
                                    callAlertDialog("Server Down... Please try again");
                                }
                            }
                        }.execute();

                    }
                });
                customDialog.show();
                customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);



            }
        });


        holder.removeNetworkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customDialog = new Dialog(context);
                customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customDialog.setContentView(R.layout.custom_messbox);
                alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                alertMsgOkBtn.setText(context.getResources().getString(R.string.alert_msg_yes));
                alertMessageText.setText(context.getResources().getString(R.string.sure_to_remove_from_network));
                customDialog.setCancelable(true);
                alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customDialog.dismiss();
                        final String memberId=String.valueOf(memberList.get(position).getMemberId());
                        final String networkId=String.valueOf(memberList.get(position).getNetworkId());
                        new AsyncTask<String, String, String>() {
                            ProgressDialog progressDialog;
                            @Override
                            protected void onPreExecute() {
                                super.onPreExecute();
                                progressDialog = new ProgressDialog( context);
                                progressDialog.setMessage("Processing...");
                                progressDialog.setProgressDrawable(new ColorDrawable(
                                        android.graphics.Color.GRAY));
                                progressDialog.setCancelable(true);
                                progressDialog.setCanceledOnTouchOutside(false);
                                progressDialog.show();
                            }

                            @Override
                            protected String doInBackground(String... params) {
                                HttpConfig httpConfig=new HttpConfig();
                                String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"deletenetworkmember.json?memberid="+memberId+"&networkid="+networkId);
                                return result;
                            }

                            @Override
                            protected void onPostExecute(String s) {
                                super.onPostExecute(s);
                                progressDialog.dismiss();
                                if(s!=null){
                                    if(s.trim().equals("SUCCESS")){
                                        customDialog = new Dialog(context);
                                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                        customDialog.setContentView(R.layout.custom_messbox);
                                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                                        alertMsgOkBtn.setVisibility(View.GONE);
                                        alertMessageText.setText(context.getResources().getString(R.string.member_remove_group));
                                        customDialog.setCancelable(true);
                                        customDialog.setCanceledOnTouchOutside(true);
                                        customDialog.setOnCancelListener(
                                                new DialogInterface.OnCancelListener() {
                                                    @Override
                                                    public void onCancel(DialogInterface dialog) {
                                                        customDialog.dismiss();
                                                        getContext().startActivity(new Intent(context, GroupMemberPage.class));
                                                        ((Activity)context).finish();
                                                    }
                                                }
                                        );

                                        customDialog.show();
                                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                                    }else{
                                        if(s.trim().equals("FAIL")){
                                            callAlertDialog("Member Can't be Removed, Please try again...");
                                        }

                                    }

                                }else{
                                    callAlertDialog("Server Down... Please try again");
                                }
                            }
                        }.execute();
                    }
                });
                customDialog.show();
                customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


            }
        });

        holder.exitNetworkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customDialog = new Dialog(context);
                customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customDialog.setContentView(R.layout.custom_messbox);
                alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                alertMsgOkBtn.setText(context.getResources().getString(R.string.alert_msg_yes));
                alertMessageText.setText(context.getResources().getString(R.string.sure_to_leave_network));
                customDialog.setCancelable(true);
                alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customDialog.dismiss();
                        final String memberId=String.valueOf(memberList.get(position).getMemberId());
                        final String networkId=String.valueOf(memberList.get(position).getNetworkId());
                        new AsyncTask<String, String, String>() {
                            ProgressDialog progressDialog;
                            @Override
                            protected void onPreExecute() {
                                super.onPreExecute();
                                progressDialog = new ProgressDialog( context);
                                progressDialog.setMessage("Processing...");
                                progressDialog.setProgressDrawable(new ColorDrawable(
                                        android.graphics.Color.GRAY));
                                progressDialog.setCancelable(true);
                                progressDialog.setCanceledOnTouchOutside(false);
                                progressDialog.show();
                            }

                            @Override
                            protected String doInBackground(String... params) {
                                HttpConfig httpConfig=new HttpConfig();
                                String result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"leavenetwork.json?memberid="+memberId+"&networkid="+networkId);
                                return result;
                            }

                            @Override
                            protected void onPostExecute(String s) {
                                super.onPostExecute(s);
                                progressDialog.dismiss();
                                if(s!=null){
                                    if(s.trim().equals("SUCCESS")){
                                        customDialog = new Dialog(context);
                                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                        customDialog.setContentView(R.layout.custom_messbox);
                                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                                        alertMsgOkBtn.setVisibility(View.GONE);
                                        alertMessageText.setText(context.getResources().getString(R.string.exit_from_network));
                                        customDialog.setCancelable(true);
                                        customDialog.setCanceledOnTouchOutside(true);
                                        customDialog.setOnCancelListener(
                                                new DialogInterface.OnCancelListener() {
                                                    @Override
                                                    public void onCancel(DialogInterface dialog) {
                                                        customDialog.dismiss();
                                                        getContext().startActivity(new Intent(context, GroupPage.class));
                                                        ((Activity)context).finish();
                                                    }
                                                }
                                        );
                                        customDialog.show();
                                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                                    }else{
                                        if(s.trim().equals("FAIL")){
                                            callAlertDialog("you Can't be exit, Please try again...");
                                        }

                                    }

                                }else{
                                    callAlertDialog("Server Down... Please try again");
                                }
                            }
                        }.execute();

                    }
                });
                customDialog.show();
                customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


            }
        });
      


        return vi;

    }

    public static class ViewHolder {

        public TextView memberName,memberDetails;
        public ImageView memberImage;
        public Button removeNetworkBtn,exitNetworkBtn,assignModeratorBtn;
       

    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(context);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

}
