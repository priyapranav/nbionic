package info.com.neighbourbase.Adapter;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.List;
import info.com.neighbourbase.R;
import info.com.neighbourbase.activity.GroupInvitationPage;
import info.com.neighbourbase.activity.GroupMemberPage;
import info.com.neighbourbase.model.InvitationDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;


/**
 * Created by SIVANATH on 16-Feb-18.
 */

public class GroupInvitationAdapter extends ArrayAdapter<InvitationDto> {

    private Context context;
    List<InvitationDto> inviteList;
    LayoutInflater inflater;
    private Dialog customDialog;
    private TextView alertMessageText;
    private Button alertMsgOkBtn;


    public GroupInvitationAdapter(Context context, List<InvitationDto> inviteList) {
        super(context, 0,inviteList);

        this.context = context;
        this.inviteList = inviteList;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        GroupInvitationAdapter.ViewHolder holder;
        holder = new GroupInvitationAdapter.ViewHolder();
        if (vi == null) {
            vi = inflater.inflate(R.layout.group_invitation_list_items, null);
            vi.setTag(holder);
        } else {
            vi.getTag();
        }
        vi.setFocusable(false);
        holder.invitationMsgTxt=(TextView)vi.findViewById(R.id.invitation_msg_text);
        holder.invitationDate=(TextView)vi.findViewById(R.id.invitation_date);
        holder.accpetBtn=(Button)vi.findViewById(R.id.accept_button);
        holder.declineBtn=(Button)vi.findViewById(R.id.decline_button);
        holder.inviteGroupImage=(ImageView)vi.findViewById(R.id.invite_group_image);
        if(inviteList.get(position).getNetworkDto().getPicture()==null||inviteList.get(position).getNetworkDto().getPicture().equals("No Image")||inviteList.get(position).getNetworkDto().getPicture().equals("")) {
            Glide.clear(holder.inviteGroupImage);
            holder.inviteGroupImage.setImageResource(R.drawable.no_image);
        }else{
            Glide.with(context)
                    .load(Webconfig.CONTEXT_PATH1+"images/"+inviteList.get(position).getNetworkDto().getPicture()) .thumbnail(0.5f)
                    .crossFade()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(holder.inviteGroupImage);
        }

        holder.invitationMsgTxt.setText(Html.fromHtml("Your friend " +"<font color=\"#15B37A\">"+  inviteList.get(position).getMember().getFirstName()+ "</font>"+" invited to join in private Group "+"<font color=\"#15B37A\">"+inviteList.get(position).getNetworkDto().getName()+ "</font>"));

        holder.invitationDate.setText(inviteList.get(position).getDateStr());
        holder.declineBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int networkId= (int) inviteList.get(position).getNetworkDto().getNetworkId();
                final int inviteMemId=(int)inviteList.get(position).getMember().getMemberId();
                final String emailid=inviteList.get(position).getEmailId();
                customDialog = new Dialog(context);
                customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customDialog.setContentView(R.layout.custom_messbox);
                alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                alertMsgOkBtn.setText(context.getResources().getString(R.string.alert_msg_yes));
                alertMessageText.setText("Are you sure to decline this invitation from your friend?");
                customDialog.setCancelable(true);
                alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customDialog.dismiss();
                        new AsyncTask<String, String, String>() {
                            ProgressDialog progressDialog;
                            @Override
                            protected void onPreExecute() {
                                super.onPreExecute();
                                progressDialog = new ProgressDialog( context);
                                progressDialog.setMessage("Processing...");
                                progressDialog.setProgressDrawable(new ColorDrawable(
                                        android.graphics.Color.GRAY));
                                progressDialog.setCancelable(true);
                                progressDialog.setCanceledOnTouchOutside(false);
                                progressDialog.show();
                            }

                            @Override
                            protected String doInBackground(String... strings) {
                                HttpConfig httpConfig=new HttpConfig();
                                String result;
                                result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"declineInvite.json?networkId="+networkId+"&invitedMemId="+inviteMemId+"&emailId="+emailid);
                                return result;
                            }

                            @Override
                            protected void onPostExecute(String s) {
                                super.onPostExecute(s);
                                progressDialog.dismiss();
                                if(s!=null){
                                    if(s.trim().equals("true")){
                                        customDialog = new Dialog(context);
                                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                        customDialog.setContentView(R.layout.custom_messbox);
                                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                                        alertMsgOkBtn.setVisibility(View.GONE);
                                        alertMessageText.setText("You are declined the invitation from "+inviteList.get(position).getNetworkDto().getName());
                                        customDialog.setCancelable(true);
                                        customDialog.setCanceledOnTouchOutside(true);
                                        customDialog.setOnCancelListener(
                                                new DialogInterface.OnCancelListener() {
                                                    @Override
                                                    public void onCancel(DialogInterface dialog) {
                                                        customDialog.dismiss();
                                                        getContext().startActivity(new Intent(context, GroupInvitationPage.class));
                                                        ((Activity)context).finish();
                                                    }
                                                }
                                        );

                                        customDialog.show();
                                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                                    }
                                    else if(s.trim().equals("false")){
                                        callAlertDialog("You can't decline the invitation from "+inviteList.get(position).getNetworkDto().getName()+" now. Please try again later..");
                                    }
                                }else{
                                    callAlertDialog("Server Down... Please try again");
                                }
                            }
                        }.execute();
                    }
                });
                customDialog.show();
                customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);




            }
        });
        holder.accpetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int networkId= (int) inviteList.get(position).getNetworkDto().getNetworkId();
                final int inviteMemId=(int)inviteList.get(position).getMember().getMemberId();
                final String emailId=inviteList.get(position).getEmailId();
                customDialog = new Dialog(context);
                customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                customDialog.setContentView(R.layout.custom_messbox);
                alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                alertMsgOkBtn.setText(context.getResources().getString(R.string.alert_msg_yes));
                alertMessageText.setText("Are you sure to accept this invitation from your friend?");
                customDialog.setCancelable(true);
                alertMsgOkBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customDialog.dismiss();
                        new AsyncTask<String, String, String>() {
                            ProgressDialog progressDialog;
                            @Override
                            protected void onPreExecute() {
                                super.onPreExecute();
                                progressDialog = new ProgressDialog( context);
                                progressDialog.setMessage("Processing...");
                                progressDialog.setProgressDrawable(new ColorDrawable(
                                        android.graphics.Color.GRAY));
                                progressDialog.setCancelable(true);
                                progressDialog.setCanceledOnTouchOutside(false);
                                progressDialog.show();
                            }

                            @Override
                            protected String doInBackground(String... strings) {
                                HttpConfig httpConfig=new HttpConfig();
                                String result;
                                result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"acceptGroupInvite.json?networkId="+networkId+"&invitedMemId="+inviteMemId+"&emailId="+emailId);
                                return result;
                            }

                            @Override
                            protected void onPostExecute(String s) {
                                super.onPostExecute(s);
                                progressDialog.dismiss();
                                if(s!=null){
                                    if(s.trim().equals("true")){
                                        customDialog = new Dialog(context);
                                        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                        customDialog.setContentView(R.layout.custom_messbox);
                                        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
                                        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
                                        alertMsgOkBtn.setVisibility(View.GONE);
                                        alertMessageText.setText("You are now included in the "+inviteList.get(position).getNetworkDto().getName());
                                        customDialog.setCancelable(true);
                                        customDialog.setCanceledOnTouchOutside(true);
                                        customDialog.setOnCancelListener(
                                                new DialogInterface.OnCancelListener() {
                                                    @Override
                                                    public void onCancel(DialogInterface dialog) {
                                                        customDialog.dismiss();
                                                        getContext().startActivity(new Intent(context, GroupInvitationPage.class));
                                                        ((Activity)context).finish();
                                                    }
                                                }
                                        );

                                        customDialog.show();
                                        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


                                    }
                                    else if(s.trim().equals("false")){
                                        callAlertDialog("You are not included in the "+inviteList.get(position).getNetworkDto().getName()+" now. Please try again later..");
                                    }
                                }else{
                                    callAlertDialog("Server Down... Please try again");
                                }
                            }
                        }.execute();
                    }
                });
                customDialog.show();
                customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);





            }
        });


        return vi;

    }

    public static class ViewHolder {
        public TextView invitationMsgTxt;
        public Button accpetBtn;
        public Button declineBtn;
        public ImageView inviteGroupImage;
        public TextView invitationDate;

    }
    private void callAlertDialog(String message) {

        customDialog = new Dialog(context);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.custom_messbox);
        customDialog.setCancelable(true);
        alertMessageText=(TextView)customDialog.findViewById(R.id.message_text);
        alertMsgOkBtn=(Button)customDialog.findViewById(R.id.ok_btn);
        alertMessageText.setText(message);
        alertMsgOkBtn.setVisibility(View.GONE);
        customDialog.show();
        customDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


    }

}
