package info.com.neighbourbase.Adapter;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.util.List;

import info.com.neighbourbase.R;
import info.com.neighbourbase.model.NotificationThreadDto;
import info.com.neighbourbase.utility.Constant;

/**
 * Created by user on 30-06-2017.
 */

public class ChatMessageAdapter extends ArrayAdapter<NotificationThreadDto> {

private Context context;
        List<NotificationThreadDto> notificationThreadDtoList;
        LayoutInflater inflater;


public ChatMessageAdapter(Context context, List<NotificationThreadDto> dtoList) {
        super(context, 0, dtoList);

        this.context = context;
        this.notificationThreadDtoList = dtoList;
        inflater = (LayoutInflater) context
        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        }


@Override
public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        ChatMessageAdapter.ViewHolder holder;
        holder = new ChatMessageAdapter.ViewHolder();
        if (vi == null) {
        vi = inflater.inflate(R.layout.chat_message_list, null);
        vi.setTag(holder);
        } else {
        vi.getTag();
        }
        holder.messageBgLayout = (LinearLayout) vi.findViewById(R.id.chat_message_layout);
        holder.chatMessageText = (TextView) vi.findViewById(R.id.message_text_chat);
        holder.chatDate = (TextView) vi.findViewById(R.id.message_date_text);
        holder.recvdMessageLayout = (LinearLayout) vi.findViewById(R.id.recv_chat_message_layout);
        holder.chatRecvdMessageTxt = (TextView) vi.findViewById(R.id.recv_message_text_chat);
        holder.chatRecvDateTxt = (TextView) vi.findViewById(R.id.recv_message_date_text);


        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        if(Constant.requestType.equalsIgnoreCase("sent")) {
            if (notificationThreadDtoList.get(position).getIsOwnerMessage() == 0) {
                holder.chatMessageText.setText(notificationThreadDtoList.get(position).getMessage());
                holder.chatDate.setText(notificationThreadDtoList.get(position).getCreatedDateTime());
                holder.messageBgLayout.setVisibility(View.VISIBLE);
                holder.recvdMessageLayout.setVisibility(View.GONE);

            } else if (notificationThreadDtoList.get(position).getIsOwnerMessage() == 1) {
                holder.chatRecvdMessageTxt.setText(notificationThreadDtoList.get(position).getMessage());
                holder.chatRecvDateTxt.setText(notificationThreadDtoList.get(position).getCreatedDateTime());
                holder.messageBgLayout.setVisibility(View.GONE);
                holder.recvdMessageLayout.setVisibility(View.VISIBLE);

            }
        }else if(Constant.requestType.equalsIgnoreCase("received")){
            if (notificationThreadDtoList.get(position).getIsOwnerMessage() == 1) {
                holder.chatMessageText.setText(notificationThreadDtoList.get(position).getMessage());
                holder.chatDate.setText(notificationThreadDtoList.get(position).getCreatedDateTime());
                holder.messageBgLayout.setVisibility(View.VISIBLE);
                holder.recvdMessageLayout.setVisibility(View.GONE);

            } else if (notificationThreadDtoList.get(position).getIsOwnerMessage() == 0) {
                holder.chatRecvdMessageTxt.setText(notificationThreadDtoList.get(position).getMessage());
                holder.chatRecvDateTxt.setText(notificationThreadDtoList.get(position).getCreatedDateTime());
                holder.messageBgLayout.setVisibility(View.GONE);
                holder.recvdMessageLayout.setVisibility(View.VISIBLE);

            }
        }
        return vi;

        }




public static class ViewHolder {

    public TextView chatMessageText, chatDate, chatRecvdMessageTxt, chatRecvDateTxt;
    public LinearLayout messageBgLayout, recvdMessageLayout;

}

}