package info.com.neighbourbase.utility;

import android.support.design.widget.TextInputLayout;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Pattern;

import info.com.neighbourbase.activity.LoginActivity;

/**
 * Created by SIVANATH on 29-Nov-17.
 */

public class TextValidation {

    // Regular Expression
    // you can change the expression based on your need
    private static final String EMAIL_REGEX = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    private static final String PHONE_REGEX = "\\d{3}-\\d{7}";
    private static final String NAME_REGEX = "[a-zA-Z]";

    // Error Messages
    private static final String REQUIRED_MSG = "required       ";
    private static final String INVALID_PHONE_NUMBER_MSG = "10 digit is required";
    //	private static final String REQUIRED_MSG = "wifin";
    private static final String COMPARISION_MSG = "password not matching";
    private static final String EMAIL_MSG = "invalid email";
    private static final String PHONE_MSG = "Invalid";

    // call this method when you need to check email validation
    public static boolean isEmailAddress(String string, boolean required) {
        return isValid(string, EMAIL_REGEX, EMAIL_MSG, required);
    }

    // call this method when you need to check phone number validation
    public static boolean isPhoneNumber(String string, boolean required) {
        return isValid(string, PHONE_REGEX, PHONE_MSG, required);
    }

    public static boolean isName(String string, boolean required) {
        return isValid(string, NAME_REGEX, PHONE_MSG, required);
    }

    // return true if the input field is valid, based on the parameter passed
    public static boolean isValid(String string, String regex,
                                  String errMsg, boolean required) {


        // text required and editText is blank, so return false
        if (required && !hasText(string))
            return false;

        // pattern doesn't match so returning false
        if (required && !Pattern.matches(regex, string)) {
            return false;
        }

        return true;
    }

    // check the input field has any text or not
    // return true if it contains text otherwise false

    public static boolean isPin(String string) {

        // length 0 means there is no text
        if (string.length() != 6) {
            return false;
        }

        return true;
    }
    public static boolean hasText(String string) {

        // length 0 means there is no text
        if (string.length() == 0) {
            return false;
        }
        return true;
    }


    public static boolean hasfName(String string) {

        // length 0 means there is no text
        if ((string.length() == 0) || (string.length() >= 20)) {

            return false;
        }
        if (!Character.isLetter(string.charAt(0))){

            return false;
        }

        return true;
    }
    public static boolean hasName(String string) {

        // length 0 means there is no text
        if (string.length() == 0 || string.length() >= 20) {
            return false;
        }

        return true;
    }

    public static boolean hasUserName(EditText editText) {

        String text = editText.getText().toString().trim();
        editText.setError(null);

        // length 0 means there is no text
        if ((text.length() == 0) || (text.length() >= 20)) {
            editText.setError(REQUIRED_MSG);
            return false;
        }
        if (!Character.isLetter(text.charAt(0))){
            editText.setError("Username must begin with alphabet");
            return false;
        }
        if(text.length()<6){
            editText.setError("User name must have atleast 6 letters");
            return false;
        }

        return true;
    }

    public static boolean hasValidPhoneNumber(String string) {



        // length 0 means there is no text
        if (string.length() != 10) {
            return false;
        }

        return true;
    }
    public static boolean hasCompared(EditText editText, TextInputLayout textInputLayout, EditText editText1, TextInputLayout textInputLayout1) {

        String text = editText.getText().toString().trim();
        String text1=editText1.getText().toString().trim();
        textInputLayout.setError(null);
        textInputLayout1.setError(null);
        // length 0 means there is no text
        if (text!=text1) {
            textInputLayout.setError(COMPARISION_MSG);
            return false;
        }

        return true;
    }

    // check the input field has any text or not
    // return true if it contains text otherwise false
    public static boolean hasText1(TextView editText) {

        String text = editText.getText().toString().trim();
        editText.setError(null);

        // length 0 means there is no text
        if (text.length() == 0) {
            editText.setError(REQUIRED_MSG);
            return false;
        }

        return true;
    }
}
