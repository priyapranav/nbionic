package info.com.neighbourbase.utility;

/**
 * Created by user on 04-08-2017.
 */

public interface MessageCountListener {
    void messageReceived(Integer messageCount);
}
