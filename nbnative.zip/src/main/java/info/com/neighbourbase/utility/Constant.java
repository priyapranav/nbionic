package info.com.neighbourbase.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import info.com.neighbourbase.model.CategoryDto;
import info.com.neighbourbase.model.ProductListingDto;

/**
 * Created by user on 09-06-2017.
 */

public class Constant {
    public static List<ProductListingDto> productListingDtos = new ArrayList<ProductListingDto>();
    public static List<ProductListingDto> myListingProductListingDtos=new ArrayList<>();
    public static List<ProductListingDto> groupProductListingDtos=new ArrayList<>();

    public static int currentPage = 0;
    public static int myListCurrentPage=0;
    public static int groupListCurrentPage=0;
    public static long requestId = 0, requestStatusId=0;
    public static String myListGroupName = null;
    public static String myListGroupId = null;
    public static String requestType = "received";
    public static List<CategoryDto> categoryDtoListLevel1 = new ArrayList<CategoryDto>();
    public static Map<Long, String> categoryIdNameMap = new HashMap<>();
    public static long categoryId = 0, messageUnreadCount = 0;
    public static int tabPosition = 0;
    public static Integer newMessageCount = 0;
    public static double searchRadius=0.0;

    public static final String TOPIC_GLOBAL = "global";

    // broadcast receiver intent filters
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";

    // id to handle the notification in the notification tray
    public static final int NOTIFICATION_ID = 100;
    public static final int NOTIFICATION_ID_BIG_IMAGE = 101;

    public static final String SHARED_PREF = "ah_firebase";

    public static String currentActivity = "HomeScreen";
    public static String previousActivity;
    public static String groupName;
    public static String transType = "";
}
