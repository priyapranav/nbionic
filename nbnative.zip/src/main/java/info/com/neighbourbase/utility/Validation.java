package info.com.neighbourbase.utility;
import android.support.design.widget.TextInputLayout;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Pattern;

/**
 * @author Nila
 * 
 * This will validate the email address and phone number in the registration
 * page
 */

public class Validation {

	// Regular Expression
	// you can change the expression based on your need
	private static final String EMAIL_REGEX = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	private static final String PHONE_REGEX = "\\d{3}-\\d{7}";
	private static final String NAME_REGEX = "[a-zA-Z]";

	// Error Messages
	private static final String REQUIRED_MSG = "required       ";
	private static final String INVALID_PHONE_NUMBER_MSG = "10 digit is required";
//	private static final String REQUIRED_MSG = "wifin";
	private static final String COMPARISION_MSG = "password not matching";
	private static final String EMAIL_MSG = "invalid email";
	private static final String PHONE_MSG = "Invalid";

	// call this method when you need to check email validation
	public static boolean isEmailAddress(EditText editText, TextInputLayout textInputLayout, boolean required) {
		return isValid(editText, textInputLayout, EMAIL_REGEX, EMAIL_MSG, required);
	}

	// call this method when you need to check phone number validation
	public static boolean isPhoneNumber(EditText editText, TextInputLayout textInputLayout, boolean required) {
		return isValid(editText, textInputLayout, PHONE_REGEX, PHONE_MSG, required);
	}
	
	public static boolean isName(EditText editText, TextInputLayout textInputLayout, boolean required) {
		return isValid(editText, textInputLayout, NAME_REGEX, PHONE_MSG, required);
	}

	// return true if the input field is valid, based on the parameter passed
	public static boolean isValid(EditText editText, TextInputLayout textInputLayout, String regex,
								  String errMsg, boolean required) {

		String text = editText.getText().toString().trim();
		// clearing the error, if it was previously set by some other values
		textInputLayout.setError(null);

		// text required and editText is blank, so return false
		if (required && !hasText(editText, textInputLayout))
			return false;

		// pattern doesn't match so returning false
		if (required && !Pattern.matches(regex, text)) {
			textInputLayout.setError(errMsg);
			return false;
		}
	
		return true;
	}

	// check the input field has any text or not
	// return true if it contains text otherwise false
	
	public static boolean isPin(EditText editText) {

		String text = editText.getText().toString().trim();
		editText.setError(null);

		// length 0 means there is no text
		if (text.length() != 6) {
			editText.setError("Please enter a valid pin code.");
			return false;
		}

		return true;
	}
	public static boolean hasText(EditText editText, TextInputLayout textInputLayout) {

		String text = editText.getText().toString().trim();
		textInputLayout.setError(null);

		// length 0 means there is no text
		if (text.length() == 0) {
			textInputLayout.setError(REQUIRED_MSG);
			return false;
		}

		return true;
	}

	public static boolean hasText(EditText editText) {

		String text = editText.getText().toString().trim();
		editText.setError(null);

		// length 0 means there is no text
		if (text.length() == 0) {
			editText.setError(REQUIRED_MSG);
			return false;
		}

		return true;
	}
	public static boolean hasfName(EditText editText, TextInputLayout textInputLayout) {

		String text = editText.getText().toString().trim();
		textInputLayout.setError(null);

		// length 0 means there is no text
		if ((text.length() == 0) || (text.length() >= 20)) {
			textInputLayout.setError(REQUIRED_MSG);
			return false;
		}
		if (!Character.isLetter(text.charAt(0))){
			textInputLayout.setError("Name must begin with alphabet");
			return false;
		}

		return true;
	}
	public static boolean hasName(EditText editText) {

		String text = editText.getText().toString().trim();
		editText.setError(null);

		// length 0 means there is no text
		if (text.length() == 0 || text.length() >= 20) {
			editText.setError(REQUIRED_MSG);
			return false;
		}

		return true;
	}
	
	public static boolean hasUserName(EditText editText) {

		String text = editText.getText().toString().trim();
		editText.setError(null);

		// length 0 means there is no text
		if ((text.length() == 0) || (text.length() >= 20)) {
			editText.setError(REQUIRED_MSG);
			return false;
		}
		if (!Character.isLetter(text.charAt(0))){
			editText.setError("Username must begin with alphabet");
			return false;
		}
		if(text.length()<6){
			editText.setError("User name must have atleast 6 letters");
			return false;
		}

		return true;
	}
	
	public static boolean hasValidPhoneNumber(EditText editText, TextInputLayout textInputLayout) {

		String text = editText.getText().toString().trim();
		textInputLayout.setError(null);

		// length 0 means there is no text
		if (text.length() != 10) {
			textInputLayout.setError(INVALID_PHONE_NUMBER_MSG);
			return false;
		}

		return true;
	}
	public static boolean hasCompared(EditText editText, TextInputLayout textInputLayout, EditText editText1, TextInputLayout textInputLayout1) {

		String text = editText.getText().toString().trim();
		String text1=editText1.getText().toString().trim();
		textInputLayout.setError(null);
		textInputLayout1.setError(null);
		// length 0 means there is no text
		if (text!=text1) {
			textInputLayout.setError(COMPARISION_MSG);
			return false;
		}

		return true;
	}
	
	// check the input field has any text or not
		// return true if it contains text otherwise false
		public static boolean hasText1(TextView editText) {

			String text = editText.getText().toString().trim();
			editText.setError(null);

			// length 0 means there is no text
			if (text.length() == 0) {
				editText.setError(REQUIRED_MSG);
				return false;
			}

			return true;
		}


}