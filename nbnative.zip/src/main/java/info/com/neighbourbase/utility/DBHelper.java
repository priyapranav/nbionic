package info.com.neighbourbase.utility;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.preference.PreferenceManager;

import java.util.ArrayList;
import java.util.HashMap;

import info.com.neighbourbase.activity.CommonHeader;
import info.com.neighbourbase.model.PushNotificationDto;

/**
 * Created by user on 01-08-2017.
 */

public class DBHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "PushMessage.db";
    public static final String MESSAGE_TABLE_NAME = "messages";
    public static final String MEMBER_ID = "memberid";
    public static final String MESSAGE = "message";
    public static final String DATE = "date";

    public static final String CONTACTS_COLUMN_ID = "id";
    public static final String CONTACTS_COLUMN_NAME = "name";
    public static final String CONTACTS_COLUMN_EMAIL = "email";
    public static final String CONTACTS_COLUMN_STREET = "street";
    public static final String CONTACTS_COLUMN_CITY = "place";
    public static final String CONTACTS_COLUMN_PHONE = "phone";
    private HashMap hp;
    String memberId;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME , null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        memberId = CommonHeader.memberId;
        // TODO Auto-generated method stub
        db.execSQL(
                "create table messages" +
                        "(id integer primary key, memberid integer, message text, date text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS message");
        onCreate(db);
    }

    public boolean insertMessage (int memberid, String message, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("memberid", memberid);
        contentValues.put("message", message);
        contentValues.put("date", date);

        db.insert("messages", null, contentValues);
        return true;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from messages where memberid="+id+"", null );
        return res;
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, MESSAGE_TABLE_NAME);
        return numRows;
    }

    public boolean updateContact (Integer id, String message, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("memberid", id);
        contentValues.put("message", message);
        contentValues.put("date", date);
        db.update("message", contentValues, "memberid = ? ", new String[] { Integer.toString(id) } );
        return true;
    }

    public Integer deleteContact (Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("messages",
                "id = ? ",
                new String[] { Integer.toString(id) });
    }

    public ArrayList<PushNotificationDto> getAllMessages(Integer id) {
        //ArrayList<String> array_list = new ArrayList<String>();
        ArrayList<PushNotificationDto> array_list = new ArrayList<PushNotificationDto>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor =  db.rawQuery( "select * from messages where memberid="+id+" ORDER BY date DESC limit 15", null );
        cursor.moveToFirst();

       /* while(res.isAfterLast() == false){
            array_list.add(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));
            res.moveToNext();
        }
        return array_list;*/

        if (cursor.moveToFirst()) {
            do {
                PushNotificationDto messageDto = new PushNotificationDto();
                messageDto.setMemberid(Integer.parseInt(cursor.getString(1)));
                messageDto.setMessage(cursor.getString(2));
                messageDto.setDate(cursor.getString(3));

                array_list.add(messageDto);
            } while (cursor.moveToNext());
        }

        return array_list;
    }

    public void deleteAllPushMessages() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("messages", null, null);
        db.close();
    }
}
