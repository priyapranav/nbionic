package info.com.neighbourbase.utility;

import android.app.Application;

import info.com.neighbourbase.R;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

/**
 * Created by user on 19-07-2017.
 */

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/Montserrat-Regular.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build()
        );
    }
}