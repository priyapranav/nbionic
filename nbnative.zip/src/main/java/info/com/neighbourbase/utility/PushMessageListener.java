package info.com.neighbourbase.utility;

/**
 * Created by user on 02-08-2017.
 */

public interface PushMessageListener {
    void pushMessageReceived(Integer messageCount);
}
