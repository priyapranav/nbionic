package info.com.neighbourbase.utility;


public class Webconfig {
	
//	public static String HOST = "192.168.0.109";
//	public static int PORT = 8080;
//	public static String PROTOCOL = "http";
//    public static String CONTEXT_PATH="http://infoserver:8080/neighbourbase/rest";
//	public static String CONTEXT_PATH1="http://infoserver:8080/neighbourbase/";
//

//	public static String HOST = "192.168.0.109";
//	public static int PORT = 8080;
//	public static String PROTOCOL = "http";
//	public static String CONTEXT_PATH = PROTOCOL+"://"+HOST+":"+PORT+"/neighbourbase/rest/"; //http://192.168.1.47:8080/qhubws/rest/";
//	public static String CONTEXT_PATH1= PROTOCOL+"://"+HOST+":"+PORT+"/neighbourbase/";//http://192.168.0.116:8080/neighbourbase/


	public static String HOST = "www.neighbourbase.com";
	public static int PORT = 443;
	public static String PROTOCOL = "https";
	public static String CONTEXT_PATH = PROTOCOL+"://"+HOST+"/rest/"; //http://www.neighbourbase.com/rest/";
//	public static String CONTEXT_PATH="http://203.124.105.3:8080/neighbourbase/rest/";
//	public static String CONTEXT_PATH1= "http://203.124.105.3:8080/neighbourbase/";//http://www.neighbourbase.com/

	public static String CONTEXT_PATH1= PROTOCOL+"://"+HOST+"/";//http://www.neighbourbase.com/


   // *********** for google places autocomplete  ****************//

	public static String PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place";
	public static String TYPE_AUTOCOMPLETE = "/autocomplete";
	public static String OUT_JSON = "/json";
//	public static String API_KEY="AIzaSyCM4iC7kjTd4cXR36bct6iqi3pmPTiSh1I";  // test key from priya acc
	public static String API_KEY="AIzaSyB0Jgfe4BJBYBt2olMXPTS5xTZtYzDdogg";
	public static String GOOGLE_PLACE=PLACES_API_BASE+TYPE_AUTOCOMPLETE+OUT_JSON+"?key=" + API_KEY;


	/*public static String HOST = "www.neighbourbase.com";
	public static int PORT = 80;
	public static String PROTOCOL = "http";
	public static String CONTEXT_PATH = PROTOCOL+"://"+HOST+":"+PORT+"/neighbourbase-staging/rest/"; //http://192.168.1.47:8080/qhubws/rest/";
	public static String CONTEXT_PATH1= PROTOCOL+"://"+HOST+":"+PORT+"/neighbourbase-staging/";//http://192.168.0.116:8080/neighbourbase/
*/
}

