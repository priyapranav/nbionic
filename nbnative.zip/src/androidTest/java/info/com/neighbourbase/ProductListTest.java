package info.com.neighbourbase;

import com.google.gson.Gson;
import org.junit.Test;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by SIVANATH on 06-Dec-17.
 */

public class ProductListTest {
    String result,memberId="142",latitude="13.0336191",longitude="80.2686031",pincode="600004",radius="3.0";
    HttpConfig httpConfig=new HttpConfig();
    String transTypeId="1";
    CommonResponseDto commonResponseDto=new CommonResponseDto();
    String pageNumber="0";


    @Test
    public void checkProductList(){
        result = httpConfig.httppost(Webconfig.CONTEXT_PATH +"getallproductlistng.json?transtypeid="+transTypeId+"&categoryid="+ Constant.categoryId+"&pageNumber="+pageNumber+"&radius="+radius+"&pincode=" + pincode + "&lat=" + latitude + "&lng=" + longitude + "&memberId=" + memberId);
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertNotNull(commonResponseDto.getStatus());
        assertEquals("some error occur check input details","success",commonResponseDto.getStatus());
        assertNotNull(commonResponseDto.getProductListingDto());
        assertTrue(!commonResponseDto.getProductListingDto().isEmpty());

        assertNotNull(commonResponseDto.getUnreadCount());
        assertEquals("check the unread count",2,commonResponseDto.getUnreadCount());

        assertNotNull(commonResponseDto.getProductListingDto().get(0).getProductName());
        assertNotNull(commonResponseDto.getProductListingDto().get(0).getProductDescription());
        assertNotNull(commonResponseDto.getProductListingDto().get(0).getPicture());


        transTypeId="3";
        result = httpConfig.httppost(Webconfig.CONTEXT_PATH +"getallproductlistng.json?transtypeid="+transTypeId+"&categoryid="+ Constant.categoryId+"&pageNumber="+pageNumber+"&radius="+radius+"&pincode=" + pincode + "&lat=" + latitude + "&lng=" + longitude + "&memberId=" + memberId);
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertNotNull(commonResponseDto.getStatus());
        assertEquals("some error occur check input details","success",commonResponseDto.getStatus());
        assertTrue(!commonResponseDto.getProductListingDto().isEmpty());
        assertNotNull(commonResponseDto.getProductListingDto().get(0).getSalePrice());

        transTypeId="2";
        result = httpConfig.httppost(Webconfig.CONTEXT_PATH +"getallproductlistng.json?transtypeid="+transTypeId+"&categoryid="+ Constant.categoryId+"&pageNumber="+pageNumber+"&radius="+radius+"&pincode=" + pincode + "&lat=" + latitude + "&lng=" + longitude + "&memberId=" + memberId);
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertNotNull(commonResponseDto.getStatus());
        assertEquals("some error occur check input details","success",commonResponseDto.getStatus());
        assertTrue(!commonResponseDto.getProductListingDto().isEmpty());
        assertNotNull(commonResponseDto.getProductListingDto().get(0).getPriceperday());

        transTypeId="4";
        result = httpConfig.httppost(Webconfig.CONTEXT_PATH +"getallproductlistng.json?transtypeid="+transTypeId+"&categoryid="+ Constant.categoryId+"&pageNumber="+pageNumber+"&radius="+radius+"&pincode=" + pincode + "&lat=" + latitude + "&lng=" + longitude + "&memberId=" + memberId);
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertNotNull(commonResponseDto.getStatus());
        assertEquals("some error occur check input details","success",commonResponseDto.getStatus());
        assertTrue(commonResponseDto.getProductListingDto().isEmpty());


    }
    @Test
    public void checkScrollProductList(){
        pageNumber="1";
        transTypeId="1";
        result = httpConfig.httppost(Webconfig.CONTEXT_PATH +"getallproductlistng.json?transtypeid="+transTypeId+"&categoryid="+Constant.categoryId+"&pageNumber="+pageNumber+"&radius="+radius+"&pincode=" + pincode + "&lat=" + latitude + "&lng=" + longitude + "&memberId=" + memberId);
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertNotNull(commonResponseDto.getStatus());
        assertEquals("some error occur check input details","success",commonResponseDto.getStatus());
        assertTrue(commonResponseDto.getProductListingDto().isEmpty());
    }

    @Test
    public void checkSearchList(){
        String searchProductName="LAPTOP for sell";
        searchProductName=searchProductName.replaceAll(" ","%20");
        memberId="143";
        result = httpConfig.httpget(Webconfig.CONTEXT_PATH + "getproductbynameandtranstype.json?prodNameTransName="+searchProductName+"&networkId=2&memberId="+memberId+"&radius="+radius+"&latitude="+latitude+"&longitude="+longitude);
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);

        assertNotNull(commonResponseDto.getStatus());
        assertEquals("some error occur check input details","success",commonResponseDto.getStatus());

        assertNotNull(commonResponseDto.getProductListingSearchDto());
        assertTrue(!commonResponseDto.getProductListingSearchDto().isEmpty());

        assertNotNull(commonResponseDto.getUnreadCount());
        assertEquals("check the unread count",3,commonResponseDto.getUnreadCount());

        assertNotNull(commonResponseDto.getProductListingSearchDto().get(0).getProductName());
        assertNotNull(commonResponseDto.getProductListingSearchDto().get(0).getProductDescription());
        assertNotNull(commonResponseDto.getProductListingSearchDto().get(0).getPicture());
    }
}
