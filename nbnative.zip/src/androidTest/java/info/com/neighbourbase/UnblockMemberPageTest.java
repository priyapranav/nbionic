package info.com.neighbourbase;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.junit.Test;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.model.BlockListDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;


/**
 * Created by SIVANATH on 01-Dec-17.
 */

public class UnblockMemberPageTest {
    String result,memberId="143",requestId="17";
    List<BlockListDto> blockList=new ArrayList<>();
    HttpConfig httpConfig=new HttpConfig();

    @Test
    public void checkBlockList(){
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getblocklistbymemberid.json?memberId="+memberId);
        Type listType = new TypeToken<List<BlockListDto>>(){}.getType();
        blockList=new Gson().fromJson(result,listType);
        assertFalse(blockList.isEmpty());
        assertEquals("wrong list length",1,blockList.size());
        assertNotNull(blockList.get(0).getRequesterName());
        assertNotNull(blockList.get(0).getDate());
        assertNotNull(blockList.get(0).getRequesterImage());

    }
    @Test
    public void unblockResponse(){
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"unblockrequest.json?requestid="+requestId+"&memberId="+memberId);
        assertEquals("no member is blocked","success",result.trim());
//        assertEquals("no member is blocked","fail",result.trim());

    }
}

