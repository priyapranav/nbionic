package info.com.neighbourbase;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.junit.Test;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import info.com.neighbourbase.model.BlockListDto;
import info.com.neighbourbase.model.IssuerNoteDto;
import info.com.neighbourbase.model.ReceiverNoteDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Created by SIVANATH on 04-Dec-17.
 */

public class ReminderPageTest {
    String memberId="143",result;
    HttpConfig httpConfig=new HttpConfig();
    ReceiverNoteDto receiverNoteDto=new ReceiverNoteDto();
    IssuerNoteDto issuerNoteDto=new IssuerNoteDto();
    List<ReceiverNoteDto> receiverReminderList=new ArrayList<>();
    List<IssuerNoteDto> issuerReminderList=new ArrayList<>();

    @Test
    public void checkReceiverReminderResponse(){
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getreceivernotedateremainder.json?memberId="+memberId);

        // coming o/p is list of dto ,so convert into list then get a details

        Type listType = new TypeToken<List<ReceiverNoteDto>>(){}.getType();  // get a type of list
        receiverReminderList=new Gson().fromJson(result,listType);
        assertNotNull(receiverReminderList.get(0).getReturnByStr());
        assertEquals("no reminder date","12/12/2017",receiverReminderList.get(0).getReturnByStr());

    }
    @Test
    public void checkIssuerReminderResponse(){
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getissuernotedateremainder.json?memberId="+memberId);
        Type listType = new TypeToken<List<IssuerNoteDto>>(){}.getType();
        issuerReminderList=new Gson().fromJson(result,listType);
        assertNotNull(issuerReminderList.get(0).getReturnByStr());
        assertEquals("no reminder date","06/12/2017",issuerReminderList.get(0).getReturnByStr());

    }
}
