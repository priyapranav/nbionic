package info.com.neighbourbase;

import com.google.gson.Gson;

import static info.com.neighbourbase.activity.ViewPage.round;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.math.BigDecimal;

import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.OwnerRatingDto;
import info.com.neighbourbase.model.ProductListingDto;
import info.com.neighbourbase.model.ProductRatingDto;
import info.com.neighbourbase.model.ReportAbuseDto;
import info.com.neighbourbase.model.RequestDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.TextValidation;
import info.com.neighbourbase.utility.Webconfig;

/**
 * Created by SIVANATH on 30-Nov-17.
 */

public class ViewPageTest {
    String result,reqData,reportAbuseData,memberId="143";
    HttpConfig httpConfig=new HttpConfig();
    OwnerRatingDto ownerRatingDto=new OwnerRatingDto();
    ProductRatingDto productRatingDto=new ProductRatingDto();
    String productId="85";
    long networkId=2;
    ProductListingDto productListingDto=new ProductListingDto();
    ReportAbuseDto reportAbuseDto = new ReportAbuseDto();
    CommonResponseDto commonResponseDto=new CommonResponseDto();
    RequestDto requestDto=new RequestDto();


    @Test
    public void checkValidation(){
        assertTrue(!TextValidation.hasText(""));
        assertTrue(TextValidation.hasText("android"));
    }
    @Test
    public void checkOwnerRatingResponse(){
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"productownerreviews.json?memberId="+memberId);
        ownerRatingDto=new Gson().fromJson(result,OwnerRatingDto.class);
        assertEquals("No rating or some error occur",4.0F,ownerRatingDto.getAvgRating(),0.001F);

    }
    @Test
    public void checkProductRatingResponse(){
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getproductreviews.json?productId="+productId);
        productRatingDto=new Gson().fromJson(result,ProductRatingDto.class);
        assertEquals("No rating or some error occur",2.3333333F,productRatingDto.getAvgRating(),0.001F);

    }
    @Test
    public void getViewDetails(){
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getproductlistingbyproductid.json?productid="+productId);
        productListingDto=new Gson().fromJson(result,ProductListingDto.class);
        assertNotNull(productListingDto.getProductName());
        assertEquals("some thing wrong","Printer",productListingDto.getProductName());
        assertNotNull(productListingDto.getProductDescription());
        assertNotNull(productListingDto.getPicture());
        assertNotNull(productListingDto.getDayfrom());
        assertNotNull(productListingDto.getDayto());


    }
    @Test
    public void reportAbuseResponse(){
        reportAbuseDto.setNetworkId(networkId);
        reportAbuseDto.setProductId(Long.parseLong(productId));
        reportAbuseDto.setReportingMemberId(Long.parseLong(memberId));
        reportAbuseDto.setRemarks("not nice");
        reportAbuseData=new Gson().toJson(reportAbuseDto);
        result=httpConfig.doPost(reportAbuseData,Webconfig.CONTEXT_PATH+"createreportabuse.json");
        assertEquals("may be wrong input","SUCCESS",result.trim());
        reportAbuseDto.setNetworkId(0L);
        reportAbuseData=new Gson().toJson(reportAbuseDto);
        result=httpConfig.doPost(reportAbuseData,Webconfig.CONTEXT_PATH+"createreportabuse.json");
        assertEquals("may be wrong input","FAIL",result.trim());

    }
    @Test
    public void checkRequestAlreadySendorNot(){
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getallrequestmade.json?productid="+productId+"&memberId="+memberId);
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertTrue(commonResponseDto.getBlockListDto().isEmpty());
        assertEquals("we can send request again",productId,String.valueOf(commonResponseDto.getRequestDtos().getProductId()).trim());

    }
    @Test
    public void checkRequestSendResponse(){
        requestDto.setProductId(Long.parseLong(productId));
        requestDto.setNetworkId(networkId);
        requestDto.setRequestStatusId(2);
        requestDto.setFirstReqstMsg("I would like to Borrow Your Printer");
        reqData=new Gson().toJson(requestDto);
        result=httpConfig.doPost(reqData, Webconfig.CONTEXT_PATH+"createrequest.json?memberId="+memberId);
        assertNotNull(result);

    }

}
