package info.com.neighbourbase;

import android.content.Context;
import android.support.test.InstrumentationRegistry;

import com.google.gson.Gson;

import org.junit.Test;


import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.MemberDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.TextValidation;
import info.com.neighbourbase.utility.Webconfig;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by SIVANATH on 29-Nov-17.
 */

public class SignUpActivityTest {
    MemberDto memberDto=new MemberDto();
    String responseData,result;
    HttpConfig httpConfig=new HttpConfig();
    int possibleRegisterCase=1;
    boolean markerStatus;
    CommonResponseDto commonResponseDto=new CommonResponseDto();

    @Test
    public void checkValidation(){
        assertTrue(TextValidation.hasText("android"));
        assertTrue(!TextValidation.hasText(""));
        assertTrue(TextValidation.isEmailAddress("pri@gmail.com",true));
        assertTrue(!TextValidation.isEmailAddress("pri@gmai",true));
        assertTrue(TextValidation.hasValidPhoneNumber("9874563215"));
        assertTrue(!TextValidation.hasValidPhoneNumber(""));
        assertTrue(!TextValidation.hasValidPhoneNumber("987458"));

    }
  //  @Test
    public void registerResponseTest(){
        memberDto.setFirstName("priya");
        memberDto.setEmail("san@gmail.com");
        memberDto.setPincode(600004);
        memberDto.setAddress("mylapore,chennai");
        memberDto.setArea("chennai");
        memberDto.setContactNumber(9874563215L);
        memberDto.setLatitude(13.0336191);
        memberDto.setLongitude(80.2686031);
        memberDto.setPassword("priya");
        responseData=new Gson().toJson(memberDto);

        switch (possibleRegisterCase){
            case 1:
                result=httpConfig.doPost(responseData, Webconfig.CONTEXT_PATH+"createmember.json");
                assertEquals("register failed","success",result.trim());
            case 2:
                memberDto.setEmail("priya@infocareerindia.com");
                responseData=new Gson().toJson(memberDto);
                result=httpConfig.doPost(responseData, Webconfig.CONTEXT_PATH+"createmember.json");
                assertEquals("register failed","exists",result.trim());

        }

    }
    @Test
    public void checkEmailExistence(){
        switch(possibleRegisterCase){
            case 1:
                String email="priya@infocareerindia.com";
                result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"emailavailablecheck.json?email="+email);
                commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
                assertEquals("give valid email","Email already exists",commonResponseDto.getStatus().trim());
            case 2:
                email="pri@infocareerindia.com";
                result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"emailavailablecheck.json?email="+email);
                commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
                assertEquals("give another valid email","success",commonResponseDto.getStatus().trim());

        }

    }
    @Test
    public void takeAddressByMarkerPosition(){

        result=httpConfig.httpget("http://maps.googleapis.com/maps/api/geocode/json?latlng=13.13588526,18.134552215&sensor=true_or_false");
        markerStatus=result.contains("\"status\" : \"OK\"");
        assertTrue(markerStatus);

    }
    @Test
    public void takeLatlonbyAddress(){
        result=httpConfig.httppost("http://maps.googleapis.com/maps/api/geocode/json?address=mylapore,chennai&sensor=true_or_false");
        markerStatus=result.contains("\"status\" : \"OK\"");
        assertTrue(markerStatus);

    }
    @Test
    public void checkGoogleAutoComplete(){
        result=httpConfig.httppost("https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyB0Jgfe4BJBYBt2olMXPTS5xTZtYzDdogg&input=mandaveli");
        markerStatus=result.contains("\"status\" : \"OK\"");
        assertTrue(markerStatus);
        result=httpConfig.httppost("https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyB0Jgfe4BJBYBt2olMXPTS5xTZtYzDdogg&input=");
        markerStatus=result.contains("\"status\" : \"INVALID_REQUEST\"");
        assertTrue(markerStatus);
    }
}
