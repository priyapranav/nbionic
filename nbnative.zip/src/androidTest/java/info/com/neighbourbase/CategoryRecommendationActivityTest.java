package info.com.neighbourbase;

import org.junit.Test;

import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by SIVANATH on 06-Dec-17.
 */

public class CategoryRecommendationActivityTest {
    String result;
    String productNameStrChange="iron box";
    HttpConfig httpConfig=new HttpConfig();

    @Test
    public void checkGetCategory(){
        if(productNameStrChange.contains(" "))
            productNameStrChange=productNameStrChange.replaceAll(" ","%20");
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"categoryrecommendation.json?catname="+productNameStrChange);
        assertNotNull(result);
        assertTrue(!result.isEmpty());

    }
}
