package info.com.neighbourbase;

import com.google.gson.Gson;

import org.junit.Test;

import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by SIVANATH on 01-Dec-17.
 */

public class SearchActivityTest {
    HttpConfig httpConfig=new HttpConfig();
    CommonResponseDto commonResponseDto=new CommonResponseDto();
    String result;

    @Test
    public void checkProductNameGetResponse(){
        result=httpConfig.httpget(Webconfig.CONTEXT_PATH+"productnamesearch.json?productName=ladder&networkId=2&memberId=143&radius=3.0&latitude=13.0279117&longitude=80.26051369999999");
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertTrue(commonResponseDto.getStatus().equals("success"));
    }
}
