package info.com.neighbourbase;

import com.google.gson.Gson;

import org.junit.Test;

import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.MemberDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.TextValidation;
import info.com.neighbourbase.utility.Webconfig;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by SIVANATH on 01-Dec-17.
 */

public class ResetPasswordTest {

    HttpConfig httpConfig=new HttpConfig();
    String result,memberId="143",reqData;
    MemberDto memberDto=new MemberDto();
    CommonResponseDto commonResponseDto=new CommonResponseDto();
    @Test
    public void checkValidation(){
        assertTrue(TextValidation.hasText("ANDROID"));
        assertFalse(TextValidation.hasText(""));
    }

    @Test
    public void resetPasswordTest(){
        // success case
        memberDto.setMemberId(Long.parseLong(memberId));
        memberDto.setPassword("a");
        reqData=new Gson().toJson(memberDto);
        result=httpConfig.doPost(reqData, Webconfig.CONTEXT_PATH+"updatemember.json");
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertTrue(commonResponseDto.getStatus().trim().equals("success"));
        // fail case
        memberDto.setMemberId(0);
        reqData=new Gson().toJson(memberDto);
        result=httpConfig.doPost(reqData, Webconfig.CONTEXT_PATH+"updatemember.json");
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertTrue(commonResponseDto.getStatus().trim().equals("fail"));


    }

}
