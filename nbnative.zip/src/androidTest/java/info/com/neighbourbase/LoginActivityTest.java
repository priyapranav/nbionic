package info.com.neighbourbase;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.google.gson.Gson;

import org.junit.Test;
import org.junit.runner.RunWith;

import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.TextValidation;
import info.com.neighbourbase.utility.Webconfig;

import static org.junit.Assert.*;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class LoginActivityTest {
    String result,userName,password;
    String possibleCase="wrong pass";
    HttpConfig httpConfig=new HttpConfig();

    CommonResponseDto commonResponseDto=new CommonResponseDto();
    @Test
    public void useAppContext() throws Exception {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();

        assertEquals("info.com.neighbourbase", appContext.getPackageName());
    }
    @Test
    public void checkValidation(){
        assertTrue(TextValidation.hasName("priya"));
        assertTrue(TextValidation.isEmailAddress("priya@gmail.com",true));
        assertTrue(!TextValidation.hasName(""));
    }
    @Test
    public void loginTestSuccess(){

        switch (possibleCase){
            case "wrong pass":
                userName="priya@infocareerindia.com"; password="aa";
                result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"loginValidate.json?email="+userName+"&password="+password);
                commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
                assertEquals("something wrong","PASSWORD", commonResponseDto.getStatus() );
            case "wrong user":
                userName="priy@infocareerindia.com"; password="a";
                result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"loginValidate.json?email="+userName+"&password="+password);
                commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
                assertEquals("something wrong", "USERNAME", commonResponseDto.getStatus());
            case "login":
                userName="priya@infocareerindia.com"; password="a";
                result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"loginValidate.json?email="+userName+"&password="+password);
                commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
                assertEquals("something wrong", "success",commonResponseDto.getStatus());

        }

    }
    @Test
    public void testForgetPassword(){
        userName="priya@infocareerindia.com";
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"forgotpassword.json?email="+userName);
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertEquals("wrong input", "success",commonResponseDto.getStatus());
    }
}
