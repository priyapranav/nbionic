package info.com.neighbourbase;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.junit.Test;

import java.lang.reflect.Type;
import java.util.List;

import info.com.neighbourbase.model.BlockListDto;
import info.com.neighbourbase.model.CategoryDto;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by SIVANATH on 07-Dec-17.
 */

public class CategoryActivityTest {
    HttpConfig httpConfig=new HttpConfig();
    String result,rootId="5";
    List<CategoryDto> categoryList;
    @Test
    public void checkChildCategory(){
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getchildcategories.json?parentid="+rootId);
        Type listType = new TypeToken<List<CategoryDto>>(){}.getType();
        categoryList=new Gson().fromJson(result,listType);
        assertFalse(categoryList.isEmpty());
        assertNotNull(categoryList.get(0).getCategoryId());
        assertEquals("categoryId not matched",95,categoryList.get(0).getCategoryId());
        assertNotNull(categoryList.get(0).getParentId());
        assertEquals("parentId not matched",5,categoryList.get(0).getParentId(),0L);
        assertNotNull(categoryList.get(0).getCategoryName());
        assertEquals("parentId not matched","Cars",categoryList.get(0).getCategoryName());


    }

    @Test
    public void checkAvailableCategory(){
        rootId="3";
        result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"getavailablecategories.json?parentid="+rootId);
        CommonResponseDto commonResponseDto=new CommonResponseDto();
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertNotNull(commonResponseDto.getStatus());
        assertTrue("status not success","success".equals(commonResponseDto.getStatus()));
        assertNotNull(commonResponseDto.getCategoryDtoMap());
        assertTrue(!commonResponseDto.getCategoryDtoMap().isEmpty());

    }
}
