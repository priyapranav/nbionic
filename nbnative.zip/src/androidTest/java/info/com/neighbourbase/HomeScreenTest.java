package info.com.neighbourbase;

import com.google.gson.Gson;
import org.apache.http.client.methods.HttpOptions;
import org.junit.Test;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.model.IssuerFeedbackDto;
import info.com.neighbourbase.model.ReceiverFeedbackDto;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by SIVANATH on 07-Dec-17.
 */

public class HomeScreenTest {
    String result,memberId="143",issuerFeedbackData,receiverData;
    HttpConfig httpConfig=new HttpConfig();
    CommonResponseDto commonResponseDto=new CommonResponseDto();
    @Test
    public void checkFeedbackReminder(){
        result = httpConfig.httppost(Webconfig.CONTEXT_PATH + "feedbackRemainder.json?&memberId=" + memberId);
        commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
        assertNotNull(commonResponseDto);
        assertNotNull(commonResponseDto.getStatus());
        assertNotNull(commonResponseDto.getFeedbackRemainderDto());
        assertTrue("check status","success".equals(commonResponseDto.getStatus()));

        if(!commonResponseDto.getFeedbackRemainderDto().isEmpty()&&commonResponseDto.getFeedbackRemainderDto().get(0).getMemberId()==0){  // this step check if any feeddback is pending
            // if any feedback is pending check with below code
            assertNotNull(commonResponseDto.getFeedbackRemainderDto().get(0).getProductName());
            assertNotNull(commonResponseDto.getFeedbackRemainderDto().get(0).getReceiverName());
            assertNotNull(commonResponseDto.getFeedbackRemainderDto().get(0).getTransTypeName());
            assertNotNull(commonResponseDto.getFeedbackRemainderDto().get(0).getReceiverPicture());
            assertNotNull(commonResponseDto.getFeedbackRemainderDto().get(0).getPicture());

            IssuerFeedbackDto issuerFeedbackDto = new IssuerFeedbackDto();
            issuerFeedbackDto.setReceiverRating(4);
            issuerFeedbackDto.setRemarks(null);
            issuerFeedbackDto.setRequestId(commonResponseDto.getFeedbackRemainderDto().get(0).getRequestId());

            issuerFeedbackData = new Gson().toJson(issuerFeedbackDto);

            // send issuer feedback response
            result = httpConfig.doPost(issuerFeedbackData, Webconfig.CONTEXT_PATH + "createissuerfeedback.json?&memberId=" + memberId);
            assertNotNull(result);

        }else if(!commonResponseDto.getFeedbackRemainderDto().isEmpty()&&commonResponseDto.getFeedbackRemainderDto().get(0).getMemberId()!=0){  // message send feedback pending
            assertNotNull(commonResponseDto.getFeedbackRemainderDto().get(0).getOwnerName());
            assertNotNull(commonResponseDto.getFeedbackRemainderDto().get(0).getProductName());
            assertNotNull(commonResponseDto.getFeedbackRemainderDto().get(0).getTransTypeName());
            assertNotNull(commonResponseDto.getFeedbackRemainderDto().get(0).getOwnerPicture());
            assertNotNull(commonResponseDto.getFeedbackRemainderDto().get(0).getPicture());

            ReceiverFeedbackDto receiverFeedbackDto = new ReceiverFeedbackDto();
            receiverFeedbackDto.setIssuerRating((int) Math.round(3.5));
            receiverFeedbackDto.setProductRating((int) Math.round(4.4));
            receiverFeedbackDto.setIssuerRemarks("good");
            receiverFeedbackDto.setProductRemarks(null);
            receiverFeedbackDto.setRequestId(commonResponseDto.getFeedbackRemainderDto().get(0).getRequestId());

            receiverData = new Gson().toJson(receiverFeedbackDto);

            // SendReceiverFeedback response
            result = httpConfig.doPost(receiverData, Webconfig.CONTEXT_PATH + "createreceiverfeedback.json");
            assertNotNull(result);

        }

    }
}
