package info.com.neighbourbase;

import android.os.AsyncTask;

import com.google.gson.Gson;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;

import java.util.Timer;
import java.util.TimerTask;

import info.com.neighbourbase.activity.LoginActivity;
import info.com.neighbourbase.activity.SignUpActivity;
import info.com.neighbourbase.model.CommonResponseDto;
import info.com.neighbourbase.utility.Constant;
import info.com.neighbourbase.utility.HttpConfig;
import info.com.neighbourbase.utility.Webconfig;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    String result,userName,password;
    String possibleCase="wrong pass";
    CommonResponseDto commonResponseDto=new CommonResponseDto();

    @Test
    public void loginTestSuccess(){
        HttpConfig httpConfig=new HttpConfig();

        switch (possibleCase){
            case "wrong pass":
                userName="priya@infocareerindia.com"; password="senthi";
                result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"loginValidate.json?email="+userName+"&password="+password);
                commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
                assertEquals("something wrong","PASSWORD", commonResponseDto.getStatus() );
            case "wrong user":
                userName="priy@infocareerindia.com"; password="a";
                result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"loginValidate.json?email="+userName+"&password="+password);
                commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
                assertEquals("something wrong", "USERNAME", commonResponseDto.getStatus());
            case "login":
                userName="priya@infocareerindia.com"; password="a";
                result=httpConfig.httppost(Webconfig.CONTEXT_PATH+"loginValidate.json?email="+userName+"&password="+password);
                commonResponseDto=new Gson().fromJson(result,CommonResponseDto.class);
                assertEquals("something wrong", "success",commonResponseDto.getStatus());

        }

    }}